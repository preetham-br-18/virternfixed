import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';

// Protect against noisy Firestore offline connection warnings in sandboxed preview environments
if (typeof window !== 'undefined') {
  const suppress = [
    'Could not reach Cloud Firestore backend',
    '@firebase/firestore',
    "reading 'indexOf'"
  ];
  (['error', 'warn'] as const).forEach((m) => {
    const orig = console[m];
    console[m] = (...args: unknown[]) => {
      const str = args.map((a) => (typeof a === 'string' ? a : (a as Error)?.message || '')).join(' ');
      if (suppress.some((p) => str.includes(p))) return;
      orig.apply(console, args);
    };
  });
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
