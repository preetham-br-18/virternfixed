import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { LandingPage } from './components/LandingPage';
import { DomainSelection } from './components/DomainSelection';
import { Dashboard } from './components/Dashboard';
import { CompletionView } from './components/CompletionView';
import { CertificateVerification } from './components/CertificateVerification';
import { ResumeBuilder } from './components/ResumeBuilder';
import { InterviewPrep } from './components/InterviewPrep';
import { PremiumSection } from './components/PremiumSection';
import { ReferralDashboard } from './components/ReferralDashboard';
import { DomainLeaderboardView } from './components/DomainLeaderboardView';
import { LeaderboardView } from './components/LeaderboardView';
import { MyPerformanceView } from './components/MyPerformanceView';
import { AdminPortal } from './components/admin/AdminPortal';
import { CompanyPortal } from './components/company/CompanyPortal';
import { AuthModal } from './components/AuthModal';
import { AgreementModal } from './components/AgreementModal';
import { EmailSimulatorModal } from './components/EmailSimulatorModal';
import { LegalModal, LegalTab } from './components/LegalModal';
import { DomainItem } from './types';
import { dataService } from './services/dataService';
import { isAuthorizedAdmin } from './firebase/config';
import confetti from 'canvas-confetti';

function AppContent() {
  const { user, activeInternship, refreshProfile, loading, enrollInDomain } = useAuth();
  
  // Persistent view selection: Strictly respect verified user role
  const [currentView, setCurrentViewRaw] = useState<string>(() => {
    try {
      const cachedUser = localStorage.getItem('virintern_cached_user');
      if (cachedUser) {
        const parsed = JSON.parse(cachedUser);
        const isAdmin = isAuthorizedAdmin(parsed.uid, parsed.email);
        if (isAdmin) {
          return 'admin';
        }
        if (parsed.role === 'company') {
          return 'company';
        }
        // ALL OTHER LOGINS COME UNDER USER LOGIN (STUDENT)
        const hasEnrolled = localStorage.getItem('virintern_has_enrolled') === 'true';
        const cachedInt = localStorage.getItem('virintern_cached_internship');
        if (hasEnrolled || cachedInt || parsed.selectedDomain) {
          return 'dashboard';
        }
        return 'domains';
      }
      return 'landing';
    } catch {
      return 'landing';
    }
  });

  const setCurrentView = (view: string, replace = false) => {
    try {
      localStorage.setItem('virintern_current_view', view);
      if (view === 'dashboard') {
        localStorage.setItem('virintern_has_enrolled', 'true');
      }
    } catch {
      // ignore
    }

    try {
      if (replace) {
        window.history.replaceState({ view, virinternApp: true }, '', window.location.href);
      } else {
        window.history.pushState({ view, virinternApp: true }, '', window.location.href);
      }
    } catch {
      // ignore
    }

    setCurrentViewRaw(view);
  };

  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [authModalMode, setAuthModalMode] = useState<'login' | 'signup'>('login');
  const [authModalPortal, setAuthModalPortal] = useState<'student' | 'company'>('student');
  const [agreementModalOpen, setAgreementModalOpen] = useState(false);
  const [emailSimulatorOpen, setEmailSimulatorOpen] = useState(false);
  const [pendingDomain, setPendingDomain] = useState<DomainItem | null>(null);
  const [domainSearchFilter, setDomainSearchFilter] = useState<string>('');
  const [legalModalOpen, setLegalModalOpen] = useState(false);
  const [legalInitialTab, setLegalInitialTab] = useState<LegalTab>('privacy');

  const handleOpenLegal = (tab: LegalTab = 'privacy') => {
    setLegalInitialTab(tab);
    setLegalModalOpen(true);
  };

  const handleFooterDomainClick = (domainKeyword: string) => {
    setDomainSearchFilter(domainKeyword);
    setCurrentView('domains');
    window.scrollTo({ top: 0, left: 0, behavior: 'instant' });
  };

  // Mobile Edge-Swipe Back Prevention & History Stack Buffer
  const hasInitializedMount = React.useRef(false);

  useEffect(() => {
    // Push an initial safety state so history.length is always at least 2
    try {
      if (!window.history.state || !window.history.state.virinternApp) {
        window.history.replaceState({ view: currentView, virinternApp: true, step: 0 }, '', window.location.href);
        window.history.pushState({ view: currentView, virinternApp: true, step: 1 }, '', window.location.href);
      }
    } catch {}

    const handlePopState = () => {
      // 1. If any top-level modal is open, close the modal first instead of navigating back or closing app
      if (authModalOpen) {
        setAuthModalOpen(false);
        try { window.history.pushState({ view: currentView, virinternApp: true }, '', window.location.href); } catch {}
        return;
      }
      if (agreementModalOpen) {
        setAgreementModalOpen(false);
        try { window.history.pushState({ view: currentView, virinternApp: true }, '', window.location.href); } catch {}
        return;
      }
      if (emailSimulatorOpen) {
        setEmailSimulatorOpen(false);
        try { window.history.pushState({ view: currentView, virinternApp: true }, '', window.location.href); } catch {}
        return;
      }

      // Re-push a buffer state so consecutive back-swipes NEVER close the browser window or website
      try {
        window.history.pushState({ view: currentView, virinternApp: true }, '', window.location.href);
      } catch {}

      const isEnrolled = Boolean(activeInternship || (user && user.selectedDomain) || localStorage.getItem('virintern_has_enrolled') === 'true');
      const rootTarget = (user && isEnrolled) ? 'dashboard' : 'landing';

      // If user is on a sub-view (domains, leaderboard, performance, etc.), navigate smoothly back to rootTarget
      if (currentView !== rootTarget) {
        setCurrentViewRaw(rootTarget);
        try { localStorage.setItem('virintern_current_view', rootTarget); } catch {}
      }
    };

    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, [currentView, activeInternship, user, authModalOpen, agreementModalOpen, emailSimulatorOpen]);

  // Check URL params for verify link: e.g. /verify/VI-2026-WD-12345 or /login or /signup
  useEffect(() => {
    const path = window.location.pathname;
    if (path.includes('/verify')) {
      setCurrentView('verify_cert');
    } else if (path.includes('/login')) {
      openAuth('login');
    } else if (path.includes('/signup')) {
      openAuth('signup');
    }
  }, []);

  // Global Scroll To Top: Whenever view changes, guarantee page scrolls immediately to top
  useEffect(() => {
    window.scrollTo({ top: 0, left: 0, behavior: 'instant' });
  }, [currentView]);

  // Strict Role-Based View Guard & Access Control
  useEffect(() => {
    if (loading) return;

    const studentOnlyViews = ['dashboard', 'completion', 'referrals', 'performance', 'premium'];

    // 1. Unauthenticated users cannot access restricted dashboards
    if (!user) {
      if (currentView === 'admin' || currentView === 'company' || studentOnlyViews.includes(currentView)) {
        setCurrentView('landing');
      }
      return;
    }

    // 2. Admin Portal Access Rules: Admin cannot access company or student workspaces
    if (user.role === 'admin') {
      if (currentView === 'company' || currentView === 'dashboard' || currentView === 'completion' || currentView === 'referrals' || currentView === 'premium') {
        setCurrentView('admin');
      }
      return;
    }

    // 3. Company Portal Access Rules: Company accounts must NEVER access student tasks or admin portal
    if (user.role === 'company') {
      if (currentView === 'admin' || currentView === 'dashboard' || currentView === 'completion' || currentView === 'referrals' || currentView === 'performance') {
        setCurrentView('company');
      }
      return;
    }

    // 4. Student Portal Access Rules: Students must NEVER access admin or company portals
    if (user.role === 'student') {
      if (currentView === 'admin' || currentView === 'company') {
        const hasEnrolled = Boolean(activeInternship || user.selectedDomain || localStorage.getItem('virintern_has_enrolled') === 'true');
        setCurrentView(hasEnrolled ? 'dashboard' : 'domains');
      }
    }
  }, [user, currentView, loading, activeInternship]);

  // Immediate role-authoritative redirection upon fresh login or signup
  const prevUserUidRef = React.useRef<string | null>(null);
  useEffect(() => {
    if (user && !loading) {
      const isNewLogin = prevUserUidRef.current !== user.uid;
      prevUserUidRef.current = user.uid;

      if (isNewLogin) {
        if (user.role === 'admin') {
          setCurrentView('admin');
        } else if (user.role === 'company') {
          setCurrentView('company');
        } else {
          // student
          const hasEnrolled = Boolean(activeInternship || user.selectedDomain || localStorage.getItem('virintern_has_enrolled') === 'true');
          if (hasEnrolled) {
            setCurrentView('dashboard');
          } else if (!pendingDomain) {
            setCurrentView('domains');
          }
        }
      }
    } else if (!user) {
      prevUserUidRef.current = null;
    }
  }, [user, loading, activeInternship, pendingDomain]);

  // If a student signed in after selecting a domain, process agreement/enrollment smoothly
  useEffect(() => {
    if (user && pendingDomain) {
      if (user.role === 'admin') {
        setPendingDomain(null);
        setCurrentView('admin');
        return;
      }
      if (user.role === 'company') {
        setPendingDomain(null);
        setCurrentView('company');
        return;
      }
      if (!user.agreementAccepted) {
        setAgreementModalOpen(true);
      } else {
        const dom = pendingDomain;
        setPendingDomain(null);
        enrollInDomain(dom)
          .catch(() => dataService.startInternship(user, dom))
          .then(() => {
            setCurrentView('dashboard');
            window.scrollTo({ top: 0, left: 0, behavior: 'instant' });
            try {
              confetti({ particleCount: 70, spread: 70, origin: { y: 0.6 } });
            } catch {}
          });
      }
    }
  }, [user, pendingDomain]);

  const openAuth = (mode: 'login' | 'signup', portal: 'student' | 'company' = 'student') => {
    setAuthModalMode(mode);
    setAuthModalPortal(portal);
    setAuthModalOpen(true);
  };

  const handleSelectDomain = async (domain: DomainItem) => {
    if (!user) {
      setPendingDomain(domain);
      openAuth('signup');
      return;
    }

    if (user.role === 'admin') {
      setCurrentView('admin');
      return;
    }

    if (!user.agreementAccepted) {
      setPendingDomain(domain);
      setAgreementModalOpen(true);
      return;
    }

    // Immediately enroll and transition directly to dashboard tasks with zero delay
    try {
      await enrollInDomain(domain);
    } catch {
      await dataService.startInternship(user, domain);
      await refreshProfile();
    }
    setCurrentView('dashboard');
    window.scrollTo({ top: 0, left: 0, behavior: 'instant' });
    try {
      confetti({ particleCount: 70, spread: 70, origin: { y: 0.6 } });
    } catch {}
  };

  const handleAgreementAccepted = async () => {
    setAgreementModalOpen(false);
    if (pendingDomain && user) {
      const dom = pendingDomain;
      setPendingDomain(null);
      try {
        await enrollInDomain(dom);
      } catch {
        await dataService.startInternship(user, dom);
        await refreshProfile();
      }
      setCurrentView('dashboard');
      window.scrollTo({ top: 0, left: 0, behavior: 'instant' });
      try {
        confetti({ particleCount: 70, spread: 70, origin: { y: 0.6 } });
      } catch {}
    } else {
      window.scrollTo({ top: 0, left: 0, behavior: 'instant' });
      setCurrentView('domains');
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#F4F2EE] text-[#191919] font-sans">
      {/* Top Navbar */}
      <Navbar
        currentView={currentView}
        setCurrentView={setCurrentView}
        openAuthModal={openAuth}
        openEmailSimulator={() => setEmailSimulatorOpen(true)}
        onOpenLegal={handleOpenLegal}
      />

      {/* Main Content Body */}
      <main className="flex-1">
        {currentView === 'landing' && (
          <LandingPage
            setCurrentView={setCurrentView}
            openAuthModal={openAuth}
            onSelectDomain={handleSelectDomain}
            onOpenLegal={handleOpenLegal}
          />
        )}

        {currentView === 'domains' && (
          <DomainSelection
            onSelectDomain={handleSelectDomain}
            openAgreementModal={(dom) => {
              setPendingDomain(dom);
              setAgreementModalOpen(true);
            }}
            setCurrentView={setCurrentView}
            initialSearch={domainSearchFilter}
          />
        )}

        {currentView === 'dashboard' && (
          <Dashboard
            setCurrentView={setCurrentView}
            openEmailSimulator={() => setEmailSimulatorOpen(true)}
          />
        )}

        {currentView === 'completion' && (
          <CompletionView
            setCurrentView={setCurrentView}
            openEmailSimulator={() => setEmailSimulatorOpen(true)}
          />
        )}

        {currentView === 'verify_cert' && (
          <CertificateVerification
            setCurrentView={setCurrentView}
          />
        )}

        {currentView === 'premium' && (
          <PremiumSection
            setCurrentView={setCurrentView}
            openEmailSimulator={() => setEmailSimulatorOpen(true)}
          />
        )}

        {currentView === 'resume_builder' && (
          <ResumeBuilder setCurrentView={setCurrentView} />
        )}

        {currentView === 'interview_prep' && (
          <InterviewPrep setCurrentView={setCurrentView} />
        )}

        {currentView === 'referrals' && (
          <ReferralDashboard />
        )}

        {currentView === 'performance' && (
          <MyPerformanceView
            onBackToDashboard={() => setCurrentView('dashboard')}
            onNavigateToLeaderboard={() => setCurrentView('leaderboard')}
            onNavigateToTasks={() => setCurrentView('dashboard')}
          />
        )}

        {currentView === 'leaderboard' && (
          <LeaderboardView
            onBackToDashboard={() => setCurrentView('dashboard')}
            defaultDomainId={activeInternship?.domainId || 'all'}
          />
        )}

        {currentView === 'company' && (
          <CompanyPortal
            setCurrentView={setCurrentView}
          />
        )}

        {currentView === 'admin' && (
          <AdminPortal
            setCurrentView={setCurrentView}
          />
        )}
      </main>

      {/* Global Footer */}
      <Footer
        setCurrentView={setCurrentView}
        onSelectDomainByName={handleFooterDomainClick}
        onOpenLegal={handleOpenLegal}
      />

      {/* Authentication Modal */}
      <AuthModal
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
        initialMode={authModalMode}
        initialPortal={authModalPortal}
      />

      {/* E-Agreement Modal */}
      <AgreementModal
        isOpen={agreementModalOpen}
        onAccepted={handleAgreementAccepted}
        onCancel={() => {
          setAgreementModalOpen(false);
          setPendingDomain(null);
        }}
        onOpenLegal={handleOpenLegal}
      />

      {/* Transactional Email Simulator Modal (PRD Section 45) */}
      <EmailSimulatorModal
        isOpen={emailSimulatorOpen}
        onClose={() => setEmailSimulatorOpen(false)}
      />

      {/* Official Legal & Compliance Modal (Privacy Policy, Disclaimer, Terms, Refund) */}
      <LegalModal
        isOpen={legalModalOpen}
        onClose={() => setLegalModalOpen(false)}
        initialTab={legalInitialTab}
      />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
