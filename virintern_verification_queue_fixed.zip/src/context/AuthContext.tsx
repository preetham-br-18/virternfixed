import React, { createContext, useContext, useState, useEffect } from 'react';
import { UserProfile, UserRole, InternshipRecord, AppNotification, DomainItem, CompanyProfile } from '../types';
import { auth, googleProvider } from '../firebase/firebase';
import {
  signInWithPopup,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut as firebaseSignOut,
  onAuthStateChanged,
  updateProfile
} from 'firebase/auth';
import { doc, getDoc, setDoc, onSnapshot } from 'firebase/firestore';
import { db } from '../firebase/firebase';
import { dataService } from '../services/dataService';
import { DEFAULT_ADMIN_EMAIL, ADMIN_UID, ADMIN_EMAILS, isAuthorizedAdmin } from '../firebase/config';

interface AuthContextType {
  user: UserProfile | null;
  loading: boolean;
  activeInternship: InternshipRecord | null;
  notifications: AppNotification[];
  unreadCount: number;
  companyProfile: CompanyProfile | null;
  loginWithGoogle: () => Promise<void>;
  loginWithEmail: (email: string, pass: string) => Promise<void>;
  signUpWithEmail: (name: string, email: string, pass: string, refCode?: string) => Promise<void>;
  registerCompany: (companyData: {
    name: string;
    officialEmail: string;
    password: string;
    contactPerson: string;
    designation: string;
    website: string;
    industry: string;
    description: string;
    hiringRequirements: string[];
    preferredSkills: string[];
    logoUrl?: string;
  }) => Promise<CompanyProfile>;
  logout: () => Promise<void>;
  acceptAgreement: () => Promise<void>;
  enrollInDomain: (domain: DomainItem) => Promise<InternshipRecord>;
  refreshProfile: () => Promise<void>;
  markNotificationsRead: () => Promise<void>;
  updateProfilePhoto: (photoURL: string) => Promise<void>;
  loginAsAdmin: (emailOverride?: string) => Promise<void>;
}

const getFriendlyAuthError = (err: any): string => {
  const code = err?.code || '';
  if (code === 'auth/user-not-found' || code === 'auth/wrong-password' || code === 'auth/invalid-credential') {
    return 'Invalid email or password. Please verify your credentials or create an account.';
  }
  if (code === 'auth/email-already-in-use') {
    return 'An account with this email already exists. Please sign in instead.';
  }
  if (code === 'auth/weak-password') {
    return 'Password must be at least 6 characters.';
  }
  if (code === 'auth/invalid-email') {
    return 'Please enter a valid email address.';
  }
  if (code === 'auth/popup-closed-by-user') {
    return 'Google sign-in popup was closed before completing.';
  }
  if (code === 'auth/popup-blocked') {
    return 'Pop-up window was blocked by your browser. Please allow popups or use email & password.';
  }
  return err?.message || 'Authentication failed. Please check your credentials.';
};

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Module-level cache for student name entered during registration to prevent race condition overrides
let runtimeSignupName: string | null = null;

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const isUserAdmin = (uid: string, email?: string | null): boolean => {
    return isAuthorizedAdmin(uid, email);
  };

  const [user, setUserState] = useState<UserProfile | null>(() => {
    try {
      const cached = localStorage.getItem('virintern_cached_user');
      const parsed = cached ? JSON.parse(cached) : null;
      if (parsed) {
        if (isUserAdmin(parsed.uid, parsed.email)) {
          parsed.role = 'admin';
        } else if (parsed.role === 'company') {
          parsed.role = 'company';
        } else {
          parsed.role = 'student';
        }
        const cleanEmail = (parsed.email || '').toLowerCase();
        const remembered = typeof window !== 'undefined'
          ? (localStorage.getItem(`virintern_user_name_${cleanEmail}`) ||
             (parsed.uid ? localStorage.getItem(`virintern_user_name_${parsed.uid}`) : null) ||
             localStorage.getItem('virintern_last_signup_name') ||
             runtimeSignupName)
          : runtimeSignupName;

        if (!parsed.name || !parsed.name.trim() || parsed.name.toLowerCase() === 'intern' || parsed.name.toLowerCase() === 'student') {
          parsed.name = (remembered && remembered.trim() && remembered.trim().toLowerCase() !== 'student' && remembered.trim().toLowerCase() !== 'intern')
            ? remembered.trim()
            : (cleanEmail ? cleanEmail.split('@')[0] : 'Student');
        } else if (remembered && remembered.trim() && remembered.trim().toLowerCase() !== 'student' && remembered.trim().toLowerCase() !== 'intern') {
          parsed.name = remembered.trim();
        }
      }
      return parsed;
    } catch {
      return null;
    }
  });

  const [activeInternship, setActiveInternshipState] = useState<InternshipRecord | null>(() => {
    try {
      const cachedUser = localStorage.getItem('virintern_cached_user');
      const parsedUser = cachedUser ? JSON.parse(cachedUser) : null;
      if (!parsedUser || !parsedUser.uid) return null;
      const cached = localStorage.getItem('virintern_cached_internship');
      if (!cached) return null;
      const parsedInt = JSON.parse(cached);
      if (parsedInt && parsedInt.userId === parsedUser.uid) {
        return parsedInt;
      }
      return null;
    } catch {
      return null;
    }
  });

  const [companyProfile, setCompanyProfile] = useState<CompanyProfile | null>(() => {
    try {
      const cached = localStorage.getItem('virintern_cached_company');
      return cached ? JSON.parse(cached) : null;
    } catch {
      return null;
    }
  });

  const setUser = (newUser: UserProfile | null) => {
    if (newUser) {
      if (!newUser.role) {
        newUser.role = 'student';
      }
      const cleanEmail = (newUser.email || '').toLowerCase();
      const remembered = typeof window !== 'undefined'
        ? (localStorage.getItem(`virintern_user_name_${cleanEmail}`) ||
           (newUser.uid ? localStorage.getItem(`virintern_user_name_${newUser.uid}`) : null) ||
           localStorage.getItem('virintern_last_signup_name') ||
           runtimeSignupName)
        : runtimeSignupName;

      const validRemembered = (remembered && remembered.trim() && remembered.trim().toLowerCase() !== 'student' && remembered.trim().toLowerCase() !== 'intern')
        ? remembered.trim()
        : null;

      if (validRemembered) {
        if (!newUser.name || newUser.name.trim().toLowerCase() === 'student' || newUser.name.trim().toLowerCase() === 'intern' || newUser.name === cleanEmail.split('@')[0]) {
          newUser.name = validRemembered;
        }
      } else if (!newUser.name || !newUser.name.trim() || newUser.name.trim().toLowerCase() === 'intern') {
        newUser.name = cleanEmail ? cleanEmail.split('@')[0] : 'Student';
      }

      if (isUserAdmin(newUser.uid, newUser.email)) {
        newUser.role = 'admin';
      } else if (newUser.role === 'admin') {
        newUser.role = 'student';
      }

      if (typeof window !== 'undefined' && newUser.name && newUser.name.toLowerCase() !== 'student' && newUser.name.toLowerCase() !== 'intern') {
        if (cleanEmail) localStorage.setItem(`virintern_user_name_${cleanEmail}`, newUser.name);
        if (newUser.uid) localStorage.setItem(`virintern_user_name_${newUser.uid}`, newUser.name);
        localStorage.setItem('virintern_last_signup_name', newUser.name);
        runtimeSignupName = newUser.name;
      }
    }
    setUserState(newUser);
    try {
      if (newUser) {
        localStorage.setItem('virintern_cached_user', JSON.stringify(newUser));
        localStorage.setItem('virintern_cached_role', newUser.role);
      } else {
        localStorage.removeItem('virintern_cached_user');
        localStorage.removeItem('virintern_cached_role');
        localStorage.removeItem('virintern_cached_company');
        setCompanyProfile(null);
      }
    } catch {}
  };

  const setActiveInternship = (newInt: InternshipRecord | null) => {
    setActiveInternshipState(newInt);
    try {
      if (newInt) {
        localStorage.setItem('virintern_cached_internship', JSON.stringify(newInt));
        localStorage.setItem('virintern_has_enrolled', 'true');
        if (newInt.domainId) {
          localStorage.setItem('virintern_enrolled_domain', newInt.domainId);
        }
        if (newInt.domainName) {
          localStorage.setItem('virintern_enrolled_domain_name', newInt.domainName);
        }
      } else {
        localStorage.removeItem('virintern_cached_internship');
        localStorage.removeItem('virintern_has_enrolled');
        localStorage.removeItem('virintern_enrolled_domain');
        localStorage.removeItem('virintern_enrolled_domain_name');
      }
    } catch {}
  };

  const [loading, setLoading] = useState<boolean>(true);
  const [notifications, setNotifications] = useState<AppNotification[]>(() => {
    try {
      const cachedUser = localStorage.getItem('virintern_cached_user');
      const userId = cachedUser ? JSON.parse(cachedUser)?.uid : null;
      const raw = localStorage.getItem('virintern_notifications');
      const all: AppNotification[] = raw ? JSON.parse(raw) : [];
      if (userId) {
        const userNotifs = all.filter(n => n.userId === userId);
        if (userNotifs.length > 0) return userNotifs;
      }
      return all.length > 0 ? all : [];
    } catch {
      return [];
    }
  });

  // Generate unique referral code from name/email
  const generateReferralCode = (name: string): string => {
    const clean = name.replace(/[^a-zA-Z]/g, '').toUpperCase().slice(0, 5) || 'VIR';
    const rand = Math.floor(100 + Math.random() * 900);
    return `${clean}${rand}`;
  };

  const loadOrCreateUserProfile = async (uid: string, email: string, name: string, photoURL?: string): Promise<UserProfile> => {
    const isAdmin = isUserAdmin(uid, email);
    const cleanEmail = (email || '').trim().toLowerCase();

    // Check if we have the real name entered during registration saved anywhere
    let rememberedName: string | null = null;
    if (name && name.trim() && name.trim().toLowerCase() !== 'intern' && name.trim().toLowerCase() !== 'student') {
      rememberedName = name.trim();
    }
    if (!rememberedName && typeof window !== 'undefined') {
      rememberedName = localStorage.getItem(`virintern_user_name_${cleanEmail}`) ||
        (uid ? localStorage.getItem(`virintern_user_name_${uid}`) : null) ||
        localStorage.getItem('virintern_last_signup_name') ||
        runtimeSignupName;

      if (!rememberedName) {
        try {
          const cred = localStorage.getItem(`virintern_cred_${cleanEmail}`);
          if (cred) {
            const parsed = JSON.parse(cred);
            if (parsed.name && parsed.name.toLowerCase() !== 'intern' && parsed.name.toLowerCase() !== 'student') {
              rememberedName = parsed.name;
            }
          }
        } catch {}
      }
    }

    let profile = await dataService.getUserProfile(uid);

    // If profile not found by UID, check if user exists in allUsers by email
    if (!profile && cleanEmail) {
      try {
        const allUsers = await dataService.getAllUsers();
        const matchByEmail = allUsers.find(u => u.email && u.email.toLowerCase() === cleanEmail);
        if (matchByEmail) {
          profile = { ...matchByEmail, uid };
          if (!rememberedName && matchByEmail.name && matchByEmail.name.toLowerCase() !== 'intern' && matchByEmail.name.toLowerCase() !== 'student') {
            rememberedName = matchByEmail.name;
          }
        }
      } catch {}
    }

    // Direct server lookup if profile still missing or has generic name
    if ((!profile || !profile.name || profile.name === 'Student' || profile.name.toLowerCase() === 'intern') && cleanEmail) {
      try {
        const srvRes = await fetch(`/api/users/${uid}?email=${encodeURIComponent(cleanEmail)}`);
        if (srvRes.ok) {
          const srvData = await srvRes.json();
          if (srvData.user) {
            if (!profile) profile = srvData.user;
            if (srvData.user.name && srvData.user.name.toLowerCase() !== 'intern' && srvData.user.name.toLowerCase() !== 'student') {
              rememberedName = srvData.user.name;
            }
          }
        }
      } catch {}
    }

    const resolvedName = (rememberedName && rememberedName.trim() && rememberedName.trim().toLowerCase() !== 'student' && rememberedName.trim().toLowerCase() !== 'intern')
      ? rememberedName.trim()
      : (name && name.trim() && name.trim().toLowerCase() !== 'intern' && name.trim().toLowerCase() !== 'student'
        ? name.trim()
        : (cleanEmail ? cleanEmail.split('@')[0] : 'Student'));

    if (!profile) {
      const now = new Date().toISOString();
      profile = {
        uid,
        name: resolvedName,
        email: cleanEmail,
        photoURL: photoURL || undefined,
        role: isAdmin ? 'admin' : 'student',
        referralCode: generateReferralCode(resolvedName || cleanEmail),
        internshipStatus: 'none',
        progress: 0,
        agreementAccepted: true,
        agreementAcceptedAt: now,
        agreementVersion: 'v1.0-2026',
        createdAt: now,
        updatedAt: now
      };
      await dataService.saveUser(profile);
      await dataService.saveEAgreement({
        userId: uid,
        userName: profile.name,
        userEmail: cleanEmail,
        agreementVersion: 'v1.0-2026'
      }).catch(() => {});
    } else {
      // If profile exists, make sure real human name is retained
      if (resolvedName && resolvedName !== 'Student' && resolvedName.toLowerCase() !== 'intern') {
        profile.name = resolvedName;
      }
      // CRITICAL FIX: Always sync profile.email to authenticated Google/Firebase email
      if (cleanEmail && cleanEmail !== 'student@virintern.com') {
        profile.email = cleanEmail;
      }
      if (photoURL && !profile.photoURL) {
        profile.photoURL = photoURL;
      }
      if (!profile.role) {
        profile.role = isAdmin ? 'admin' : 'student';
      } else if (isAdmin && profile.role !== 'admin') {
        profile.role = 'admin';
        profile.agreementAccepted = true;
      } else if (!isAdmin && profile.role === 'admin') {
        profile.role = 'student';
      }
      await dataService.saveUser(profile);
    }

    if (typeof window !== 'undefined' && profile.name && profile.name !== 'Student') {
      localStorage.setItem(`virintern_user_name_${cleanEmail}`, profile.name);
      localStorage.setItem(`virintern_user_name_${profile.uid}`, profile.name);
      localStorage.setItem('virintern_last_signup_name', profile.name);
      runtimeSignupName = profile.name;
    }

    return profile;
  };

  useEffect(() => {
    dataService.initializeDatabase();

    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      if (firebaseUser) {
        try {
          const cleanEmail = (firebaseUser.email || 'student@virintern.com').toLowerCase();
          const remembered = typeof window !== 'undefined'
            ? (localStorage.getItem(`virintern_user_name_${cleanEmail}`) ||
               localStorage.getItem(`virintern_user_name_${firebaseUser.uid}`) ||
               localStorage.getItem('virintern_last_signup_name') ||
               runtimeSignupName)
            : runtimeSignupName;

          const initialName = (remembered && remembered.trim() && remembered.trim().toLowerCase() !== 'student' && remembered.trim().toLowerCase() !== 'intern')
            ? remembered.trim()
            : (firebaseUser.displayName && firebaseUser.displayName.trim().toLowerCase() !== 'student' && firebaseUser.displayName.trim().toLowerCase() !== 'intern'
                ? firebaseUser.displayName.trim()
                : (firebaseUser.email ? firebaseUser.email.split('@')[0] : 'Student'));

          const profile = await loadOrCreateUserProfile(
            firebaseUser.uid,
            cleanEmail,
            initialName,
            firebaseUser.photoURL || undefined
          );

          // Ensure profile is kept in sync and stored with proper role and email
          setUser(profile);

          let [internship, notifs] = await Promise.all([
            dataService.getInternship(firebaseUser.uid),
            dataService.getNotifications(firebaseUser.uid)
          ]);
          let activeInt = internship;
          if (!activeInt && profile.selectedDomain) {
            const allDomains = await dataService.getDomains();
            const matched = allDomains.find(
              d => d.name.toLowerCase() === profile.selectedDomain?.toLowerCase() ||
                   d.id.toLowerCase() === profile.selectedDomain?.toLowerCase()
            );
            if (matched) {
              activeInt = await dataService.startInternship(profile, matched);
            }
          }
          setActiveInternship(activeInt);

          // Guarantee student has welcome notification if list is empty
          if (!notifs || notifs.length === 0) {
            await dataService.addNotification({
              userId: firebaseUser.uid,
              title: 'Welcome to VirIntern! 🎉',
              message: 'Your virtual internship account is active. Explore career domains, verify your pre-attached offer letter, and begin Task 1.',
              type: 'internship_started'
            });
            notifs = await dataService.getNotifications(firebaseUser.uid);
          }
          setNotifications(notifs);
        } catch (e) {
          console.error("Error loading user profile after auth state change:", e);
        }
      } else {
        // Only clear if no cached user exists
        const cached = localStorage.getItem('virintern_cached_user');
        if (!cached) {
          setUser(null);
          setActiveInternship(null);
          setNotifications([]);
        }
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  // Real-time listener for current user's profile, active internship & notifications
  useEffect(() => {
    if (!user?.uid) return;

    // Real-time listener for user profile
    const unsubUser = dataService.subscribeUserProfile(user.uid, (freshUser) => {
      if (freshUser) {
        if (isUserAdmin(freshUser.uid, freshUser.email)) {
          freshUser.role = 'admin';
        }
        if (!freshUser.name || freshUser.name.toLowerCase() === 'student' || freshUser.name.toLowerCase() === 'intern') {
          if (user?.name && user.name.toLowerCase() !== 'student' && user.name.toLowerCase() !== 'intern') {
            freshUser.name = user.name;
          }
        }
        setUser(freshUser);
      }
    });

    // Real-time listener for internship
    const unsubInternship = dataService.subscribeInternship(user.uid, (freshInternship) => {
      setActiveInternship(freshInternship);
    });

    // Real-time listener for notifications
    const unsubNotifs = dataService.subscribeNotifications(user.uid, (freshNotifs) => {
      setNotifications(freshNotifs);
    });

    return () => {
      unsubUser();
      unsubInternship();
      unsubNotifs();
    };
  }, [user?.uid]);

  const loginWithGoogle = async () => {
    setLoading(true);
    try {
      const result = await signInWithPopup(auth, googleProvider);
      if (result.user) {
        const profile = await loadOrCreateUserProfile(
          result.user.uid,
          result.user.email || 'student@virintern.com',
          result.user.displayName || 'Google Student',
          result.user.photoURL || undefined
        );
        setUser(profile);
        const [internship, notifs] = await Promise.all([
          dataService.getInternship(result.user.uid),
          dataService.getNotifications(result.user.uid)
        ]);
        setActiveInternship(internship);
        setNotifications(notifs);
      }
    } catch (err: any) {
      console.warn("Google sign-in error:", err);
      throw new Error(getFriendlyAuthError(err));
    } finally {
      setLoading(false);
    }
  };

  const loginWithEmail = async (email: string, pass: string) => {
    setLoading(true);
    try {
      const cleanEmail = email.trim().toLowerCase();
      const isEmailAuthorizedAdmin = isAuthorizedAdmin(null, cleanEmail);

      // If authorized admin email, attempt Firebase Auth first so Firestore admin rules succeed cleanly
      if (isEmailAuthorizedAdmin) {
        console.info("Signing in authorized admin:", cleanEmail);
        try {
          await signInWithEmailAndPassword(auth, cleanEmail, pass);
        } catch {
          // Proceed with local/backend admin session if password differs or email auth is unlinked
        }
        await loginAsAdmin(cleanEmail);
        return;
      }

      // 1. Try Firebase Authentication
      try {
        const res = await signInWithEmailAndPassword(auth, cleanEmail, pass);
        const savedName = (typeof window !== 'undefined' ? localStorage.getItem(`virintern_user_name_${cleanEmail}`) : null) ||
          res.user.displayName ||
          cleanEmail.split('@')[0];

        const profile = await loadOrCreateUserProfile(
          res.user.uid,
          res.user.email || cleanEmail,
          savedName
        );

        if (!profile.role) {
          profile.role = profile.companyId ? 'company' : 'student';
        }
        if ((!profile.name || profile.name.trim().toLowerCase() === 'intern' || profile.name === 'Student') && savedName && savedName !== 'Student') {
          profile.name = savedName;
          await dataService.saveUser(profile);
        }

        setUser(profile);

        if (profile.role === 'company' || profile.companyId) {
          profile.role = 'company';
          const comp = await dataService.getCompany(profile.companyId || profile.uid);
          if (comp) {
            setCompanyProfile(comp);
            try {
              localStorage.setItem('virintern_cached_company', JSON.stringify(comp));
              localStorage.setItem('virintern_current_view', 'company');
            } catch {}
          }
        } else {
          // Student role
          profile.role = 'student';
          const [internship, notifs] = await Promise.all([
            dataService.getInternship(res.user.uid),
            dataService.getNotifications(res.user.uid)
          ]);
          setActiveInternship(internship);
          setNotifications(notifs);
          try {
            const hasEnrolled = Boolean(internship || profile.selectedDomain);
            localStorage.setItem('virintern_current_view', hasEnrolled ? 'dashboard' : 'domains');
          } catch {}
        }
        return;
      } catch (authErr: any) {
        console.warn("Firebase Auth sign in attempt failed, checking persistent database:", authErr?.message || authErr);

        // 2. Try persistent backend /api/auth/login endpoint
        try {
          const authRes = await fetch('/api/auth/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email: cleanEmail, password: pass })
          });
          if (authRes.ok) {
            const authData = await authRes.json();
            if (authData.user) {
              const matched = authData.user as UserProfile;
              if (!matched.role) {
                matched.role = matched.companyId ? 'company' : 'student';
              }
              if (!matched.name || !matched.name.trim() || matched.name.toLowerCase() === 'intern') {
                matched.name = cleanEmail.split('@')[0] || 'Student';
              }
              setUser(matched);

              if (matched.role === 'company' || matched.companyId) {
                const comp = await dataService.getCompany(matched.companyId || matched.uid);
                if (comp) {
                  setCompanyProfile(comp);
                  try {
                    localStorage.setItem('virintern_cached_company', JSON.stringify(comp));
                    localStorage.setItem('virintern_current_view', 'company');
                  } catch {}
                }
              } else {
                matched.role = 'student';
                const [internship, notifs] = await Promise.all([
                  dataService.getInternship(matched.uid),
                  dataService.getNotifications(matched.uid)
                ]);
                setActiveInternship(internship);
                setNotifications(notifs);
                try {
                  const hasEnrolled = Boolean(internship || matched.selectedDomain);
                  localStorage.setItem('virintern_current_view', hasEnrolled ? 'dashboard' : 'domains');
                } catch {}
              }
              return;
            }
          }
        } catch (backendErr) {
          console.warn("Backend auth call fallback:", backendErr);
        }

        // 3. Fallback: Check local and cached users store
        const allUsers = await dataService.getAllUsers();
        let localMatch = allUsers.find(u => u.email && u.email.toLowerCase() === cleanEmail);

        if (!localMatch) {
          try {
            const rawCred = localStorage.getItem(`virintern_cred_${cleanEmail}`);
            if (rawCred) {
              const parsedCred = JSON.parse(rawCred);
              if (parsedCred && parsedCred.email === cleanEmail) {
                localMatch = {
                  uid: parsedCred.uid || `usr_${Date.now()}`,
                  name: parsedCred.name || cleanEmail.split('@')[0] || 'Student',
                  email: cleanEmail,
                  role: 'student',
                  referralCode: `VIR${Math.floor(100 + Math.random() * 900)}`,
                  internshipStatus: 'none',
                  progress: 0,
                  agreementAccepted: true,
                  createdAt: new Date().toISOString(),
                  updatedAt: new Date().toISOString()
                };
              }
            }
          } catch {}
        }

        if (localMatch) {
          if (localMatch.role === 'company' || localMatch.companyId) {
            localMatch.role = 'company';
            setUser(localMatch);
            const comp = await dataService.getCompany(localMatch.companyId || localMatch.uid);
            if (comp) {
              setCompanyProfile(comp);
              try {
                localStorage.setItem('virintern_cached_company', JSON.stringify(comp));
                localStorage.setItem('virintern_current_view', 'company');
              } catch {}
            }
            return;
          } else {
            // Student
            localMatch.role = 'student';
            if (!localMatch.name || localMatch.name.trim().toLowerCase() === 'intern') {
              localMatch.name = localMatch.email ? localMatch.email.split('@')[0] : 'Student';
            }
            setUser(localMatch);
            const [internship, notifs] = await Promise.all([
              dataService.getInternship(localMatch.uid),
              dataService.getNotifications(localMatch.uid)
            ]);
            setActiveInternship(internship);
            setNotifications(notifs);
            try {
              const hasEnrolled = Boolean(internship || localMatch.selectedDomain);
              localStorage.setItem('virintern_current_view', hasEnrolled ? 'dashboard' : 'domains');
            } catch {}
            return;
          }
        }

        // 4. Also check if registered as company
        const allCompanies = await dataService.getCompanies();
        const companyMatch = allCompanies.find(c => c.officialEmail && c.officialEmail.toLowerCase() === cleanEmail);
        if (companyMatch) {
          const compUser: UserProfile = {
            uid: companyMatch.userId || companyMatch.id,
            name: companyMatch.name,
            email: companyMatch.officialEmail,
            role: 'company',
            companyId: companyMatch.id,
            referralCode: 'COMP' + Math.floor(100 + Math.random() * 900),
            internshipStatus: 'none',
            progress: 0,
            createdAt: companyMatch.createdAt,
            updatedAt: companyMatch.updatedAt
          };
          setUser(compUser);
          setCompanyProfile(companyMatch);
          try {
            localStorage.setItem('virintern_cached_company', JSON.stringify(companyMatch));
            localStorage.setItem('virintern_current_view', 'company');
          } catch {}
          return;
        }

        throw new Error('Account not recognized. Please check your email and password or create a free account.');
      }
    } catch (err: any) {
      console.warn("Authentication login error:", err);
      throw new Error(getFriendlyAuthError(err));
    } finally {
      setLoading(false);
    }
  };

  const signUpWithEmail = async (name: string, email: string, pass: string, refCode?: string) => {
    setLoading(true);
    try {
      const cleanEmail = email.trim().toLowerCase();
      const rawName = (name || '').trim();
      const cleanName = (rawName && rawName.toLowerCase() !== 'intern' && rawName.toLowerCase() !== 'student')
        ? rawName
        : (cleanEmail.split('@')[0] || 'Student');

      // Update runtime & localStorage caches immediately
      runtimeSignupName = cleanName;
      if (typeof window !== 'undefined') {
        localStorage.setItem(`virintern_user_name_${cleanEmail}`, cleanName);
        localStorage.setItem('virintern_last_signup_name', cleanName);
      }

      const isEmailAuthorizedAdmin = ADMIN_EMAILS.some(a => a.trim().toLowerCase() === cleanEmail);
      if (isEmailAuthorizedAdmin) {
        console.info("Authorized admin signing in via admin flow:", cleanEmail);
        try {
          await signInWithEmailAndPassword(auth, cleanEmail, pass);
        } catch {
          // Proceed cleanly
        }
        await loginAsAdmin(cleanEmail);
        return;
      }

      let uid = '';

      // 1. Also create in Firebase Auth first to obtain definitive UID
      try {
        const res = await createUserWithEmailAndPassword(auth, cleanEmail, pass);
        uid = res.user.uid;
        if (typeof window !== 'undefined' && cleanName && cleanName !== 'Student') {
          localStorage.setItem(`virintern_user_name_${uid}`, cleanName);
          localStorage.setItem('virintern_last_signup_name', cleanName);
        }
        try {
          await updateProfile(res.user, { displayName: cleanName });
        } catch (e) {
          // non-critical
        }
      } catch (fbErr: any) {
        console.warn("Firebase Auth sign up fallback for preview environment:", fbErr);
        if (fbErr.code === 'auth/email-already-in-use') {
          try {
            const signInRes = await signInWithEmailAndPassword(auth, cleanEmail, pass);
            uid = signInRes.user.uid;
          } catch {
            if (!uid) uid = `usr_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
          }
        } else if (!uid) {
          uid = `usr_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
        }
      }

      // 2. Register with backend persistence immediately with matching UID
      try {
        const srvRes = await fetch('/api/auth/register', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            uid: uid || undefined,
            name: cleanName,
            email: cleanEmail,
            password: pass,
            role: 'student',
            referralCode: generateReferralCode(cleanName || cleanEmail),
            referredBy: refCode || undefined
          })
        });
        if (srvRes.ok) {
          const srvData = await srvRes.json();
          if (srvData.user?.uid && !uid) {
            uid = srvData.user.uid;
          }
        }
      } catch (srvErr) {
        console.warn("Backend register call fallback:", srvErr);
      }

      const now = new Date().toISOString();
      const newProfile: UserProfile = {
        uid,
        name: cleanName,
        email: cleanEmail,
        photoURL: undefined,
        role: 'student', // Public registration is ALWAYS student
        referralCode: generateReferralCode(cleanName || cleanEmail),
        referredBy: refCode || undefined,
        internshipStatus: 'none',
        progress: 0,
        agreementAccepted: true,
        agreementAcceptedAt: now,
        agreementVersion: 'v1.0-2026',
        consentShareProfile: true,
        consentShareResume: true,
        createdAt: now,
        updatedAt: now
      };

      // Save locally and to backend
      await dataService.saveUser(newProfile);
      await dataService.saveEAgreement({
        userId: uid,
        userName: newProfile.name,
        userEmail: cleanEmail,
        agreementVersion: 'v1.0-2026'
      }).catch(() => {});

      // Persist credentials locally so offline/preview logins always recognize this account
      try {
        localStorage.setItem(`virintern_cred_${cleanEmail}`, JSON.stringify({
          email: cleanEmail,
          password: pass,
          name: cleanName,
          uid,
          role: 'student'
        }));
        localStorage.setItem(`virintern_user_name_${cleanEmail}`, cleanName);
        if (uid) {
          localStorage.setItem(`virintern_user_name_${uid}`, cleanName);
        }
        localStorage.setItem('virintern_last_signup_name', cleanName);
      } catch {}

      // Clear any prior cached internship and submissions from previous sessions so newly registered student starts completely fresh
      dataService.clearSession();
      setActiveInternship(null);
      try {
        localStorage.removeItem('virintern_cached_internship');
        localStorage.removeItem('virintern_has_enrolled');
        localStorage.removeItem('virintern_enrolled_domain');
        localStorage.removeItem('virintern_enrolled_domain_name');
        localStorage.removeItem('virintern_data_submissions');
        localStorage.removeItem('virintern_submissions');
        localStorage.removeItem('virintern_data_evaluations');
        localStorage.removeItem('virintern_evaluations');
        localStorage.removeItem('virintern_auto_random_track');
        localStorage.setItem('virintern_current_view', 'domains');
      } catch {}

      setUser(newProfile);

      // Async welcome notifications & referrals
      Promise.allSettled([
        dataService.addNotification({
          userId: uid,
          title: 'Welcome to VirIntern! 🎉',
          message: 'Your account is verified and ready. Explore domains and start your structured virtual internship.',
          type: 'internship_started'
        }),
        dataService.logEmail({
          to: cleanEmail,
          subject: 'Welcome to VirIntern Virtual Internship Portal',
          preview: `Hello ${cleanName}, welcome to VirIntern. Gain practical experience, complete verified milestone projects, and build a standout portfolio.`,
          type: 'welcome'
        }),
        refCode ? dataService.trackReferralSignup(refCode, newProfile) : Promise.resolve()
      ]).catch(() => {});
    } catch (err: any) {
      console.warn("Sign up error:", err);
      throw new Error(getFriendlyAuthError(err));
    } finally {
      setLoading(false);
    }
  };

  const acceptAgreement = async () => {
    if (!user) return;
    const now = new Date().toISOString();
    const updated: UserProfile = {
      ...user,
      agreementAccepted: true,
      agreementAcceptedAt: now,
      agreementVersion: 'v1.0-2026',
      internshipStatus: user.internshipStatus === 'none' ? 'agreement_pending' : user.internshipStatus,
      updatedAt: now
    };
    await Promise.allSettled([
      dataService.saveUser(updated),
      dataService.saveEAgreement({
        userId: user.uid,
        userName: user.name,
        userEmail: user.email,
        agreementVersion: 'v1.0-2026'
      })
    ]);
    setUser(updated);
  };

  const enrollInDomain = async (domain: DomainItem): Promise<InternshipRecord> => {
    if (!user) throw new Error('User not logged in');
    const record = await dataService.startInternship(user, domain);
    try {
      localStorage.setItem('virintern_has_enrolled', 'true');
      localStorage.setItem('virintern_enrolled_domain', domain.id);
      localStorage.setItem('virintern_enrolled_domain_name', domain.name);
      localStorage.setItem('virintern_cached_internship', JSON.stringify(record));
      localStorage.setItem('virintern_current_view', 'dashboard');
    } catch {}
    setActiveInternship(record);
    const updatedUser: UserProfile = {
      ...user,
      selectedDomain: domain.name,
      internshipStatus: record.status === 'completed' ? 'completed' : 'active',
      internshipStartDate: record.startDate,
      internshipEndDate: record.endDate,
      progress: record.progress || 0,
      updatedAt: new Date().toISOString()
    };
    setUser(updatedUser);
    return record;
  };

  const refreshProfile = async () => {
    if (!user) return;
    const freshUser = await dataService.getUserProfile(user.uid);
    if (freshUser) {
      if (isUserAdmin(freshUser.uid, freshUser.email)) {
        freshUser.role = 'admin';
      }
      setUser(freshUser);
    }
    const currentDomainId = localStorage.getItem('virintern_enrolled_domain') || undefined;
    let freshInternship = await dataService.getInternship(user.uid, currentDomainId);
    if (!freshInternship && (freshUser?.selectedDomain || user?.selectedDomain)) {
      const domName = freshUser?.selectedDomain || user?.selectedDomain;
      const allDomains = await dataService.getDomains();
      const matched = allDomains.find(
        d => d.name.toLowerCase() === domName?.toLowerCase() ||
             d.id.toLowerCase() === domName?.toLowerCase()
      );
      if (matched && (freshUser || user)) {
        freshInternship = await dataService.startInternship(freshUser || user, matched);
      }
    }
    setActiveInternship(freshInternship);
    const freshNotifs = await dataService.getNotifications(user.uid);
    setNotifications(freshNotifs);
  };

  const markNotificationsRead = async () => {
    if (!user) return;
    await dataService.markAllNotificationsAsRead(user.uid);
    const freshNotifs = await dataService.getNotifications(user.uid);
    setNotifications(freshNotifs);
  };

  const updateProfilePhoto = async (photoURL: string) => {
    if (!user) return;
    const updated: UserProfile = {
      ...user,
      photoURL: photoURL.trim() || undefined,
      updatedAt: new Date().toISOString()
    };
    await dataService.saveUser(updated);
    setUser(updated);
  };

  const loginAsAdmin = async (emailOverride?: string) => {
    setLoading(true);
    try {
      const now = new Date().toISOString();
      const resolvedEmail = (
        emailOverride ||
        auth.currentUser?.email ||
        user?.email ||
        DEFAULT_ADMIN_EMAIL
      ).trim().toLowerCase();
      const resolvedUid = auth.currentUser?.uid || ADMIN_UID;
      const adminProfile: UserProfile = {
        uid: resolvedUid,
        email: resolvedEmail,
        name: user?.name && user.name !== 'Student' && user.name.toLowerCase() !== 'intern' ? user.name : 'VirIntern Admin',
        role: 'admin',
        referralCode: 'ADMIN777',
        internshipStatus: 'none',
        progress: 100,
        agreementAccepted: true,
        agreementAcceptedAt: now,
        agreementVersion: 'v1.0-2026',
        createdAt: now,
        updatedAt: now
      };
      await dataService.saveUser(adminProfile);
      setUser(adminProfile);
      try {
        localStorage.setItem('virintern_current_view', 'admin');
        localStorage.removeItem('virintern_has_enrolled');
        localStorage.removeItem('virintern_cached_internship');
        localStorage.removeItem('virintern_enrolled_domain');
      } catch {}
    } finally {
      setLoading(false);
    }
  };


  const registerCompany = async (companyData: {
    name: string;
    officialEmail: string;
    password: string;
    contactPerson: string;
    designation: string;
    website: string;
    industry: string;
    description: string;
    hiringRequirements: string[];
    preferredSkills: string[];
    logoUrl?: string;
  }): Promise<CompanyProfile> => {
    setLoading(true);
    try {
      const cleanEmail = companyData.officialEmail.trim().toLowerCase();
      let uid: string;
      try {
        const res = await createUserWithEmailAndPassword(auth, cleanEmail, companyData.password);
        uid = res.user.uid;
        try {
          await updateProfile(res.user, { displayName: companyData.name.trim() });
        } catch {}
      } catch (err: any) {
        if (err.code === 'auth/email-already-in-use') {
          const res = await signInWithEmailAndPassword(auth, cleanEmail, companyData.password);
          uid = res.user.uid;
        } else {
          uid = `comp_${Date.now()}`;
        }
      }

      const now = new Date().toISOString();
      const companyId = uid;
      const compRecord: CompanyProfile = {
        id: companyId,
        userId: uid,
        name: companyData.name.trim(),
        officialEmail: cleanEmail,
        contactPerson: companyData.contactPerson.trim(),
        designation: companyData.designation.trim(),
        website: companyData.website.trim(),
        industry: companyData.industry || 'Technology',
        description: companyData.description.trim(),
        hiringRequirements: companyData.hiringRequirements || [],
        preferredSkills: companyData.preferredSkills || [],
        logoUrl: companyData.logoUrl,
        verificationStatus: 'pending_verification',
        talentDiscoveryEnabled: false,
        createdAt: now,
        updatedAt: now
      };

      await dataService.saveCompany(compRecord);

      const userProfile: UserProfile = {
        uid,
        name: companyData.name.trim(),
        email: cleanEmail,
        role: 'company',
        companyId,
        referralCode: 'COMP' + Math.floor(100 + Math.random() * 900),
        internshipStatus: 'none',
        progress: 0,
        createdAt: now,
        updatedAt: now
      };

      await dataService.saveUser(userProfile);
      setUser(userProfile);
      setCompanyProfile(compRecord);
      try {
        localStorage.setItem('virintern_cached_company', JSON.stringify(compRecord));
        localStorage.setItem('virintern_current_view', 'company');
      } catch {}

      // Add notification for company
      await dataService.addNotification({
        userId: uid,
        title: 'Company Registration Received 🏢',
        message: 'Your company profile is under review by VirIntern Admin. Talent discovery will unlock upon verification.',
        type: 'internship_started'
      });

      return compRecord;
    } catch (err: any) {
      throw new Error(getFriendlyAuthError(err));
    } finally {
      setLoading(false);
    }
  };

  const logout = async () => {
    try {
      await firebaseSignOut(auth);
    } catch {
      // ignore
    }
    try {
      localStorage.removeItem('virintern_cached_user');
      localStorage.removeItem('virintern_cached_role');
      localStorage.removeItem('virintern_cached_company');
      localStorage.removeItem('virintern_cached_internship');
      localStorage.removeItem('virintern_has_enrolled');
      localStorage.removeItem('virintern_enrolled_domain');
      localStorage.removeItem('virintern_enrolled_domain_name');
      localStorage.removeItem('virintern_data_submissions');
      localStorage.removeItem('virintern_submissions');
      localStorage.removeItem('virintern_data_evaluations');
      localStorage.removeItem('virintern_evaluations');
      localStorage.setItem('virintern_current_view', 'landing');
    } catch {}
    dataService.clearSession();
    setUser(null);
    setCompanyProfile(null);
    setActiveInternship(null);
    setNotifications([]);
  };

  const unreadCount = notifications.filter(n => !n.isRead).length;

  return (
    <AuthContext.Provider
      value={{
        user,
        loading,
        activeInternship,
        notifications,
        unreadCount,
        companyProfile,
        loginWithGoogle,
        loginWithEmail,
        signUpWithEmail,
        registerCompany,
        logout,
        acceptAgreement,
        enrollInDomain,
        refreshProfile,
        markNotificationsRead,
        updateProfilePhoto,
        loginAsAdmin
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

