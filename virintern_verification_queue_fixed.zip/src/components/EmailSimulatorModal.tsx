import React, { useState, useEffect } from 'react';
import { EmailLog } from '../types';
import { dataService } from '../services/dataService';
import { Mail, X, CheckCircle2, Clock, Inbox, ChevronRight } from 'lucide-react';

interface EmailSimulatorModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const EmailSimulatorModal: React.FC<EmailSimulatorModalProps> = ({ isOpen, onClose }) => {
  const [emails, setEmails] = useState<EmailLog[]>([]);
  const [selectedEmail, setSelectedEmail] = useState<EmailLog | null>(null);

  useEffect(() => {
    if (isOpen) {
      dataService.getEmailLogs().then((logs) => {
        setEmails(logs);
        if (logs.length > 0 && !selectedEmail) {
          setSelectedEmail(logs[0]);
        }
      });
    }
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fadeIn">
      <div className="bg-white w-full max-w-3xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col h-[560px]">
        {/* Modal Header */}
        <div className="p-4 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-indigo-600 flex items-center justify-center">
              <Mail className="w-4 h-4 text-white" />
            </div>
            <div>
              <h3 className="text-sm font-bold">VirIntern Email Delivery Simulator</h3>
              <p className="text-[11px] text-slate-400">
                Live transactional email logs dispatched by backend triggers (PRD Section 45)
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Columns */}
        <div className="flex-1 flex overflow-hidden">
          {/* Email List Left */}
          <div className="w-1/3 border-r border-slate-200 overflow-y-auto divide-y divide-slate-100 bg-slate-50">
            {emails.length === 0 ? (
              <div className="p-6 text-center text-xs text-slate-400">
                <Inbox className="w-8 h-8 mx-auto mb-2 text-slate-300" />
                No email dispatches yet
              </div>
            ) : (
              emails.map((em) => (
                <button
                  key={em.id}
                  onClick={() => setSelectedEmail(em)}
                  className={`w-full p-3.5 text-left transition-colors flex flex-col gap-1 ${
                    selectedEmail?.id === em.id ? 'bg-white border-l-4 border-indigo-600 shadow-sm' : 'hover:bg-slate-100'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-indigo-600">
                      {em.type.replace('_', ' ')}
                    </span>
                    <span className="text-[10px] text-slate-400">{em.sentAt}</span>
                  </div>
                  <p className="text-xs font-bold text-slate-900 line-clamp-1">{em.subject}</p>
                  <p className="text-[11px] text-slate-500 line-clamp-1">{em.preview}</p>
                </button>
              ))
            )}
          </div>

          {/* Email Preview Right */}
          <div className="flex-1 p-6 overflow-y-auto bg-white flex flex-col justify-between">
            {selectedEmail ? (
              <div className="space-y-4 text-xs">
                <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-1.5">
                  <div className="flex justify-between">
                    <span className="text-slate-500">To:</span>
                    <span className="font-semibold text-slate-800">{selectedEmail.to}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">From:</span>
                    <span className="font-semibold text-slate-800">no-reply@virintern.com</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Subject:</span>
                    <span className="font-bold text-indigo-700">{selectedEmail.subject}</span>
                  </div>
                  <div className="flex justify-between text-[11px] text-slate-400 pt-1 border-t border-slate-200">
                    <span>Delivered:</span>
                    <span>{selectedEmail.sentAt}</span>
                  </div>
                </div>

                {/* Email Body Template */}
                <div className="p-6 bg-slate-50/50 rounded-2xl border border-slate-200 space-y-4">
                  <div className="flex items-center gap-2 border-b border-slate-200 pb-3">
                    <div className="w-7 h-7 rounded-lg bg-indigo-600 text-white font-bold flex items-center justify-center text-xs">
                      VI
                    </div>
                    <span className="font-bold text-slate-900">VirIntern Virtual Internship</span>
                  </div>

                  <p className="text-sm font-semibold text-slate-900">
                    {selectedEmail.subject}
                  </p>

                  <p className="text-xs text-slate-700 leading-relaxed">
                    {selectedEmail.preview}
                  </p>

                  <div className="p-4 bg-white rounded-xl border border-slate-200 text-[11px] text-slate-600">
                    Log in to your student dashboard anytime to check your active task instructions and track feedback.
                  </div>

                  <div className="pt-2 text-[10px] text-slate-400">
                    This notification was automatically dispatched according to PRD transactional event specifications.
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-center py-20 text-xs text-slate-400">
                Select an email from the left pane to view details.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
