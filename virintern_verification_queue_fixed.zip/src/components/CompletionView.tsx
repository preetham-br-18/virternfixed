import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../context/AuthContext';
import { PackageConfig, PackageBenefit, CertificateRecord } from '../types';
import { dataService } from '../services/dataService';
import confetti from 'canvas-confetti';
import {
  Award,
  CheckCircle2,
  Download,
  ExternalLink,
  FileText,
  Lock,
  Printer,
  QrCode,
  ShieldCheck,
  Sparkles,
  Star,
  Users,
  CreditCard,
  X,
  BookOpen,
  Paperclip,
  Briefcase
} from 'lucide-react';

interface CompletionViewProps {
  setCurrentView: (view: string) => void;
  openEmailSimulator: () => void;
}

export const CompletionView: React.FC<CompletionViewProps> = ({ setCurrentView }) => {
  const { user, activeInternship, refreshProfile } = useAuth();
  const [packageConfig, setPackageConfig] = useState<PackageConfig | null>(null);
  const [activeBenefits, setActiveBenefits] = useState<PackageBenefit[]>([]);
  const [hasPaid, setHasPaid] = useState<boolean>(false);
  const [certificates, setCertificates] = useState<{ completion?: CertificateRecord; appreciation?: CertificateRecord }>({});
  const [activeCertTab, setActiveCertTab] = useState<'completion' | 'appreciation'>('completion');
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [paymentStep, setPaymentStep] = useState<'checkout' | 'processing' | 'success'>('checkout');
  const [paymentMethod, setPaymentMethod] = useState<'upi' | 'card' | 'netbanking'>('upi');
  const [razorpayPaymentId, setRazorpayPaymentId] = useState('');
  const certificateRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Fire festive celebration confetti!
    confetti({
      particleCount: 100,
      spread: 70,
      origin: { y: 0.6 }
    });

    const unsubPackage = dataService.subscribePackageConfig((pkg) => {
      setPackageConfig(pkg);
    });

    // Real-time subscription to active package benefits (100% database driven!)
    const unsubBenefits = dataService.subscribePackageBenefits((benefits) => {
      setActiveBenefits(benefits);
    }, true);

    if (user) {
      if (user.hasPaidPackage) {
        setHasPaid(true);
        dataService.getUserCertificates(user.uid).then(certs => {
          const comp = certs.find(c => c.type === 'Completion');
          const appr = certs.find(c => c.type === 'Appreciation');
          if (comp && appr) {
            setCertificates({ completion: comp, appreciation: appr });
          }
        });
      }
    }

    return () => {
      unsubPackage();
      unsubBenefits();
    };
  }, [user]);

  const renderBenefitIcon = (iconName?: string) => {
    switch (iconName) {
      case 'Star': return <Star className="w-5 h-5 text-amber-500" />;
      case 'ShieldCheck': return <ShieldCheck className="w-5 h-5 text-emerald-600" />;
      case 'FileText': return <FileText className="w-5 h-5 text-indigo-600" />;
      case 'BookOpen': return <BookOpen className="w-5 h-5 text-sky-600" />;
      case 'Briefcase': return <Briefcase className="w-5 h-5 text-amber-600" />;
      case 'Download': return <Download className="w-5 h-5 text-purple-600" />;
      case 'Sparkles': return <Sparkles className="w-5 h-5 text-amber-400" />;
      case 'CheckCircle': return <CheckCircle2 className="w-5 h-5 text-emerald-500" />;
      default: return <Award className="w-5 h-5 text-indigo-600" />;
    }
  };

  const handlePrintCertificate = () => {
    window.print();
  };

  const handleSimulateRazorpayPayment = async () => {
    if (!user || !activeInternship || !packageConfig) return;
    setPaymentStep('processing');

    const fakePaymentId = `pay_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`;
    setRazorpayPaymentId(fakePaymentId);

    setTimeout(async () => {
      // Backend signature verification simulation
      const verified = true;
      if (verified) {
        // Issue certificates
        const issued = await dataService.issueCertificates(user, activeInternship);
        setCertificates(issued);

        // Update user state
        const updatedUser = {
          ...user,
          hasPaidPackage: true,
          paidPackageAt: new Date().toISOString()
        };
        await dataService.saveUser(updatedUser);

        // Process referral rewards (10% reward)
        await dataService.processReferralPurchase(user.uid, packageConfig.price);

        // Log notification & email
        await dataService.addNotification({
          userId: user.uid,
          title: 'Completion Package Unlocked! 📜',
          message: 'Your official completion credentials, certificates, badge, resume kit, and 1000 QA bank are now active.',
          type: 'reward'
        });

        await dataService.logEmail({
          to: user.email,
          subject: 'Your VirIntern Completion Credentials are Ready',
          preview: `Payment of ₹${packageConfig.price} verified. Your official completion certificate (${issued.completion.certificateId}) has been issued!`,
          type: 'package_ready'
        });

        setPaymentStep('success');
        setHasPaid(true);
        await refreshProfile();

        confetti({
          particleCount: 150,
          spread: 90,
          origin: { y: 0.5 }
        });
      }
    }, 50);
  };

  const currentCert = activeCertTab === 'completion' ? certificates.completion : certificates.appreciation;
  const price = packageConfig?.price || 99;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-10">
      {/* 20. Congratulations Hero Header */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 rounded-3xl p-8 sm:p-12 text-white text-center relative overflow-hidden shadow-2xl border border-indigo-900/50">
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs font-bold mb-4">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>100% COMPLETE • ALL 5 MILESTONES APPROVED</span>
        </div>
        <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight">
          Congratulations, {user?.name || 'Intern'}! 🎓
        </h1>
        <p className="text-base sm:text-lg text-slate-300 max-w-2xl mx-auto mt-3 leading-relaxed">
          You have successfully completed your VirIntern virtual internship in{' '}
          <span className="text-indigo-400 font-semibold">{activeInternship?.domainName || 'Software Development'}</span>.
        </p>

        {/* Free Completion State Notice */}
        <div className="mt-6 inline-block bg-white/10 backdrop-blur-md px-5 py-2.5 rounded-xl border border-white/15 text-xs text-slate-200">
          ✓ <strong>Free Completion State:</strong> Your project portfolio and curriculum completion are permanently recorded.
        </div>
      </div>

      {/* Package Offer OR Certificate Viewer */}
      {!hasPaid ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* 21. Package Benefits List (LOCKED STATE) */}
          <div className="lg:col-span-7 bg-white rounded-3xl border border-slate-200 p-8 shadow-sm space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
              <div>
                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-50 text-amber-800 text-xs font-bold mb-2 border border-amber-200">
                  <Lock className="w-3.5 h-3.5 text-amber-600" />
                  <span>Package Benefits (Locked Until Purchase)</span>
                </div>
                <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900">
                  Internship Completion Package
                </h2>
                <p className="text-xs text-slate-600 mt-1">
                  Admin Configured Price: <span className="font-bold text-slate-900">₹{price}</span> (Original value ₹999)
                </p>
              </div>

              <div className="px-3 py-1.5 bg-amber-50 rounded-xl border border-amber-200 text-center sm:text-right shrink-0">
                <span className="text-[10px] uppercase font-bold text-amber-800 block">Status</span>
                <span className="text-xs font-bold text-amber-700 flex items-center gap-1">
                  <Lock className="w-3.5 h-3.5" />
                  <span>Locked</span>
                </span>
              </div>
            </div>

            {/* Banner explaining locking */}
            <div className="p-3.5 bg-amber-50/70 border border-amber-200/80 rounded-2xl flex items-center gap-3 text-xs text-amber-900">
              <Lock className="w-4 h-4 text-amber-600 shrink-0" />
              <p>
                All <strong>{activeBenefits.length || 5} credentials and career tools</strong> below are locked and will be unlocked immediately once the completion package purchase is completed.
              </p>
            </div>

            <div className="space-y-3.5">
              {activeBenefits.length === 0 ? (
                <div className="p-8 text-center bg-slate-50 rounded-2xl border border-slate-100 text-xs text-slate-500">
                  No benefits currently active in package.
                </div>
              ) : (
                activeBenefits.map((benefit, idx) => (
                  <div key={benefit.id} className="relative flex items-start gap-3.5 p-4 rounded-2xl bg-slate-50/80 border border-slate-200 transition-all hover:border-amber-300 hover:bg-amber-50/30">
                    <div className="relative w-11 h-11 rounded-xl bg-white text-slate-500 border border-slate-200 flex items-center justify-center font-bold text-sm shrink-0 overflow-hidden shadow-2xs">
                      {benefit.imageUrl ? (
                        <img src={benefit.imageUrl} alt={benefit.title} className="w-full h-full object-cover opacity-80" />
                      ) : (
                        renderBenefitIcon(benefit.icon)
                      )}
                      <div className="absolute -bottom-1 -right-1 bg-amber-500 text-white rounded-full p-0.5 shadow-xs" title="Locked Benefit">
                        <Lock className="w-2.5 h-2.5" />
                      </div>
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <span className="text-[10px] font-mono font-bold text-slate-400">0{idx + 1}</span>
                          <h4 className="text-sm font-bold text-slate-900">{benefit.title}</h4>
                        </div>
                        <span className="inline-flex items-center gap-1 text-[10px] font-bold text-amber-800 bg-amber-100/70 px-2 py-0.5 rounded-full border border-amber-200 shrink-0">
                          <Lock className="w-2.5 h-2.5 text-amber-700" />
                          <span>LOCKED</span>
                        </span>
                      </div>
                      <p className="text-xs text-slate-600 mt-1 leading-relaxed">{benefit.description}</p>
                      
                      {/* Locked Deliverable Notice */}
                      <div className="flex flex-wrap items-center gap-2 mt-2.5 pt-2 border-t border-slate-200/60">
                        {benefit.fileName && (
                          <span className="inline-flex items-center gap-1 text-[11px] font-medium text-slate-500 bg-slate-200/60 px-2 py-0.5 rounded-md border border-slate-300">
                            <Lock className="w-3 h-3 text-slate-400" />
                            <span>Attached: {benefit.fileName} (Locked)</span>
                          </span>
                        )}
                        {benefit.resourceLink && (
                          <span className="inline-flex items-center gap-1 text-[11px] font-medium text-slate-500 bg-slate-200/60 px-2 py-0.5 rounded-md border border-slate-300">
                            <Lock className="w-3 h-3 text-slate-400" />
                            <span>Resource Link (Locked)</span>
                          </span>
                        )}
                        <span className="text-[11px] text-amber-700 font-medium">
                          ✦ Unlocks with completion package
                        </span>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Pricing & Checkout Card */}
          <div className="lg:col-span-5 bg-gradient-to-b from-indigo-600 to-indigo-800 text-white rounded-3xl p-8 shadow-xl relative overflow-hidden">
            <div className="space-y-4 text-center">
              <span className="px-3 py-1 bg-white/20 text-indigo-100 font-bold text-xs uppercase tracking-wider rounded-full">
                Special Internship Offer
              </span>
              <h3 className="text-3xl font-extrabold text-white">VirIntern Completion Package</h3>
              
              <div className="py-4">
                <div className="flex items-baseline justify-center gap-2">
                  <span className="text-5xl font-extrabold">₹{price}</span>
                  <span className="text-sm text-indigo-200 line-through">₹999</span>
                  <span className="text-xs bg-emerald-400 text-emerald-950 font-bold px-2 py-0.5 rounded">
                    90% OFF
                  </span>
                </div>
                <p className="text-xs text-indigo-200 mt-1">One-time payment • Lifetime verifiable access</p>
              </div>

              <div className="p-4 bg-white/10 rounded-2xl text-xs text-left space-y-2 border border-white/15">
                <div className="font-bold text-indigo-100 pb-1 border-b border-white/15 flex items-center gap-1.5">
                  <Lock className="w-3.5 h-3.5 text-amber-300" />
                  <span>Purchasing will instantly unlock:</span>
                </div>
                {activeBenefits.slice(0, 5).map((b) => (
                  <div key={b.id} className="flex items-center gap-2 text-white">
                    <CheckCircle2 className="w-4 h-4 text-emerald-300 shrink-0" />
                    <span className="truncate">{b.title}</span>
                  </div>
                ))}
                {activeBenefits.length > 5 && (
                  <div className="text-[11px] text-indigo-200 pl-6">
                    + {activeBenefits.length - 5} additional exclusive benefits
                  </div>
                )}
                <div className="flex items-center gap-2 pt-1 border-t border-white/10 text-emerald-300">
                  <CheckCircle2 className="w-4 h-4 text-emerald-300 shrink-0" />
                  <span>Instant Razorpay Payment Verification</span>
                </div>
              </div>

              <button
                onClick={() => {
                  setPaymentStep('checkout');
                  setIsCheckoutOpen(true);
                }}
                className="w-full py-4 bg-emerald-400 hover:bg-emerald-300 text-emerald-950 font-extrabold text-base rounded-2xl shadow-lg transition-transform hover:scale-[1.02] flex items-center justify-center gap-2"
              >
                <Sparkles className="w-5 h-5 text-emerald-900" />
                <span>Unlock All Benefits — ₹{price}</span>
              </button>

              <p className="text-[11px] text-indigo-200">
                100% money back guarantee if not satisfied with credentials.
              </p>
            </div>
          </div>
        </div>
      ) : (
        /* 23. Digital Certificates View with PDF Generation / Print */
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 bg-white p-4 rounded-2xl border border-slate-200 shadow-sm">
            <div className="flex items-center gap-2">
              <button
                onClick={() => setActiveCertTab('completion')}
                className={`px-4 py-2 text-xs font-bold rounded-xl transition-colors ${
                  activeCertTab === 'completion'
                    ? 'bg-indigo-600 text-white'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                Completion Certificate
              </button>
              <button
                onClick={() => setActiveCertTab('appreciation')}
                className={`px-4 py-2 text-xs font-bold rounded-xl transition-colors ${
                  activeCertTab === 'appreciation'
                    ? 'bg-indigo-600 text-white'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                Appreciation Certificate
              </button>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handlePrintCertificate}
                className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs rounded-xl shadow flex items-center gap-1.5 transition-colors"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>Download / Print PDF</span>
              </button>
              {currentCert && (
                <button
                  onClick={() => setCurrentView('verify_cert')}
                  className="px-3.5 py-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-semibold text-xs rounded-xl flex items-center gap-1.5 transition-colors"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>Public Lookup</span>
                </button>
              )}
            </div>
          </div>

          {/* Certificate Canvas / Rendered Certificate */}
          {currentCert && (
            <div
              ref={certificateRef}
              id="printable-certificate"
              className="bg-white rounded-3xl border-8 border-indigo-900/10 p-8 sm:p-14 shadow-2xl relative max-w-4xl mx-auto overflow-hidden print:m-0 print:border-none print:shadow-none"
              style={{
                backgroundImage: 'radial-gradient(#6366f1 0.75px, transparent 0.75px)',
                backgroundSize: '20px 20px',
                backgroundColor: '#fcfdfd'
              }}
            >
              {/* Inner Decorative Border */}
              <div className="border-2 border-indigo-900/30 p-6 sm:p-10 rounded-2xl relative text-center space-y-6">
                {/* Header */}
                <div className="flex items-center justify-between border-b border-indigo-100 pb-4">
                  <div className="flex items-center gap-2 text-left">
                    <div className="w-10 h-10 rounded-xl bg-indigo-900 text-white flex items-center justify-center font-bold text-lg">
                      VI
                    </div>
                    <div>
                      <h2 className="font-extrabold text-indigo-950 text-xl tracking-tight leading-none">
                        VirIntern
                      </h2>
                      <span className="text-[10px] text-slate-500 uppercase tracking-widest font-semibold">
                        Virtual Internship Council
                      </span>
                    </div>
                  </div>
                  <div className="text-right text-[11px] text-slate-500 font-mono">
                    <p>ID: <strong className="text-slate-900">{currentCert.certificateId}</strong></p>
                    <p>Issued: {currentCert.issueDate}</p>
                  </div>
                </div>

                {/* Certificate Title */}
                <div>
                  <span className="text-xs uppercase tracking-widest font-bold text-amber-700 bg-amber-50 px-3 py-1 rounded-full border border-amber-200">
                    Official Credential
                  </span>
                  <h1 className="text-3xl sm:text-4xl font-serif font-bold text-indigo-950 mt-3">
                    Certificate of {currentCert.type}
                  </h1>
                  <p className="text-xs text-slate-500 uppercase tracking-widest mt-1">
                    This document proudly certifies that
                  </p>
                </div>

                {/* Student Name */}
                <div className="py-2">
                  <h2 className="text-3xl sm:text-4xl font-serif italic font-bold text-indigo-900 underline decoration-indigo-200 underline-offset-8">
                    {currentCert.studentName}
                  </h2>
                </div>

                {/* Body Text */}
                <p className="text-xs sm:text-sm text-slate-700 max-w-2xl mx-auto leading-relaxed">
                  has successfully fulfilled all academic, practical, and mentor-verified requirements of the{' '}
                  <strong>{currentCert.internshipDomain} Virtual Internship</strong> from{' '}
                  <span className="font-semibold">{currentCert.startDate}</span> to{' '}
                  <span className="font-semibold">{currentCert.completionDate}</span>, completing all 5 milestone projects with distinction.
                </p>

                {/* Signatures & Seal */}
                <div className="grid grid-cols-3 gap-4 pt-8 border-t border-indigo-100 items-end">
                  <div className="text-center">
                    <div className="h-10 border-b border-slate-400 flex items-center justify-center font-serif italic text-sm text-slate-800">
                      Dr. K. Raghavan
                    </div>
                    <p className="text-[10px] text-slate-500 mt-1 uppercase font-semibold">Program Director</p>
                  </div>

                  <div className="flex flex-col items-center justify-center">
                    <div className="w-16 h-16 rounded-full bg-gradient-to-tr from-amber-400 to-amber-600 text-white flex items-center justify-center shadow-lg border-2 border-white">
                      <Award className="w-8 h-8" />
                    </div>
                    <span className="text-[9px] uppercase font-bold text-amber-800 mt-1">Verified Credential</span>
                  </div>

                  <div className="text-center">
                    <div className="h-10 border-b border-slate-400 flex items-center justify-center font-serif italic text-sm text-slate-800">
                      Prajju M.
                    </div>
                    <p className="text-[10px] text-slate-500 mt-1 uppercase font-semibold">Lead Academic Mentor</p>
                  </div>
                </div>

                {/* Verification Footer Link */}
                <div className="pt-2 text-[10px] text-slate-400 font-mono">
                  Online Verification: https://virintern.com/verify/{currentCert.certificateId}
                </div>
              </div>
            </div>
          )}

          {/* Dynamic Unlocked Package Deliverables */}
          <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <h3 className="text-base font-bold text-slate-900">Unlocked Package Deliverables & Resources</h3>
                <p className="text-xs text-slate-500">Access all active benefits and materials provided with your completion package.</p>
              </div>
              <span className="text-xs font-semibold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200">
                {activeBenefits.length} Deliverables Unlocked
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {activeBenefits.map((benefit) => (
                <div key={benefit.id} className="p-4 rounded-2xl border border-slate-200 bg-slate-50/60 flex items-start justify-between gap-3 text-xs">
                  <div className="flex items-start gap-3 flex-1 min-w-0">
                    <div className="w-10 h-10 rounded-xl bg-white text-indigo-700 border border-slate-200 flex items-center justify-center shrink-0 shadow-2xs overflow-hidden">
                      {benefit.imageUrl ? (
                        <img src={benefit.imageUrl} alt={benefit.title} className="w-full h-full object-cover" />
                      ) : (
                        renderBenefitIcon(benefit.icon)
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <h4 className="font-bold text-slate-900 text-sm">{benefit.title}</h4>
                        <span className="inline-flex items-center gap-1 text-[10px] font-bold text-emerald-800 bg-emerald-100/80 px-2 py-0.2 rounded-full border border-emerald-300">
                          <CheckCircle2 className="w-2.5 h-2.5 text-emerald-700" />
                          <span>UNLOCKED</span>
                        </span>
                      </div>
                      <p className="text-slate-600 line-clamp-2 mt-0.5">{benefit.description}</p>
                    </div>
                  </div>

                  <div className="flex flex-col gap-1.5 shrink-0">
                    {benefit.id === 'benefit_resume' && (
                      <button
                        onClick={() => setCurrentView('resume_builder')}
                        className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-lg flex items-center gap-1 shadow-xs transition-colors"
                      >
                        <FileText className="w-3.5 h-3.5" />
                        <span>Launch Builder</span>
                      </button>
                    )}
                    {benefit.id === 'benefit_interview' && (
                      <button
                        onClick={() => setCurrentView('interview_prep')}
                        className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-lg flex items-center gap-1 shadow-xs transition-colors"
                      >
                        <BookOpen className="w-3.5 h-3.5" />
                        <span>Open 1000 QA</span>
                      </button>
                    )}
                    {benefit.fileUrl && (
                      <a
                        href={benefit.fileUrl}
                        download={benefit.fileName || `${String(benefit.title || 'benefit').toLowerCase().replace(/\s+/g, '_')}`}
                        className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-lg flex items-center gap-1 shadow-xs transition-colors"
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span>Download</span>
                      </a>
                    )}
                    {benefit.resourceLink && (
                      <a
                        href={benefit.resourceLink}
                        target="_blank"
                        rel="noreferrer"
                        className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-lg flex items-center gap-1 shadow-xs transition-colors"
                      >
                        <ExternalLink className="w-3.5 h-3.5" />
                        <span>Resource</span>
                      </a>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Quick Access to Tools */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <button
              onClick={() => setCurrentView('resume_builder')}
              className="p-5 bg-white rounded-2xl border border-slate-200 hover:border-indigo-400 shadow-sm flex items-center justify-between text-left group transition-all"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
                  <FileText className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900 group-hover:text-indigo-600 transition-colors">
                    Launch Resume Builder Kit
                  </h4>
                  <p className="text-xs text-slate-500">Edit templates and export PDF with completed internship details.</p>
                </div>
              </div>
              <ExternalLink className="w-4 h-4 text-slate-400 group-hover:text-indigo-600 transition-colors" />
            </button>

            <button
              onClick={() => setCurrentView('interview_prep')}
              className="p-5 bg-white rounded-2xl border border-slate-200 hover:border-emerald-400 shadow-sm flex items-center justify-between text-left group transition-all"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
                  <BookOpen className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900 group-hover:text-emerald-600 transition-colors">
                    Open 1000+ Interview QA Bank
                  </h4>
                  <p className="text-xs text-slate-500">Practice questions across HR, Technical, AI/ML & System Design.</p>
                </div>
              </div>
              <ExternalLink className="w-4 h-4 text-slate-400 group-hover:text-emerald-600 transition-colors" />
            </button>
          </div>
        </div>
      )}

      {/* 22. Razorpay Checkout Modal Simulation */}
      {isCheckoutOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-sm animate-fadeIn">
          <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl border border-slate-200 overflow-hidden relative">
            <button
              onClick={() => setIsCheckoutOpen(false)}
              className="absolute top-4 right-4 p-1.5 text-slate-400 hover:text-slate-700 rounded-full hover:bg-slate-100"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Header with Razorpay Branding */}
            <div className="bg-slate-900 px-6 py-5 text-white flex items-center justify-between border-b border-slate-800">
              <div className="flex items-center gap-2">
                <CreditCard className="w-5 h-5 text-indigo-400" />
                <div>
                  <h3 className="text-sm font-bold">Razorpay Secure Checkout</h3>
                  <p className="text-[11px] text-slate-400">VirIntern Completion Package</p>
                </div>
              </div>
              <span className="text-xs font-mono font-bold bg-indigo-500/30 text-indigo-300 px-2 py-1 rounded">
                ₹{price}.00
              </span>
            </div>

            <div className="p-6 space-y-4">
              {paymentStep === 'checkout' && (
                <>
                  <div className="space-y-2 text-xs">
                    <p className="font-semibold text-slate-700">Choose Payment Method:</p>
                    <div className="grid grid-cols-3 gap-2">
                      <button
                        type="button"
                        onClick={() => setPaymentMethod('upi')}
                        className={`p-2.5 rounded-xl border text-center font-semibold transition-colors ${
                          paymentMethod === 'upi' ? 'border-indigo-600 bg-indigo-50 text-indigo-700' : 'border-slate-200 text-slate-600'
                        }`}
                      >
                        📱 UPI / QR
                      </button>
                      <button
                        type="button"
                        onClick={() => setPaymentMethod('card')}
                        className={`p-2.5 rounded-xl border text-center font-semibold transition-colors ${
                          paymentMethod === 'card' ? 'border-indigo-600 bg-indigo-50 text-indigo-700' : 'border-slate-200 text-slate-600'
                        }`}
                      >
                        💳 Card
                      </button>
                      <button
                        type="button"
                        onClick={() => setPaymentMethod('netbanking')}
                        className={`p-2.5 rounded-xl border text-center font-semibold transition-colors ${
                          paymentMethod === 'netbanking' ? 'border-indigo-600 bg-indigo-50 text-indigo-700' : 'border-slate-200 text-slate-600'
                        }`}
                      >
                        🏦 NetBanking
                      </button>
                    </div>
                  </div>

                  <div className="p-3 bg-slate-50 rounded-xl text-xs space-y-1.5 border border-slate-200">
                    <div className="flex justify-between text-slate-600">
                      <span>Package Item:</span>
                      <span className="font-medium text-slate-900">Completion Certificate + Toolkit</span>
                    </div>
                    <div className="flex justify-between text-slate-600">
                      <span>Customer:</span>
                      <span className="font-medium text-slate-900">{user?.name}</span>
                    </div>
                    <div className="flex justify-between text-slate-600">
                      <span>Amount:</span>
                      <span className="font-bold text-indigo-600">₹{price}.00</span>
                    </div>
                  </div>

                  <button
                    onClick={handleSimulateRazorpayPayment}
                    className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl shadow-md transition-all flex items-center justify-center gap-2"
                  >
                    <span>Pay ₹{price}.00 via Razorpay</span>
                  </button>

                  <p className="text-[10px] text-slate-400 text-center">
                    Simulated Sandbox Payment: Authenticated backend cryptographic verification.
                  </p>
                </>
              )}

              {paymentStep === 'processing' && (
                <div className="py-8 text-center space-y-3">
                  <div className="w-10 h-10 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin mx-auto"></div>
                  <h4 className="text-sm font-bold text-slate-900">Verifying Payment Signature...</h4>
                  <p className="text-xs text-slate-500">
                    Securely connecting with backend verification service to validate payment token.
                  </p>
                </div>
              )}

              {paymentStep === 'success' && (
                <div className="py-6 text-center space-y-4">
                  <div className="w-12 h-12 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto">
                    <CheckCircle2 className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="text-base font-bold text-slate-900">Payment Successful!</h4>
                    <p className="text-xs text-slate-500 font-mono mt-0.5">Ref: {razorpayPaymentId}</p>
                    <p className="text-xs text-emerald-700 font-semibold mt-2">
                      Your completion certificates and toolkit are now unlocked!
                    </p>
                  </div>
                  <button
                    onClick={() => setIsCheckoutOpen(false)}
                    className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow"
                  >
                    View My Certificates
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
