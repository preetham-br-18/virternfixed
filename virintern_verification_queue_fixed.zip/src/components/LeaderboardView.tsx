import React, { useState, useEffect } from 'react';
import {
  Trophy,
  Medal,
  Award,
  Sparkles,
  Search,
  Filter,
  ArrowLeft,
  ChevronDown,
  User,
  Star,
  CheckCircle2,
  Calendar,
  Layers
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { dataService } from '../services/dataService';
import { LeaderboardRecord, DomainItem } from '../types';

interface LeaderboardViewProps {
  onBackToDashboard?: () => void;
  defaultDomainId?: string;
}

export const LeaderboardView: React.FC<LeaderboardViewProps> = ({
  onBackToDashboard,
  defaultDomainId
}) => {
  const { user, activeInternship } = useAuth();
  const [timeframe, setTimeframe] = useState<'overall' | 'weekly' | 'monthly'>('overall');
  const [selectedDomainId, setSelectedDomainId] = useState<string>(
    defaultDomainId || activeInternship?.domainId || 'all'
  );
  const [domains, setDomains] = useState<DomainItem[]>([]);
  const [leaderboard, setLeaderboard] = useState<LeaderboardRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    dataService.getDomains().then((doms) => {
      setDomains(doms);
    });
  }, []);

  useEffect(() => {
    setLoading(true);
    const unsub = dataService.subscribeLeaderboard(timeframe, selectedDomainId, (data) => {
      setLeaderboard(data);
      setLoading(false);
    });
    return () => {
      unsub();
    };
  }, [timeframe, selectedDomainId]);

  const filteredEntries = leaderboard.filter((item) =>
    (item.userName || '').toLowerCase().includes(searchQuery.toLowerCase())
  );

  const currentUserEntry = leaderboard.find((item) => item.userId === user?.uid);
  const top3 = leaderboard.slice(0, 3);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8 space-y-6 sm:space-y-8 animate-fadeIn">
      {/* Header */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex flex-wrap items-center gap-2 mb-1">
            {onBackToDashboard && (
              <button
                type="button"
                onClick={onBackToDashboard}
                className="inline-flex items-center gap-1 text-xs font-bold text-slate-500 hover:text-[#0A66C2] mr-2 transition-colors cursor-pointer"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Dashboard</span>
              </button>
            )}
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wider bg-amber-100 text-amber-900 border border-amber-200 flex items-center gap-1">
              <Trophy className="w-3 h-3 text-amber-700" />
              <span>Official Cohort Leaderboard</span>
            </span>
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-blue-50 text-[#0A66C2] border border-blue-200 flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-[#0A66C2]" />
              <span>Verified Points Engine</span>
            </span>
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200 flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping" />
              <span>Live Sync</span>
            </span>
          </div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 flex items-center gap-2">
            <span>Global & Track Leaderboard</span>
          </h1>
          <p className="text-xs text-slate-600 mt-1 max-w-2xl">
            Ranked strictly by verified task points, percentage score, advanced task completions, and milestone volume.
          </p>
        </div>

        {/* Filter Controls */}
        <div className="flex flex-wrap items-center gap-3">
          {/* Timeframe Filter */}
          <div className="flex items-center p-1 bg-slate-100 rounded-xl text-xs">
            <button
              type="button"
              onClick={() => setTimeframe('overall')}
              className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
                timeframe === 'overall' ? 'bg-white shadow-2xs text-[#0A66C2]' : 'text-slate-600'
              }`}
            >
              Overall
            </button>
            <button
              type="button"
              onClick={() => setTimeframe('weekly')}
              className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
                timeframe === 'weekly' ? 'bg-white shadow-2xs text-[#0A66C2]' : 'text-slate-600'
              }`}
            >
              Weekly
            </button>
            <button
              type="button"
              onClick={() => setTimeframe('monthly')}
              className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
                timeframe === 'monthly' ? 'bg-white shadow-2xs text-[#0A66C2]' : 'text-slate-600'
              }`}
            >
              Monthly
            </button>
          </div>

          {/* Domain Track Dropdown Filter */}
          <div className="relative">
            <select
              value={selectedDomainId}
              onChange={(e) => setSelectedDomainId(e.target.value)}
              className="appearance-none bg-slate-50 border border-slate-300 rounded-xl pl-3 pr-8 py-2 text-xs font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#0A66C2] shadow-2xs cursor-pointer"
            >
              <option value="all">All Domains (Global)</option>
              {domains.map((dom) => (
                <option key={dom.id} value={dom.id}>
                  {dom.name}
                </option>
              ))}
            </select>
            <ChevronDown className="w-3.5 h-3.5 text-slate-500 absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          </div>
        </div>
      </div>

      {/* Current User Highlight Banner */}
      {currentUserEntry && (
        <div className="p-4 sm:p-5 bg-gradient-to-r from-blue-50 via-indigo-50/50 to-white rounded-2xl border-2 border-[#0A66C2] shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-[#0A66C2] text-white flex items-center justify-center shrink-0 font-black text-lg shadow-xs">
              #{currentUserEntry.rank}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-sm font-black text-slate-900">{currentUserEntry.userName}</span>
                <span className="px-2 py-0.5 bg-[#0A66C2] text-white font-extrabold text-[9px] rounded-md tracking-wider uppercase">
                  YOU
                </span>
                {currentUserEntry.badges?.[0] && (
                  <span className="px-2 py-0.5 bg-amber-100 text-amber-900 font-bold text-[10px] rounded-full">
                    {currentUserEntry.badges[0]}
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-600 mt-0.5">
                Total Points: <strong className="text-slate-900 font-black">{currentUserEntry.totalPoints} pts</strong> • 
                Completed: <strong className="text-slate-900">{currentUserEntry.tasksCompleted} / 5 Milestones</strong> • 
                Average Score: <strong className="text-[#0A66C2]">{currentUserEntry.averageScore}%</strong>
              </p>
            </div>
          </div>

          <div className="text-right">
            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
              Cohort Position
            </span>
            <span className="text-xs font-bold text-[#0A66C2]">
              {currentUserEntry.rank === 1
                ? '🏆 You are holding the #1 position!'
                : `Submit tasks to advance to #${currentUserEntry.rank - 1}`}
            </span>
          </div>
        </div>
      )}

      {/* Top 3 Podium Cards */}
      {top3.length >= 3 && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
          {/* 2nd Place */}
          <div className="order-2 md:order-1 bg-white rounded-2xl border border-slate-200 p-5 shadow-2xs text-center flex flex-col justify-between relative overflow-hidden">
            <div className="absolute top-0 inset-x-0 h-1.5 bg-slate-300" />
            <div className="space-y-3">
              <div className="w-14 h-14 rounded-full bg-slate-100 text-slate-700 flex items-center justify-center mx-auto border-2 border-slate-300 shadow-2xs relative">
                <Medal className="w-7 h-7 text-slate-500" />
                <span className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-slate-600 text-white text-[10px] font-black flex items-center justify-center">
                  2
                </span>
              </div>
              <div>
                <h4 className="text-sm font-bold text-slate-900">{top3[1]?.userName}</h4>
                <p className="text-[11px] text-slate-500 font-semibold">{top3[1]?.domainName || 'Intern'}</p>
              </div>
              <div className="p-3 bg-slate-50 rounded-xl space-y-1 text-xs">
                <div className="flex justify-between text-slate-600">
                  <span>Total Points:</span>
                  <span className="font-extrabold text-slate-900">{top3[1]?.totalPoints} pts</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Average Quality:</span>
                  <span className="font-bold text-[#0A66C2]">{top3[1]?.averageScore}%</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Tasks Passed:</span>
                  <span className="font-bold text-emerald-700">{top3[1]?.tasksCompleted} / 5</span>
                </div>
              </div>
            </div>
            <div className="mt-3 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
              Runner Up • 2nd Place
            </div>
          </div>

          {/* 1st Place - Champion */}
          <div className="order-1 md:order-2 bg-gradient-to-b from-amber-50/80 via-white to-amber-50/40 rounded-2xl border-2 border-amber-300 p-6 shadow-md text-center flex flex-col justify-between relative overflow-hidden md:-translate-y-2">
            <div className="absolute top-0 inset-x-0 h-2 bg-gradient-to-r from-amber-400 via-amber-500 to-amber-400" />
            <div className="space-y-3">
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-amber-400 to-amber-600 text-white flex items-center justify-center mx-auto shadow-md relative">
                <Trophy className="w-8 h-8 text-white" />
                <span className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-amber-700 text-white text-xs font-black flex items-center justify-center border-2 border-white">
                  1
                </span>
              </div>
              <div>
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-amber-200/90 text-amber-900 inline-block mb-1">
                  Cohort Champion
                </span>
                <h3 className="text-base font-black text-slate-900">{top3[0]?.userName}</h3>
                <p className="text-xs text-amber-800 font-bold">{top3[0]?.domainName || 'Top Performer'}</p>
              </div>
              <div className="p-3 bg-amber-100/60 rounded-xl space-y-1.5 text-xs border border-amber-200">
                <div className="flex justify-between text-amber-900">
                  <span className="font-semibold">Total Verified Points:</span>
                  <span className="font-black text-slate-900 text-sm">{top3[0]?.totalPoints} pts</span>
                </div>
                <div className="flex justify-between text-amber-900">
                  <span className="font-semibold">Mentor Review Avg:</span>
                  <span className="font-black text-[#0A66C2]">{top3[0]?.averageScore}%</span>
                </div>
                <div className="flex justify-between text-amber-900">
                  <span className="font-semibold">Milestones Verified:</span>
                  <span className="font-black text-emerald-800">{top3[0]?.tasksCompleted} of 5 Done</span>
                </div>
              </div>
            </div>
            <div className="mt-3 text-[11px] font-black text-amber-800 flex items-center justify-center gap-1">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Ranked #1 in Cohort</span>
            </div>
          </div>

          {/* 3rd Place */}
          <div className="order-3 bg-white rounded-2xl border border-slate-200 p-5 shadow-2xs text-center flex flex-col justify-between relative overflow-hidden">
            <div className="absolute top-0 inset-x-0 h-1.5 bg-amber-600/50" />
            <div className="space-y-3">
              <div className="w-14 h-14 rounded-full bg-amber-50 text-amber-800 flex items-center justify-center mx-auto border-2 border-amber-600/40 shadow-2xs relative">
                <Medal className="w-7 h-7 text-amber-700" />
                <span className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-amber-800 text-white text-[10px] font-black flex items-center justify-center">
                  3
                </span>
              </div>
              <div>
                <h4 className="text-sm font-bold text-slate-900">{top3[2]?.userName}</h4>
                <p className="text-[11px] text-slate-500 font-semibold">{top3[2]?.domainName || 'Intern'}</p>
              </div>
              <div className="p-3 bg-slate-50 rounded-xl space-y-1 text-xs">
                <div className="flex justify-between text-slate-600">
                  <span>Total Points:</span>
                  <span className="font-extrabold text-slate-900">{top3[2]?.totalPoints} pts</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Average Quality:</span>
                  <span className="font-bold text-[#0A66C2]">{top3[2]?.averageScore}%</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Tasks Passed:</span>
                  <span className="font-bold text-emerald-700">{top3[2]?.tasksCompleted} / 5</span>
                </div>
              </div>
            </div>
            <div className="mt-3 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
              Podium • 3rd Place
            </div>
          </div>
        </div>
      )}

      {/* Main Leaderboard Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        {/* Controls */}
        <div className="p-4 sm:p-5 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <h3 className="text-sm sm:text-base font-extrabold text-slate-900 flex items-center gap-2">
            <Trophy className="w-4 h-4 text-[#0A66C2]" />
            <span>Complete Cohort Rankings ({timeframe.toUpperCase()})</span>
          </h3>

          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search by intern name..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-8 pr-3 py-1.5 text-xs border border-slate-200 rounded-xl focus:outline-none focus:border-[#0A66C2] text-slate-800 w-48"
            />
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-[11px] font-extrabold uppercase text-slate-500 tracking-wider">
                <th className="py-3 px-4 text-center w-16">Rank</th>
                <th className="py-3 px-4">Intern</th>
                <th className="py-3 px-4 text-center">Tasks Completed</th>
                <th className="py-3 px-4 text-center">Average Score</th>
                <th className="py-3 px-4 text-center">Total Points</th>
                <th className="py-3 px-4 text-right">Badges</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-xs">
              {filteredEntries.map((entry, idx) => {
                const isUser = entry.userId === user?.uid;
                return (
                  <tr
                    key={`lb-${entry.userId || 'user'}-${idx}`}
                    className={`transition-colors ${
                      isUser
                        ? 'bg-blue-50/80 font-semibold ring-1 ring-[#0A66C2]/30'
                        : 'hover:bg-slate-50'
                    }`}
                  >
                    {/* Rank */}
                    <td className="py-3.5 px-4 text-center">
                      {entry.rank === 1 ? (
                        <span className="inline-flex w-7 h-7 rounded-full bg-amber-100 text-amber-900 font-black items-center justify-center border border-amber-300 shadow-2xs">
                          🥇
                        </span>
                      ) : entry.rank === 2 ? (
                        <span className="inline-flex w-7 h-7 rounded-full bg-slate-100 text-slate-800 font-black items-center justify-center border border-slate-300 shadow-2xs">
                          🥈
                        </span>
                      ) : entry.rank === 3 ? (
                        <span className="inline-flex w-7 h-7 rounded-full bg-amber-50 text-amber-900 font-black items-center justify-center border border-amber-600/30 shadow-2xs">
                          🥉
                        </span>
                      ) : (
                        <span className="font-bold text-slate-500">#{entry.rank}</span>
                      )}
                    </td>

                    {/* Profile & Name */}
                    <td className="py-3.5 px-4">
                      <div className="flex items-center gap-2.5">
                        <div className="w-8 h-8 rounded-full bg-slate-200 text-slate-700 flex items-center justify-center font-bold text-xs shrink-0 overflow-hidden border border-slate-200">
                          {entry.userPhoto ? (
                            <img src={entry.userPhoto} alt={entry.userName} className="w-full h-full object-cover" />
                          ) : (
                            <span>{(entry.userName || 'I').slice(0, 1)}</span>
                          )}
                        </div>
                        <div>
                          <div className="flex items-center gap-1.5">
                            <span className="font-bold text-slate-900">{entry.userName}</span>
                            {isUser && (
                              <span className="px-1.5 py-0.2 bg-[#0A66C2] text-white text-[9px] font-black rounded tracking-wider">
                                YOU
                              </span>
                            )}
                          </div>
                          <span className="text-[10px] text-slate-400 block truncate max-w-[200px]">
                            {entry.domainName || 'Virtual Internship Track'}
                          </span>
                        </div>
                      </div>
                    </td>

                    {/* Tasks Completed */}
                    <td className="py-3.5 px-4 text-center">
                      <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold ${
                        entry.tasksCompleted === 5
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-slate-100 text-slate-700'
                      }`}>
                        {entry.tasksCompleted === 5 && <CheckCircle2 className="w-3 h-3 text-emerald-700" />}
                        <span>{entry.tasksCompleted} / 5</span>
                      </span>
                    </td>

                    {/* Average Score */}
                    <td className="py-3.5 px-4 text-center font-bold">
                      <span className={entry.averageScore >= 90 ? 'text-[#057642]' : entry.averageScore >= 80 ? 'text-[#0A66C2]' : 'text-slate-700'}>
                        {entry.averageScore > 0 ? `${entry.averageScore}%` : '--'}
                      </span>
                    </td>

                    {/* Total Points */}
                    <td className="py-3.5 px-4 text-center">
                      <span className="font-black text-slate-900 text-sm">
                        {entry.totalPoints}
                      </span>
                      <span className="text-[10px] text-slate-400 block">pts</span>
                    </td>

                    {/* Badges */}
                    <td className="py-3.5 px-4 text-right">
                      <div className="flex items-center justify-end gap-1 flex-wrap">
                        {Array.isArray(entry.badges) && entry.badges.length > 0 ? (
                          entry.badges.slice(0, 2).map((b, i) => (
                            <span
                              key={i}
                              className="px-2 py-0.5 bg-slate-100 text-slate-800 rounded-lg text-[10px] font-bold border border-slate-200"
                            >
                              {b}
                            </span>
                          ))
                        ) : (
                          <span className="text-[10px] text-slate-400">--</span>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}

              {filteredEntries.length === 0 && (
                <tr key="empty-row">
                  <td colSpan={6} className="py-8 text-center text-slate-500">
                    No interns found matching the selected filter.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
