import React, { useState, useEffect } from 'react';
import { CertificateRecord } from '../types';
import { dataService } from '../services/dataService';
import { ShieldCheck, Search, Award, CheckCircle2, XCircle, ArrowLeft, Calendar, User, BookOpen } from 'lucide-react';

interface CertificateVerificationProps {
  setCurrentView: (view: string) => void;
  initialCertId?: string;
}

export const CertificateVerification: React.FC<CertificateVerificationProps> = ({
  setCurrentView,
  initialCertId = ''
}) => {
  const [certIdInput, setCertIdInput] = useState(initialCertId);
  const [result, setResult] = useState<CertificateRecord | null>(null);
  const [searched, setSearched] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (initialCertId) {
      verifyId(initialCertId);
    }
  }, [initialCertId]);

  const verifyId = async (id: string) => {
    if (!id.trim()) return;
    setLoading(true);
    setSearched(true);
    const cert = await dataService.getCertificate(id.trim());
    setResult(cert);
    setLoading(false);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    verifyId(certIdInput);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-8">
      {/* Header */}
      <div className="text-center space-y-3">
        <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-[#EBF4FD] border border-[#0A66C2]/30 text-[#0A66C2] text-xs font-semibold">
          <ShieldCheck className="w-4 h-4 text-[#0A66C2]" />
          <span>Public Credential Verification Service</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-[#191919] tracking-tight">
          Verify VirIntern Certificate
        </h1>
        <p className="text-sm text-[#666666] max-w-xl mx-auto">
          Confirm the authenticity and completion status of credentials issued by the VirIntern Virtual Internship Council.
        </p>
      </div>

      {/* Search Input Box */}
      <div className="bg-white p-6 rounded-xl border border-[#E0DFDC] shadow-xs max-w-2xl mx-auto">
        <form onSubmit={handleSubmit} className="flex gap-2">
          <div className="relative flex-1">
            <Search className="w-5 h-5 text-[#666666] absolute left-3.5 top-3.5" />
            <input
              type="text"
              value={certIdInput}
              onChange={(e) => setCertIdInput(e.target.value.toUpperCase())}
              placeholder="e.g. VI-2026-WD-104928"
              className="w-full pl-10 pr-4 py-2.5 text-sm font-mono uppercase bg-white border border-[#E0DFDC] rounded-xl focus:border-[#0A66C2] focus:ring-1 focus:ring-[#0A66C2] outline-none text-[#191919]"
            />
          </div>
          <button
            type="submit"
            disabled={loading || !certIdInput.trim()}
            className="px-6 py-2.5 bg-[#0A66C2] hover:bg-[#004182] text-white font-semibold text-xs rounded-full shadow-xs transition-colors flex items-center gap-1.5"
          >
            {loading ? 'Checking...' : 'Verify Now'}
          </button>
        </form>

        {/* Certificate format tip */}
        <div className="mt-3 pt-3 border-t border-[#E0DFDC] flex items-center justify-between text-[11px] text-[#666666]">
          <span>Official VirIntern Credential Format: <strong className="font-mono text-[#191919]">VI-YYYY-DOMAIN-XXXXXX</strong></span>
          <span className="text-[#057642] font-medium flex items-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5 text-[#057642]" /> 256-Bit Tamper Proof
          </span>
        </div>
      </div>

      {/* Verification Result Card (PRD Section 24) */}
      {searched && (
        <div className="max-w-2xl mx-auto animate-fadeIn">
          {result ? (
            <div className="bg-white rounded-3xl border-2 border-emerald-500/40 p-8 shadow-xl relative overflow-hidden">
              <div className="absolute top-0 right-0 bg-emerald-500 text-white text-[11px] font-extrabold uppercase px-4 py-1 rounded-bl-xl tracking-wider">
                ✓ Officially Verified
              </div>

              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 rounded-2xl bg-emerald-100 text-emerald-700 flex items-center justify-center">
                  <ShieldCheck className="w-7 h-7" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-slate-900">Valid Credential Confirmed</h3>
                  <p className="text-xs text-slate-500 font-mono">Certificate ID: {result.certificateId}</p>
                </div>
              </div>

              {/* Data fields without exposing personal private information (PRD Section 24) */}
              <div className="space-y-3 bg-slate-50 p-5 rounded-2xl border border-slate-200 text-xs">
                <div className="flex justify-between py-1.5 border-b border-slate-200">
                  <span className="text-slate-500 flex items-center gap-1.5">
                    <User className="w-3.5 h-3.5 text-slate-400" />
                    Student Name
                  </span>
                  <span className="font-bold text-slate-900 text-sm">{result.studentName}</span>
                </div>

                <div className="flex justify-between py-1.5 border-b border-slate-200">
                  <span className="text-slate-500 flex items-center gap-1.5">
                    <BookOpen className="w-3.5 h-3.5 text-slate-400" />
                    Internship Domain
                  </span>
                  <span className="font-semibold text-indigo-700">{result.internshipDomain}</span>
                </div>

                <div className="flex justify-between py-1.5 border-b border-slate-200">
                  <span className="text-slate-500 flex items-center gap-1.5">
                    <Award className="w-3.5 h-3.5 text-slate-400" />
                    Certificate Type
                  </span>
                  <span className="font-semibold text-slate-800">
                    Certificate of {result.type} ({result.grade || 'Passed'})
                  </span>
                </div>

                <div className="flex justify-between py-1.5 border-b border-slate-200">
                  <span className="text-slate-500 flex items-center gap-1.5">
                    <Calendar className="w-3.5 h-3.5 text-slate-400" />
                    Completion Date
                  </span>
                  <span className="font-medium text-slate-800">{result.completionDate}</span>
                </div>

                <div className="flex justify-between py-1.5">
                  <span className="text-slate-500">Status</span>
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-emerald-100 text-emerald-800">
                    Active & Valid
                  </span>
                </div>
              </div>

              <div className="mt-5 text-center text-[11px] text-slate-400">
                Issued by VirIntern Virtual Internship Portal • Backed by 5 Practical Projects
              </div>
            </div>
          ) : (
            <div className="bg-white rounded-2xl border border-rose-200 p-8 text-center space-y-3 shadow-sm">
              <div className="w-12 h-12 bg-rose-100 text-rose-600 rounded-full flex items-center justify-center mx-auto">
                <XCircle className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-slate-900">Certificate Not Found</h3>
              <p className="text-xs text-slate-600 max-w-sm mx-auto">
                No record matches certificate ID <strong className="font-mono text-slate-900">{certIdInput}</strong>. Please verify the ID format or contact VirIntern support.
              </p>
            </div>
          )}
        </div>
      )}

      {/* Return button */}
      <div className="text-center pt-4">
        <button
          onClick={() => setCurrentView('landing')}
          className="text-xs text-slate-500 hover:text-slate-800 font-semibold inline-flex items-center gap-1.5"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Back to Home</span>
        </button>
      </div>
    </div>
  );
};
