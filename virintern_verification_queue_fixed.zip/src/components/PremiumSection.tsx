import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { dataService } from '../services/dataService';
import { PackageConfig, PackageBenefit } from '../types';
import { ResumeBuilder } from './ResumeBuilder';
import { InterviewPrep } from './InterviewPrep';
import { CompletionView } from './CompletionView';
import confetti from 'canvas-confetti';
import {
  Crown,
  Lock,
  Unlock,
  CheckCircle2,
  Sparkles,
  FileText,
  BookOpen,
  Award,
  ArrowRight,
  ShieldCheck,
  Star,
  Download,
  ExternalLink,
  ChevronRight,
  Zap,
  Briefcase,
  HelpCircle,
  X
} from 'lucide-react';

interface PremiumSectionProps {
  setCurrentView: (view: string) => void;
  openEmailSimulator?: () => void;
}

export const PremiumSection: React.FC<PremiumSectionProps> = ({
  setCurrentView,
  openEmailSimulator
}) => {
  const { user, activeInternship, refreshProfile } = useAuth();
  const [packageConfig, setPackageConfig] = useState<PackageConfig | null>(null);
  const [benefits, setBenefits] = useState<PackageBenefit[]>([]);
  const [activeTab, setActiveTab] = useState<'overview' | 'resume' | 'interview' | 'credentials' | 'toolkit'>('overview');
  const [paymentModalOpen, setPaymentModalOpen] = useState(false);
  const [paymentStep, setPaymentStep] = useState<'idle' | 'processing' | 'success'>('idle');
  const [paymentId, setPaymentId] = useState('');
  const [downloadToast, setDownloadToast] = useState<string | null>(null);

  const isUnlocked = Boolean(user?.hasPaidPackage || user?.role === 'admin');

  useEffect(() => {
    // Always scroll to top when opening premium section
    window.scrollTo({ top: 0, left: 0, behavior: 'instant' });

    dataService.getPackageConfig().then(setPackageConfig);
    dataService.getPackageBenefits(true).then(setBenefits);
  }, []);

  const handleSimulatePayment = async () => {
    if (!user || !packageConfig) return;
    setPaymentStep('processing');

    const fakePaymentId = `pay_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`;
    setPaymentId(fakePaymentId);

    setTimeout(async () => {
      // Issue certificates if internship exists
      if (activeInternship) {
        await dataService.issueCertificates(user, activeInternship);
      }

      // Update user state
      const updatedUser = {
        ...user,
        hasPaidPackage: true,
        paidPackageAt: new Date().toISOString()
      };
      await dataService.saveUser(updatedUser);

      // Process referral rewards (10% reward)
      await dataService.processReferralPurchase(user.uid, packageConfig.price);

      // Log notification & email
      await dataService.addNotification({
        userId: user.uid,
        title: 'Premium Package Unlocked! 👑',
        message: 'Your official completion credentials, certificates, ATS resume kit, and 1000 QA bank are now active.',
        type: 'reward'
      });

      await dataService.logEmail({
        to: user.email,
        subject: 'Welcome to VirIntern Premium Career Suite',
        preview: `Payment of ₹${packageConfig.price} verified. All premium benefits, certificates, and kits are now unlocked!`,
        type: 'package_ready'
      });

      await refreshProfile();

      setPaymentStep('success');
      confetti({
        particleCount: 100,
        spread: 80,
        origin: { y: 0.6 }
      });
    }, 1200);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 animate-fadeIn">
      {/* Top Banner */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-slate-900 via-indigo-950 to-[#0A66C2] text-white p-8 sm:p-10 shadow-xl border border-slate-700">
        <div className="absolute top-0 right-0 -mr-16 -mt-16 w-80 h-80 rounded-full bg-indigo-500/10 blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 right-10 opacity-10 pointer-events-none">
          <Crown className="w-64 h-64 text-amber-400" />
        </div>

        <div className="relative z-10 max-w-3xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-400/20 border border-amber-300/30 text-amber-300 text-xs font-bold mb-4 backdrop-blur-sm">
            <Crown className="w-3.5 h-3.5 text-amber-400" />
            <span>VIRINTERN PREMIUM SUITE</span>
            {isUnlocked ? (
              <span className="ml-1 px-2 py-0.2 rounded-full bg-emerald-500 text-white text-[10px] font-extrabold flex items-center gap-1">
                <CheckCircle2 className="w-2.5 h-2.5" />
                ACTIVE
              </span>
            ) : (
              <span className="ml-1 px-2 py-0.2 rounded-full bg-amber-500 text-slate-900 text-[10px] font-extrabold flex items-center gap-1">
                <Lock className="w-2.5 h-2.5" />
                LOCKED
              </span>
            )}
          </div>

          <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-white mb-3">
            Career Acceleration & Placement Suite
          </h1>
          <p className="text-slate-300 text-sm sm:text-base leading-relaxed mb-6">
            Everything ambitious engineers and professionals need to convert virtual internship projects into full-time job offers: ATS Resume Builder, 1,000+ Domain Q&A, and Verified Credentials.
          </p>

          {isUnlocked ? (
            <div className="flex flex-wrap items-center gap-3">
              <span className="px-4 py-2 rounded-xl bg-emerald-500/20 border border-emerald-400/30 text-emerald-300 font-semibold text-xs flex items-center gap-2">
                <Unlock className="w-4 h-4 text-emerald-400" />
                <span>All Premium Tools & Credentials Unlocked</span>
              </span>
              <button
                onClick={() => setActiveTab('resume')}
                className="px-4 py-2 bg-white hover:bg-slate-100 text-slate-900 text-xs font-bold rounded-xl transition-all shadow-md flex items-center gap-1.5"
              >
                <FileText className="w-3.5 h-3.5 text-[#0A66C2]" />
                <span>Launch Resume Kit</span>
              </button>
              <button
                onClick={() => setActiveTab('interview')}
                className="px-4 py-2 bg-[#0A66C2] hover:bg-[#004182] text-white text-xs font-bold rounded-xl transition-all shadow-md flex items-center gap-1.5"
              >
                <BookOpen className="w-3.5 h-3.5 text-white" />
                <span>Browse 1000+ Q&A Bank</span>
              </button>
            </div>
          ) : (
            <div className="flex flex-wrap items-center gap-4">
              <button
                onClick={() => setPaymentModalOpen(true)}
                className="px-6 py-3 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-500 hover:to-amber-600 text-slate-950 font-extrabold text-sm rounded-xl shadow-lg transition-all transform hover:-translate-y-0.5 flex items-center gap-2"
              >
                <Crown className="w-4 h-4 text-slate-950" />
                <span>Unlock All Benefits — ₹{packageConfig?.price || 499}</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <div className="flex items-center gap-2 text-xs text-slate-300">
                <Lock className="w-3.5 h-3.5 text-amber-400" />
                <span>Currently locked for your account</span>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Navigation Tabs (Available if unlocked, or for previewing locked modules) */}
      <div className="flex items-center gap-2 border-b border-[#E0DFDC] pb-2 overflow-x-auto">
        <button
          onClick={() => setActiveTab('overview')}
          className={`px-4 py-2 text-xs sm:text-sm font-bold rounded-xl transition-colors flex items-center gap-2 whitespace-nowrap ${
            activeTab === 'overview'
              ? 'bg-[#0A66C2] text-white shadow-xs'
              : 'text-[#666666] hover:text-[#191919] hover:bg-[#EBF4FD]'
          }`}
        >
          <Sparkles className="w-4 h-4" />
          <span>Premium Overview</span>
        </button>

        <button
          onClick={() => setActiveTab('resume')}
          className={`px-4 py-2 text-xs sm:text-sm font-bold rounded-xl transition-colors flex items-center gap-2 whitespace-nowrap ${
            activeTab === 'resume'
              ? 'bg-[#0A66C2] text-white shadow-xs'
              : 'text-[#666666] hover:text-[#191919] hover:bg-[#EBF4FD]'
          }`}
        >
          <FileText className="w-4 h-4" />
          <span>ATS Resume Builder</span>
          {!isUnlocked && <Lock className="w-3 h-3 text-amber-500" />}
        </button>

        <button
          onClick={() => setActiveTab('interview')}
          className={`px-4 py-2 text-xs sm:text-sm font-bold rounded-xl transition-colors flex items-center gap-2 whitespace-nowrap ${
            activeTab === 'interview'
              ? 'bg-[#0A66C2] text-white shadow-xs'
              : 'text-[#666666] hover:text-[#191919] hover:bg-[#EBF4FD]'
          }`}
        >
          <BookOpen className="w-4 h-4" />
          <span>1000+ Interview Q&A Bank</span>
          {!isUnlocked && <Lock className="w-3 h-3 text-amber-500" />}
        </button>

        <button
          onClick={() => setActiveTab('credentials')}
          className={`px-4 py-2 text-xs sm:text-sm font-bold rounded-xl transition-colors flex items-center gap-2 whitespace-nowrap ${
            activeTab === 'credentials'
              ? 'bg-[#0A66C2] text-white shadow-xs'
              : 'text-[#666666] hover:text-[#191919] hover:bg-[#EBF4FD]'
          }`}
        >
          <Award className="w-4 h-4" />
          <span>Verified Credentials & LOR</span>
          {!isUnlocked && <Lock className="w-3 h-3 text-amber-500" />}
        </button>

        <button
          onClick={() => setActiveTab('toolkit')}
          className={`px-4 py-2 text-xs sm:text-sm font-bold rounded-xl transition-colors flex items-center gap-2 whitespace-nowrap ${
            activeTab === 'toolkit'
              ? 'bg-[#0A66C2] text-white shadow-xs'
              : 'text-[#666666] hover:text-[#191919] hover:bg-[#EBF4FD]'
          }`}
        >
          <Briefcase className="w-4 h-4" />
          <span>Career Resources & Downloads</span>
          {!isUnlocked && <Lock className="w-3 h-3 text-amber-500" />}
        </button>
      </div>

      {/* Tab 1: Overview & Locked Feature Cards */}
      {activeTab === 'overview' && (
        <div className="space-y-8">
          {/* Lock notice card if not paid */}
          {!isUnlocked && (
            <div className="p-5 rounded-2xl bg-amber-50 border border-amber-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center font-bold shrink-0">
                  <Lock className="w-5 h-5 text-amber-700" />
                </div>
                <div>
                  <h3 className="font-bold text-sm text-amber-950">
                    Premium Section is Locked
                  </h3>
                  <p className="text-xs text-amber-800">
                    Purchase the VirIntern Completion Package for ₹{packageConfig?.price || 499} to unlock instant full access to all features below.
                  </p>
                </div>
              </div>

              <button
                onClick={() => setPaymentModalOpen(true)}
                className="px-4 py-2 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs rounded-xl shadow-xs transition-colors shrink-0 flex items-center gap-1.5"
              >
                <Crown className="w-3.5 h-3.5" />
                <span>Unlock All Benefits</span>
              </button>
            </div>
          )}

          {/* Feature Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* 1. ATS Resume Kit */}
            <div className="bg-white rounded-2xl border border-[#E0DFDC] p-6 shadow-xs flex flex-col justify-between hover:border-[#0A66C2]/40 transition-all">
              <div>
                <div className="flex items-center justify-between mb-4">
                  <div className="w-12 h-12 rounded-xl bg-blue-50 text-[#0A66C2] flex items-center justify-center font-bold">
                    <FileText className="w-6 h-6" />
                  </div>
                  {isUnlocked ? (
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200 flex items-center gap-1">
                      <CheckCircle2 className="w-2.5 h-2.5" />
                      UNLOCKED
                    </span>
                  ) : (
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800 border border-amber-200 flex items-center gap-1">
                      <Lock className="w-2.5 h-2.5" />
                      LOCKED
                    </span>
                  )}
                </div>

                <h3 className="text-lg font-bold text-[#191919] mb-1">ATS Resume Builder & Kit</h3>
                <p className="text-xs text-[#666666] leading-relaxed mb-4">
                  Complete interactive resume builder with real-time preview, high-impact bullet formulas, ATS keyword scoring, and printable PDF export.
                </p>

                <ul className="text-xs text-slate-600 space-y-1.5 mb-6">
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#057642]" />
                    <span>Domain-tailored experience summaries</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#057642]" />
                    <span>Single-click Clean PDF export</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#057642]" />
                    <span>ATS formatting standards</span>
                  </li>
                </ul>
              </div>

              <button
                onClick={() => setActiveTab('resume')}
                className={`w-full py-2.5 px-4 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 ${
                  isUnlocked
                    ? 'bg-[#0A66C2] hover:bg-[#004182] text-white shadow-xs'
                    : 'bg-[#F4F2EE] hover:bg-[#E0DFDC] text-[#191919] border border-[#E0DFDC]'
                }`}
              >
                <span>{isUnlocked ? 'Open Resume Builder' : 'Preview Resume Kit (Locked)'}</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>

            {/* 2. 1000+ Interview Q&A */}
            <div className="bg-white rounded-2xl border border-[#E0DFDC] p-6 shadow-xs flex flex-col justify-between hover:border-[#0A66C2]/40 transition-all">
              <div>
                <div className="flex items-center justify-between mb-4">
                  <div className="w-12 h-12 rounded-xl bg-emerald-50 text-[#057642] flex items-center justify-center font-bold">
                    <BookOpen className="w-6 h-6" />
                  </div>
                  {isUnlocked ? (
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200 flex items-center gap-1">
                      <CheckCircle2 className="w-2.5 h-2.5" />
                      UNLOCKED
                    </span>
                  ) : (
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800 border border-amber-200 flex items-center gap-1">
                      <Lock className="w-2.5 h-2.5" />
                      LOCKED
                    </span>
                  )}
                </div>

                <h3 className="text-lg font-bold text-[#191919] mb-1">1,000+ Interview Q&A Bank</h3>
                <p className="text-xs text-[#666666] leading-relaxed mb-4">
                  Curated interview questions across 12 tech domains including Frontend, Backend, AI/ML, ECE, Cloud, DSA, and Behavioral STAR method.
                </p>

                <ul className="text-xs text-slate-600 space-y-1.5 mb-6">
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#057642]" />
                    <span>Real-world technical coding scenarios</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#057642]" />
                    <span>System design & architectural tradeoffs</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#057642]" />
                    <span>HR STAR behavioral response templates</span>
                  </li>
                </ul>
              </div>

              <button
                onClick={() => setActiveTab('interview')}
                className={`w-full py-2.5 px-4 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 ${
                  isUnlocked
                    ? 'bg-[#057642] hover:bg-[#046237] text-white shadow-xs'
                    : 'bg-[#F4F2EE] hover:bg-[#E0DFDC] text-[#191919] border border-[#E0DFDC]'
                }`}
              >
                <span>{isUnlocked ? 'Explore All Questions' : 'Preview Q&A Bank (Locked)'}</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>

            {/* 3. Verified Certificates & LOR */}
            <div className="bg-white rounded-2xl border border-[#E0DFDC] p-6 shadow-xs flex flex-col justify-between hover:border-[#0A66C2]/40 transition-all">
              <div>
                <div className="flex items-center justify-between mb-4">
                  <div className="w-12 h-12 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center font-bold">
                    <Award className="w-6 h-6" />
                  </div>
                  {isUnlocked ? (
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200 flex items-center gap-1">
                      <CheckCircle2 className="w-2.5 h-2.5" />
                      UNLOCKED
                    </span>
                  ) : (
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800 border border-amber-200 flex items-center gap-1">
                      <Lock className="w-2.5 h-2.5" />
                      LOCKED
                    </span>
                  )}
                </div>

                <h3 className="text-lg font-bold text-[#191919] mb-1">Verified Certificate & LOR</h3>
                <p className="text-xs text-[#666666] leading-relaxed mb-4">
                  Tamper-proof verifiable completion certificate with unique cryptographic ID, QR code, signed Letter of Recommendation, and Digital Badge.
                </p>

                <ul className="text-xs text-slate-600 space-y-1.5 mb-6">
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#057642]" />
                    <span>Permanent QR verification URL</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#057642]" />
                    <span>Official Letter of Recommendation (LOR)</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#057642]" />
                    <span>1-Click LinkedIn Certificate import</span>
                  </li>
                </ul>
              </div>

              <button
                onClick={() => setActiveTab('credentials')}
                className={`w-full py-2.5 px-4 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 ${
                  isUnlocked
                    ? 'bg-purple-600 hover:bg-purple-700 text-white shadow-xs'
                    : 'bg-[#F4F2EE] hover:bg-[#E0DFDC] text-[#191919] border border-[#E0DFDC]'
                }`}
              >
                <span>{isUnlocked ? 'View Credentials' : 'Check Requirements (Locked)'}</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Dynamic Benefits Checklist from Admin Settings */}
          {benefits.length > 0 && (
            <div className="bg-white rounded-2xl border border-[#E0DFDC] p-6 shadow-xs space-y-4">
              <div className="flex items-center justify-between border-b border-[#E0DFDC] pb-3">
                <h3 className="text-base font-bold text-[#191919]">
                  Complete Premium Deliverables Included
                </h3>
                <span className="text-xs text-[#666666]">
                  {benefits.length} Core Career Assets
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {benefits.map((b) => (
                  <div
                    key={b.id}
                    className={`p-4 rounded-xl border flex items-start gap-3 transition-colors ${
                      isUnlocked
                        ? 'bg-[#E8F5E9]/50 border-[#C8E6C9]'
                        : 'bg-[#F4F2EE] border-[#E0DFDC]'
                    }`}
                  >
                    <div className="w-8 h-8 rounded-lg bg-white border border-[#E0DFDC] flex items-center justify-center shrink-0">
                      {isUnlocked ? (
                        <CheckCircle2 className="w-4 h-4 text-[#057642]" />
                      ) : (
                        <Lock className="w-4 h-4 text-amber-600" />
                      )}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="text-xs font-bold text-[#191919]">{b.title}</h4>
                        {isUnlocked ? (
                          <span className="text-[10px] text-[#057642] font-semibold bg-emerald-100 px-1.5 py-0.2 rounded">
                            Unlocked
                          </span>
                        ) : (
                          <span className="text-[10px] text-amber-700 font-semibold bg-amber-100 px-1.5 py-0.2 rounded">
                            Locked
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-[#666666] mt-0.5">{b.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Bottom Upgrade CTA if locked */}
          {!isUnlocked && (
            <div className="text-center p-8 bg-gradient-to-b from-[#EBF4FD] to-white rounded-2xl border border-[#0A66C2]/20 shadow-xs space-y-4">
              <Crown className="w-10 h-10 text-amber-500 mx-auto" />
              <h3 className="text-xl font-extrabold text-[#191919]">
                Ready to Boost Your Technical Career?
              </h3>
              <p className="text-xs text-[#666666] max-w-md mx-auto">
                Get full access to the ATS Resume Builder, 1,000+ Interview Questions, and official verified credentials for just ₹{packageConfig?.price || 499}.
              </p>
              <button
                onClick={() => setPaymentModalOpen(true)}
                className="px-6 py-3 bg-[#0A66C2] hover:bg-[#004182] text-white font-extrabold text-sm rounded-full shadow-md transition-all inline-flex items-center gap-2"
              >
                <span>Unlock All Benefits Now — ₹{packageConfig?.price || 499}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      )}

      {/* Tab 2: Embedded Resume Builder */}
      {activeTab === 'resume' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between bg-white p-4 rounded-xl border border-[#E0DFDC]">
            <div className="flex items-center gap-2">
              <FileText className="w-5 h-5 text-[#0A66C2]" />
              <div>
                <h3 className="text-sm font-bold text-[#191919]">ATS Resume Builder & Kit</h3>
                <p className="text-xs text-[#666666]">Craft tailored technical resumes with high ATS score adherence.</p>
              </div>
            </div>
            {!isUnlocked && (
              <button
                onClick={() => setPaymentModalOpen(true)}
                className="px-3 py-1.5 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs rounded-lg transition-colors flex items-center gap-1.5 shadow-2xs"
              >
                <Lock className="w-3.5 h-3.5" />
                <span>Unlock Full Access</span>
              </button>
            )}
          </div>
          <ResumeBuilder setCurrentView={setCurrentView} />
        </div>
      )}

      {/* Tab 3: Embedded 1000+ Interview Prep */}
      {activeTab === 'interview' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between bg-white p-4 rounded-xl border border-[#E0DFDC]">
            <div className="flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-[#057642]" />
              <div>
                <h3 className="text-sm font-bold text-[#191919]">1,000+ Technical & Behavioral Interview Q&A</h3>
                <p className="text-xs text-[#666666]">Master technical interviews across all 12 domains.</p>
              </div>
            </div>
            {!isUnlocked && (
              <button
                onClick={() => setPaymentModalOpen(true)}
                className="px-3 py-1.5 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs rounded-lg transition-colors flex items-center gap-1.5 shadow-2xs"
              >
                <Lock className="w-3.5 h-3.5" />
                <span>Unlock All Questions</span>
              </button>
            )}
          </div>
          <InterviewPrep setCurrentView={setCurrentView} />
        </div>
      )}

      {/* Tab 4: Verified Credentials & LOR */}
      {activeTab === 'credentials' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between bg-white p-4 rounded-xl border border-[#E0DFDC]">
            <div className="flex items-center gap-2">
              <Award className="w-5 h-5 text-purple-600" />
              <div>
                <h3 className="text-sm font-bold text-[#191919]">Verified Credentials Hub</h3>
                <p className="text-xs text-[#666666]">Access your verified certificate, LOR, and digital credentials.</p>
              </div>
            </div>
            {!isUnlocked && (
              <button
                onClick={() => setPaymentModalOpen(true)}
                className="px-3 py-1.5 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs rounded-lg transition-colors flex items-center gap-1.5 shadow-2xs"
              >
                <Lock className="w-3.5 h-3.5" />
                <span>Unlock Credentials</span>
              </button>
            )}
          </div>
          <CompletionView
            setCurrentView={setCurrentView}
            openEmailSimulator={openEmailSimulator || (() => {})}
          />
        </div>
      )}

      {/* Tab 5: Downloadable Career Toolkit */}
      {activeTab === 'toolkit' && (
        <div className="bg-white rounded-2xl border border-[#E0DFDC] p-6 shadow-xs space-y-6">
          <div className="border-b border-[#E0DFDC] pb-4">
            <h3 className="text-lg font-bold text-[#191919]">Downloadable Placement Toolkit</h3>
            <p className="text-xs text-[#666666]">Curated cheat sheets, architecture blueprints, and cold email scripts.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {[
              {
                title: 'High-Impact Technical Resume Action Verbs & Bullet Formulas',
                type: 'PDF Guide',
                size: '2.4 MB'
              },
              {
                title: 'FAANG & Top Startup System Design Cheatsheet 2026',
                type: 'PDF Reference',
                size: '4.8 MB'
              },
              {
                title: 'STAR Method Behavioral Interview Mastery Workbook',
                type: 'PDF Template',
                size: '1.9 MB'
              },
              {
                title: 'Cold Outreach & LinkedIn InMail Templates for Referrals',
                type: 'DOCX / Markdown',
                size: '1.1 MB'
              },
              {
                title: 'Domain Project Architecture & Git Clean Commit Standards',
                type: 'PDF Guide',
                size: '3.1 MB'
              },
              {
                title: 'Salary Negotiation & Offer Countering Playbook',
                type: 'Executive Guide',
                size: '1.5 MB'
              }
            ].map((res, i) => (
              <div
                key={i}
                className="p-4 rounded-xl border border-[#E0DFDC] flex items-center justify-between hover:bg-[#F4F2EE] transition-colors"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-blue-50 text-[#0A66C2] flex items-center justify-center shrink-0">
                    <Download className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-[#191919]">{res.title}</h4>
                    <p className="text-[11px] text-[#666666]">
                      {res.type} • {res.size}
                    </p>
                  </div>
                </div>

                {isUnlocked ? (
                  <button
                    onClick={() => {
                      confetti({ particleCount: 25, spread: 40 });
                      setDownloadToast(`Downloading ${res.title}...`);
                      setTimeout(() => setDownloadToast(null), 3000);
                    }}
                    className="px-3 py-1.5 bg-[#0A66C2] hover:bg-[#004182] text-white font-bold text-xs rounded-lg transition-colors flex items-center gap-1 shrink-0"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download</span>
                  </button>
                ) : (
                  <button
                    onClick={() => setPaymentModalOpen(true)}
                    className="px-3 py-1.5 bg-[#F4F2EE] text-[#666666] font-semibold text-xs rounded-lg border border-[#E0DFDC] hover:text-[#191919] flex items-center gap-1 shrink-0"
                  >
                    <Lock className="w-3.5 h-3.5 text-amber-600" />
                    <span>Locked</span>
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Payment / Unlock Modal */}
      {paymentModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-xs animate-fadeIn">
          <div className="bg-white max-w-md w-full rounded-2xl shadow-2xl border border-slate-200 p-6 relative">
            <button
              onClick={() => {
                setPaymentModalOpen(false);
                setPaymentStep('idle');
              }}
              className="absolute top-4 right-4 p-1.5 text-slate-400 hover:text-slate-600 rounded-full hover:bg-slate-100 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            {paymentStep === 'idle' && (
              <div className="space-y-5 text-center">
                <div className="w-14 h-14 rounded-2xl bg-amber-100 text-amber-800 flex items-center justify-center mx-auto shadow-xs border border-amber-200">
                  <Crown className="w-7 h-7 text-amber-600" />
                </div>

                <div>
                  <h3 className="text-xl font-extrabold text-slate-900">
                    Unlock Premium Suite
                  </h3>
                  <p className="text-xs text-slate-600 mt-1">
                    Instant lifetime access to the complete career tools, ATS Resume Kit, 1,000+ Q&A Bank, and verified credentials.
                  </p>
                </div>

                <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 text-left space-y-2 text-xs">
                  <div className="flex justify-between items-center">
                    <span className="text-slate-600">Package:</span>
                    <span className="font-bold text-slate-900">{packageConfig?.title || 'VirIntern Completion Package'}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-slate-600">Access:</span>
                    <span className="font-bold text-emerald-600">Lifetime Instant Access</span>
                  </div>
                  <div className="flex justify-between items-center pt-2 border-t border-slate-200 text-sm">
                    <span className="font-bold text-slate-900">Total Price:</span>
                    <span className="font-extrabold text-[#0A66C2] text-lg">₹{packageConfig?.price || 499}</span>
                  </div>
                </div>

                <button
                  onClick={handleSimulatePayment}
                  className="w-full py-3 bg-[#0A66C2] hover:bg-[#004182] text-white font-extrabold text-sm rounded-xl shadow-md transition-all flex items-center justify-center gap-2"
                >
                  <Lock className="w-4 h-4" />
                  <span>Pay ₹{packageConfig?.price || 499} via Razorpay</span>
                </button>
              </div>
            )}

            {paymentStep === 'processing' && (
              <div className="py-10 text-center space-y-4">
                <div className="w-12 h-12 border-4 border-[#0A66C2] border-t-transparent rounded-full animate-spin mx-auto" />
                <h3 className="text-base font-bold text-slate-900">Verifying Payment...</h3>
                <p className="text-xs text-slate-500 font-mono">Reference: {paymentId}</p>
              </div>
            )}

            {paymentStep === 'success' && (
              <div className="text-center space-y-5 py-4">
                <div className="w-14 h-14 rounded-2xl bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto shadow-xs border border-emerald-200">
                  <CheckCircle2 className="w-8 h-8 text-emerald-600" />
                </div>

                <div>
                  <h3 className="text-xl font-extrabold text-slate-900">
                    Payment Successful! 🎉
                  </h3>
                  <p className="text-xs text-slate-600 mt-1">
                    All premium features and verified deliverables are now completely unlocked!
                  </p>
                </div>

                <button
                  onClick={() => {
                    setPaymentModalOpen(false);
                    setPaymentStep('idle');
                    setActiveTab('resume');
                  }}
                  className="w-full py-3 bg-[#057642] hover:bg-[#046237] text-white font-extrabold text-sm rounded-xl shadow-md transition-all flex items-center justify-center gap-2"
                >
                  <span>Explore Premium Tools Now</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {downloadToast && (
        <div className="fixed bottom-6 right-6 z-50 bg-slate-900 text-white px-4 py-3 rounded-xl shadow-xl flex items-center gap-2.5 text-xs font-semibold animate-fadeIn">
          <Download className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{downloadToast}</span>
        </div>
      )}
    </div>
  );
};
