import React, { useState, useEffect } from 'react';
import {
  Trophy,
  Award,
  Sparkles,
  TrendingUp,
  CheckCircle2,
  AlertCircle,
  Calendar,
  Layers,
  ArrowRight,
  ArrowLeft,
  Star,
  ShieldCheck,
  ChevronRight,
  ExternalLink,
  Target,
  Zap,
  BookOpen
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { dataService } from '../services/dataService';
import { TaskEvaluationRecord } from '../types';
import { StudentEvaluationModal } from './StudentEvaluationModal';

interface MyPerformanceViewProps {
  onBackToDashboard?: () => void;
  onNavigateToLeaderboard?: () => void;
  onNavigateToTasks?: () => void;
}

export const MyPerformanceView: React.FC<MyPerformanceViewProps> = ({
  onBackToDashboard,
  onNavigateToLeaderboard,
  onNavigateToTasks
}) => {
  const { user, activeInternship } = useAuth();
  const [loading, setLoading] = useState(true);
  const [performance, setPerformance] = useState<any>(null);
  const [selectedEvaluation, setSelectedEvaluation] = useState<TaskEvaluationRecord | null>(null);
  const [modalOpen, setModalOpen] = useState(false);

  useEffect(() => {
    if (!user) return;
    dataService.ensureLiveEvents();

    const loadPerf = (showLoader = false) => {
      if (showLoader) setLoading(true);
      dataService.getUserPerformance(user.uid)
        .then((data) => {
          setPerformance(data);
          setLoading(false);
        })
        .catch((err) => {
          console.error('Failed to load performance metrics:', err);
          setLoading(false);
        });
    };

    loadPerf(true);

    const refreshSilent = () => loadPerf(false);
    const unsubLb = dataService.on('leaderboard_updated', refreshSilent);
    const unsubVer = dataService.on('submission_verified', refreshSilent);
    const unsubSub = dataService.on('submission_updated', refreshSilent);

    if (typeof window !== 'undefined') {
      window.addEventListener('virintern_leaderboard_updated', refreshSilent);
      window.addEventListener('virintern_submission_updated', refreshSilent);
    }

    return () => {
      unsubLb();
      unsubVer();
      unsubSub();
      if (typeof window !== 'undefined') {
        window.removeEventListener('virintern_leaderboard_updated', refreshSilent);
        window.removeEventListener('virintern_submission_updated', refreshSilent);
      }
    };
  }, [user]);

  const openEvaluationModal = (evaluation: TaskEvaluationRecord) => {
    setSelectedEvaluation(evaluation);
    setModalOpen(true);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8 space-y-6 sm:space-y-8 animate-fadeIn">
      {/* Top Header */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            {onBackToDashboard && (
              <button
                type="button"
                onClick={onBackToDashboard}
                className="inline-flex items-center gap-1 text-xs font-bold text-slate-500 hover:text-[#0A66C2] mr-2 transition-colors cursor-pointer"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Dashboard</span>
              </button>
            )}
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wider bg-blue-100 text-[#0A66C2] border border-blue-200 flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-[#0A66C2]" />
              <span>Verified Analytics</span>
            </span>
          </div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 flex items-center gap-2">
            <span>My Internship Performance</span>
          </h1>
          <p className="text-xs text-slate-600 mt-1 max-w-2xl">
            Live metric tracking across verified tasks, mentor review quality scores, difficulty tiers, and cohort rank.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          {onNavigateToLeaderboard && (
            <button
              type="button"
              onClick={onNavigateToLeaderboard}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold rounded-xl transition-colors flex items-center gap-1.5"
            >
              <Trophy className="w-3.5 h-3.5 text-amber-600" />
              <span>View Leaderboard</span>
            </button>
          )}
          {onNavigateToTasks && (
            <button
              type="button"
              onClick={onNavigateToTasks}
              className="px-4 py-2 bg-[#0A66C2] hover:bg-[#004182] text-white text-xs font-bold rounded-xl shadow-xs transition-colors flex items-center gap-1.5"
            >
              <span>Submit Next Task</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Top 4 KPI Metrics */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        {/* Total Points */}
        <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider">Total Points</span>
            <div className="w-7 h-7 rounded-lg bg-amber-50 text-amber-700 flex items-center justify-center">
              <Zap className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl sm:text-3xl font-black text-slate-900">
            {performance?.totalPoints || 0} <span className="text-xs font-bold text-slate-400">pts</span>
          </p>
          <p className="text-[10px] text-amber-700 font-semibold mt-0.5">Verified Task Points</p>
        </div>

        {/* Current Rank */}
        <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider">Current Rank</span>
            <div className="w-7 h-7 rounded-lg bg-blue-50 text-[#0A66C2] flex items-center justify-center">
              <Trophy className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl sm:text-3xl font-black text-slate-900">
            #{performance?.currentRank || '--'}
          </p>
          <p className="text-[10px] text-[#0A66C2] font-semibold mt-0.5">Cohort Standing</p>
        </div>

        {/* Tasks Completed */}
        <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider">Tasks Completed</span>
            <div className="w-7 h-7 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center">
              <CheckCircle2 className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl sm:text-3xl font-black text-slate-900">
            {performance?.tasksCompleted || 0} <span className="text-xs font-bold text-slate-400">/ 5</span>
          </p>
          <p className="text-[10px] text-emerald-700 font-semibold mt-0.5">
            {performance?.tasksCompleted === 5 ? '100% Requirements Fulfilled' : 'Active Milestone Path'}
          </p>
        </div>

        {/* Average Score */}
        <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider">Average Score</span>
            <div className="w-7 h-7 rounded-lg bg-indigo-50 text-indigo-700 flex items-center justify-center">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl sm:text-3xl font-black text-slate-900">
            {performance?.averageScore || 0}%
          </p>
          <p className="text-[10px] text-indigo-700 font-semibold mt-0.5">Mentor Review Quality Avg</p>
        </div>
      </div>

      {/* Difficulty Breakdown (Beginner, Intermediate, Advanced) */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <h3 className="text-sm font-black text-slate-900 flex items-center gap-2">
            <Layers className="w-4 h-4 text-[#0A66C2]" />
            <span>Task Difficulty Weighting & Completions</span>
          </h3>
          <span className="text-xs text-slate-500">Proportional Points Allocation</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {/* Beginner */}
          <div className="p-4 rounded-xl border border-emerald-200 bg-emerald-50/40">
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs font-bold text-emerald-900">Beginner Tasks</span>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-emerald-100 text-emerald-800">
                100 Max Pts
              </span>
            </div>
            <p className="text-xl font-black text-slate-900 mt-2">
              {performance?.beginnerTasks || 0}{' '}
              <span className="text-xs font-semibold text-slate-500">completed</span>
            </p>
            <p className="text-[11px] text-slate-600 mt-1">
              Foundation milestones & onboarding verification.
            </p>
          </div>

          {/* Intermediate */}
          <div className="p-4 rounded-xl border border-blue-200 bg-blue-50/40">
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs font-bold text-blue-900">Intermediate Tasks</span>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-blue-100 text-[#0A66C2]">
                150 Max Pts
              </span>
            </div>
            <p className="text-xl font-black text-slate-900 mt-2">
              {performance?.intermediateTasks || 0}{' '}
              <span className="text-xs font-semibold text-slate-500">completed</span>
            </p>
            <p className="text-[11px] text-slate-600 mt-1">
              Core architecture, stateful workflows, and APIs.
            </p>
          </div>

          {/* Advanced */}
          <div className="p-4 rounded-xl border border-purple-200 bg-purple-50/40">
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs font-bold text-purple-900">Advanced Tasks</span>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-purple-100 text-purple-800">
                200 Max Pts
              </span>
            </div>
            <p className="text-xl font-black text-slate-900 mt-2">
              {performance?.advancedTasks || 0}{' '}
              <span className="text-xs font-semibold text-slate-500">completed</span>
            </p>
            <p className="text-[11px] text-slate-600 mt-1">
              Production capstone, CI/CD, and flagship deployments.
            </p>
          </div>
        </div>
      </div>

      {/* Earned Badges Section */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4">
        <h3 className="text-sm font-black text-slate-900 flex items-center gap-2">
          <Award className="w-4 h-4 text-amber-500" />
          <span>Earned Engineering Badges</span>
        </h3>
        <div className="flex flex-wrap gap-2.5">
          {Array.isArray(performance?.badges) && performance.badges.length > 0 ? (
            performance.badges.map((badge: string, i: number) => (
              <span
                key={i}
                className="px-3.5 py-1.5 rounded-xl text-xs font-bold bg-amber-50 text-amber-900 border border-amber-200 shadow-2xs flex items-center gap-1.5"
              >
                <span>{badge}</span>
              </span>
            ))
          ) : (
            <span className="text-xs text-slate-400 italic">
              Submit and pass tasks to unlock badges on your profile.
            </span>
          )}
        </div>
      </div>

      {/* Recent Evaluations & Progress Timeline */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <h3 className="text-sm font-black text-slate-900 flex items-center gap-2">
            <Calendar className="w-4 h-4 text-[#0A66C2]" />
            <span>Recent AI Evaluations & Feedback</span>
          </h3>
          <span className="text-xs text-slate-500">Click any card to inspect full rubric</span>
        </div>

        <div className="space-y-3">
          {Array.isArray(performance?.recentEvaluations) && performance.recentEvaluations.length > 0 ? (
            performance.recentEvaluations.map((ev: TaskEvaluationRecord) => (
              <div
                key={ev.evaluationId}
                onClick={() => openEvaluationModal(ev)}
                className="p-4 rounded-xl border border-slate-200 hover:border-[#0A66C2] bg-slate-50/50 hover:bg-blue-50/30 transition-all cursor-pointer flex flex-col sm:flex-row sm:items-center justify-between gap-3 group"
              >
                <div className="flex items-center gap-3.5">
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center font-black text-sm shrink-0 shadow-2xs ${
                    ev.status === 'passed'
                      ? 'bg-emerald-600 text-white'
                      : 'bg-amber-600 text-white'
                  }`}>
                    {ev.totalScore}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-slate-900 group-hover:text-[#0A66C2] transition-colors">
                        {ev.taskTitle || `Task ${ev.taskNumber}`}
                      </span>
                      <span className={`px-2 py-0.2 rounded-full text-[10px] font-extrabold uppercase ${
                        ev.status === 'passed'
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}>
                        {ev.status === 'passed' ? 'PASSED' : 'REVISION'}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-500 mt-0.5">
                      Earned Points: <strong className="text-slate-800">+{ev.earnedPoints || 0} pts</strong> • Evaluated: {new Date(ev.evaluatedAt).toLocaleDateString()}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 self-end sm:self-center">
                  <span className="text-xs font-bold text-[#0A66C2] group-hover:underline flex items-center gap-1">
                    <span>View Rubric Report</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </span>
                </div>
              </div>
            ))
          ) : (
            <div className="py-8 text-center text-xs text-slate-500">
              No evaluations on record yet. Complete and submit a task to receive AI scoring.
            </div>
          )}
        </div>
      </div>

      {/* Modal for viewing evaluation details */}
      <StudentEvaluationModal
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        evaluation={selectedEvaluation}
      />
    </div>
  );
};
