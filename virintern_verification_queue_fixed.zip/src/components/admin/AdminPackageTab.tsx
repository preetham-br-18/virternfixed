import React, { useState } from 'react';
import { PackageConfig, PackageBenefit } from '../../types';
import {
  DollarSign,
  Package,
  Plus,
  Trash2,
  Edit2,
  Check,
  CheckCircle,
  Award,
  ArrowUp,
  ArrowDown,
  Eye,
  FileText,
  BookOpen,
  Briefcase,
  Download,
  Sparkles,
  ShieldCheck,
  Star,
  ExternalLink,
  Paperclip,
  Image as ImageIcon,
  X
} from 'lucide-react';

interface AdminPackageTabProps {
  packageConfig: PackageConfig | null;
  packagePriceInput: number;
  setPackagePriceInput: (p: number) => void;
  packageTitleInput: string;
  setPackageTitleInput: (t: string) => void;
  packageBenefits: PackageBenefit[];
  onUpdatePackagePrice: (e: React.FormEvent) => Promise<void>;
  onSaveBenefit: (benefit: PackageBenefit) => Promise<void>;
  onDeleteBenefit: (id: string, title: string) => Promise<void>;
  onToggleBenefit: (id: string) => Promise<void>;
  onMoveBenefit: (index: number, direction: 'up' | 'down') => Promise<void>;
  showSuccess: (msg: string) => void;
  showError: (msg: string) => void;
}

export const AdminPackageTab: React.FC<AdminPackageTabProps> = ({
  packageConfig,
  packagePriceInput,
  setPackagePriceInput,
  packageTitleInput,
  setPackageTitleInput,
  packageBenefits,
  onUpdatePackagePrice,
  onSaveBenefit,
  onDeleteBenefit,
  onToggleBenefit,
  onMoveBenefit,
  showSuccess,
  showError
}) => {
  const [isBenefitModalOpen, setIsBenefitModalOpen] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [benefitForm, setBenefitForm] = useState<{
    id?: string;
    title: string;
    description: string;
    icon: string;
    imageUrl?: string;
    fileUrl?: string;
    fileName?: string;
    resourceLink?: string;
    isActive: boolean;
  }>({
    title: '',
    description: '',
    icon: 'Award',
    imageUrl: '',
    fileUrl: '',
    fileName: '',
    resourceLink: '',
    isActive: true
  });

  const handleOpenAdd = () => {
    setBenefitForm({
      title: '',
      description: '',
      icon: 'Award',
      imageUrl: '',
      fileUrl: '',
      fileName: '',
      resourceLink: '',
      isActive: true
    });
    setIsEditing(false);
    setIsBenefitModalOpen(true);
  };

  const handleOpenEdit = (b: PackageBenefit) => {
    setBenefitForm({
      id: b.id,
      title: b.title,
      description: b.description,
      icon: b.icon || 'Award',
      imageUrl: b.imageUrl || '',
      fileUrl: b.fileUrl || '',
      fileName: b.fileName || '',
      resourceLink: b.resourceLink || '',
      isActive: b.isActive
    });
    setIsEditing(true);
    setIsBenefitModalOpen(true);
  };

  const handleSubmitBenefit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!benefitForm.title.trim()) {
      showError('Please enter a benefit title');
      return;
    }

    const benefitId = benefitForm.id || `benefit_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
    const benefitToSave: PackageBenefit = {
      id: benefitId,
      title: benefitForm.title.trim(),
      description: benefitForm.description.trim(),
      icon: benefitForm.icon,
      imageUrl: benefitForm.imageUrl || undefined,
      fileUrl: benefitForm.fileUrl || undefined,
      fileName: benefitForm.fileName || undefined,
      resourceLink: benefitForm.resourceLink?.trim() || undefined,
      isActive: benefitForm.isActive,
      order: benefitForm.id
        ? (packageBenefits.find(b => b.id === benefitForm.id)?.order || packageBenefits.length)
        : packageBenefits.length + 1,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    await onSaveBenefit(benefitToSave);
    setIsBenefitModalOpen(false);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) {
      showError('File must be smaller than 5MB');
      return;
    }
    const reader = new FileReader();
    reader.onloadend = () => {
      setBenefitForm(prev => ({
        ...prev,
        fileUrl: reader.result as string,
        fileName: file.name
      }));
      showSuccess(`File "${file.name}" attached.`);
    };
    reader.readAsDataURL(file);
  };

  const renderIcon = (name?: string) => {
    switch (name) {
      case 'Star': return <Star className="w-4 h-4 text-amber-500" />;
      case 'ShieldCheck': return <ShieldCheck className="w-4 h-4 text-emerald-600" />;
      case 'FileText': return <FileText className="w-4 h-4 text-indigo-600" />;
      case 'BookOpen': return <BookOpen className="w-4 h-4 text-sky-600" />;
      case 'Briefcase': return <Briefcase className="w-4 h-4 text-amber-600" />;
      case 'Download': return <Download className="w-4 h-4 text-purple-600" />;
      case 'Sparkles': return <Sparkles className="w-4 h-4 text-amber-400" />;
      default: return <Award className="w-4 h-4 text-purple-600" />;
    }
  };

  return (
    <div className="space-y-8 animate-slideUp">
      {/* Top: Package Price & Display Title */}
      <div className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-200 shadow-sm space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-5">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 text-emerald-700 text-xs font-semibold mb-2">
              <DollarSign className="w-3.5 h-3.5" />
              <span>Admin Pricing Control</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900">Configure Completion Package Pricing</h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Set the student checkout price dynamically. Changes take effect across the platform instantly without rebuilds.
            </p>
          </div>
          <div className="text-right">
            <span className="text-[11px] uppercase tracking-wider text-slate-400 font-bold block">Current Price</span>
            <span className="text-3xl font-extrabold text-emerald-600 font-mono">₹{packageConfig?.price || 99}</span>
          </div>
        </div>

        <form onSubmit={onUpdatePackagePrice} className="grid grid-cols-1 md:grid-cols-12 gap-4 items-end text-xs">
          <div className="md:col-span-5">
            <label className="block font-semibold text-slate-700 mb-1">Package Display Title</label>
            <input
              type="text"
              value={packageTitleInput}
              onChange={(e) => setPackageTitleInput(e.target.value)}
              className="w-full p-2.5 border border-slate-300 rounded-xl outline-none focus:border-purple-600"
              placeholder="e.g. VirIntern Official Completion Package"
            />
          </div>

          <div className="md:col-span-4">
            <label className="block font-semibold text-slate-700 mb-1">
              Active Price in INR (₹) <span className="text-emerald-600 font-bold">*</span>
            </label>
            <div className="relative">
              <span className="absolute left-3.5 top-2.5 text-slate-500 font-bold text-sm">₹</span>
              <input
                type="number"
                min="0"
                max="9999"
                value={packagePriceInput}
                onChange={(e) => setPackagePriceInput(Number(e.target.value))}
                className="w-full pl-8 pr-3 py-2 border border-slate-300 rounded-xl font-mono text-base font-bold text-slate-900 outline-none focus:border-purple-600"
              />
            </div>
          </div>

          <div className="md:col-span-3">
            <button
              type="submit"
              className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Check className="w-4 h-4" />
              <span>Save Package Price</span>
            </button>
          </div>
        </form>
      </div>

      {/* Package Benefits CRUD */}
      <div className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-200 shadow-sm space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-5">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-bold text-slate-900">₹{packageConfig?.price || 99} Package Benefits Pool</h2>
              <span className="text-xs bg-indigo-50 text-indigo-700 font-bold px-2.5 py-0.5 rounded-full border border-indigo-200">
                {packageBenefits.filter(b => b.isActive).length} Active of {packageBenefits.length}
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-1 max-w-2xl">
              Add, edit, delete, reorder, or toggle benefits. Attach downloadable guides (PDF, PNG, DOCX) or resource links.
            </p>
          </div>

          <button
            type="button"
            onClick={handleOpenAdd}
            className="px-4 py-2.5 bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs rounded-xl shadow-md transition-all flex items-center gap-2 cursor-pointer self-start sm:self-auto"
          >
            <Plus className="w-4 h-4" />
            <span>Add New Benefit</span>
          </button>
        </div>

        {/* Benefits List */}
        <div className="space-y-3">
          {packageBenefits.length === 0 ? (
            <div className="py-12 text-center text-slate-400 bg-slate-50 rounded-2xl border border-dashed border-slate-200">
              <Package className="w-8 h-8 text-slate-300 mx-auto mb-2" />
              <p className="font-bold text-slate-600 text-xs">No benefits added to the package yet</p>
            </div>
          ) : (
            packageBenefits.map((b, idx) => (
              <div
                key={b.id}
                className={`p-4 rounded-2xl border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4 ${
                  b.isActive ? 'bg-white border-slate-200 hover:border-purple-300' : 'bg-slate-50 border-slate-200 opacity-60'
                }`}
              >
                <div className="flex items-start gap-3.5">
                  <div className="w-10 h-10 rounded-xl bg-purple-50 flex items-center justify-center shrink-0 border border-purple-100 mt-0.5">
                    {renderIcon(b.icon)}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="font-bold text-slate-900 text-sm">{b.title}</h4>
                      <span className={`px-2 py-0.2 rounded-full text-[10px] font-black uppercase ${
                        b.isActive ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-200 text-slate-600'
                      }`}>
                        {b.isActive ? 'Active' : 'Hidden'}
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 mt-0.5">{b.description}</p>
                    {b.fileName && (
                      <span className="inline-flex items-center gap-1 text-[11px] text-purple-700 font-mono mt-1 bg-purple-50 px-2 py-0.5 rounded">
                        <Paperclip className="w-3 h-3" />
                        {b.fileName}
                      </span>
                    )}
                  </div>
                </div>

                <div className="flex items-center gap-1.5 self-end sm:self-auto shrink-0">
                  <button
                    type="button"
                    onClick={() => onMoveBenefit(idx, 'up')}
                    disabled={idx === 0}
                    className="p-1.5 text-slate-400 hover:text-slate-800 disabled:opacity-30 rounded-lg hover:bg-slate-100"
                    title="Move up"
                  >
                    <ArrowUp className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => onMoveBenefit(idx, 'down')}
                    disabled={idx === packageBenefits.length - 1}
                    className="p-1.5 text-slate-400 hover:text-slate-800 disabled:opacity-30 rounded-lg hover:bg-slate-100"
                    title="Move down"
                  >
                    <ArrowDown className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => onToggleBenefit(b.id)}
                    className="px-2.5 py-1 text-xs font-bold text-slate-600 hover:bg-slate-100 rounded-lg border border-slate-200"
                  >
                    {b.isActive ? 'Hide' : 'Show'}
                  </button>
                  <button
                    type="button"
                    onClick={() => handleOpenEdit(b)}
                    className="p-1.5 text-purple-600 hover:bg-purple-50 rounded-lg"
                    title="Edit benefit"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => onDeleteBenefit(b.id, b.title)}
                    className="p-1.5 text-rose-600 hover:bg-rose-50 rounded-lg"
                    title="Delete benefit"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Benefit Modal */}
      {isBenefitModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-white rounded-3xl max-w-lg w-full border border-slate-200 shadow-2xl overflow-hidden my-4 animate-scaleIn">
            <div className="p-5 bg-gradient-to-r from-purple-900 to-indigo-950 text-white flex items-center justify-between">
              <h3 className="text-base font-bold">
                {isEditing ? 'Edit Package Benefit' : 'Add New Benefit to Package'}
              </h3>
              <button
                type="button"
                onClick={() => setIsBenefitModalOpen(false)}
                className="p-1.5 text-white/70 hover:text-white rounded-full hover:bg-white/10"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmitBenefit} className="p-6 space-y-4 text-xs text-slate-700">
              <div>
                <label className="block font-bold text-slate-800 mb-1">
                  Benefit Title <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={benefitForm.title}
                  onChange={(e) => setBenefitForm({ ...benefitForm, title: e.target.value })}
                  placeholder="e.g. Official Verified Digital Credentials"
                  className="w-full p-2.5 border border-slate-300 rounded-xl outline-none focus:border-purple-600"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-800 mb-1">Description</label>
                <textarea
                  rows={3}
                  value={benefitForm.description}
                  onChange={(e) => setBenefitForm({ ...benefitForm, description: e.target.value })}
                  placeholder="Brief summary of what the student receives..."
                  className="w-full p-2.5 border border-slate-300 rounded-xl outline-none focus:border-purple-600"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-800 mb-1">Badge Icon</label>
                  <select
                    value={benefitForm.icon}
                    onChange={(e) => setBenefitForm({ ...benefitForm, icon: e.target.value })}
                    className="w-full p-2.5 border border-slate-300 rounded-xl outline-none"
                  >
                    <option value="Award">Award</option>
                    <option value="Star">Star</option>
                    <option value="ShieldCheck">ShieldCheck</option>
                    <option value="FileText">FileText</option>
                    <option value="BookOpen">BookOpen</option>
                    <option value="Briefcase">Briefcase</option>
                    <option value="Download">Download</option>
                    <option value="Sparkles">Sparkles</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-800 mb-1">Active Status</label>
                  <select
                    value={benefitForm.isActive ? 'true' : 'false'}
                    onChange={(e) => setBenefitForm({ ...benefitForm, isActive: e.target.value === 'true' })}
                    className="w-full p-2.5 border border-slate-300 rounded-xl outline-none"
                  >
                    <option value="true">Active (Visible)</option>
                    <option value="false">Hidden (Inactive)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-800 mb-1">Attach Guide / Resource File</label>
                <input
                  type="file"
                  onChange={handleFileUpload}
                  className="w-full text-xs text-slate-500 file:mr-3 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-bold file:bg-purple-50 file:text-purple-700 hover:file:bg-purple-100 cursor-pointer"
                />
                {benefitForm.fileName && (
                  <p className="text-[11px] text-emerald-700 font-mono mt-1">
                    Attached: {benefitForm.fileName}
                  </p>
                )}
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsBenefitModalOpen(false)}
                  className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-xl font-bold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-purple-600 hover:bg-purple-700 text-white font-bold rounded-xl shadow-md cursor-pointer flex items-center gap-1.5"
                >
                  <CheckCircle className="w-4 h-4" />
                  <span>{isEditing ? 'Save Benefit' : 'Add Benefit'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
