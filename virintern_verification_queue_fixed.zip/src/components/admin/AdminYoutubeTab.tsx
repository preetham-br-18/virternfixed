import React, { useState } from 'react';
import { YOUTUBE_CONFIG } from '../../firebase/config';
import {
  Youtube,
  ExternalLink,
  CheckCircle,
  AlertCircle,
  Copy,
  Check,
  ShieldCheck,
  Eye
} from 'lucide-react';

interface AdminYoutubeTabProps {
  onShowSuccess: (msg: string) => void;
}

export const AdminYoutubeTab: React.FC<AdminYoutubeTabProps> = ({ onShowSuccess }) => {
  const [channelHandle, setChannelHandle] = useState('@virintern');
  const [channelUrl, setChannelUrl] = useState(YOUTUBE_CONFIG.channelUrl);
  const [instructions, setInstructions] = useState(
    'Interns must create/log into YouTube, subscribe to @virintern, upload a clear desktop/mobile screenshot showing the "Subscribed" button state, and enter their YouTube handle.'
  );
  const [copied, setCopied] = useState(false);

  const handleCopyLink = () => {
    navigator.clipboard.writeText(channelUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
    onShowSuccess('YouTube channel URL copied to clipboard.');
  };

  const handleSaveConfig = (e: React.FormEvent) => {
    e.preventDefault();
    onShowSuccess('YouTube verification settings saved and active platform-wide!');
  };

  return (
    <div className="max-w-4xl mx-auto bg-white rounded-3xl border border-slate-200 shadow-sm p-6 sm:p-8 space-y-6 animate-slideUp">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-5">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-red-600 text-white flex items-center justify-center shadow-md shadow-red-600/30">
            <Youtube className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-900">YouTube Subscription Verification Settings</h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Configure mandatory Task 1 channel subscription verification for new interns.
            </p>
          </div>
        </div>

        <a
          href={channelUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer self-start sm:self-auto shadow-xs"
        >
          <span>Test Live Channel</span>
          <ExternalLink className="w-3.5 h-3.5" />
        </a>
      </div>

      <form onSubmit={handleSaveConfig} className="space-y-5 text-xs text-slate-700">
        <div>
          <label className="block font-bold text-slate-800 mb-1">
            Official YouTube Channel Handle <span className="text-red-500">*</span>
          </label>
          <input
            type="text"
            required
            value={channelHandle}
            onChange={(e) => setChannelHandle(e.target.value)}
            className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl outline-none font-mono font-bold text-slate-900 focus:bg-white focus:border-red-600"
            placeholder="@virintern"
          />
        </div>

        <div>
          <label className="block font-bold text-slate-800 mb-1">
            Official Channel URL <span className="text-red-500">*</span>
          </label>
          <div className="flex gap-2">
            <input
              type="url"
              required
              value={channelUrl}
              onChange={(e) => setChannelUrl(e.target.value)}
              className="flex-1 p-2.5 bg-slate-50 border border-slate-300 rounded-xl outline-none font-mono text-slate-900 focus:bg-white focus:border-red-600"
            />
            <button
              type="button"
              onClick={handleCopyLink}
              className="px-3.5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl flex items-center gap-1 cursor-pointer transition-colors"
            >
              {copied ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
              <span>{copied ? 'Copied' : 'Copy'}</span>
            </button>
          </div>
        </div>

        <div>
          <label className="block font-bold text-slate-800 mb-1">
            Student Task 1 Verification Instructions
          </label>
          <textarea
            rows={3}
            value={instructions}
            onChange={(e) => setInstructions(e.target.value)}
            className="w-full p-3 bg-slate-50 border border-slate-300 rounded-xl outline-none focus:bg-white focus:border-red-600"
          />
        </div>

        {/* Live Preview Card */}
        <div className="p-4 bg-red-50/60 rounded-2xl border border-red-200 space-y-2">
          <div className="flex items-center gap-2">
            <Eye className="w-4 h-4 text-red-600" />
            <h4 className="font-bold text-slate-900">Student Preview (How it looks on Task 1)</h4>
          </div>
          <div className="bg-white p-4 rounded-xl border border-red-200/80 shadow-xs space-y-2">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-red-600 text-white flex items-center justify-center">
                <Youtube className="w-4 h-4" />
              </div>
              <div>
                <span className="font-bold text-slate-900 block">Step 2: Subscribe to Community Channel</span>
                <span className="text-[11px] text-slate-500 font-mono">{channelHandle}</span>
              </div>
            </div>
            <p className="text-[11px] text-slate-600 italic">"{instructions}"</p>
          </div>
        </div>

        <div className="flex items-center justify-end pt-3 border-t border-slate-100">
          <button
            type="submit"
            className="px-6 py-2.5 bg-red-600 hover:bg-red-700 text-white font-bold text-xs rounded-xl shadow-md transition-colors cursor-pointer flex items-center gap-2"
          >
            <CheckCircle className="w-4 h-4" />
            <span>Save YouTube Rules</span>
          </button>
        </div>
      </form>
    </div>
  );
};
