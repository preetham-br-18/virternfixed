import React, { useState } from 'react';
import { AuditLogRecord } from '../../types';
import { exportToCsv } from './adminUtils';
import {
  History,
  Search,
  Filter,
  Download,
  ShieldCheck,
  Clock,
  UserCheck,
  Sliders,
  Settings,
  AlertTriangle
} from 'lucide-react';

interface AdminAuditTabProps {
  auditLogs: AuditLogRecord[];
  onRefreshLogs: () => void;
}

export const AdminAuditTab: React.FC<AdminAuditTabProps> = ({ auditLogs, onRefreshLogs }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterAction, setFilterAction] = useState('all');

  const filteredLogs = auditLogs.filter((log) => {
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchAdmin = (log.adminId || '').toLowerCase().includes(q);
      const matchTarget = (log.targetId || '').toLowerCase().includes(q);
      const matchReason = (log.reason || '').toLowerCase().includes(q);
      const matchAction = (log.action || '').toLowerCase().includes(q);
      if (!matchAdmin && !matchTarget && !matchReason && !matchAction) return false;
    }
    if (filterAction !== 'all') {
      if ((log.action || '').toUpperCase() !== filterAction.toUpperCase()) return false;
    }
    return true;
  });

  const handleExportCsv = () => {
    const headers = ['Log ID', 'Timestamp', 'Admin ID', 'Action', 'Target Type', 'Target ID', 'Reason', 'Prev Score', 'New Score'];
    const rows = filteredLogs.map((l) => [
      l.id,
      l.timestamp,
      l.adminId,
      l.action,
      l.targetType || '',
      l.targetId,
      l.reason || '',
      l.previousScore ?? '',
      l.newScore ?? ''
    ]);
    exportToCsv(`virintern_audit_logs_${new Date().toISOString().split('T')[0]}`, headers, rows);
  };

  return (
    <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-6 space-y-6 animate-slideUp">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-5">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-xl bg-purple-100 text-purple-700">
              <History className="w-5 h-5" />
            </span>
            <h2 className="text-xl font-bold text-slate-900">Security & Operational Audit Trail</h2>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Immutable log of all manual verifications, rubric overrides, system setting updates, and student account actions.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleExportCsv}
            className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export Audit CSV</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="relative w-full sm:w-72">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by admin ID, student, reason..."
            className="w-full text-xs pl-8 pr-3 py-2.5 bg-white border border-slate-300 rounded-xl outline-none font-medium focus:border-purple-600"
          />
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
        </div>

        <div className="flex items-center gap-3 w-full sm:w-auto">
          <select
            value={filterAction}
            onChange={(e) => setFilterAction(e.target.value)}
            className="w-full sm:w-56 text-xs p-2.5 bg-white border border-slate-300 rounded-xl outline-none font-semibold text-slate-800"
          >
            <option value="all">All Action Types ({auditLogs.length})</option>
            <option value="ADMIN_MANUAL_VERIFICATION">Manual Verifications</option>
            <option value="EVALUATION_OVERRIDE">Score Overrides</option>
            <option value="FLAG_SUSPICIOUS_SUBMISSION">Flagged Submissions</option>
            <option value="SETTINGS_UPDATE">Settings Updates</option>
            <option value="USER_SUSPENSION">User Status</option>
            <option value="PACKAGE_UPDATE">Package Pricing</option>
          </select>
        </div>
      </div>

      {/* Logs Table */}
      <div className="overflow-x-auto rounded-2xl border border-slate-200">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200">
            <tr>
              <th className="py-3 px-4">Timestamp</th>
              <th className="py-3 px-4">Admin Actor</th>
              <th className="py-3 px-4">Operation</th>
              <th className="py-3 px-4">Target Ref</th>
              <th className="py-3 px-4">Details & Justification</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {filteredLogs.length === 0 ? (
              <tr>
                <td colSpan={5} className="py-12 text-center text-slate-400">
                  <ShieldCheck className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                  <p className="font-bold text-slate-600">No audit records match filters</p>
                </td>
              </tr>
            ) : (
              filteredLogs.map((log) => {
                const actionColor =
                  log.action.includes('OVERRIDE')
                    ? 'bg-purple-100 text-purple-900 border-purple-200'
                    : log.action.includes('SUSPEND')
                    ? 'bg-rose-100 text-rose-900 border-rose-200'
                    : log.action.includes('FLAG')
                    ? 'bg-amber-100 text-amber-900 border-amber-200'
                    : log.action.includes('VERIFICATION') || log.action.includes('REVIEW')
                    ? 'bg-emerald-100 text-emerald-900 border-emerald-200'
                    : 'bg-indigo-100 text-indigo-900 border-indigo-200';

                return (
                  <tr key={log.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3 px-4 text-slate-500 whitespace-nowrap">
                      {new Date(log.timestamp).toLocaleString()}
                    </td>
                    <td className="py-3 px-4 font-mono font-bold text-slate-800">
                      {log.adminId}
                    </td>
                    <td className="py-3 px-4">
                      <span className={`px-2 py-0.5 rounded-md text-[10px] font-black uppercase tracking-wider border ${actionColor}`}>
                        {log.action.replace(/_/g, ' ')}
                      </span>
                    </td>
                    <td className="py-3 px-4 font-mono text-[11px] text-slate-600">
                      {log.targetId}
                    </td>
                    <td className="py-3 px-4 text-slate-700 max-w-md">
                      <div className="space-y-0.5">
                        {log.reason && (
                          <p className="font-semibold text-purple-950">"{log.reason}"</p>
                        )}
                        {log.previousScore !== undefined && log.newScore !== undefined && (
                          <p className="text-[11px] text-slate-500">
                            Score changed: {log.previousScore} → <strong>{log.newScore}</strong>
                          </p>
                        )}
                        {!log.reason && log.metadata && (
                          <p className="text-[11px] text-slate-500 truncate">{JSON.stringify(log.metadata)}</p>
                        )}
                        {!log.reason && !log.metadata && (
                          <p className="text-[11px] text-slate-400 italic">No notes provided</p>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
