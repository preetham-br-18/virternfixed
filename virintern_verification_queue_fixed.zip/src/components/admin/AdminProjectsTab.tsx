import React, { useState } from 'react';
import { DomainItem, ProjectTask } from '../../types';
import {
  Layers,
  Plus,
  Trash2,
  Edit2,
  CheckCircle,
  FileText,
  AlertCircle,
  ChevronDown,
  ChevronUp,
  Tag
} from 'lucide-react';

interface AdminProjectsTabProps {
  domains: DomainItem[];
  projects: ProjectTask[];
  onAddDomain: (e: React.FormEvent, domain: { name: string; description: string; tags: string }) => Promise<void>;
  onToggleDomain: (domain: DomainItem) => Promise<void>;
  onDeleteDomain: (id: string) => Promise<void>;
  onAddProject: (e: React.FormEvent, project: any) => Promise<void>;
  onDeleteProject: (id: string) => Promise<void>;
}

export const AdminProjectsTab: React.FC<AdminProjectsTabProps> = ({
  domains,
  projects,
  onAddDomain,
  onToggleDomain,
  onDeleteDomain,
  onAddProject,
  onDeleteProject
}) => {
  const [newDomain, setNewDomain] = useState({
    name: '',
    description: '',
    tags: 'React, TypeScript, Node.js'
  });

  const [selectedDomainFilter, setSelectedDomainFilter] = useState('all');

  const [newProject, setNewProject] = useState({
    domainId: domains[0]?.id || '',
    taskNumber: 1,
    title: '',
    difficulty: 'Beginner' as 'Beginner' | 'Intermediate' | 'Advanced',
    objective: '',
    description: '',
    instructions: '1. Initialize git repository\n2. Develop module requirements\n3. Deploy live and verify'
  });

  const handleDomainSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await onAddDomain(e, newDomain);
    setNewDomain({ name: '', description: '', tags: 'React, TypeScript, Node.js' });
  };

  const handleProjectSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await onAddProject(e, newProject);
    setNewProject(prev => ({
      ...prev,
      title: '',
      objective: '',
      description: ''
    }));
  };

  const filteredProjects = projects.filter(p => {
    if (selectedDomainFilter === 'all') return true;
    return p.domainId === selectedDomainFilter;
  });

  return (
    <div className="space-y-8 animate-slideUp">
      {/* Top: Domains & Tracks Management */}
      <div className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-200 shadow-sm space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-5">
          <div>
            <div className="flex items-center gap-2">
              <span className="p-1.5 rounded-xl bg-indigo-100 text-indigo-700">
                <Layers className="w-5 h-5" />
              </span>
              <h2 className="text-xl font-bold text-slate-900">Curriculum Domain Tracks ({domains.length})</h2>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              Add new engineering specializations, toggle enrollment status, and manage active tracks.
            </p>
          </div>
        </div>

        {/* Add Domain Form */}
        <form onSubmit={handleDomainSubmit} className="p-5 bg-slate-50 rounded-2xl border border-slate-200 space-y-4 text-xs">
          <h3 className="text-xs font-black uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
            <Plus className="w-4 h-4 text-indigo-600" />
            <span>Add New Domain Specialization</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block font-bold text-slate-700 mb-1">Track Name *</label>
              <input
                type="text"
                required
                value={newDomain.name}
                onChange={(e) => setNewDomain({ ...newDomain, name: e.target.value })}
                placeholder="e.g. Artificial Intelligence & ML"
                className="w-full p-2.5 bg-white border border-slate-300 rounded-xl outline-none focus:border-indigo-600"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Tech Tags (Comma separated)</label>
              <input
                type="text"
                value={newDomain.tags}
                onChange={(e) => setNewDomain({ ...newDomain, tags: e.target.value })}
                placeholder="Python, PyTorch, LangChain"
                className="w-full p-2.5 bg-white border border-slate-300 rounded-xl outline-none focus:border-indigo-600"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Description</label>
              <input
                type="text"
                value={newDomain.description}
                onChange={(e) => setNewDomain({ ...newDomain, description: e.target.value })}
                placeholder="Syllabus overview..."
                className="w-full p-2.5 bg-white border border-slate-300 rounded-xl outline-none focus:border-indigo-600"
              />
            </div>
          </div>

          <div className="flex justify-end">
            <button
              type="submit"
              className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl shadow-xs transition-colors cursor-pointer flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              <span>Create Track</span>
            </button>
          </div>
        </form>

        {/* Existing Domains Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {domains.map((dom) => {
            const taskCount = projects.filter(p => p.domainId === dom.id).length;
            return (
              <div
                key={dom.id}
                className="p-4 bg-white rounded-2xl border border-slate-200 hover:border-indigo-300 transition-all flex flex-col justify-between space-y-2 shadow-2xs"
              >
                <div>
                  <div className="flex items-center justify-between">
                    <h4 className="font-bold text-slate-900 text-sm">{dom.name}</h4>
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-black uppercase ${
                      dom.isActive ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-500'
                    }`}>
                      {dom.isActive ? 'Active' : 'Disabled'}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500 mt-1 line-clamp-2">{dom.description}</p>
                </div>

                <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs">
                  <span className="text-[11px] font-bold text-indigo-700">{taskCount} Project Tasks</span>
                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => onToggleDomain(dom)}
                      className="px-2 py-1 text-[11px] font-bold text-slate-600 hover:bg-slate-100 rounded-lg border border-slate-200"
                    >
                      {dom.isActive ? 'Disable' : 'Enable'}
                    </button>
                    <button
                      type="button"
                      onClick={() => onDeleteDomain(dom.id)}
                      className="p-1 text-rose-600 hover:bg-rose-50 rounded-lg"
                      title="Delete domain"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Bottom: Project Tasks Pool */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Create Task Form */}
        <div className="lg:col-span-5 bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4">
          <h3 className="text-sm font-bold uppercase tracking-wider text-slate-700">Add Milestone Task to Pool</h3>
          <form onSubmit={handleProjectSubmit} className="space-y-3 text-xs text-slate-700">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Target Track</label>
              <select
                value={newProject.domainId || (domains[0]?.id || '')}
                onChange={(e) => setNewProject({ ...newProject, domainId: e.target.value })}
                className="w-full p-2.5 border border-slate-300 rounded-xl outline-none"
              >
                {domains.map(d => (
                  <option key={d.id} value={d.id}>{d.name}</option>
                ))}
              </select>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Task Milestone</label>
                <select
                  value={newProject.taskNumber}
                  onChange={(e) => setNewProject({ ...newProject, taskNumber: Number(e.target.value) })}
                  className="w-full p-2.5 border border-slate-300 rounded-xl outline-none font-bold"
                >
                  {[
                    { n: 1, label: 'Milestone 1: Onboarding & Verification (20%)' },
                    { n: 2, label: 'Milestone 2: Foundation Deliverable (40%)' },
                    { n: 3, label: 'Milestone 3: Core Implementation (60%)' },
                    { n: 4, label: 'Milestone 4: Advanced Architecture (80%)' },
                    { n: 5, label: 'Milestone 5: Capstone Completion (100%)' }
                  ].map(m => (
                    <option key={m.n} value={m.n}>{m.label}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Difficulty</label>
                <select
                  value={newProject.difficulty}
                  onChange={(e) => setNewProject({ ...newProject, difficulty: e.target.value as any })}
                  className="w-full p-2.5 border border-slate-300 rounded-xl outline-none"
                >
                  <option value="Beginner">Beginner (100 pts)</option>
                  <option value="Intermediate">Intermediate (150 pts)</option>
                  <option value="Advanced">Advanced (200 pts)</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Task Title *</label>
              <input
                type="text"
                required
                value={newProject.title}
                onChange={(e) => setNewProject({ ...newProject, title: e.target.value })}
                placeholder="e.g. Real-Time WebSockets Dashboard"
                className="w-full p-2.5 border border-slate-300 rounded-xl outline-none"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Objective</label>
              <input
                type="text"
                value={newProject.objective}
                onChange={(e) => setNewProject({ ...newProject, objective: e.target.value })}
                placeholder="Core milestone goal..."
                className="w-full p-2.5 border border-slate-300 rounded-xl outline-none"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Step-by-step Instructions (Newline separated)</label>
              <textarea
                rows={4}
                value={newProject.instructions}
                onChange={(e) => setNewProject({ ...newProject, instructions: e.target.value })}
                className="w-full p-2.5 border border-slate-300 rounded-xl outline-none font-mono"
              />
            </div>

            <button
              type="submit"
              className="w-full py-2.5 bg-purple-600 hover:bg-purple-700 text-white font-bold rounded-xl shadow transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Save Task to Pool</span>
            </button>
          </form>
        </div>

        {/* Existing Tasks List */}
        <div className="lg:col-span-7 bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
            <h3 className="text-sm font-bold uppercase tracking-wider text-slate-700">
              Active Project Tasks Pool ({filteredProjects.length})
            </h3>

            <select
              value={selectedDomainFilter}
              onChange={(e) => setSelectedDomainFilter(e.target.value)}
              className="text-xs p-2 bg-slate-50 border border-slate-300 rounded-xl outline-none font-semibold"
            >
              <option value="all">Filter: All Tracks</option>
              {domains.map(d => (
                <option key={d.id} value={d.id}>{d.name}</option>
              ))}
            </select>
          </div>

          <div className="space-y-3 max-h-[600px] overflow-y-auto">
            {filteredProjects.length === 0 ? (
              <p className="text-xs text-slate-400 text-center py-12">No project tasks found</p>
            ) : (
              filteredProjects.map((p) => (
                <div key={p.id} className="p-4 bg-slate-50/70 rounded-2xl border border-slate-200 space-y-2">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="px-2 py-0.5 rounded-md text-[10px] font-black bg-purple-100 text-purple-900">
                          Milestone {p.taskNumber} ({p.taskNumber * 20}%)
                        </span>
                        <span className="text-[10px] font-bold text-slate-400">
                          {domains.find(d => d.id === p.domainId)?.name}
                        </span>
                      </div>
                      <h4 className="font-bold text-slate-900 text-xs mt-1">{p.title}</h4>
                      <p className="text-[11px] text-slate-500 mt-0.5">{p.objective}</p>
                    </div>

                    <button
                      type="button"
                      onClick={() => onDeleteProject(p.id)}
                      className="p-1.5 text-rose-600 hover:bg-rose-50 rounded-lg cursor-pointer"
                      title="Delete task"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
