import React from 'react';
import { SystemSettings } from '../../types';
import {
  Settings,
  Award,
  ShieldCheck,
  CheckCircle,
  Sliders,
  Layers,
  Sparkles
} from 'lucide-react';

interface AdminSettingsTabProps {
  systemSettings: SystemSettings;
  setSystemSettings: React.Dispatch<React.SetStateAction<SystemSettings>>;
  onSaveSettings: (e: React.FormEvent) => Promise<void>;
}

export const AdminSettingsTab: React.FC<AdminSettingsTabProps> = ({
  systemSettings,
  setSystemSettings,
  onSaveSettings
}) => {
  return (
    <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-6 sm:p-8 space-y-6 animate-slideUp">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-xl bg-purple-100 text-purple-700">
              <Settings className="w-5 h-5" />
            </span>
            <h2 className="text-xl font-bold text-slate-900">Platform Evaluation & Level Progression Rules</h2>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Configure rubric passing thresholds, progression levels, and randomized task allocation algorithms.
          </p>
        </div>
        <span className="px-3 py-1 bg-purple-50 text-purple-700 text-xs font-bold rounded-full border border-purple-200 self-start sm:self-auto">
          Live Real-Time Sync
        </span>
      </div>

      <form onSubmit={onSaveSettings} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Passing Threshold */}
          <div className="p-5 rounded-2xl border border-slate-200 bg-slate-50/50 space-y-3">
            <div className="flex items-center gap-2">
              <Award className="w-4 h-4 text-emerald-600" />
              <h3 className="text-sm font-bold text-slate-900">Minimum Passing Threshold</h3>
            </div>
            <p className="text-xs text-slate-500 leading-relaxed">
              Default passing score required for a milestone submission to be approved and count toward progression. Any score below this triggers a revision requirement.
            </p>
            <div className="flex items-center gap-3 pt-2">
              <input
                type="number"
                min="50"
                max="100"
                value={systemSettings.passingScore}
                onChange={(e) => setSystemSettings({ ...systemSettings, passingScore: Number(e.target.value) })}
                className="w-24 px-3 py-2 bg-white border border-slate-300 rounded-xl text-base font-black text-purple-900 text-center outline-none focus:ring-2 focus:ring-purple-500"
              />
              <span className="text-xs font-bold text-slate-700">% score required to pass</span>
            </div>
          </div>

          {/* Cross-Student Balancing */}
          <div className="p-5 rounded-2xl border border-slate-200 bg-slate-50/50 space-y-3">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-indigo-600" />
              <h3 className="text-sm font-bold text-slate-900">Dynamic Task Allocation Algorithm</h3>
            </div>
            <p className="text-xs text-slate-500 leading-relaxed">
              Distributes tasks randomly from the active domain pool while cross-balancing assignments to ensure varied project coverage across all enrolled students.
            </p>
            <label className="flex items-center gap-3 pt-2 cursor-pointer">
              <input
                type="checkbox"
                checked={systemSettings.crossStudentBalancing}
                onChange={(e) => setSystemSettings({ ...systemSettings, crossStudentBalancing: e.target.checked })}
                className="w-4 h-4 rounded text-purple-600 focus:ring-purple-500 cursor-pointer"
              />
              <span className="text-xs font-bold text-slate-800">
                Enable Pool Balancing & Anti-Duplicate Randomization
              </span>
            </label>
          </div>
        </div>

        {/* Required Tasks per Progression Level */}
        <div className="p-5 rounded-2xl border border-slate-200 bg-slate-50/50 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Required Tasks per Progression Level</h3>
              <p className="text-xs text-slate-500">
                Define task completion criteria before a student unlocks the next difficulty tier.
              </p>
            </div>
            <span className="text-xs font-semibold text-slate-500">4 Difficulty Tiers</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 pt-1">
            {(['Easy', 'Intermediate', 'Hard', 'Advanced'] as const).map((lvl) => (
              <div key={lvl} className="bg-white p-4 rounded-xl border border-slate-200 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-800">
                    {lvl === 'Advanced' ? 'Level 4: Capstone' : `Level: ${lvl}`}
                  </span>
                  <span className="text-[10px] uppercase font-bold text-slate-400">
                    {lvl === 'Easy' ? 'Beginner' : lvl === 'Intermediate' ? 'Core' : lvl === 'Hard' ? 'Advanced' : 'Flagship'}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    min="1"
                    max="10"
                    value={systemSettings.tasksPerLevel[lvl]}
                    onChange={(e) => setSystemSettings({
                      ...systemSettings,
                      tasksPerLevel: {
                        ...systemSettings.tasksPerLevel,
                        [lvl]: Number(e.target.value)
                      }
                    })}
                    className="w-full px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-bold text-slate-900 text-center outline-none focus:bg-white"
                  />
                  <span className="text-xs text-slate-500 shrink-0">tasks</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Save Button */}
        <div className="flex items-center justify-between pt-4 border-t border-slate-100">
          <p className="text-xs text-slate-500 italic">
            Changes apply immediately to newly assigned project tasks and mentor evaluation reviews.
          </p>
          <button
            type="submit"
            className="px-6 py-2.5 bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs rounded-xl shadow-md transition-all cursor-pointer flex items-center gap-2"
          >
            <CheckCircle className="w-4 h-4" />
            <span>Save System Rules</span>
          </button>
        </div>
      </form>
    </div>
  );
};
