import React from 'react';
import {
  UserProfile,
  TaskSubmission,
  DomainItem,
  PackageConfig,
  LeaderboardRecord
} from '../../types';
import {
  Users,
  Briefcase,
  FileCheck2,
  Award,
  DollarSign,
  Layers,
  Sparkles,
  RefreshCw,
  Plus,
  ArrowRight,
  Clock,
  CheckCircle,
  ExternalLink,
  Youtube,
  Globe,
  Trophy,
  Medal,
  TrendingUp,
  ShieldAlert,
  ChevronRight,
  Eye
} from 'lucide-react';

interface AdminOverviewTabProps {
  allUsers: UserProfile[];
  submissions: TaskSubmission[];
  domains: DomainItem[];
  packageConfig: PackageConfig | null;
  leaderboard: LeaderboardRecord[];
  onNavigateTab: (tab: any) => void;
  onRefreshData: () => void;
  onInspectSubmission: (sub: TaskSubmission) => void;
  onViewStudentDossier: (user: UserProfile) => void;
}

export const AdminOverviewTab: React.FC<AdminOverviewTabProps> = ({
  allUsers,
  submissions,
  domains,
  packageConfig,
  leaderboard,
  onNavigateTab,
  onRefreshData,
  onInspectSubmission,
  onViewStudentDossier
}) => {
  // Calculated stats (strictly real registered student interns, reconciled with live submissions)
  const studentUsers = allUsers.filter(u => u.role !== 'admin' && u.role !== 'company');
  const totalUsersCount = studentUsers.length;
  const activeInternsCount = studentUsers.filter(u => {
    const userSubs = submissions.filter(s => s.userId === u.uid);
    const approvedCount = new Set(userSubs.filter(s => s.status === 'approved').map(s => Number(s.taskNumber))).size;
    const effectiveProgress = Math.max(u.progress || 0, Math.min(100, approvedCount * 20));
    return u.internshipStatus === 'active' || effectiveProgress > 0 || userSubs.length > 0;
  }).length;
  const completedInternshipsCount = studentUsers.filter(u => {
    const approvedCount = new Set(submissions.filter(s => s.userId === u.uid && s.status === 'approved').map(s => Number(s.taskNumber))).size;
    const effectiveProgress = Math.max(u.progress || 0, Math.min(100, approvedCount * 20));
    return u.internshipStatus === 'completed' || effectiveProgress >= 100 || approvedCount >= 5;
  }).length;
  const isPendingReview = (s: TaskSubmission) =>
    s.status === 'submitted' ||
    s.status === 'pending_review' ||
    s.status === 'under_review' ||
    (!s.isManuallyVerified && s.status !== 'approved' && s.status !== 'rejected');

  const pendingReviewsCount = submissions.filter(isPendingReview).length;
  const paidUsersCount = studentUsers.filter(u => u.hasPaidPackage).length;
  const currentPrice = packageConfig?.price || 99;
  const totalRevenue = paidUsersCount * currentPrice;
  const totalCertificatesIssued = paidUsersCount * 2;
  const totalReferralRewards = paidUsersCount * (currentPrice * 0.1);
  const activeDomainsCount = domains.filter(d => d.isActive).length;

  // Recent 8 submissions — pending reviews prioritized first, then newest submittedAt
  const recentSubmissions = [...submissions]
    .sort((a, b) => {
      const aPending = isPendingReview(a);
      const bPending = isPendingReview(b);
      if (aPending && !bPending) return -1;
      if (!aPending && bPending) return 1;
      return new Date(b.submittedAt).getTime() - new Date(a.submittedAt).getTime();
    })
    .slice(0, 8);

  // Top 3 students on leaderboard
  const topStudents = leaderboard.slice(0, 3);

  return (
    <div className="space-y-8 animate-slideUp">
      {/* Urgent Pending Verification Queue Banner */}
      {pendingReviewsCount > 0 && (
        <div className="p-4 sm:p-5 bg-gradient-to-r from-amber-50 via-amber-100/70 to-orange-50 border-2 border-amber-300 rounded-3xl flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-sm">
          <div className="flex items-start sm:items-center gap-3.5">
            <div className="w-11 h-11 rounded-2xl bg-amber-500 text-white flex items-center justify-center shrink-0 shadow-md">
              <Clock className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-sm sm:text-base font-black text-amber-950">
                {pendingReviewsCount} Intern Submission{pendingReviewsCount > 1 ? 's' : ''} Awaiting Verification & Marks
              </h3>
              <p className="text-xs text-amber-900 mt-0.5">
                Inspect submitted proofs/screenshots, assign official marks (0–100), and unlock the next milestone for waiting interns.
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => onNavigateTab('submissions')}
            className="px-5 py-3 bg-amber-600 hover:bg-amber-700 text-white font-black text-xs rounded-2xl shadow-md transition-all flex items-center justify-center gap-2 shrink-0 cursor-pointer"
          >
            <FileCheck2 className="w-4 h-4" />
            <span>Open Verification Queue ({pendingReviewsCount})</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Quick Actions Command Center */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 rounded-3xl p-6 text-white border border-slate-800 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4">
          <div>
            <span className="text-[10px] uppercase font-black tracking-widest text-purple-300 bg-purple-500/20 px-2.5 py-0.5 rounded-full border border-purple-500/30">
              Executive Fast Actions
            </span>
            <h2 className="text-lg font-black text-white mt-1">Platform Operations Control Hub</h2>
            <p className="text-xs text-slate-300">
              Instant shortcuts to manual verification, syllabus updates, pricing rules, and live synchronization.
            </p>
          </div>

          <button
            type="button"
            onClick={onRefreshData}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold rounded-xl flex items-center gap-2 border border-slate-700 transition-all cursor-pointer self-start sm:self-auto hover:border-purple-400"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Sync Live Database</span>
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 pt-2">
          <button
            type="button"
            onClick={() => onNavigateTab('submissions')}
            className={`p-3.5 rounded-2xl text-left border transition-all cursor-pointer group flex flex-col justify-between ${
              pendingReviewsCount > 0
                ? 'bg-amber-500/20 border-amber-500/40 hover:bg-amber-500/30 text-amber-200'
                : 'bg-white/5 border-white/10 hover:bg-white/10 text-slate-200'
            }`}
          >
            <div className="flex items-center justify-between">
              <FileCheck2 className={`w-5 h-5 ${pendingReviewsCount > 0 ? 'text-amber-400 animate-bounce' : 'text-purple-400'}`} />
              {pendingReviewsCount > 0 && (
                <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-amber-400 text-amber-950">
                  {pendingReviewsCount} Due
                </span>
              )}
            </div>
            <div className="mt-3">
              <span className="text-xs font-bold text-white block">Verification Queue</span>
              <span className="text-[10px] text-slate-400 group-hover:text-slate-200 flex items-center gap-1 mt-0.5">
                Review proofs <ChevronRight className="w-3 h-3" />
              </span>
            </div>
          </button>

          <button
            type="button"
            onClick={() => onNavigateTab('projects')}
            className="p-3.5 rounded-2xl bg-white/5 border border-white/10 hover:bg-white/10 text-slate-200 text-left transition-all cursor-pointer group flex flex-col justify-between"
          >
            <Layers className="w-5 h-5 text-indigo-400" />
            <div className="mt-3">
              <span className="text-xs font-bold text-white block">Curriculum & Projects</span>
              <span className="text-[10px] text-slate-400 group-hover:text-slate-200 flex items-center gap-1 mt-0.5">
                Manage curriculum <ChevronRight className="w-3 h-3" />
              </span>
            </div>
          </button>

          <button
            type="button"
            onClick={() => onNavigateTab('package')}
            className="p-3.5 rounded-2xl bg-white/5 border border-white/10 hover:bg-white/10 text-slate-200 text-left transition-all cursor-pointer group flex flex-col justify-between"
          >
            <DollarSign className="w-5 h-5 text-emerald-400" />
            <div className="mt-3">
              <span className="text-xs font-bold text-white block">₹{currentPrice} Package Control</span>
              <span className="text-[10px] text-slate-400 group-hover:text-slate-200 flex items-center gap-1 mt-0.5">
                Edit price & perks <ChevronRight className="w-3 h-3" />
              </span>
            </div>
          </button>

          <button
            type="button"
            onClick={() => onNavigateTab('users')}
            className="p-3.5 rounded-2xl bg-white/5 border border-white/10 hover:bg-white/10 text-slate-200 text-left transition-all cursor-pointer group flex flex-col justify-between"
          >
            <Users className="w-5 h-5 text-sky-400" />
            <div className="mt-3">
              <span className="text-xs font-bold text-white block">Student Roster</span>
              <span className="text-[10px] text-slate-400 group-hover:text-slate-200 flex items-center gap-1 mt-0.5">
                Manage accounts <ChevronRight className="w-3 h-3" />
              </span>
            </div>
          </button>

          <button
            type="button"
            onClick={() => onNavigateTab('leaderboard')}
            className="p-3.5 rounded-2xl bg-white/5 border border-white/10 hover:bg-white/10 text-slate-200 text-left transition-all cursor-pointer group flex flex-col justify-between"
          >
            <Trophy className="w-5 h-5 text-amber-400" />
            <div className="mt-3">
              <span className="text-xs font-bold text-white block">Real Standings</span>
              <span className="text-[10px] text-slate-400 group-hover:text-slate-200 flex items-center gap-1 mt-0.5">
                View top interns <ChevronRight className="w-3 h-3" />
              </span>
            </div>
          </button>
        </div>
      </div>

      {/* 8 Executive Metrics Cards Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {/* Card 1 */}
        <div
          onClick={() => onNavigateTab('users')}
          className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs hover:border-purple-300 hover:shadow-md transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between text-slate-400 group-hover:text-purple-600 transition-colors">
            <span className="text-[11px] uppercase tracking-wider font-extrabold text-slate-500">Registered Students</span>
            <div className="w-8 h-8 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <p className="text-3xl font-black text-slate-900 mt-2">{totalUsersCount}</p>
          <div className="flex items-center justify-between text-[11px] text-slate-500 mt-2 pt-2 border-t border-slate-100">
            <span>Active accounts</span>
            <span className="font-bold text-purple-600 flex items-center gap-0.5">
              View Roster <ArrowRight className="w-3 h-3" />
            </span>
          </div>
        </div>

        {/* Card 2 */}
        <div
          onClick={() => onNavigateTab('users')}
          className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs hover:border-indigo-300 hover:shadow-md transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between text-slate-400 group-hover:text-indigo-600 transition-colors">
            <span className="text-[11px] uppercase tracking-wider font-extrabold text-slate-500">Active Working</span>
            <div className="w-8 h-8 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
              <Briefcase className="w-4 h-4" />
            </div>
          </div>
          <p className="text-3xl font-black text-indigo-600 mt-2">{activeInternsCount}</p>
          <div className="flex items-center justify-between text-[11px] text-slate-500 mt-2 pt-2 border-t border-slate-100">
            <span>In-progress projects</span>
            <span className="font-bold text-indigo-600">
              {totalUsersCount > 0 ? Math.round((activeInternsCount / totalUsersCount) * 100) : 0}% ratio
            </span>
          </div>
        </div>

        {/* Card 3 */}
        <div
          onClick={() => onNavigateTab('submissions')}
          className={`p-5 rounded-2xl border shadow-xs transition-all cursor-pointer group ${
            pendingReviewsCount > 0
              ? 'bg-amber-50/50 border-amber-300 hover:border-amber-400 hover:shadow-md'
              : 'bg-white border-slate-200 hover:border-amber-300 hover:shadow-md'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-[11px] uppercase tracking-wider font-extrabold text-amber-900">Pending Reviews</span>
            <div className={`w-8 h-8 rounded-xl flex items-center justify-center ${
              pendingReviewsCount > 0 ? 'bg-amber-500 text-white animate-badgePulse' : 'bg-amber-50 text-amber-600'
            }`}>
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <p className="text-3xl font-black text-amber-600 mt-2">{pendingReviewsCount}</p>
          <div className="flex items-center justify-between text-[11px] text-amber-800 mt-2 pt-2 border-t border-amber-200/60">
            <span>{pendingReviewsCount > 0 ? 'Needs admin action' : 'Queue clear'}</span>
            <span className="font-black text-amber-700 flex items-center gap-0.5">
              Review Queue <ArrowRight className="w-3 h-3" />
            </span>
          </div>
        </div>

        {/* Card 4 */}
        <div
          onClick={() => onNavigateTab('users')}
          className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs hover:border-emerald-300 hover:shadow-md transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between text-slate-400 group-hover:text-emerald-600 transition-colors">
            <span className="text-[11px] uppercase tracking-wider font-extrabold text-slate-500">Graduated Interns</span>
            <div className="w-8 h-8 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <CheckCircle className="w-4 h-4" />
            </div>
          </div>
          <p className="text-3xl font-black text-emerald-600 mt-2">{completedInternshipsCount}</p>
          <div className="flex items-center justify-between text-[11px] text-slate-500 mt-2 pt-2 border-t border-slate-100">
            <span>Completed all 5 milestones</span>
            <span className="font-bold text-emerald-600">100% finished</span>
          </div>
        </div>

        {/* Card 5 */}
        <div
          onClick={() => onNavigateTab('package')}
          className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs hover:border-emerald-400 hover:shadow-md transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between text-slate-400 group-hover:text-emerald-700 transition-colors">
            <span className="text-[11px] uppercase tracking-wider font-extrabold text-slate-500">Platform Revenue</span>
            <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold">
              ₹
            </div>
          </div>
          <p className="text-3xl font-black text-emerald-700 mt-2">₹{totalRevenue.toLocaleString('en-IN')}</p>
          <div className="flex items-center justify-between text-[11px] text-slate-500 mt-2 pt-2 border-t border-slate-100">
            <span>{paidUsersCount} verified packages</span>
            <span className="font-bold text-emerald-600">₹{currentPrice}/pkg</span>
          </div>
        </div>

        {/* Card 6 */}
        <div
          onClick={() => onNavigateTab('package')}
          className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs hover:border-purple-300 hover:shadow-md transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between text-slate-400 group-hover:text-purple-600 transition-colors">
            <span className="text-[11px] uppercase tracking-wider font-extrabold text-slate-500">Certificates Issued</span>
            <div className="w-8 h-8 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center">
              <Award className="w-4 h-4" />
            </div>
          </div>
          <p className="text-3xl font-black text-purple-600 mt-2">{totalCertificatesIssued}</p>
          <div className="flex items-center justify-between text-[11px] text-slate-500 mt-2 pt-2 border-t border-slate-100">
            <span>Completion + Appreciation</span>
            <span className="font-bold text-purple-600">Verified</span>
          </div>
        </div>

        {/* Card 7 */}
        <div
          onClick={() => onNavigateTab('package')}
          className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs hover:border-orange-300 hover:shadow-md transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between text-slate-400 group-hover:text-orange-600 transition-colors">
            <span className="text-[11px] uppercase tracking-wider font-extrabold text-slate-500">Referral Pool</span>
            <div className="w-8 h-8 rounded-xl bg-orange-50 text-orange-600 flex items-center justify-center">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <p className="text-3xl font-black text-orange-600 mt-2">₹{totalReferralRewards.toFixed(1)}</p>
          <div className="flex items-center justify-between text-[11px] text-slate-500 mt-2 pt-2 border-t border-slate-100">
            <span>10% student incentive</span>
            <span className="font-bold text-orange-600">Active</span>
          </div>
        </div>

        {/* Card 8 */}
        <div
          onClick={() => onNavigateTab('projects')}
          className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs hover:border-slate-400 hover:shadow-md transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between text-slate-400 group-hover:text-slate-800 transition-colors">
            <span className="text-[11px] uppercase tracking-wider font-extrabold text-slate-500">Curriculum Tracks</span>
            <div className="w-8 h-8 rounded-xl bg-slate-100 text-slate-700 flex items-center justify-center">
              <Layers className="w-4 h-4" />
            </div>
          </div>
          <p className="text-3xl font-black text-slate-800 mt-2">{activeDomainsCount}</p>
          <div className="flex items-center justify-between text-[11px] text-slate-500 mt-2 pt-2 border-t border-slate-100">
            <span>{domains.length} total domains</span>
            <span className="font-bold text-slate-700 flex items-center gap-0.5">
              Manage Pool <ArrowRight className="w-3 h-3" />
            </span>
          </div>
        </div>
      </div>

      {/* Main Grid: Live Submissions Feed & Domain Matrix */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: Live Recent Submissions Activity Feed */}
        <div className="lg:col-span-7 bg-white rounded-3xl border border-slate-200 p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping" />
                <h3 className="text-base font-bold text-slate-900">Live Submissions Stream</h3>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">Real-time incoming intern milestone deliverables</p>
            </div>

            <button
              type="button"
              onClick={() => onNavigateTab('submissions')}
              className="text-xs font-bold text-[#0A66C2] hover:underline flex items-center gap-1 cursor-pointer"
            >
              <span>View All ({submissions.length})</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {recentSubmissions.length === 0 ? (
            <div className="py-12 text-center text-slate-400 bg-slate-50/60 rounded-2xl border border-dashed border-slate-200">
              <Clock className="w-8 h-8 text-slate-300 mx-auto mb-2" />
              <p className="font-bold text-slate-600 text-xs">No student submissions recorded yet</p>
            </div>
          ) : (
            <div className="space-y-3">
              {recentSubmissions.map((sub) => {
                const pending = isPendingReview(sub);
                const subKey = sub.id || sub.submissionId;
                return (
                <div
                  key={subKey}
                  className={`p-4 rounded-2xl border transition-all hover:shadow-md flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                    pending
                      ? 'bg-amber-50/40 border-amber-300'
                      : sub.status === 'approved'
                      ? 'bg-emerald-50/20 border-emerald-200'
                      : 'bg-slate-50/50 border-slate-200'
                  }`}
                >
                  <div className="space-y-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-extrabold text-slate-900 text-xs">{sub.userName}</span>
                      <span className="text-[10px] text-slate-400 font-mono">({sub.userEmail})</span>
                      <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-indigo-50 text-indigo-700">
                        {sub.domainName}
                      </span>
                    </div>

                    <p className="text-xs font-semibold text-slate-700 flex items-center gap-2">
                      <span className="px-1.5 py-0.2 rounded bg-purple-100 text-purple-900 font-extrabold text-[10px]">
                        Milestone {sub.taskNumber}
                      </span>
                      <span>{sub.projectTitle || `Milestone ${sub.taskNumber}`}</span>
                    </p>

                    <div className="flex flex-wrap items-center gap-3 text-[11px] text-slate-500 pt-1">
                      <span>Submitted: {new Date(sub.submittedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                      {sub.taskNumber === 1 && sub.youtubeScreenshotUrl && sub.youtubeScreenshotUrl !== '[STORED_IN_MEMORY_AND_SERVER]' && (
                        <span className="text-red-700 font-bold flex items-center gap-1">
                          <Youtube className="w-3.5 h-3.5" />
                          <span>YouTube Proof Screenshot Attached</span>
                        </span>
                      )}
                      {sub.repositoryURL && (
                        <span className="text-slate-700 font-medium truncate max-w-[200px]">
                          Repo: {sub.repositoryURL}
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0 self-end sm:self-auto">
                    <span className={`px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wider ${
                      pending
                        ? 'bg-amber-400 text-amber-950 animate-pulse'
                        : sub.status === 'approved'
                        ? 'bg-emerald-100 text-emerald-800'
                        : sub.status === 'revision_required'
                        ? 'bg-amber-100 text-amber-800'
                        : 'bg-rose-100 text-rose-800'
                    }`}>
                      {pending ? 'Needs Review' : String(sub.status || '').replace('_', ' ')}
                    </span>

                    <button
                      type="button"
                      onClick={() => onInspectSubmission(sub)}
                      className="px-3 py-1.5 bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs rounded-xl shadow-xs transition-colors flex items-center gap-1 cursor-pointer"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>Review</span>
                    </button>
                  </div>
                </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Right Column: Domain Enrollment Matrix & Leaderboard Spotlight */}
        <div className="lg:col-span-5 space-y-6">
          {/* Domain Breakdown */}
          <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="text-base font-bold text-slate-900">Domain Enrollment Breakdown</h3>
              <button
                type="button"
                onClick={() => onNavigateTab('projects')}
                className="text-xs font-bold text-[#0A66C2] hover:underline"
              >
                Manage Tracks
              </button>
            </div>

            <div className="space-y-3">
              {domains.slice(0, 6).map((dom) => {
                const internsInDom = studentUsers.filter(u => u.selectedDomain === dom.id || u.selectedDomain === dom.slug || u.selectedDomain === dom.name).length;
                const percent = totalUsersCount > 0 ? Math.round((internsInDom / totalUsersCount) * 100) : 0;
                return (
                  <div key={dom.id} className="p-3 bg-slate-50/70 rounded-2xl border border-slate-200/80 space-y-1.5">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-bold text-slate-900">{dom.name}</span>
                      <span className="font-extrabold text-indigo-700">{internsInDom} Students ({percent}%)</span>
                    </div>
                    <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                      <div
                        className="bg-indigo-600 h-full rounded-full transition-all"
                        style={{ width: `${percent}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Leaderboard Top 3 Spotlight */}
          <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <Trophy className="w-4 h-4 text-amber-500" />
                <h3 className="text-base font-bold text-slate-900">Leaderboard Podium Spotlight</h3>
              </div>
              <button
                type="button"
                onClick={() => onNavigateTab('leaderboard')}
                className="text-xs font-bold text-amber-700 hover:underline"
              >
                Full Standings
              </button>
            </div>

            {topStudents.length === 0 ? (
              <p className="text-xs text-slate-400 text-center py-4">No ranked students yet</p>
            ) : (
              <div className="space-y-2.5">
                {topStudents.map((st, idx) => (
                  <div
                    key={st.userId}
                    className={`p-3 rounded-2xl border flex items-center justify-between gap-3 ${
                      idx === 0
                        ? 'bg-amber-50/60 border-amber-300'
                        : idx === 1
                        ? 'bg-slate-100/80 border-slate-300'
                        : 'bg-amber-100/40 border-amber-200'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className={`w-8 h-8 rounded-xl flex items-center justify-center font-black text-xs ${
                        idx === 0 ? 'bg-amber-400 text-amber-950' : idx === 1 ? 'bg-slate-300 text-slate-800' : 'bg-amber-600 text-white'
                      }`}>
                        {idx === 0 ? '🥇' : idx === 1 ? '🥈' : '🥉'}
                      </div>
                      <div>
                        <p className="font-bold text-xs text-slate-900">{st.userName}</p>
                        <p className="text-[10px] text-slate-500">{st.domainName || 'General Track'}</p>
                      </div>
                    </div>

                    <div className="text-right">
                      <span className="font-black text-sm text-purple-900 font-mono block">{st.totalPoints} pts</span>
                      <span className="text-[10px] text-slate-500">{st.tasksCompleted}/5 Milestones</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
