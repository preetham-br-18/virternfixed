import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import {
  DomainItem,
  ProjectTask,
  TaskSubmission,
  PackageConfig,
  PackageBenefit,
  UserProfile,
  SystemSettings,
  TaskEvaluationRecord,
  AuditLogRecord,
  LeaderboardRecord,
  InternshipRecord
} from '../../types';
import { dataService, DEFAULT_SETTINGS } from '../../services/dataService';
import { YOUTUBE_CONFIG, DEFAULT_ADMIN_EMAIL, ADMIN_UID } from '../../firebase/config';
import {
  Shield,
  Layers,
  FileCheck2,
  Users,
  DollarSign,
  Package,
  Award,
  Settings,
  CheckCircle,
  Clock,
  XCircle,
  RefreshCw,
  AlertCircle,
  Eye,
  Sliders,
  History,
  Flag,
  Trophy,
  ExternalLink,
  Youtube,
  X
} from 'lucide-react';

import { AdminOverviewTab } from './AdminOverviewTab';
import { AdminSubmissionsTab } from './AdminSubmissionsTab';
import { AdminUsersTab } from './AdminUsersTab';
import { AdminLeaderboardTab } from './AdminLeaderboardTab';
import { AdminProjectsTab } from './AdminProjectsTab';
import { AdminPackageTab } from './AdminPackageTab';
import { AdminYoutubeTab } from './AdminYoutubeTab';
import { AdminSettingsTab } from './AdminSettingsTab';
import { AdminAuditTab } from './AdminAuditTab';
import { AdminCompaniesTab } from './AdminCompaniesTab';
import { AdminStudentDossierModal } from './AdminStudentDossierModal';
import { Building2 } from 'lucide-react';

interface AdminPortalProps {
  setCurrentView: (view: string) => void;
}

export const AdminPortal: React.FC<AdminPortalProps> = ({ setCurrentView }) => {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState<
    'overview' | 'submissions' | 'leaderboard' | 'users' | 'companies' | 'projects' | 'package' | 'youtube' | 'settings' | 'audit'
  >('overview');

  // State data
  const [submissions, setSubmissions] = useState<TaskSubmission[]>([]);
  const [domains, setDomains] = useState<DomainItem[]>([]);
  const [projects, setProjects] = useState<ProjectTask[]>([]);
  const [packageConfig, setPackageConfig] = useState<PackageConfig | null>(null);
  const [packageBenefits, setPackageBenefits] = useState<PackageBenefit[]>([]);
  const [allUsers, setAllUsers] = useState<UserProfile[]>([]);
  const [systemSettings, setSystemSettings] = useState<SystemSettings>(DEFAULT_SETTINGS);
  const [evaluations, setEvaluations] = useState<TaskEvaluationRecord[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLogRecord[]>([]);
  const [adminLeaderboard, setAdminLeaderboard] = useState<LeaderboardRecord[]>([]);
  const [leaderboardLoading, setLeaderboardLoading] = useState<boolean>(false);

  // Filters & Feedback
  const [feedbackText, setFeedbackText] = useState<Record<string, string>>({});
  const [manualScores, setManualScores] = useState<Record<string, number>>({});
  const [subFilterStatus, setSubFilterStatus] = useState<'all' | 'submitted' | 'approved' | 'revision_required' | 'rejected'>('all');
  const [subFilterDomain, setSubFilterDomain] = useState<string>('all');
  const [subFilterTask, setSubFilterTask] = useState<number | 'all'>('all');
  const [subSearchQuery, setSubSearchQuery] = useState<string>('');

  // Toast feedback
  const [actionSuccess, setActionSuccess] = useState<string | null>(null);
  const [actionError, setActionError] = useState<string | null>(null);

  // Modals
  const [screenshotLightbox, setScreenshotLightbox] = useState<{
    isOpen: boolean;
    imageUrl: string;
    studentName: string;
    studentEmail: string;
    fileName: string;
    youtubeHandle?: string;
  } | null>(null);

  const [detailedVerifyModal, setDetailedVerifyModal] = useState<{
    isOpen: boolean;
    sub: TaskSubmission | null;
    score: number;
    feedback: string;
    status: 'approved' | 'revision_required' | 'rejected';
  } | null>(null);

  const [selectedUserForDossier, setSelectedUserForDossier] = useState<UserProfile | null>(null);

  const [flagModal, setFlagModal] = useState<{
    isOpen: boolean;
    sub?: TaskSubmission;
    reason: string;
  }>({
    isOpen: false,
    reason: ''
  });

  // Package Price & Title inputs
  const [packagePriceInput, setPackagePriceInput] = useState<number>(99);
  const [packageTitleInput, setPackageTitleInput] = useState<string>('VirIntern Official Completion Package');

  // Real-time subscriptions
  useEffect(() => {
    const unsubSubmissions = dataService.subscribeSubmissions(undefined, (subs) => {
      setSubmissions(subs);
    });

    const unsubDomains = dataService.subscribeDomains((doms) => {
      setDomains(doms);
    });

    const unsubProjects = dataService.subscribeProjects(undefined, (projs) => {
      setProjects(projs);
    });

    const unsubPackage = dataService.subscribePackageConfig((pkg) => {
      setPackageConfig(pkg);
      setPackagePriceInput(pkg.price);
      setPackageTitleInput(pkg.title);
    });

    const unsubBenefits = dataService.subscribePackageBenefits((benefits) => {
      setPackageBenefits(benefits);
    }, false);

    const unsubUsers = dataService.subscribeAllUsers((users) => {
      setAllUsers(users);
    });

    const unsubSettings = dataService.subscribeSettings((settings) => {
      setSystemSettings(settings);
    });

    const unsubLeaderboard = dataService.subscribeLeaderboard('overall', undefined, (board) => {
      setAdminLeaderboard(board);
    });

    const unsubEvaluations = dataService.subscribeEvaluations((evals) => {
      setEvaluations(evals);
    });

    const unsubAuditLogs = dataService.subscribeAuditLogs((logs) => {
      setAuditLogs(logs);
    });

    const syncAuxiliary = () => {
      dataService.getAllUsers().then(setAllUsers).catch(() => {});
    };
    syncAuxiliary();

    const unsubSubCreated = dataService.on('submission_created', syncAuxiliary);
    const unsubSubVerified = dataService.on('submission_verified', syncAuxiliary);
    const unsubUserUpdated = dataService.on('user_updated', syncAuxiliary);

    return () => {
      unsubSubmissions();
      unsubDomains();
      unsubProjects();
      unsubPackage();
      unsubBenefits();
      unsubUsers();
      unsubSettings();
      unsubLeaderboard();
      unsubEvaluations();
      unsubAuditLogs();
      unsubSubCreated();
      unsubSubVerified();
      unsubUserUpdated();
    };
  }, []);

  // Guarantee instant database sync on tab change or window focus
  useEffect(() => {
    if (activeTab === 'submissions' || activeTab === 'overview' || activeTab === 'leaderboard') {
      dataService.getSubmissions().then((subs) => {
        if (subs) setSubmissions(subs);
      }).catch(() => {});
      dataService.getLeaderboard('overall').then(setAdminLeaderboard).catch(() => {});
      dataService.getEvaluations().then(setEvaluations).catch(() => {});
    }
  }, [activeTab]);

  useEffect(() => {
    const handleSubmissionLoadError = (event: Event) => {
      const detail = (event as CustomEvent<{ code?: string; message?: string }>).detail;
      if (detail?.code === 'permission-denied') {
        setActionError('Verification Queue access was denied by Firestore. Sign in with the authorized admin UID or a verified admin email, and confirm the latest Firestore rules are deployed to virintern-daa89.');
      } else {
        setActionError(`Verification Queue could not load submissions: ${detail?.message || 'Unknown database error'}`);
      }
    };
    const handleSubmissionLoadSuccess = () => {
      setActionError(current => current?.startsWith('Verification Queue') ? null : current);
    };
    const handleSubUpdate = () => {
      dataService.getSubmissions().then((subs) => {
        if (subs) setSubmissions(subs);
      }).catch(() => {});
      dataService.getAllUsers().then(setAllUsers).catch(() => {});
      dataService.getEvaluations().then(setEvaluations).catch(() => {});
    };

    window.addEventListener('virintern_submission_updated', handleSubUpdate);
    window.addEventListener('virintern_submission_created', handleSubUpdate);
    window.addEventListener('virintern_submissions_load_error', handleSubmissionLoadError);
    window.addEventListener('virintern_submissions_loaded', handleSubmissionLoadSuccess);
    window.addEventListener('focus', handleSubUpdate);

    // Active 3-second heartbeat to guarantee verification queue stays 100% synchronized live
    const pollTimer = setInterval(handleSubUpdate, 3000);

    return () => {
      clearInterval(pollTimer);
      window.removeEventListener('virintern_submission_updated', handleSubUpdate);
      window.removeEventListener('virintern_submission_created', handleSubUpdate);
      window.removeEventListener('virintern_submissions_load_error', handleSubmissionLoadError);
      window.removeEventListener('virintern_submissions_loaded', handleSubmissionLoadSuccess);
      window.removeEventListener('focus', handleSubUpdate);
    };
  }, []);

  const showSuccess = (msg: string) => {
    setActionSuccess(msg);
    setActionError(null);
    setTimeout(() => setActionSuccess(null), 3800);
  };

  const showError = (msg: string) => {
    setActionError(msg);
    setActionSuccess(null);
    setTimeout(() => setActionError(null), 4200);
  };

  const loadAllAdminData = async () => {
    try {
      const [subs, doms, projs, pkg, users, evals, logs, board] = await Promise.all([
        dataService.getSubmissions(),
        dataService.getDomains(),
        dataService.getProjects(),
        dataService.getPackageConfig(),
        dataService.getAllUsers(),
        dataService.getEvaluations(),
        dataService.getAuditLogs(),
        dataService.getLeaderboard('overall')
      ]);
      setSubmissions(subs);
      setDomains(doms);
      setProjects(projs);
      setPackageConfig(pkg);
      setPackagePriceInput(pkg.price);
      setPackageTitleInput(pkg.title);
      setAllUsers(users);
      setEvaluations(evals);
      setAuditLogs(logs);
      setAdminLeaderboard(board);
      showSuccess('Admin dashboard synchronized live with database.');
    } catch {
      showError('Failed to refresh data.');
    }
  };

  const handleRefreshLeaderboard = async (domainId?: string) => {
    setLeaderboardLoading(true);
    try {
      const board = await dataService.getLeaderboard('overall', domainId);
      setAdminLeaderboard(board);
      showSuccess('Cohort leaderboard standings updated.');
    } catch {
      showError('Failed to refresh leaderboard standings.');
    } finally {
      setLeaderboardLoading(false);
    }
  };

  const handleOpenVerificationQueue = () => {
    setSubFilterDomain('all');
    setSubFilterTask('all');
    setSubSearchQuery('');
    const currentPending = submissions.filter(
      s => s.status === 'submitted' || s.status === 'pending_review' || s.status === 'under_review' || (!s.isManuallyVerified && s.status !== 'approved' && s.status !== 'rejected')
    ).length;
    setSubFilterStatus(currentPending > 0 ? 'submitted' : 'all');
    setActiveTab('submissions');

    Promise.all([
      dataService.getSubmissions(),
      dataService.getAllUsers(),
      dataService.getEvaluations()
    ])
      .then(([subs, users, evals]) => {
        if (subs) {
          setSubmissions(subs);
          const refreshedPending = subs.filter(
            s => s.status === 'submitted' || s.status === 'pending_review' || s.status === 'under_review' || (!s.isManuallyVerified && s.status !== 'approved' && s.status !== 'rejected')
          ).length;
          if (refreshedPending > 0 && currentPending === 0) {
            setSubFilterStatus('submitted');
          }
        }
        if (users) setAllUsers(users);
        if (evals) setEvaluations(evals);
      })
      .catch(() => {});
  };

  // Review Submission
  const handleReviewSubmission = async (
    subId: string,
    decision: 'approved' | 'revision_required' | 'rejected',
    score?: number,
    customFeedback?: string
  ) => {
    try {
      const defaultScore = decision === 'approved' ? 90 : decision === 'revision_required' ? 60 : 35;
      const finalScore = score !== undefined ? score : (manualScores[subId] ?? defaultScore);
      const feedback = customFeedback || feedbackText[subId] || (
        decision === 'approved'
          ? 'Manual verification passed! All deliverables verified and accepted by administrator.'
          : decision === 'revision_required'
          ? 'Revisions required by Admin. Please update your deliverables and resubmit.'
          : 'Submission rejected by Admin. Please fix the required items and resubmit.'
      );

      await dataService.reviewSubmission(subId, decision, finalScore, feedback, undefined, user?.name || 'Super Admin');
      showSuccess(`Milestone verified as ${decision.replace('_', ' ').toUpperCase()} (Score: ${finalScore}/100). Points and leaderboard updated!`);
      await loadAllAdminData();
    } catch (err: any) {
      showError(err?.message || 'Failed to verify submission and assign marks.');
    }
  };

  // Toggle user suspension
  const handleToggleSuspendUser = async (uid: string) => {
    await dataService.toggleUserSuspension(uid);
    await loadAllAdminData();
    showSuccess('User account suspension status updated.');
  };

  // 1-Click Toggle Paid Package (₹99)
  const handleTogglePaidPackage = async (targetUser: UserProfile) => {
    const updatedStatus = !targetUser.hasPaidPackage;
    const updatedUser: UserProfile = {
      ...targetUser,
      hasPaidPackage: updatedStatus,
      paidPackageAt: updatedStatus ? new Date().toISOString() : undefined,
      updatedAt: new Date().toISOString()
    };
    await dataService.saveUser(updatedUser);
    showSuccess(`Student ${targetUser.name} package status changed to ${updatedStatus ? '★ PAID (₹99)' : 'FREE TIER'}.`);
    await loadAllAdminData();
    if (selectedUserForDossier?.uid === targetUser.uid) {
      setSelectedUserForDossier(updatedUser);
    }
  };

  // Issue Certificates for Student
  const handleIssueCertificates = async (targetUser: UserProfile) => {
    try {
      const internship =
        (await dataService.getInternship(targetUser.uid, targetUser.selectedDomain)) ||
        (await dataService.getInternship(targetUser.uid));

      const fallbackInternship: InternshipRecord = internship || {
        id: `int_${targetUser.uid}`,
        userId: targetUser.uid,
        domainId: targetUser.selectedDomain || 'fullstack-web',
        domainName: domains.find(d => d.id === targetUser.selectedDomain)?.name || 'Full Stack Web Development',
        startDate: new Date().toISOString(),
        endDate: new Date(Date.now() + 30 * 86400000).toISOString(),
        currentTask: 5,
        completedTasks: [1, 2, 3, 4, 5],
        progress: 100,
        status: 'completed',
        task1VerificationCompleted: true,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      const certs = await dataService.issueCertificates(targetUser, fallbackInternship);
      showSuccess(`Certificates issued for ${targetUser.name}: Completion (${certs.completion.certificateId}) & Commendation (${certs.appreciation.certificateId})!`);
      await loadAllAdminData();
    } catch {
      showError('Failed to issue certificates.');
    }
  };

  // Save Settings
  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await dataService.saveSettings(systemSettings);
      showSuccess('Platform evaluation & progression rules saved and synced live!');
    } catch (err: any) {
      showError(err.message || 'Failed to update system settings');
    }
  };

  // Add Domain
  const handleAddDomain = async (
    e: React.FormEvent,
    newDom: { name: string; description: string; tags: string }
  ) => {
    if (!newDom.name.trim()) return;
    const slug = newDom.name.toLowerCase().replace(/[^a-z0-9]+/g, '-');
    const item: DomainItem = {
      id: slug,
      name: newDom.name.trim(),
      slug,
      description: newDom.description.trim(),
      icon: 'Code',
      color: 'from-indigo-600 to-blue-600',
      isActive: true,
      durationDays: 30,
      tags: newDom.tags.split(',').map(t => t.trim()),
      createdAt: new Date().toISOString()
    };
    await dataService.saveDomain(item);
    await loadAllAdminData();
    showSuccess(`Track "${item.name}" added to curriculum pool!`);
  };

  const handleToggleDomain = async (domain: DomainItem) => {
    const updated = { ...domain, isActive: !domain.isActive };
    await dataService.saveDomain(updated);
    await loadAllAdminData();
    showSuccess(`Track "${domain.name}" status updated.`);
  };

  const handleDeleteDomain = async (id: string) => {
    if (confirm('Are you sure you want to delete this track from curriculum?')) {
      await dataService.deleteDomain(id);
      await loadAllAdminData();
      showSuccess('Track deleted from database.');
    }
  };

  // Add Project Task
  const handleAddProject = async (e: React.FormEvent, newProj: any) => {
    if (!newProj.title.trim()) return;
    const task: ProjectTask = {
      id: `proj_${Date.now()}`,
      domainId: newProj.domainId || domains[0]?.id || 'fullstack-web',
      taskNumber: newProj.taskNumber as 1 | 2 | 3 | 4 | 5,
      title: newProj.title.trim(),
      difficulty: newProj.difficulty,
      objective: newProj.objective.trim() || 'Construct and verify project module',
      description: newProj.description.trim() || 'Implement task per instructions',
      instructions: newProj.instructions.split('\n').filter((s: string) => s.trim().length > 0),
      expectedOutput: 'Clean GitHub repository URL with documentation',
      submissionType: 'github_and_demo',
      resources: [{ title: 'Developer Reference Guide', url: 'https://developer.mozilla.org' }],
      isActive: true,
      createdAt: new Date().toISOString()
    };
    await dataService.saveProject(task);
    await loadAllAdminData();
    showSuccess(`Task "${task.title}" added to Milestone ${task.taskNumber}!`);
  };

  const handleDeleteProject = async (id: string) => {
    if (confirm('Delete this project task from the pool?')) {
      await dataService.deleteProject(id);
      await loadAllAdminData();
      showSuccess('Task removed from pool.');
    }
  };

  // Package Price & Benefits
  const handleUpdatePackagePrice = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!packageConfig) return;
    const updated: PackageConfig = {
      ...packageConfig,
      price: Number(packagePriceInput) || 99,
      title: packageTitleInput || packageConfig.title,
      updatedAt: new Date().toISOString()
    };
    await dataService.updatePackageConfig(updated);
    setPackageConfig(updated);
    showSuccess(`Package price dynamically updated to ₹${updated.price} across the entire platform!`);
  };

  const handleSaveBenefit = async (benefit: PackageBenefit) => {
    await dataService.savePackageBenefit(benefit);
    showSuccess(`Benefit "${benefit.title}" saved instantly to database!`);
    await loadAllAdminData();
  };

  const handleDeleteBenefit = async (id: string, title: string) => {
    if (confirm(`Remove benefit "${title}" from the completion package?`)) {
      await dataService.deletePackageBenefit(id);
      showSuccess(`Benefit "${title}" removed.`);
      await loadAllAdminData();
    }
  };

  const handleToggleBenefit = async (id: string) => {
    await dataService.toggleBenefitStatus(id);
    showSuccess('Benefit visibility updated.');
    await loadAllAdminData();
  };

  const handleMoveBenefit = async (currentIndex: number, direction: 'up' | 'down') => {
    const targetIndex = direction === 'up' ? currentIndex - 1 : currentIndex + 1;
    if (targetIndex < 0 || targetIndex >= packageBenefits.length) return;
    const updated = [...packageBenefits];
    const [moved] = updated.splice(currentIndex, 1);
    updated.splice(targetIndex, 0, moved);
    await dataService.reorderBenefits(updated);
    showSuccess('Benefits reordered.');
    await loadAllAdminData();
  };

  // Flag Suspicious
  const handleSaveFlag = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!flagModal.sub || !flagModal.reason.trim()) return;
    await dataService.flagSubmission(user?.uid || 'admin', flagModal.sub.id, flagModal.reason.trim());
    showSuccess('Submission flagged for review. Audit log updated.');
    setFlagModal({ isOpen: false, reason: '' });
    await loadAllAdminData();
  };

  const pendingReviewsCount = submissions.filter(s => s.status === 'submitted' || s.status === 'pending_review' || s.status === 'under_review' || (!s.isManuallyVerified && s.status !== 'approved' && s.status !== 'rejected')).length;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 animate-fadeIn">
      {/* Super Admin Title Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 rounded-3xl p-6 sm:p-8 text-white flex flex-col md:flex-row md:items-center justify-between gap-6 shadow-2xl border border-slate-800">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-purple-600 to-indigo-500 flex items-center justify-center text-white shadow-xl shadow-purple-600/30">
            <Shield className="w-7 h-7" />
          </div>
          <div>
            <div className="flex items-center gap-2.5">
              <h1 className="text-xl sm:text-2xl font-black tracking-tight">VirIntern Admin Control Portal</h1>
              <span className="text-[10px] uppercase font-black tracking-widest px-2.5 py-0.5 rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/30">
                Super Admin
              </span>
            </div>
            <div className="text-xs text-slate-400 mt-1 flex flex-wrap items-center gap-2">
              <span>Admin UID: <span className="text-purple-300 font-mono font-semibold bg-purple-950/70 px-1.5 py-0.5 rounded border border-purple-500/30">{user?.uid || ADMIN_UID}</span></span>
              <span>•</span>
              <span className="text-slate-200 font-mono">{user?.email || DEFAULT_ADMIN_EMAIL}</span>
              <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-bold ml-1">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                Live Database Active
              </span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            type="button"
            onClick={handleOpenVerificationQueue}
            className={`px-4 py-2.5 text-xs font-black rounded-xl flex items-center gap-2 transition-all cursor-pointer shadow-md ${
              pendingReviewsCount > 0
                ? 'bg-amber-500 hover:bg-amber-600 text-white animate-badgePulse'
                : 'bg-slate-800 hover:bg-slate-700 text-slate-200'
            }`}
          >
            <FileCheck2 className="w-4 h-4" />
            <span>Verification Queue</span>
            {pendingReviewsCount > 0 && (
              <span className="px-2 py-0.5 rounded-full text-[10px] bg-white text-amber-950 font-black">
                {pendingReviewsCount}
              </span>
            )}
          </button>

          <button
            type="button"
            onClick={loadAllAdminData}
            className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold rounded-xl flex items-center gap-2 border border-slate-700 transition-colors cursor-pointer hover:border-purple-400"
            title="Refresh Admin Data"
          >
            <RefreshCw className="w-4 h-4" />
            <span>Sync Live</span>
          </button>
        </div>
      </div>

      {/* Floating Animated Toasts */}
      {actionSuccess && (
        <div className="p-4 bg-emerald-50 border-2 border-emerald-300 text-emerald-900 text-xs rounded-2xl flex items-center gap-3 shadow-lg animate-slideUp">
          <CheckCircle className="w-5 h-5 text-emerald-600 shrink-0" />
          <span className="font-bold">{actionSuccess}</span>
        </div>
      )}

      {actionError && (
        <div className="p-4 bg-rose-50 border-2 border-rose-300 text-rose-900 text-xs rounded-2xl flex items-center gap-3 shadow-lg animate-slideUp">
          <AlertCircle className="w-5 h-5 text-rose-600 shrink-0" />
          <span className="font-bold">{actionError}</span>
        </div>
      )}

      {/* Tab Navigation Pill Bar */}
      <div className="flex flex-wrap gap-1.5 border-b border-slate-200 pb-2">
        {[
          { id: 'overview', label: 'Overview Metrics', icon: Shield },
          { id: 'submissions', label: `Verification Queue (${pendingReviewsCount})`, icon: FileCheck2, highlight: pendingReviewsCount > 0 },
          { id: 'leaderboard', label: 'Real Standings', icon: Trophy },
          { id: 'users', label: `Student Roster (${allUsers.length})`, icon: Users },
          { id: 'companies', label: 'Corporate Partners & Talent', icon: Building2 },
          { id: 'projects', label: 'Curriculum & Project Library', icon: Layers },
          { id: 'package', label: `₹${packageConfig?.price || 99} Package Pricing`, icon: DollarSign },
          { id: 'youtube', label: 'YouTube Verification Rules', icon: Youtube },
          { id: 'settings', label: 'Evaluation Rules & Rubrics', icon: Settings },
          { id: 'audit', label: `Security Audit (${auditLogs.length})`, icon: History }
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => {
                if (tab.id === 'submissions') {
                  handleOpenVerificationQueue();
                } else {
                  setActiveTab(tab.id as any);
                }
              }}
              className={`px-4 py-2.5 rounded-2xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer ${
                isActive
                  ? 'bg-purple-600 text-white shadow-lg shadow-purple-600/30'
                  : tab.highlight
                  ? 'bg-amber-100 text-amber-900 border border-amber-300 hover:bg-amber-200'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Tab 1: Overview */}
      {activeTab === 'overview' && (
        <AdminOverviewTab
          allUsers={allUsers}
          submissions={submissions}
          domains={domains}
          packageConfig={packageConfig}
          leaderboard={adminLeaderboard}
          onNavigateTab={(tab: any) => {
            if (tab === 'submissions') {
              handleOpenVerificationQueue();
              return;
            }
            setActiveTab(tab);
          }}
          onRefreshData={loadAllAdminData}
          onInspectSubmission={(sub) => {
            const key = sub.id || sub.submissionId || '';
            const score = manualScores[key] ?? (sub.rubricScore ?? 85);
            setDetailedVerifyModal({
              isOpen: true,
              sub,
              score,
              feedback: feedbackText[key] || '',
              status: score >= 70 ? 'approved' : 'revision_required'
            });
          }}
          onViewStudentDossier={setSelectedUserForDossier}
        />
      )}

      {/* Tab 2: Submissions Queue */}
      {activeTab === 'submissions' && (
        <AdminSubmissionsTab
          submissions={submissions}
          domains={domains}
          evaluations={evaluations}
          subFilterStatus={subFilterStatus}
          setSubFilterStatus={setSubFilterStatus}
          subFilterDomain={subFilterDomain}
          setSubFilterDomain={setSubFilterDomain}
          subFilterTask={subFilterTask}
          setSubFilterTask={setSubFilterTask}
          subSearchQuery={subSearchQuery}
          setSubSearchQuery={setSubSearchQuery}
          manualScores={manualScores}
          setManualScores={setManualScores}
          feedbackText={feedbackText}
          setFeedbackText={setFeedbackText}
          onReviewSubmission={handleReviewSubmission}
          onOpenDetailedVerifyModal={(sub, score) => {
            const key = sub.id || sub.submissionId || '';
            setDetailedVerifyModal({
              isOpen: true,
              sub,
              score,
              feedback: feedbackText[key] || '',
              status: score >= 70 ? 'approved' : 'revision_required'
            });
          }}
          onOpenScreenshotLightbox={(sub) => {
            if (sub.youtubeScreenshotUrl && sub.youtubeScreenshotUrl !== '[STORED_IN_MEMORY_AND_SERVER]') {
              setScreenshotLightbox({
                isOpen: true,
                imageUrl: sub.youtubeScreenshotUrl,
                studentName: sub.userName,
                studentEmail: sub.userEmail,
                fileName: sub.youtubeScreenshotFileName || 'youtube_subscribe_proof.png',
                youtubeHandle: sub.youtubeProofText || sub.youtubeSubscribeProof
              });
            }
          }}
          onOpenFlagModal={(sub) => {
            setFlagModal({
              isOpen: true,
              sub,
              reason: ''
            });
          }}
          onRefreshData={loadAllAdminData}
        />
      )}

      {/* Tab 3: Leaderboard */}
      {activeTab === 'leaderboard' && (
        <AdminLeaderboardTab
          leaderboard={adminLeaderboard}
          domains={domains}
          loading={leaderboardLoading}
          onRefreshLeaderboard={handleRefreshLeaderboard}
        />
      )}

      {/* Tab 4: Student Roster */}
      {activeTab === 'users' && (
        <AdminUsersTab
          allUsers={allUsers}
          domains={domains}
          submissions={submissions}
          onToggleSuspendUser={handleToggleSuspendUser}
          onTogglePaidPackage={handleTogglePaidPackage}
          onIssueCertificates={handleIssueCertificates}
          onViewStudentDossier={setSelectedUserForDossier}
        />
      )}

      {/* Tab 4.5: Corporate Partners & Talent Discovery */}
      {activeTab === 'companies' && (
        <AdminCompaniesTab
          onSuccess={showSuccess}
          onError={showError}
        />
      )}

      {/* Tab 5: Curriculum & Project Tasks */}
      {activeTab === 'projects' && (
        <AdminProjectsTab
          domains={domains}
          projects={projects}
          onAddDomain={handleAddDomain}
          onToggleDomain={handleToggleDomain}
          onDeleteDomain={handleDeleteDomain}
          onAddProject={handleAddProject}
          onDeleteProject={handleDeleteProject}
        />
      )}

      {/* Tab 6: Package Pricing & Benefits */}
      {activeTab === 'package' && (
        <AdminPackageTab
          packageConfig={packageConfig}
          packagePriceInput={packagePriceInput}
          setPackagePriceInput={setPackagePriceInput}
          packageTitleInput={packageTitleInput}
          setPackageTitleInput={setPackageTitleInput}
          packageBenefits={packageBenefits}
          onUpdatePackagePrice={handleUpdatePackagePrice}
          onSaveBenefit={handleSaveBenefit}
          onDeleteBenefit={handleDeleteBenefit}
          onToggleBenefit={handleToggleBenefit}
          onMoveBenefit={handleMoveBenefit}
          showSuccess={showSuccess}
          showError={showError}
        />
      )}

      {/* Tab 7: YouTube Rules */}
      {activeTab === 'youtube' && (
        <AdminYoutubeTab
          onShowSuccess={showSuccess}
        />
      )}

      {/* Tab 8: Settings & Rules */}
      {activeTab === 'settings' && (
        <AdminSettingsTab
          systemSettings={systemSettings}
          setSystemSettings={setSystemSettings}
          onSaveSettings={handleSaveSettings}
        />
      )}

      {/* Tab 9: Audit Trail */}
      {activeTab === 'audit' && (
        <AdminAuditTab
          auditLogs={auditLogs}
          onRefreshLogs={loadAllAdminData}
        />
      )}

      {/* Student Dossier Modal */}
      {selectedUserForDossier && (
        <AdminStudentDossierModal
          user={selectedUserForDossier}
          submissions={submissions}
          domains={domains}
          onClose={() => setSelectedUserForDossier(null)}
          onTogglePaidPackage={handleTogglePaidPackage}
          onToggleSuspend={handleToggleSuspendUser}
          onIssueCertificates={handleIssueCertificates}
          onInspectSubmission={(sub) => {
            const key = sub.id || sub.submissionId || '';
            const score = manualScores[key] ?? (sub.rubricScore ?? 85);
            setDetailedVerifyModal({
              isOpen: true,
              sub,
              score,
              feedback: feedbackText[key] || '',
              status: score >= 70 ? 'approved' : 'revision_required'
            });
          }}
        />
      )}

      {/* YouTube Subscribe Screenshot Lightbox */}
      {screenshotLightbox && screenshotLightbox.isOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 animate-fadeIn">
          <div className="bg-slate-900 text-white rounded-3xl max-w-4xl w-full border border-slate-700 shadow-2xl overflow-hidden my-4 animate-scaleIn">
            <div className="p-4 sm:p-5 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-red-600 text-white flex items-center justify-center shrink-0">
                  <Youtube className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm sm:text-base font-bold text-white flex items-center gap-2">
                    <span>YouTube Channel Subscribe Proof Screenshot</span>
                    <span className="text-[10px] font-mono bg-red-950 text-red-300 px-2 py-0.5 rounded border border-red-800">
                      @virintern
                    </span>
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Intern: <strong className="text-white">{screenshotLightbox.studentName}</strong> ({screenshotLightbox.studentEmail}) • Handle: <span className="text-red-400 font-mono font-bold">{screenshotLightbox.youtubeHandle || 'Not provided'}</span>
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <a
                  href={screenshotLightbox.imageUrl}
                  target="_blank"
                  rel="noreferrer"
                  download={screenshotLightbox.fileName}
                  className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition-colors"
                  title="Open full image in new tab"
                >
                  <ExternalLink className="w-5 h-5" />
                </a>
                <button
                  type="button"
                  onClick={() => setScreenshotLightbox(null)}
                  className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition-colors cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            <div className="p-4 sm:p-6 flex items-center justify-center bg-slate-950/60 max-h-[70vh] overflow-auto">
              <img
                src={screenshotLightbox.imageUrl}
                alt="Student YouTube Subscription Proof"
                className="max-h-[62vh] max-w-full rounded-2xl object-contain shadow-2xl border border-slate-800"
              />
            </div>

            <div className="p-4 bg-slate-950 border-t border-slate-800 flex items-center justify-between text-xs">
              <span className="text-slate-400 font-mono">{screenshotLightbox.fileName}</span>
              <button
                type="button"
                onClick={() => setScreenshotLightbox(null)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white font-bold rounded-xl transition-colors cursor-pointer"
              >
                Close Inspector
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Detailed Full-Screen Manual Verification Modal */}
      {detailedVerifyModal && detailedVerifyModal.isOpen && detailedVerifyModal.sub && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-black/70 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 animate-fadeIn">
          <div className="bg-white rounded-3xl max-w-4xl w-full border border-slate-200 shadow-2xl overflow-hidden my-4 animate-scaleIn">
            <div className="p-5 bg-gradient-to-r from-slate-900 to-indigo-950 text-white flex items-center justify-between">
              <div>
                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-purple-500/30 text-purple-200 border border-purple-500/40">
                    Milestone {detailedVerifyModal.sub.taskNumber} Manual Review
                  </span>
                  <span className="text-xs text-slate-300">
                    {detailedVerifyModal.sub.domainName}
                  </span>
                </div>
                <h3 className="text-base sm:text-lg font-black text-white mt-1">
                  Manual Verification: {detailedVerifyModal.sub.projectTitle || `Task ${detailedVerifyModal.sub.taskNumber}`}
                </h3>
                <p className="text-xs text-slate-300 mt-0.5">
                  Student: <strong>{detailedVerifyModal.sub.userName}</strong> ({detailedVerifyModal.sub.userEmail})
                </p>
              </div>

              <button
                type="button"
                onClick={() => setDetailedVerifyModal(null)}
                className="p-2 text-white/70 hover:text-white hover:bg-white/10 rounded-full transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-5 max-h-[70vh] overflow-y-auto text-xs text-slate-700">
              <div className="space-y-4">
                <h4 className="font-extrabold uppercase tracking-wider text-slate-400 text-[10px]">
                  Submitted Deliverables & Verification Proof:
                </h4>

                {/* If Task 1, show YouTube Screenshot */}
                {detailedVerifyModal.sub.taskNumber === 1 && (
                  <div className="p-4 bg-red-50/70 rounded-2xl border border-red-200 space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2 text-red-700 font-bold">
                        <Youtube className="w-5 h-5" />
                        <span>YouTube Subscription Verification (@virintern)</span>
                      </div>
                      <span className="font-mono text-xs bg-white px-2.5 py-1 rounded-lg border border-red-200 font-bold text-slate-900">
                        Handle: {detailedVerifyModal.sub.youtubeProofText || detailedVerifyModal.sub.youtubeSubscribeProof || '@not_provided'}
                      </span>
                    </div>

                    {detailedVerifyModal.sub.youtubeScreenshotUrl ? (
                      <div className="space-y-2">
                        <span className="text-[11px] font-bold text-slate-600 block">Subscription Proof Screenshot Preview:</span>
                        <div className="bg-slate-950 p-3 rounded-2xl flex items-center justify-center">
                          <img
                            src={detailedVerifyModal.sub.youtubeScreenshotUrl}
                            alt="Subscribe Screenshot"
                            className="max-h-72 rounded-xl object-contain shadow-lg"
                          />
                        </div>
                      </div>
                    ) : (
                      <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-amber-900 font-semibold">
                        ⚠️ No subscribe proof screenshot was uploaded for this submission.
                      </div>
                    )}
                  </div>
                )}

                {/* Tasks 2-5 links */}
                {detailedVerifyModal.sub.taskNumber > 1 && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 p-4 bg-slate-50 rounded-2xl border border-slate-200">
                    <div>
                      <span className="font-bold text-slate-600 block mb-1">GitHub Repository:</span>
                      {detailedVerifyModal.sub.repositoryURL || detailedVerifyModal.sub.githubUrl ? (
                        <a
                          href={detailedVerifyModal.sub.repositoryURL || detailedVerifyModal.sub.githubUrl}
                          target="_blank"
                          rel="noreferrer"
                          className="text-[#0A66C2] font-bold underline flex items-center gap-1 text-xs"
                        >
                          <span>{detailedVerifyModal.sub.repositoryURL || detailedVerifyModal.sub.githubUrl}</span>
                          <ExternalLink className="w-3 h-3" />
                        </a>
                      ) : (
                        <span className="text-slate-400">Not provided</span>
                      )}
                    </div>

                    <div>
                      <span className="font-bold text-slate-600 block mb-1">Live Project Demo URL:</span>
                      {detailedVerifyModal.sub.demoURL || detailedVerifyModal.sub.projectUrl ? (
                        <a
                          href={detailedVerifyModal.sub.demoURL || detailedVerifyModal.sub.projectUrl}
                          target="_blank"
                          rel="noreferrer"
                          className="text-[#0A66C2] font-bold underline flex items-center gap-1 text-xs"
                        >
                          <span>{detailedVerifyModal.sub.demoURL || detailedVerifyModal.sub.projectUrl}</span>
                          <ExternalLink className="w-3 h-3" />
                        </a>
                      ) : (
                        <span className="text-slate-400">Not provided</span>
                      )}
                    </div>
                  </div>
                )}

                {/* Score Controls */}
                <div className="p-5 bg-purple-50/50 rounded-2xl border border-purple-200 space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-bold text-slate-900 text-sm">Assign Official Rubric Score</h4>
                      <p className="text-[11px] text-slate-500">Scores ≥70 pass and unlock next milestone</p>
                    </div>

                    <div className="flex items-center gap-2">
                      <input
                        type="number"
                        min={0}
                        max={100}
                        value={detailedVerifyModal.score}
                        onChange={(e) => {
                          const val = Math.max(0, Math.min(100, Number(e.target.value) || 0));
                          setDetailedVerifyModal(prev => prev ? ({ ...prev, score: val }) : null);
                        }}
                        className="w-20 p-2 text-center text-base font-black text-purple-950 bg-white border-2 border-purple-400 rounded-xl"
                      />
                      <span className="text-sm font-bold text-slate-600">/ 100</span>
                      <span className={`px-2.5 py-1 rounded-full text-xs font-black ${
                        detailedVerifyModal.score >= 70 ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
                      }`}>
                        {detailedVerifyModal.score >= 70 ? 'PASSING' : 'FAILING'}
                      </span>
                    </div>
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">
                      Administrator Remarks / Mentor Feedback:
                    </label>
                    <textarea
                      rows={3}
                      value={detailedVerifyModal.feedback}
                      onChange={(e) => {
                        const val = e.target.value;
                        setDetailedVerifyModal(prev => prev ? ({ ...prev, feedback: val }) : null);
                      }}
                      placeholder="Enter constructive milestone evaluation notes..."
                      className="w-full text-xs p-3 bg-white border border-slate-300 rounded-xl outline-none focus:border-purple-600"
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="p-5 bg-slate-50 border-t border-slate-200 flex flex-wrap items-center justify-between gap-3">
              <button
                type="button"
                onClick={() => setDetailedVerifyModal(null)}
                className="px-4 py-2.5 bg-white border border-slate-300 text-slate-700 font-bold text-xs rounded-xl hover:bg-slate-100"
              >
                Cancel
              </button>

              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={async () => {
                    const subId = detailedVerifyModal.sub!.id || detailedVerifyModal.sub!.submissionId || '';
                    const score = detailedVerifyModal.score;
                    const fb = detailedVerifyModal.feedback || 'Manual verification passed! All deliverables verified by administrator.';
                    await handleReviewSubmission(subId, 'approved', score, fb);
                    setDetailedVerifyModal(null);
                  }}
                  className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow transition-all flex items-center gap-1.5 cursor-pointer"
                >
                  <CheckCircle className="w-4 h-4" />
                  <span>Approve & Award Score ({detailedVerifyModal.score}/100)</span>
                </button>

                <button
                  type="button"
                  onClick={async () => {
                    const subId = detailedVerifyModal.sub!.id || detailedVerifyModal.sub!.submissionId || '';
                    const score = detailedVerifyModal.score;
                    const fb = detailedVerifyModal.feedback || 'Revisions required by Admin. Please update deliverables and resubmit.';
                    await handleReviewSubmission(subId, 'revision_required', score, fb);
                    setDetailedVerifyModal(null);
                  }}
                  className="px-4 py-2.5 bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs rounded-xl shadow transition-all flex items-center gap-1.5 cursor-pointer"
                >
                  <AlertCircle className="w-4 h-4" />
                  <span>Request Revision</span>
                </button>

                <button
                  type="button"
                  onClick={async () => {
                    const subId = detailedVerifyModal.sub!.id || detailedVerifyModal.sub!.submissionId || '';
                    const score = detailedVerifyModal.score;
                    const fb = detailedVerifyModal.feedback || 'Submission rejected by Admin.';
                    await handleReviewSubmission(subId, 'rejected', score, fb);
                    setDetailedVerifyModal(null);
                  }}
                  className="px-4 py-2.5 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs rounded-xl shadow transition-all flex items-center gap-1.5 cursor-pointer"
                >
                  <XCircle className="w-4 h-4" />
                  <span>Reject</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Flag Suspicious Submission Modal */}
      {flagModal.isOpen && flagModal.sub && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-white rounded-3xl max-w-md w-full border border-slate-200 shadow-2xl overflow-hidden my-8 animate-scaleIn">
            <div className="p-5 bg-gradient-to-r from-rose-900 to-slate-900 text-white flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <Flag className="w-5 h-5 text-rose-300" />
                <h3 className="text-base font-bold">Flag Suspicious Submission</h3>
              </div>
              <button
                type="button"
                onClick={() => setFlagModal(prev => ({ ...prev, isOpen: false }))}
                className="p-1.5 text-white/70 hover:text-white rounded-full hover:bg-white/10"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveFlag} className="p-6 space-y-4 text-xs text-slate-700">
              <p className="text-slate-600">
                Flagging submission for <strong>{flagModal.sub.userName}</strong> (Task {flagModal.sub.taskNumber}: {flagModal.sub.projectTitle}).
              </p>

              <div>
                <label className="block font-bold text-slate-800 mb-1">
                  Reason for Flagging <span className="text-rose-500">*</span>
                </label>
                <textarea
                  rows={3}
                  required
                  value={flagModal.reason}
                  onChange={(e) => setFlagModal(prev => ({ ...prev, reason: e.target.value }))}
                  placeholder="e.g. Copied code from template repository without customization, invalid live demo URL, or fraudulent verification..."
                  className="w-full p-2.5 border border-slate-300 rounded-xl outline-none focus:ring-2 focus:ring-rose-500"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setFlagModal(prev => ({ ...prev, isOpen: false }))}
                  className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-xl font-bold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-xl shadow-md cursor-pointer flex items-center gap-1.5"
                >
                  <Flag className="w-4 h-4" />
                  <span>Flag Submission</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
