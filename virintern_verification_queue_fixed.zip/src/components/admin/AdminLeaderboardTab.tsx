import React, { useState } from 'react';
import { LeaderboardRecord, DomainItem } from '../../types';
import { isSameDomain } from '../../services/dataService';
import { exportToCsv } from './adminUtils';
import {
  Trophy,
  Medal,
  Search,
  RefreshCw,
  Download,
  ShieldCheck,
  Award,
  ExternalLink,
  ChevronRight
} from 'lucide-react';

interface AdminLeaderboardTabProps {
  leaderboard: LeaderboardRecord[];
  domains: DomainItem[];
  loading: boolean;
  onRefreshLeaderboard: (domainId?: string) => void;
}

export const AdminLeaderboardTab: React.FC<AdminLeaderboardTabProps> = ({
  leaderboard,
  domains,
  loading,
  onRefreshLeaderboard
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterDomain, setFilterDomain] = useState('all');

  const filteredBoard = leaderboard.filter((record) => {
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchName = (record.userName || '').toLowerCase().includes(q);
      const matchEmail = (record.userEmail || '').toLowerCase().includes(q);
      const matchDomain = (record.domainName || '').toLowerCase().includes(q);
      if (!matchName && !matchEmail && !matchDomain) return false;
    }
    if (filterDomain !== 'all') {
      const domObj = domains.find(d => d.id === filterDomain);
      if (!isSameDomain(record.domainId, filterDomain, record.domainName, domObj?.name || filterDomain)) {
        return false;
      }
    }
    return true;
  });

  const handleExportCsv = () => {
    const headers = ['Rank', 'Intern Name', 'Email', 'Domain Track', 'Milestones Cleared', 'Total Points', 'Verified Avg Score'];
    const rows = filteredBoard.map((r, i) => [
      i + 1,
      r.userName,
      r.userEmail || '',
      r.domainName || 'General Track',
      r.tasksCompleted || 0,
      r.totalPoints || 0,
      r.averageScore || 0
    ]);
    exportToCsv(`virintern_leaderboard_${new Date().toISOString().split('T')[0]}`, headers, rows);
  };

  const top3 = filteredBoard.slice(0, 3);

  return (
    <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-6 space-y-6 animate-slideUp">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-5">
        <div>
          <div className="flex flex-wrap items-center gap-2">
            <span className="p-1.5 rounded-xl bg-amber-100 text-amber-700">
              <Trophy className="w-5 h-5" />
            </span>
            <h2 className="text-xl font-bold text-slate-900">Student Standings & Cohort Leaderboard</h2>
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200 flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping" />
              <span>Real-Time</span>
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Real registered students ranked by verified milestone points awarded by administrator mentor evaluations.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => onRefreshLeaderboard(filterDomain === 'all' ? undefined : filterDomain)}
            disabled={loading}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
            <span>{loading ? 'Syncing...' : 'Recalculate Standings'}</span>
          </button>

          <button
            type="button"
            onClick={handleExportCsv}
            className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>
        </div>
      </div>

      {/* Podium Top 3 Cards if available */}
      {top3.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {top3.map((intern, idx) => {
            const medalEmoji = idx === 0 ? '🥇' : idx === 1 ? '🥈' : '🥉';
            const medalColor =
              idx === 0
                ? 'from-amber-500/20 to-yellow-500/10 border-amber-300'
                : idx === 1
                ? 'from-slate-300/30 to-slate-200/10 border-slate-300'
                : 'from-amber-700/20 to-orange-500/10 border-amber-400';
            return (
              <div
                key={intern.userId}
                className={`p-5 rounded-2xl border bg-gradient-to-b ${medalColor} relative overflow-hidden flex flex-col justify-between shadow-xs`}
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <span className="text-3xl">{medalEmoji}</span>
                    <div>
                      <span className="text-[10px] font-black uppercase tracking-wider text-slate-500">
                        Rank #{idx + 1}
                      </span>
                      <h4 className="font-extrabold text-slate-900 text-sm truncate max-w-[150px]">
                        {intern.userName}
                      </h4>
                      <p className="text-[11px] text-slate-500 truncate">{intern.userEmail}</p>
                    </div>
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-200/60 flex items-center justify-between text-xs">
                  <div>
                    <span className="text-[10px] text-slate-400 block">Milestones</span>
                    <span className="font-bold text-slate-800">{intern.tasksCompleted || 0} / 5</span>
                  </div>
                  <div className="text-right">
                    <span className="text-[10px] text-slate-400 block">Score</span>
                    <span className="text-lg font-black text-purple-900 font-mono">{intern.totalPoints} pts</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Filter and Search Bar */}
      <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="relative w-full sm:w-72">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search student or email..."
            className="w-full text-xs pl-8 pr-3 py-2.5 bg-white border border-slate-300 rounded-xl outline-none font-medium focus:border-purple-600"
          />
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
        </div>

        <div className="flex items-center gap-3 w-full sm:w-auto">
          <select
            value={filterDomain}
            onChange={(e) => {
              setFilterDomain(e.target.value);
              onRefreshLeaderboard(e.target.value === 'all' ? undefined : e.target.value);
            }}
            className="w-full sm:w-60 text-xs p-2.5 bg-white border border-slate-300 rounded-xl outline-none font-semibold text-slate-800"
          >
            <option value="all">All Domain Tracks ({domains.length})</option>
            {domains.map((dom) => (
              <option key={dom.id} value={dom.id}>
                {dom.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Standings Table */}
      <div className="overflow-x-auto rounded-2xl border border-slate-200">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200">
            <tr>
              <th className="py-3 px-4 w-16 text-center">Rank</th>
              <th className="py-3 px-4">Intern Name & Email</th>
              <th className="py-3 px-4">Domain Track</th>
              <th className="py-3 px-4 text-center">Milestones Done</th>
              <th className="py-3 px-4 text-center">Average Score</th>
              <th className="py-3 px-4 text-right">Total Verified Points</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {filteredBoard.length === 0 ? (
              <tr>
                <td colSpan={6} className="py-12 text-center text-slate-400">
                  <Trophy className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                  <p className="font-bold text-slate-600">No ranked students found</p>
                </td>
              </tr>
            ) : (
              filteredBoard.map((record, index) => {
                const rank = index + 1;
                return (
                  <tr key={record.userId} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3 px-4 text-center">
                      <span className={`w-7 h-7 rounded-xl flex items-center justify-center font-black mx-auto text-xs ${
                        rank === 1
                          ? 'bg-amber-400 text-amber-950 shadow-2xs'
                          : rank === 2
                          ? 'bg-slate-300 text-slate-800'
                          : rank === 3
                          ? 'bg-amber-600 text-white'
                          : 'bg-slate-100 text-slate-700'
                      }`}>
                        {rank}
                      </span>
                    </td>

                    <td className="py-3 px-4">
                      <div className="flex items-center gap-2.5">
                        <div className="w-8 h-8 rounded-xl bg-purple-100 text-purple-700 font-bold flex items-center justify-center text-xs">
                          {record.userName?.charAt(0).toUpperCase() || 'U'}
                        </div>
                        <div>
                          <p className="font-bold text-slate-900">{record.userName}</p>
                          <p className="text-[11px] text-slate-400 font-mono">{record.userEmail}</p>
                        </div>
                      </div>
                    </td>

                    <td className="py-3 px-4">
                      <span className="px-2.5 py-1 rounded-lg text-[11px] font-bold bg-indigo-50 text-indigo-700 border border-indigo-100">
                        {record.domainName || 'General Track'}
                      </span>
                    </td>

                    <td className="py-3 px-4 text-center">
                      <span className="font-bold text-slate-800">
                        {record.tasksCompleted || 0} / 5
                      </span>
                    </td>

                    <td className="py-3 px-4 text-center">
                      <span className={`px-2 py-0.5 rounded-lg text-xs font-black ${
                        (record.averageScore || 0) >= 85
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-blue-100 text-[#0A66C2]'
                      }`}>
                        {record.averageScore || 0}/100
                      </span>
                    </td>

                    <td className="py-3 px-4 text-right">
                      <span className="font-mono font-black text-sm text-purple-900 bg-purple-50 px-2.5 py-1 rounded-xl border border-purple-200">
                        {record.totalPoints} pts
                      </span>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
