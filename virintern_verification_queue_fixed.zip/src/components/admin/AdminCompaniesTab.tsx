import React, { useState, useEffect } from 'react';
import { dataService } from '../../services/dataService';
import {
  CompanyProfile,
  CompanyVerificationStatus,
  RecruitmentOpportunity,
  ShortlistRecord
} from '../../types';
import {
  Building2,
  ShieldCheck,
  ShieldAlert,
  Clock,
  Briefcase,
  Users,
  Search,
  CheckCircle,
  XCircle,
  ExternalLink,
  AlertCircle,
  Eye,
  RefreshCw,
  X
} from 'lucide-react';

interface AdminCompaniesTabProps {
  onSuccess: (msg: string) => void;
  onError: (msg: string) => void;
}

export const AdminCompaniesTab: React.FC<AdminCompaniesTabProps> = ({ onSuccess, onError }) => {
  const [companies, setCompanies] = useState<CompanyProfile[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [statusFilter, setStatusFilter] = useState<'all' | CompanyVerificationStatus>('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Opportunities state
  const [opportunities, setOpportunities] = useState<RecruitmentOpportunity[]>([]);
  const [loadingOpps, setLoadingOpps] = useState<boolean>(true);

  // Shortlists state
  const [allShortlists, setAllShortlists] = useState<ShortlistRecord[]>([]);

  // Selected company modal
  const [selectedCompany, setSelectedCompany] = useState<CompanyProfile | null>(null);

  // Sub-tab
  const [activeSubTab, setActiveSubTab] = useState<'companies' | 'opportunities' | 'shortlists'>('companies');

  const loadData = async () => {
    setLoading(true);
    setLoadingOpps(true);
    try {
      const [comps, opps, shorties] = await Promise.all([
        dataService.getCompanies(),
        dataService.getOpportunities(),
        dataService.getShortlists()
      ]);
      setCompanies(comps);
      setOpportunities(opps);
      setAllShortlists(shorties);
    } catch {
      onError('Failed to load corporate partner records.');
    } finally {
      setLoading(false);
      setLoadingOpps(false);
    }
  };

  useEffect(() => {
    loadData();
    const unsubComps = dataService.subscribeCompanies(setCompanies);
    const unsubOpps = dataService.subscribeOpportunities(setOpportunities);
    return () => {
      unsubComps();
      unsubOpps();
    };
  }, []);

  // Verification Handler
  const handleVerify = async (companyId: string, status: CompanyVerificationStatus, companyName: string) => {
    try {
      await dataService.verifyCompany(companyId, status, undefined, 'VirIntern Super Admin');
      onSuccess(`Company "${companyName}" verification status updated to ${status.toUpperCase()}.`);
      loadData();
    } catch {
      onError('Failed to update verification status.');
    }
  };

  // Opportunity Review Handler
  const handleReviewOpp = async (oppId: string, status: 'approved' | 'rejected', title: string) => {
    try {
      await dataService.reviewOpportunity(oppId, status);
      onSuccess(`Recruitment opportunity "${title}" has been ${status.toUpperCase()}.`);
      loadData();
    } catch {
      onError('Failed to review opportunity.');
    }
  };

  const pendingCount = companies.filter(c => c.verificationStatus === 'pending_verification').length;
  const approvedCount = companies.filter(c => c.verificationStatus === 'approved').length;
  const suspendedCount = companies.filter(c => c.verificationStatus === 'suspended').length;
  const pendingOppsCount = opportunities.filter(o => o.approvalStatus === 'pending').length;

  const filteredCompanies = companies.filter((c) => {
    if (statusFilter !== 'all' && c.verificationStatus !== statusFilter) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchName = c.name.toLowerCase().includes(q);
      const matchEmail = c.officialEmail.toLowerCase().includes(q);
      const matchContact = c.contactPerson?.toLowerCase().includes(q);
      const matchIndustry = c.industry?.toLowerCase().includes(q);
      if (!matchName && !matchEmail && !matchContact && !matchIndustry) return false;
    }
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Metric Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Total Companies</span>
            <Building2 className="w-4 h-4 text-slate-400" />
          </div>
          <span className="text-2xl font-extrabold text-slate-900 mt-2 block">{companies.length}</span>
          <span className="text-[11px] text-slate-400 font-medium mt-0.5 block">Registered partners</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-amber-700 uppercase tracking-wider">Pending Review</span>
            <Clock className="w-4 h-4 text-amber-600" />
          </div>
          <span className="text-2xl font-extrabold text-amber-800 mt-2 block">{pendingCount}</span>
          <span className="text-[11px] text-amber-700 font-medium mt-0.5 block">Awaiting admin verification</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-emerald-700 uppercase tracking-wider">Approved Partners</span>
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
          </div>
          <span className="text-2xl font-extrabold text-emerald-800 mt-2 block">{approvedCount}</span>
          <span className="text-[11px] text-emerald-700 font-medium mt-0.5 block">Talent discovery active</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-[#0A66C2] uppercase tracking-wider">Active Postings</span>
            <Briefcase className="w-4 h-4 text-[#0A66C2]" />
          </div>
          <span className="text-2xl font-extrabold text-[#0A66C2] mt-2 block">{opportunities.length}</span>
          <span className="text-[11px] text-slate-500 font-medium mt-0.5 block">{pendingOppsCount} pending approval</span>
        </div>
      </div>

      {/* Sub-Tabs */}
      <div className="flex items-center justify-between bg-white p-2 rounded-xl border border-slate-200 shadow-2xs">
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setActiveSubTab('companies')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
              activeSubTab === 'companies'
                ? 'bg-[#0A66C2] text-white'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            Registered Companies ({companies.length})
          </button>

          <button
            type="button"
            onClick={() => setActiveSubTab('opportunities')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-colors cursor-pointer flex items-center gap-1.5 ${
              activeSubTab === 'opportunities'
                ? 'bg-[#0A66C2] text-white'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <span>Opportunities</span>
            {pendingOppsCount > 0 && (
              <span className="px-1.5 py-0.2 rounded text-[10px] font-extrabold bg-amber-500 text-white">
                {pendingOppsCount}
              </span>
            )}
          </button>

          <button
            type="button"
            onClick={() => setActiveSubTab('shortlists')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
              activeSubTab === 'shortlists'
                ? 'bg-[#0A66C2] text-white'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            Shortlist Activity ({allShortlists.length})
          </button>
        </div>

        <button
          type="button"
          onClick={loadData}
          className="p-1.5 text-slate-500 hover:text-slate-900 rounded-lg hover:bg-slate-100"
          title="Refresh Data"
        >
          <RefreshCw className="w-4 h-4" />
        </button>
      </div>

      {/* SUB-TAB 1: COMPANIES LIST */}
      {activeSubTab === 'companies' && (
        <div className="space-y-4">
          {/* Filters & Search */}
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 text-xs">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search by company name, email, contact person, or industry..."
                className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs focus:outline-none focus:ring-2 focus:ring-[#0A66C2]"
              />
            </div>

            <div className="flex items-center gap-2">
              <span className="font-semibold text-slate-500">Status:</span>
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value as any)}
                className="px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-medium text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#0A66C2]"
              >
                <option value="all">All Verification Statuses</option>
                <option value="pending_verification">Pending Verification ({pendingCount})</option>
                <option value="approved">Approved Partners ({approvedCount})</option>
                <option value="suspended">Suspended Accounts ({suspendedCount})</option>
                <option value="rejected">Rejected Applications</option>
              </select>
            </div>
          </div>

          {/* Table */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
            {loading ? (
              <div className="py-12 text-center text-slate-500 text-xs">
                <div className="w-5 h-5 border-2 border-[#0A66C2] border-t-transparent rounded-full animate-spin mx-auto mb-2" />
                Loading company accounts...
              </div>
            ) : filteredCompanies.length === 0 ? (
              <div className="py-12 text-center text-slate-500 text-xs">
                <Building2 className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                <p className="font-bold text-slate-700">No companies found</p>
                <p className="text-slate-400 mt-0.5">Companies registered via the Corporate Registration portal will appear here.</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 uppercase font-bold tracking-wider text-[11px]">
                    <tr>
                      <th className="py-3 px-4">Company Details</th>
                      <th className="py-3 px-4">Contact Person</th>
                      <th className="py-3 px-4">Industry & Website</th>
                      <th className="py-3 px-4 text-center">Status</th>
                      <th className="py-3 px-4 text-center">Talent Discovery</th>
                      <th className="py-3 px-4 text-right">Verification Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-medium">
                    {filteredCompanies.map((c) => (
                      <tr key={c.id} className="hover:bg-slate-50/70 transition-colors">
                        <td className="py-3.5 px-4">
                          <div className="font-bold text-slate-900">{c.name}</div>
                          <div className="text-[11px] text-slate-500">{c.officialEmail}</div>
                        </td>

                        <td className="py-3.5 px-4 text-slate-700">
                          <div className="font-semibold text-slate-800">{c.contactPerson || 'Not provided'}</div>
                          <div className="text-[11px] text-slate-500">{c.designation || 'Representative'}</div>
                        </td>

                        <td className="py-3.5 px-4 text-slate-700">
                          <div>{c.industry || 'Technology'}</div>
                          {c.website ? (
                            <a
                              href={c.website}
                              target="_blank"
                              rel="noreferrer"
                              className="text-[11px] text-[#0A66C2] hover:underline inline-flex items-center gap-0.5"
                            >
                              <span>{c.website.replace(/^https?:\/\//, '')}</span>
                              <ExternalLink className="w-3 h-3" />
                            </a>
                          ) : (
                            <span className="text-[11px] text-slate-400">No website</span>
                          )}
                        </td>

                        <td className="py-3.5 px-4 text-center">
                          {c.verificationStatus === 'approved' && (
                            <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                              Approved
                            </span>
                          )}
                          {c.verificationStatus === 'pending_verification' && (
                            <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-amber-50 text-amber-800 border border-amber-200 animate-pulse">
                              Pending
                            </span>
                          )}
                          {c.verificationStatus === 'suspended' && (
                            <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-rose-50 text-rose-800 border border-rose-200">
                              Suspended
                            </span>
                          )}
                          {c.verificationStatus === 'rejected' && (
                            <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-slate-100 text-slate-600 border border-slate-300">
                              Rejected
                            </span>
                          )}
                        </td>

                        <td className="py-3.5 px-4 text-center">
                          <span className={`font-semibold text-xs ${c.talentDiscoveryEnabled ? 'text-emerald-700' : 'text-slate-400'}`}>
                            {c.talentDiscoveryEnabled ? 'Active' : 'Disabled'}
                          </span>
                        </td>

                        <td className="py-3.5 px-4 text-right">
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              type="button"
                              onClick={() => setSelectedCompany(c)}
                              className="px-2.5 py-1 text-[11px] font-semibold text-slate-700 hover:bg-slate-100 rounded transition-colors cursor-pointer"
                            >
                              Inspect
                            </button>

                            {c.verificationStatus !== 'approved' && (
                              <button
                                type="button"
                                onClick={() => handleVerify(c.id, 'approved', c.name)}
                                className="px-2.5 py-1 text-[11px] font-bold bg-emerald-600 text-white hover:bg-emerald-700 rounded transition-colors cursor-pointer flex items-center gap-1"
                              >
                                <CheckCircle className="w-3 h-3" />
                                <span>Approve</span>
                              </button>
                            )}

                            {c.verificationStatus === 'approved' && (
                              <button
                                type="button"
                                onClick={() => handleVerify(c.id, 'suspended', c.name)}
                                className="px-2.5 py-1 text-[11px] font-semibold text-amber-700 hover:bg-amber-50 border border-amber-300 rounded transition-colors cursor-pointer"
                              >
                                Suspend
                              </button>
                            )}

                            {c.verificationStatus === 'suspended' && (
                              <button
                                type="button"
                                onClick={() => handleVerify(c.id, 'approved', c.name)}
                                className="px-2.5 py-1 text-[11px] font-bold bg-[#0A66C2] text-white hover:bg-[#004182] rounded transition-colors cursor-pointer"
                              >
                                Reactivate
                              </button>
                            )}

                            {c.verificationStatus === 'pending_verification' && (
                              <button
                                type="button"
                                onClick={() => handleVerify(c.id, 'rejected', c.name)}
                                className="px-2.5 py-1 text-[11px] font-semibold text-rose-700 hover:bg-rose-50 border border-rose-300 rounded transition-colors cursor-pointer"
                              >
                                Reject
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* SUB-TAB 2: OPPORTUNITIES REVIEW */}
      {activeSubTab === 'opportunities' && (
        <div className="space-y-4">
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
            <h3 className="font-bold text-sm text-slate-900">Company Recruitment Opportunities</h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Review and approve hiring opportunities posted by partner companies before they appear to students.
            </p>
          </div>

          {loadingOpps ? (
            <div className="py-12 text-center text-slate-500 text-xs">
              <div className="w-5 h-5 border-2 border-[#0A66C2] border-t-transparent rounded-full animate-spin mx-auto mb-2" />
              Loading opportunities...
            </div>
          ) : opportunities.length === 0 ? (
            <div className="bg-white p-12 rounded-xl border border-slate-200 text-center text-slate-500 text-xs">
              <Briefcase className="w-8 h-8 text-slate-300 mx-auto mb-2" />
              <p className="font-bold text-slate-700">No recruitment postings submitted yet</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {opportunities.map((opp) => (
                <div key={opp.id} className="bg-white rounded-xl border border-slate-200 p-5 shadow-2xs space-y-3">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <h4 className="font-bold text-sm text-slate-900">{opp.title}</h4>
                      <div className="flex items-center gap-2 text-xs text-slate-500 mt-0.5">
                        <span className="font-semibold text-slate-700">{opp.companyName}</span>
                        <span aria-hidden="true">·</span>
                        <span>{opp.locationType}</span>
                        {opp.location && <span>({opp.location})</span>}
                      </div>
                    </div>

                    <div>
                      {opp.approvalStatus === 'approved' && (
                        <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                          Approved
                        </span>
                      )}
                      {opp.approvalStatus === 'pending' && (
                        <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-amber-50 text-amber-800 border border-amber-200 animate-pulse">
                          Pending Approval
                        </span>
                      )}
                      {opp.approvalStatus === 'rejected' && (
                        <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-rose-50 text-rose-800 border border-rose-200">
                          Rejected
                        </span>
                      )}
                    </div>
                  </div>

                  <p className="text-xs text-slate-600 line-clamp-3 leading-relaxed">
                    {opp.description}
                  </p>

                  {opp.requiredSkills && opp.requiredSkills.length > 0 && (
                    <div className="flex flex-wrap gap-1 text-[11px]">
                      {opp.requiredSkills.map(sk => (
                        <span key={sk} className="px-2 py-0.5 bg-slate-100 rounded text-slate-700">
                          {sk}
                        </span>
                      ))}
                    </div>
                  )}

                  <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
                    <span>Deadline: {opp.deadline}</span>

                    <div className="flex items-center gap-2">
                      {opp.approvalStatus !== 'approved' && (
                        <button
                          type="button"
                          onClick={() => handleReviewOpp(opp.id, 'approved', opp.title)}
                          className="px-3 py-1 text-xs font-bold rounded-lg bg-emerald-600 text-white hover:bg-emerald-700 cursor-pointer"
                        >
                          Approve
                        </button>
                      )}
                      {opp.approvalStatus !== 'rejected' && (
                        <button
                          type="button"
                          onClick={() => handleReviewOpp(opp.id, 'rejected', opp.title)}
                          className="px-3 py-1 text-xs font-semibold rounded-lg text-rose-700 hover:bg-rose-50 border border-rose-300 cursor-pointer"
                        >
                          Reject
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* SUB-TAB 3: SHORTLIST AUDIT */}
      {activeSubTab === 'shortlists' && (
        <div className="space-y-4">
          <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-2xs">
            <h3 className="font-bold text-sm text-slate-900">Talent Shortlist Audit Trail</h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Monitor candidate shortlists across all partner companies to ensure ethical hiring and student privacy compliance.
            </p>
          </div>

          <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
            {allShortlists.length === 0 ? (
              <div className="py-12 text-center text-slate-500 text-xs">
                <Users className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                <p className="font-bold text-slate-700">No shortlist records yet</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 uppercase font-bold tracking-wider text-[11px]">
                    <tr>
                      <th className="py-3 px-4">Company</th>
                      <th className="py-3 px-4">Student Candidate</th>
                      <th className="py-3 px-4">Role</th>
                      <th className="py-3 px-4 text-center">Status</th>
                      <th className="py-3 px-4">Private Notes</th>
                      <th className="py-3 px-4 text-right">Shortlisted At</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-medium">
                    {allShortlists.map((s) => (
                      <tr key={s.id} className="hover:bg-slate-50/70 transition-colors">
                        <td className="py-3.5 px-4 font-bold text-slate-900">{s.companyName}</td>
                        <td className="py-3.5 px-4 font-semibold text-slate-800">{s.studentName}</td>
                        <td className="py-3.5 px-4 text-slate-700">{s.roleOrOpportunityTitle}</td>
                        <td className="py-3.5 px-4 text-center">
                          <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-blue-50 text-[#0A66C2]">
                            {s.status}
                          </span>
                        </td>
                        <td className="py-3.5 px-4 text-slate-500 italic max-w-xs truncate">
                          {s.privateNotes || 'None'}
                        </td>
                        <td className="py-3.5 px-4 text-right text-slate-500 font-mono">
                          {new Date(s.createdAt).toLocaleDateString()}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* INSPECT COMPANY MODAL */}
      {selectedCompany && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-fadeIn">
          <div className="bg-white rounded-2xl max-w-lg w-full shadow-2xl border border-slate-200 p-6 space-y-4 text-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="font-bold text-base text-slate-900">{selectedCompany.name}</h3>
              <button
                type="button"
                onClick={() => setSelectedCompany(null)}
                className="text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <span className="font-bold text-slate-400 uppercase text-[10px] block">Official Email</span>
                <span className="text-slate-800 font-semibold">{selectedCompany.officialEmail}</span>
              </div>
              <div>
                <span className="font-bold text-slate-400 uppercase text-[10px] block">Industry</span>
                <span className="text-slate-800 font-semibold">{selectedCompany.industry}</span>
              </div>
              <div>
                <span className="font-bold text-slate-400 uppercase text-[10px] block">Contact Person</span>
                <span className="text-slate-800 font-semibold">{selectedCompany.contactPerson} ({selectedCompany.designation})</span>
              </div>
              <div>
                <span className="font-bold text-slate-400 uppercase text-[10px] block">Website</span>
                <a href={selectedCompany.website} target="_blank" rel="noreferrer" className="text-[#0A66C2] underline">
                  {selectedCompany.website}
                </a>
              </div>
            </div>

            <div>
              <span className="font-bold text-slate-400 uppercase text-[10px] block">About</span>
              <p className="text-slate-700 mt-1 leading-relaxed">{selectedCompany.description || 'No description provided.'}</p>
            </div>

            <div>
              <span className="font-bold text-slate-400 uppercase text-[10px] block">Preferred Skills</span>
              <div className="flex flex-wrap gap-1 mt-1">
                {selectedCompany.preferredSkills?.map(s => (
                  <span key={s} className="px-2 py-0.5 bg-slate-100 rounded text-slate-700">{s}</span>
                ))}
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setSelectedCompany(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-800"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
