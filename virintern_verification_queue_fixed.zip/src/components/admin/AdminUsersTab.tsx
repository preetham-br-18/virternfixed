import React, { useState } from 'react';
import { UserProfile, DomainItem, TaskSubmission } from '../../types';
import { exportToCsv } from './adminUtils';
import {
  Users,
  Search,
  Filter,
  DollarSign,
  Ban,
  CheckCircle,
  Award,
  Download,
  Eye,
  RotateCcw,
  ShieldCheck,
  ChevronRight,
  ExternalLink
} from 'lucide-react';

interface AdminUsersTabProps {
  allUsers: UserProfile[];
  domains: DomainItem[];
  submissions: TaskSubmission[];
  onToggleSuspendUser: (uid: string) => void;
  onTogglePaidPackage: (user: UserProfile) => void;
  onIssueCertificates: (user: UserProfile) => void;
  onViewStudentDossier: (user: UserProfile) => void;
}

export const AdminUsersTab: React.FC<AdminUsersTabProps> = ({
  allUsers,
  domains,
  submissions,
  onToggleSuspendUser,
  onTogglePaidPackage,
  onIssueCertificates,
  onViewStudentDossier
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterDomain, setFilterDomain] = useState('all');
  const [filterPayment, setFilterPayment] = useState<'all' | 'paid' | 'free'>('all');
  const [filterStatus, setFilterStatus] = useState<'all' | 'active' | 'suspended'>('all');

  const studentUsers = allUsers.filter(u => u.role !== 'admin' && u.role !== 'company');

  // Filtered users
  const filteredUsers = studentUsers.filter((u) => {
    // Search
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchName = (u.name || '').toLowerCase().includes(q);
      const matchEmail = (u.email || '').toLowerCase().includes(q);
      const matchDomain = (u.selectedDomain || '').toLowerCase().includes(q);
      if (!matchName && !matchEmail && !matchDomain) return false;
    }

    // Domain
    if (filterDomain !== 'all') {
      const domObj = domains.find(d => d.id === filterDomain);
      const uDom = (u.selectedDomain || '').toLowerCase();
      if (uDom !== filterDomain.toLowerCase() && uDom !== (domObj?.name || '').toLowerCase() && uDom !== (domObj?.slug || '').toLowerCase()) return false;
    }

    // Payment
    if (filterPayment === 'paid' && !u.hasPaidPackage) return false;
    if (filterPayment === 'free' && u.hasPaidPackage) return false;

    // Status
    if (filterStatus === 'suspended' && !u.isSuspended) return false;
    if (filterStatus === 'active' && u.isSuspended) return false;

    return true;
  });

  const paidCount = studentUsers.filter(u => u.hasPaidPackage).length;
  const suspendedCount = studentUsers.filter(u => u.isSuspended).length;
  const completedCount = studentUsers.filter(u => u.progress === 100 || u.internshipStatus === 'completed').length;

  const handleExportCsv = () => {
    const headers = [
      'UID',
      'Name',
      'Email',
      'Selected Domain',
      'Progress %',
      'Package Paid',
      'Suspended',
      'Registered At'
    ];
    const rows = filteredUsers.map(u => [
      u.uid,
      u.name,
      u.email,
      u.selectedDomain || 'None',
      u.progress || 0,
      u.hasPaidPackage ? 'YES' : 'NO',
      u.isSuspended ? 'YES' : 'NO',
      u.createdAt || ''
    ]);
    exportToCsv(`virintern_student_roster_${new Date().toISOString().split('T')[0]}`, headers, rows);
  };

  return (
    <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-6 space-y-6 animate-slideUp">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-5">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold text-slate-900">Student Roster & Account Administration</h2>
            <span className="px-2.5 py-0.5 rounded-full text-xs font-black bg-purple-100 text-purple-900 border border-purple-200">
              {studentUsers.length} Interns
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Track student onboarding, inspect individual milestone dossiers, toggle ₹99 package status, and grant completion credentials.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleExportCsv}
            className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
            title="Download CSV export"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>
        </div>
      </div>

      {/* Filter Chips & Bar */}
      <div className="bg-slate-50/80 p-4 rounded-2xl border border-slate-200 space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {/* Search Input */}
          <div className="relative">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search student by name, email..."
              className="w-full text-xs pl-8 pr-3 py-2.5 bg-white border border-slate-300 rounded-xl outline-none font-medium focus:border-purple-600"
            />
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          </div>

          {/* Domain Filter */}
          <div>
            <select
              value={filterDomain}
              onChange={(e) => setFilterDomain(e.target.value)}
              className="w-full text-xs p-2.5 bg-white border border-slate-300 rounded-xl outline-none font-semibold text-slate-800"
            >
              <option value="all">All Domain Tracks ({domains.length})</option>
              {domains.map((dom) => (
                <option key={dom.id} value={dom.id}>
                  {dom.name}
                </option>
              ))}
            </select>
          </div>

          {/* Payment Status Filter */}
          <div>
            <select
              value={filterPayment}
              onChange={(e) => setFilterPayment(e.target.value as any)}
              className="w-full text-xs p-2.5 bg-white border border-slate-300 rounded-xl outline-none font-semibold text-slate-800"
            >
              <option value="all">All Package Statuses ({studentUsers.length})</option>
              <option value="paid">★ ₹99 Paid Package ({paidCount})</option>
              <option value="free">Free Tier ({studentUsers.length - paidCount})</option>
            </select>
          </div>

          {/* Account Status Filter */}
          <div>
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value as any)}
              className="w-full text-xs p-2.5 bg-white border border-slate-300 rounded-xl outline-none font-semibold text-slate-800"
            >
              <option value="all">All Account Statuses</option>
              <option value="active">Active ({studentUsers.length - suspendedCount})</option>
              <option value="suspended">Suspended ({suspendedCount})</option>
            </select>
          </div>
        </div>

        {/* Quick status summary strip */}
        <div className="flex flex-wrap items-center gap-3 pt-1 text-xs text-slate-600 border-t border-slate-200/60">
          <span>Showing <strong>{filteredUsers.length}</strong> of {studentUsers.length} interns</span>
          <span>•</span>
          <span className="text-emerald-700 font-bold">{paidCount} Paid Package Users</span>
          <span>•</span>
          <span className="text-purple-700 font-bold">{completedCount} Graduated</span>
          {suspendedCount > 0 && (
            <>
              <span>•</span>
              <span className="text-rose-700 font-bold">{suspendedCount} Suspended</span>
            </>
          )}
        </div>
      </div>

      {/* Users Table */}
      <div className="overflow-x-auto rounded-2xl border border-slate-200">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-50 text-slate-600 font-bold border-b border-slate-200">
            <tr>
              <th className="py-3 px-4">Student Name & Email</th>
              <th className="py-3 px-4">Domain Track</th>
              <th className="py-3 px-4">Milestone Progress</th>
              <th className="py-3 px-4">₹99 Package</th>
              <th className="py-3 px-4">Account Status</th>
              <th className="py-3 px-4 text-right">Admin Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {filteredUsers.length === 0 ? (
              <tr>
                <td colSpan={6} className="py-12 text-center text-slate-400">
                  <Users className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                  <p className="font-bold text-slate-600">No students match the current filters</p>
                </td>
              </tr>
            ) : (
              filteredUsers.map((u) => {
                const uSubs = submissions.filter(s => s.userId === u.uid);
                const approvedCount = uSubs.filter(s => s.status === 'approved').length;
                const enrolledDomain = domains.find(d => d.id === u.selectedDomain || d.slug === u.selectedDomain);

                return (
                  <tr key={u.uid} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3.5 px-4">
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-purple-600 to-indigo-600 text-white font-extrabold flex items-center justify-center shrink-0 text-sm shadow-xs">
                          {u.photoURL ? (
                            <img src={u.photoURL} alt={u.name} className="w-full h-full object-cover rounded-xl" />
                          ) : (
                            u.name?.charAt(0).toUpperCase() || 'U'
                          )}
                        </div>
                        <div>
                          <p className="font-bold text-slate-900 hover:text-purple-700 cursor-pointer" onClick={() => onViewStudentDossier(u)}>
                            {u.name}
                          </p>
                          <p className="text-[11px] text-slate-400 font-mono">{u.email}</p>
                        </div>
                      </div>
                    </td>

                    <td className="py-3.5 px-4">
                      <span className="px-2.5 py-1 rounded-lg text-[11px] font-bold bg-indigo-50 text-indigo-700 border border-indigo-100">
                        {enrolledDomain?.name || u.selectedDomain || 'Unassigned'}
                      </span>
                    </td>

                    <td className="py-3.5 px-4">
                      <div className="space-y-1 w-32">
                        <div className="flex items-center justify-between text-[11px]">
                          <span className="font-extrabold text-slate-800">{u.progress || (approvedCount * 20)}%</span>
                          <span className="text-slate-400">{approvedCount}/5 done</span>
                        </div>
                        <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden">
                          <div
                            className="bg-purple-600 h-full rounded-full transition-all"
                            style={{ width: `${u.progress || (approvedCount * 20)}%` }}
                          />
                        </div>
                      </div>
                    </td>

                    <td className="py-3.5 px-4">
                      <button
                        type="button"
                        onClick={() => onTogglePaidPackage(u)}
                        className={`px-2.5 py-1 rounded-xl text-[11px] font-bold transition-all cursor-pointer flex items-center gap-1 shadow-2xs ${
                          u.hasPaidPackage
                            ? 'bg-emerald-100 hover:bg-emerald-200 text-emerald-800 border border-emerald-300'
                            : 'bg-slate-100 hover:bg-slate-200 text-slate-600 border border-slate-200'
                        }`}
                        title="Click to toggle package payment status"
                      >
                        <DollarSign className="w-3 h-3" />
                        <span>{u.hasPaidPackage ? '★ Paid ₹99' : 'Free Tier'}</span>
                      </button>
                    </td>

                    <td className="py-3.5 px-4">
                      <span
                        className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider ${
                          u.isSuspended
                            ? 'bg-rose-100 text-rose-800 border border-rose-300'
                            : 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                        }`}
                      >
                        {u.isSuspended ? 'Suspended' : 'Active'}
                      </span>
                    </td>

                    <td className="py-3.5 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          type="button"
                          onClick={() => onViewStudentDossier(u)}
                          className="px-2.5 py-1.5 bg-purple-50 hover:bg-purple-100 text-purple-700 font-bold rounded-xl transition-colors cursor-pointer flex items-center gap-1"
                          title="View student dossier and milestones"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          <span>Dossier</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => onIssueCertificates(u)}
                          className="p-1.5 text-purple-600 hover:bg-purple-50 rounded-xl transition-colors cursor-pointer"
                          title="Issue completion & appreciation certificates"
                        >
                          <Award className="w-4 h-4" />
                        </button>

                        <button
                          type="button"
                          onClick={() => onToggleSuspendUser(u.uid)}
                          className={`p-1.5 rounded-xl transition-colors cursor-pointer ${
                            u.isSuspended
                              ? 'text-emerald-600 hover:bg-emerald-50'
                              : 'text-rose-600 hover:bg-rose-50'
                          }`}
                          title={u.isSuspended ? 'Restore account' : 'Suspend account'}
                        >
                          <Ban className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
