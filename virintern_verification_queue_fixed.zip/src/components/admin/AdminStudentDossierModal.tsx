import React from 'react';
import { UserProfile, TaskSubmission, DomainItem } from '../../types';
import {
  X,
  User,
  Mail,
  Award,
  CheckCircle,
  Clock,
  AlertCircle,
  XCircle,
  ExternalLink,
  ShieldCheck,
  DollarSign,
  Ban,
  RotateCcw,
  Youtube,
  Github,
  Globe,
  FileText
} from 'lucide-react';

interface AdminStudentDossierModalProps {
  user: UserProfile | null;
  submissions: TaskSubmission[];
  domains: DomainItem[];
  onClose: () => void;
  onTogglePaidPackage: (user: UserProfile) => void;
  onToggleSuspend: (uid: string) => void;
  onIssueCertificates: (user: UserProfile) => void;
  onInspectSubmission: (sub: TaskSubmission) => void;
}

export const AdminStudentDossierModal: React.FC<AdminStudentDossierModalProps> = ({
  user,
  submissions,
  domains,
  onClose,
  onTogglePaidPackage,
  onToggleSuspend,
  onIssueCertificates,
  onInspectSubmission
}) => {
  if (!user) return null;

  const userSubmissions = submissions.filter(s => s.userId === user.uid);
  const enrolledDomain = domains.find(d => d.id === user.selectedDomain || d.slug === user.selectedDomain);
  const approvedCount = userSubmissions.filter(s => s.status === 'approved').length;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/70 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 animate-fadeIn">
      <div className="bg-white rounded-3xl max-w-4xl w-full border border-slate-200 shadow-2xl overflow-hidden my-4 animate-scaleIn">
        {/* Header */}
        <div className="p-6 bg-gradient-to-r from-slate-900 via-indigo-950 to-purple-950 text-white flex items-start justify-between">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-purple-600 to-indigo-500 flex items-center justify-center text-white text-2xl font-black shadow-lg">
              {user.photoURL ? (
                <img src={user.photoURL} alt={user.name} className="w-full h-full object-cover rounded-2xl" />
              ) : (
                user.name?.charAt(0).toUpperCase() || 'U'
              )}
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h3 className="text-xl font-bold text-white">{user.name}</h3>
                <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider ${
                  user.isSuspended ? 'bg-rose-500/30 text-rose-300 border border-rose-500/40' : 'bg-emerald-500/30 text-emerald-300 border border-emerald-500/40'
                }`}>
                  {user.isSuspended ? 'Suspended' : 'Active Account'}
                </span>
                <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider ${
                  user.hasPaidPackage ? 'bg-amber-400 text-amber-950 font-black' : 'bg-slate-800 text-slate-300 border border-slate-700'
                }`}>
                  {user.hasPaidPackage ? '★ ₹99 Package Verified' : 'Free Tier'}
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-1 flex flex-wrap items-center gap-3">
                <span className="flex items-center gap-1 font-mono">
                  <Mail className="w-3.5 h-3.5 text-purple-300" />
                  {user.email}
                </span>
                <span>•</span>
                <span>Track: <strong className="text-white">{enrolledDomain?.name || user.selectedDomain || 'None Selected'}</strong></span>
                <span>•</span>
                <span>Joined: {new Date(user.createdAt || Date.now()).toLocaleDateString()}</span>
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 text-white/70 hover:text-white hover:bg-white/10 rounded-full transition-colors cursor-pointer"
            title="Close Dossier"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Controls Strip */}
        <div className="bg-slate-50 px-6 py-3.5 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-4">
            <div>
              <span className="text-[10px] uppercase font-bold text-slate-400 block">Milestones Cleared</span>
              <span className="font-extrabold text-slate-900 text-sm">{approvedCount} of 5 Milestones</span>
            </div>
            <div className="w-px h-8 bg-slate-200" />
            <div>
              <span className="text-[10px] uppercase font-bold text-slate-400 block">Internship Progress</span>
              <div className="flex items-center gap-2 mt-0.5">
                <div className="w-24 bg-slate-200 h-2 rounded-full overflow-hidden">
                  <div
                    className="bg-purple-600 h-full rounded-full transition-all"
                    style={{ width: `${user.progress || (approvedCount * 20)}%` }}
                  />
                </div>
                <span className="font-black text-purple-700">{user.progress || (approvedCount * 20)}%</span>
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => onTogglePaidPackage(user)}
              className={`px-3 py-1.5 rounded-xl font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer shadow-xs ${
                user.hasPaidPackage
                  ? 'bg-slate-200 hover:bg-slate-300 text-slate-800'
                  : 'bg-emerald-600 hover:bg-emerald-700 text-white'
              }`}
            >
              <DollarSign className="w-3.5 h-3.5" />
              <span>{user.hasPaidPackage ? 'Revert to Free Tier' : 'Grant ₹99 Package'}</span>
            </button>

            <button
              type="button"
              onClick={() => onIssueCertificates(user)}
              className="px-3 py-1.5 bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer shadow-xs"
            >
              <Award className="w-3.5 h-3.5" />
              <span>Issue Credentials</span>
            </button>

            <button
              type="button"
              onClick={() => onToggleSuspend(user.uid)}
              className={`px-3 py-1.5 rounded-xl font-bold text-xs flex items-center gap-1.5 transition-colors cursor-pointer ${
                user.isSuspended
                  ? 'bg-emerald-100 hover:bg-emerald-200 text-emerald-800'
                  : 'bg-rose-100 hover:bg-rose-200 text-rose-800'
              }`}
            >
              <Ban className="w-3.5 h-3.5" />
              <span>{user.isSuspended ? 'Unsuspend Account' : 'Suspend Account'}</span>
            </button>
          </div>
        </div>

        {/* Modal Content: Milestones & Submissions Dossier */}
        <div className="p-6 max-h-[60vh] overflow-y-auto space-y-4">
          <div className="flex items-center justify-between">
            <h4 className="text-sm font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2">
              <FileText className="w-4 h-4 text-purple-600" />
              <span>Submitted Internship Milestones ({userSubmissions.length})</span>
            </h4>
            <span className="text-xs text-slate-500 font-medium">Click any milestone to open full inspector</span>
          </div>

          {userSubmissions.length === 0 ? (
            <div className="py-12 text-center text-slate-400 bg-slate-50 rounded-2xl border border-dashed border-slate-200 space-y-2">
              <Clock className="w-8 h-8 text-slate-300 mx-auto" />
              <p className="font-bold text-slate-600 text-sm">No submissions recorded for this student yet</p>
              <p className="text-xs text-slate-400">The student has registered but not yet submitted any task deliverables.</p>
            </div>
          ) : (
            <div className="space-y-3">
              {userSubmissions.map((sub) => (
                <div
                  key={sub.id}
                  className={`p-4 rounded-2xl border transition-all hover:shadow-md cursor-pointer ${
                    sub.status === 'approved'
                      ? 'bg-emerald-50/30 border-emerald-200'
                      : sub.status === 'submitted'
                      ? 'bg-amber-50/40 border-amber-300'
                      : sub.status === 'revision_required'
                      ? 'bg-amber-50/20 border-amber-200'
                      : 'bg-rose-50/20 border-rose-200'
                  }`}
                  onClick={() => onInspectSubmission(sub)}
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-200/60 pb-2.5">
                    <div className="flex items-center gap-2.5">
                      <span className="w-7 h-7 rounded-lg bg-indigo-600 text-white font-extrabold text-xs flex items-center justify-center shrink-0">
                        M{sub.taskNumber}
                      </span>
                      <div>
                        <h5 className="font-bold text-slate-900 text-xs">
                          {sub.projectTitle || `Milestone ${sub.taskNumber}`}
                        </h5>
                        <span className="text-[11px] text-slate-500">
                          Submitted on {new Date(sub.submittedAt).toLocaleString()} • Attempt #{sub.attemptNumber || 1}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider flex items-center gap-1 ${
                        sub.status === 'approved'
                          ? 'bg-emerald-100 text-emerald-800'
                          : sub.status === 'submitted'
                          ? 'bg-amber-400 text-amber-950 font-black animate-pulse'
                          : sub.status === 'revision_required'
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-rose-100 text-rose-800'
                      }`}>
                        {sub.status === 'approved' && <CheckCircle className="w-3 h-3" />}
                        {sub.status === 'submitted' && <Clock className="w-3 h-3" />}
                        {sub.status === 'revision_required' && <AlertCircle className="w-3 h-3" />}
                        {sub.status === 'rejected' && <XCircle className="w-3 h-3" />}
                        <span>{sub.status === 'submitted' ? 'Pending Review' : sub.status.replace('_', ' ')}</span>
                      </span>

                      {sub.rubricScore !== undefined && (
                        <span className="px-2 py-0.5 rounded-lg text-xs font-black bg-purple-100 text-purple-900 border border-purple-200">
                          {sub.rubricScore}/100
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Quick deliverable tags */}
                  <div className="pt-2 flex flex-wrap items-center gap-3 text-[11px]">
                    {sub.taskNumber === 1 ? (
                      <>
                        <span className="text-red-700 font-semibold flex items-center gap-1">
                          <Youtube className="w-3.5 h-3.5" />
                          <span>Handle: {sub.youtubeProofText || sub.youtubeSubscribeProof || 'Provided'}</span>
                        </span>
                        {sub.youtubeScreenshotUrl && (
                          <span className="text-emerald-700 font-semibold flex items-center gap-1">
                            <CheckCircle className="w-3 h-3" />
                            <span>Screenshot Attached</span>
                          </span>
                        )}
                        {sub.socialProofUrl && (
                          <span className="text-[#0A66C2] font-semibold flex items-center gap-1">
                            <Globe className="w-3 h-3" />
                            <span>LinkedIn Post Link</span>
                          </span>
                        )}
                      </>
                    ) : (
                      <>
                        {(sub.repositoryURL || sub.githubUrl) && (
                          <span className="text-slate-800 font-semibold flex items-center gap-1">
                            <Github className="w-3.5 h-3.5" />
                            <span>GitHub Repository</span>
                          </span>
                        )}
                        {(sub.demoURL || sub.projectUrl) && (
                          <span className="text-[#0A66C2] font-semibold flex items-center gap-1">
                            <ExternalLink className="w-3.5 h-3.5" />
                            <span>Live Demo</span>
                          </span>
                        )}
                      </>
                    )}

                    {sub.adminFeedback && (
                      <p className="w-full text-[11px] text-purple-900 bg-purple-50 p-2 rounded-lg mt-1 italic">
                        Mentor Remarks: "{sub.adminFeedback}"
                      </p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs rounded-xl transition-colors cursor-pointer"
          >
            Close Dossier
          </button>
        </div>
      </div>
    </div>
  );
};
