import React from 'react';
import {
  TaskSubmission,
  DomainItem,
  TaskEvaluationRecord
} from '../../types';
import { exportToCsv, calculatePointsEarned, getDifficultyMultiplier } from './adminUtils';
import { YOUTUBE_CONFIG } from '../../firebase/config';
import { isSameDomain } from '../../services/dataService';
import {
  FileCheck2,
  Clock,
  CheckCircle,
  AlertCircle,
  XCircle,
  Search,
  Filter,
  Download,
  Eye,
  Sliders,
  Flag,
  Youtube,
  Globe,
  ExternalLink,
  FileText,
  AlertTriangle,
  Github,
  RefreshCw
} from 'lucide-react';

interface AdminSubmissionsTabProps {
  submissions: TaskSubmission[];
  domains: DomainItem[];
  evaluations: TaskEvaluationRecord[];
  subFilterStatus: 'all' | 'submitted' | 'approved' | 'revision_required' | 'rejected';
  setSubFilterStatus: (status: any) => void;
  subFilterDomain: string;
  setSubFilterDomain: (dom: string) => void;
  subFilterTask: number | 'all';
  setSubFilterTask: (task: any) => void;
  subSearchQuery: string;
  setSubSearchQuery: (query: string) => void;
  manualScores: Record<string, number>;
  setManualScores: React.Dispatch<React.SetStateAction<Record<string, number>>>;
  feedbackText: Record<string, string>;
  setFeedbackText: React.Dispatch<React.SetStateAction<Record<string, string>>>;
  onReviewSubmission: (
    subId: string,
    decision: 'approved' | 'revision_required' | 'rejected',
    score?: number,
    feedback?: string
  ) => Promise<void>;
  onOpenDetailedVerifyModal: (sub: TaskSubmission, score: number) => void;
  onOpenScreenshotLightbox: (sub: TaskSubmission) => void;
  onOpenFlagModal: (sub: TaskSubmission) => void;
  onRefreshData: () => void;
}

export const AdminSubmissionsTab: React.FC<AdminSubmissionsTabProps> = ({
  submissions,
  domains,
  evaluations,
  subFilterStatus,
  setSubFilterStatus,
  subFilterDomain,
  setSubFilterDomain,
  subFilterTask,
  setSubFilterTask,
  subSearchQuery,
  setSubSearchQuery,
  manualScores,
  setManualScores,
  feedbackText,
  setFeedbackText,
  onReviewSubmission,
  onOpenDetailedVerifyModal,
  onOpenScreenshotLightbox,
  onOpenFlagModal,
  onRefreshData
}) => {
  const isPendingReview = (s: TaskSubmission) => {
    return s.status === 'submitted' || s.status === 'pending_review' || s.status === 'under_review' || (!s.isManuallyVerified && s.status !== 'approved' && s.status !== 'rejected');
  };

  // Filtered submissions
  const filteredSubs = submissions.filter((sub) => {
    // Status
    if (subFilterStatus !== 'all') {
      if (subFilterStatus === 'submitted') {
        if (!isPendingReview(sub)) return false;
      } else {
        if (sub.status !== subFilterStatus) return false;
      }
    }
    // Domain
    if (subFilterDomain !== 'all') {
      const selectedDom = domains.find(d => d.id === subFilterDomain);
      const matched = isSameDomain(sub.domainId, subFilterDomain, sub.domainName, selectedDom?.name || subFilterDomain);
      if (!matched) return false;
    }
    // Task
    if (subFilterTask !== 'all') {
      if (Number(sub.taskNumber) !== Number(subFilterTask)) return false;
    }
    // Search
    if (subSearchQuery.trim()) {
      const q = subSearchQuery.toLowerCase();
      const matchName = (sub.userName || '').toLowerCase().includes(q);
      const matchEmail = (sub.userEmail || '').toLowerCase().includes(q);
      const matchTitle = (sub.projectTitle || '').toLowerCase().includes(q);
      const matchDomain = (sub.domainName || '').toLowerCase().includes(q);
      if (!matchName && !matchEmail && !matchTitle && !matchDomain) return false;
    }
    return true;
  }).sort((a, b) => {
    const aPending = isPendingReview(a);
    const bPending = isPendingReview(b);
    if (aPending && !bPending) return -1;
    if (!aPending && bPending) return 1;
    return new Date(b.submittedAt).getTime() - new Date(a.submittedAt).getTime();
  });

  const pendingCount = submissions.filter(isPendingReview).length;
  const approvedCount = submissions.filter(s => s.status === 'approved').length;
  const revisionCount = submissions.filter(s => s.status === 'revision_required').length;
  const rejectedCount = submissions.filter(s => s.status === 'rejected').length;

  const handleExportCsv = () => {
    const headers = [
      'Submission ID',
      'Student Name',
      'Email',
      'Domain Track',
      'Task Number',
      'Project Title',
      'Status',
      'Score',
      'Submitted At',
      'Repo URL',
      'Demo URL'
    ];
    const rows = filteredSubs.map(s => [
      s.id,
      s.userName,
      s.userEmail,
      s.domainName,
      s.taskNumber,
      s.projectTitle || `Task ${s.taskNumber}`,
      s.status,
      s.rubricScore || '',
      s.submittedAt,
      s.repositoryURL || s.githubUrl || '',
      s.demoURL || s.projectUrl || ''
    ]);
    exportToCsv(`virintern_submissions_${new Date().toISOString().split('T')[0]}`, headers, rows);
  };

  return (
    <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden space-y-6 p-6 animate-slideUp">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-100 pb-5">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold text-slate-900">Task Submissions & Manual Verification Center</h2>
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-purple-100 text-purple-900 border border-purple-200">
              Admin Evaluation Engine
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Manual administrator review: Inspect YouTube subscription screenshots, code repositories, live URLs, assign official rubric scores (0-100), and unlock next milestone progression.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className={`text-xs font-bold px-3 py-1.5 rounded-xl border flex items-center gap-1.5 shadow-2xs ${
            pendingCount > 0 ? 'bg-amber-100 text-amber-900 border-amber-300 animate-badgePulse' : 'bg-slate-100 text-slate-700 border-slate-200'
          }`}>
            <Clock className="w-3.5 h-3.5 text-amber-600" />
            <span>{pendingCount} Pending Review</span>
          </span>

          <button
            type="button"
            onClick={onRefreshData}
            className="px-3.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
            title="Reload submissions"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Refresh</span>
          </button>

          <button
            type="button"
            onClick={handleExportCsv}
            className="px-3.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
            title="Export CSV"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>
        </div>
      </div>

      {/* Comprehensive Filter Controls */}
      <div className="bg-slate-50/80 p-4 rounded-2xl border border-slate-200 space-y-3">
        {/* Status Pills + Reset Filters */}
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex flex-wrap items-center gap-1.5">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider mr-1">Status:</span>
            {[
              { id: 'all', label: `All (${submissions.length})`, count: submissions.length },
              { id: 'submitted', label: `Pending Review (${pendingCount})`, count: pendingCount, highlight: pendingCount > 0 },
              { id: 'approved', label: `Approved (${approvedCount})`, count: approvedCount },
              { id: 'revision_required', label: `Revision Required (${revisionCount})`, count: revisionCount },
              { id: 'rejected', label: `Rejected (${rejectedCount})`, count: rejectedCount }
            ].map((pill) => (
              <button
                key={pill.id}
                type="button"
                onClick={() => setSubFilterStatus(pill.id as any)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                  subFilterStatus === pill.id
                    ? 'bg-purple-600 text-white shadow-xs'
                    : pill.highlight
                    ? 'bg-amber-100 text-amber-900 border border-amber-300 hover:bg-amber-200'
                    : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-100'
                }`}
              >
                <span>{pill.label}</span>
              </button>
            ))}
          </div>

          {(subFilterStatus !== 'all' || subFilterDomain !== 'all' || subFilterTask !== 'all' || subSearchQuery.trim() !== '') && (
            <button
              type="button"
              onClick={() => {
                setSubFilterStatus('all');
                setSubFilterDomain('all');
                setSubFilterTask('all');
                setSubSearchQuery('');
              }}
              className="px-3 py-1.5 bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 rounded-xl text-xs font-bold transition-colors cursor-pointer"
            >
              Reset Filters
            </button>
          )}
        </div>

        {/* Filters Row */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
          <div>
            <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-500 mb-1">
              Domain Track:
            </label>
            <select
              value={subFilterDomain}
              onChange={(e) => setSubFilterDomain(e.target.value)}
              className="w-full text-xs p-2.5 bg-white border border-slate-300 rounded-xl outline-none font-semibold text-slate-800"
            >
              <option value="all">All Domain Tracks ({domains.length})</option>
              {domains.map((dom) => (
                <option key={dom.id} value={dom.id}>
                  {dom.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-500 mb-1">
              Milestone / Task:
            </label>
            <select
              value={String(subFilterTask)}
              onChange={(e) => setSubFilterTask(e.target.value === 'all' ? 'all' : Number(e.target.value))}
              className="w-full text-xs p-2.5 bg-white border border-slate-300 rounded-xl outline-none font-semibold text-slate-800"
            >
              <option value="all">All Milestones (1 through 5)</option>
              <option value="1">Milestone 1: Offer Letter & Channel Verification</option>
              <option value="2">Milestone 2: Foundation Project Deliverable</option>
              <option value="3">Milestone 3: Core Implementation Deliverable</option>
              <option value="4">Milestone 4: Advanced Architecture Deliverable</option>
              <option value="5">Milestone 5: Capstone Project & Completion</option>
            </select>
          </div>

          <div>
            <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-500 mb-1">
              Search Intern or Milestone:
            </label>
            <div className="relative">
              <input
                type="text"
                value={subSearchQuery}
                onChange={(e) => setSubSearchQuery(e.target.value)}
                placeholder="Search intern name, email..."
                className="w-full text-xs pl-8 pr-3 py-2.5 bg-white border border-slate-300 rounded-xl outline-none font-medium"
              />
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            </div>
          </div>
        </div>

        {/* Global Pending Reviews Notice if filters are currently hiding them */}
        {pendingCount > 0 && filteredSubs.filter(isPendingReview).length === 0 && (
          <div className="p-3.5 bg-amber-50 rounded-xl border border-amber-300 text-xs text-amber-900 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-2xs">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-amber-600 shrink-0 animate-bounce" />
              <span>
                <strong>{pendingCount} student submission{pendingCount > 1 ? 's are' : ' is'}</strong> awaiting manual verification in other domain tracks or filters!
              </span>
            </div>
            <button
              type="button"
              onClick={() => {
                setSubFilterStatus('submitted');
                setSubFilterDomain('all');
                setSubFilterTask('all');
                setSubSearchQuery('');
              }}
              className="px-3.5 py-1.5 bg-amber-600 hover:bg-amber-700 text-white font-bold rounded-lg text-xs shadow-xs transition-colors cursor-pointer shrink-0 self-start sm:self-auto"
            >
              Show Verification Queue ({pendingCount})
            </button>
          </div>
        )}
      </div>

      {/* Submissions List */}
      <div className="space-y-5">
        {filteredSubs.length === 0 ? (
          <div className="py-16 text-center text-xs text-slate-400 space-y-3 bg-slate-50/50 rounded-2xl border border-dashed border-slate-200">
            <FileCheck2 className="w-10 h-10 text-slate-300 mx-auto" />
            <p className="font-bold text-slate-600 text-sm">No submissions match the selected filters</p>
            <p className="text-slate-400 text-xs max-w-md mx-auto">
              {pendingCount > 0
                ? `${pendingCount} student submission${pendingCount > 1 ? 's are' : ' is'} waiting in the verification queue under other domain tracks or filter settings.`
                : subFilterStatus === 'submitted'
                ? 'All clear! There are no pending submissions awaiting manual admin verification.'
                : 'Try broadening your filter criteria or domain selection.'}
            </p>
            <div className="flex flex-wrap items-center justify-center gap-2 pt-2">
              {pendingCount > 0 && (
                <button
                  type="button"
                  onClick={() => {
                    setSubFilterStatus('submitted');
                    setSubFilterDomain('all');
                    setSubFilterTask('all');
                    setSubSearchQuery('');
                  }}
                  className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs rounded-xl shadow-xs transition-colors cursor-pointer flex items-center gap-1.5"
                >
                  <Clock className="w-3.5 h-3.5" />
                  <span>View Pending Submissions ({pendingCount})</span>
                </button>
              )}
              {submissions.length > 0 && (
                <button
                  type="button"
                  onClick={() => {
                    setSubFilterStatus('all');
                    setSubFilterDomain('all');
                    setSubFilterTask('all');
                    setSubSearchQuery('');
                  }}
                  className="px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs rounded-xl shadow-xs transition-colors cursor-pointer"
                >
                  View All Submissions ({submissions.length})
                </button>
              )}
            </div>
          </div>
        ) : (
          filteredSubs.map((sub) => {
            const subKey = sub.id || sub.submissionId || '';
            const evalRec = evaluations.find(
              e => e.submissionId === subKey || (e.userId === sub.userId && (e.taskId === sub.taskId || e.taskId === sub.projectId))
            );
            const currentScore = manualScores[subKey] ?? (sub.rubricScore ?? (evalRec?.totalScore ?? 85));
            const maxPoints = getDifficultyMultiplier(sub.level);
            const previewPoints = calculatePointsEarned(currentScore, sub.level);

            return (
              <div
                key={subKey}
                className={`p-5 rounded-2xl border transition-all space-y-4 ${
                  isPendingReview(sub)
                    ? 'border-amber-300 bg-amber-50/30 shadow-xs'
                    : sub.status === 'approved'
                    ? 'border-emerald-200 bg-emerald-50/20'
                    : sub.status === 'revision_required'
                    ? 'border-amber-200 bg-white'
                    : 'border-slate-200 bg-slate-50/40'
                }`}
              >
                {/* Header */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200/80 pb-3">
                  <div>
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-extrabold text-slate-900 text-sm">{sub.userName}</span>
                      <span className="text-xs text-slate-500 font-mono">({sub.userEmail})</span>
                      <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-[#EBF4FD] text-[#0A66C2] border border-[#0A66C2]/20">
                        {sub.domainName}
                      </span>
                      <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-slate-100 text-slate-700">
                        Attempt #{sub.attemptNumber || 1}
                      </span>
                    </div>
                    <p className="text-xs font-bold text-slate-800 mt-1 flex items-center gap-1.5">
                      <span className="px-1.5 py-0.2 rounded bg-indigo-100 text-indigo-800 text-[10px]">
                        Milestone {sub.taskNumber}
                      </span>
                      <span>{sub.projectTitle || `Task ${sub.taskNumber}`}</span>
                    </p>
                  </div>

                  <div className="flex flex-wrap items-center gap-2 self-start sm:self-auto">
                    <span
                      className={`px-3 py-1 rounded-full text-xs font-black uppercase tracking-wider flex items-center gap-1.5 ${
                        sub.status === 'approved'
                          ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                          : sub.status === 'rejected'
                          ? 'bg-rose-100 text-rose-800 border border-rose-300'
                          : sub.status === 'revision_required'
                          ? 'bg-amber-100 text-amber-800 border border-amber-300'
                          : 'bg-amber-400 text-amber-950 font-black animate-badgePulse shadow-2xs'
                      }`}
                    >
                      {isPendingReview(sub) && <Clock className="w-3.5 h-3.5" />}
                      {sub.status === 'approved' && <CheckCircle className="w-3.5 h-3.5" />}
                      {sub.status === 'revision_required' && <AlertCircle className="w-3.5 h-3.5" />}
                      {sub.status === 'rejected' && <XCircle className="w-3.5 h-3.5" />}
                      <span>
                        {isPendingReview(sub) ? 'Pending Admin Review' : String(sub.status || 'pending').replace('_', ' ')}
                      </span>
                    </span>

                    {sub.rubricScore !== undefined && (
                      <span className="px-2.5 py-1 rounded-full text-xs font-black bg-blue-100 text-[#0A66C2] border border-blue-200">
                        Score: {sub.rubricScore}/100
                      </span>
                    )}

                    <span className="text-[11px] text-slate-400 font-medium">
                      {new Date(sub.submittedAt).toLocaleString()}
                    </span>
                  </div>
                </div>

                {/* Deliverables Section */}
                <div className="bg-white p-4 rounded-xl border border-slate-200 space-y-3">
                  <span className="text-[10px] font-extrabold uppercase tracking-wider text-slate-400 block">
                    Submitted Deliverables & Proofs:
                  </span>

                  {/* Task 1 Proofs */}
                  {sub.taskNumber === 1 && (
                    <div className="space-y-3">
                      {/* YouTube Section */}
                      <div className="p-3.5 bg-red-50/70 rounded-xl border border-red-200/90 space-y-2">
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                          <div className="flex items-center gap-2">
                            <div className="w-7 h-7 rounded-lg bg-red-600 text-white flex items-center justify-center shrink-0">
                              <Youtube className="w-4 h-4" />
                            </div>
                            <div>
                              <span className="text-xs font-bold text-slate-900 block">
                                YouTube Community Channel Subscription (@virintern)
                              </span>
                              <span className="text-[11px] text-slate-600 block mt-0.5">
                                Submitted Channel Handle: <strong className="font-mono text-red-700 bg-white px-1.5 py-0.5 rounded border border-red-200">{sub.youtubeProofText || sub.youtubeSubscribeProof || '@not_provided'}</strong>
                              </span>
                            </div>
                          </div>

                          <a
                            href={`${YOUTUBE_CONFIG.channelUrl}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-[11px] font-bold text-red-700 hover:text-red-900 inline-flex items-center gap-1 self-start sm:self-auto"
                          >
                            <span>Open Official Channel</span>
                            <ExternalLink className="w-3 h-3" />
                          </a>
                        </div>

                        {/* Screenshot Preview */}
                        <div className="mt-2 pt-2 border-t border-red-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                          <div>
                            <span className="text-[11px] font-bold text-slate-700 block mb-1">
                              Subscription Screenshot Proof:
                            </span>
                            {sub.youtubeScreenshotUrl && sub.youtubeScreenshotUrl !== '[STORED_IN_MEMORY_AND_SERVER]' ? (
                              <div className="flex items-center gap-3">
                                <div
                                  onClick={() => onOpenScreenshotLightbox(sub)}
                                  className="relative group w-16 h-16 rounded-xl border-2 border-red-300 overflow-hidden shrink-0 cursor-pointer shadow-2xs hover:border-red-500 transition-colors"
                                >
                                  <img
                                    src={sub.youtubeScreenshotUrl}
                                    alt="YouTube Proof"
                                    className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                                  />
                                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center text-white transition-opacity">
                                    <Eye className="w-4 h-4" />
                                  </div>
                                </div>
                                <div>
                                  <p className="text-xs font-bold text-slate-800 font-mono truncate max-w-[240px]">
                                    {sub.youtubeScreenshotFileName || 'youtube_screenshot.png'}
                                  </p>
                                  <span className="text-[10px] text-emerald-700 font-bold flex items-center gap-1 mt-0.5">
                                    <CheckCircle className="w-3 h-3 text-emerald-600" />
                                    <span>Proof Uploaded for Inspection</span>
                                  </span>
                                </div>
                              </div>
                            ) : (
                              <div className="p-2 bg-amber-50 rounded-lg border border-amber-200 text-xs text-amber-800 flex items-center gap-1.5 font-medium">
                                <AlertTriangle className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                                <span>No subscribe screenshot uploaded.</span>
                              </div>
                            )}
                          </div>

                          {sub.youtubeScreenshotUrl && sub.youtubeScreenshotUrl !== '[STORED_IN_MEMORY_AND_SERVER]' && (
                            <button
                              type="button"
                              onClick={() => onOpenScreenshotLightbox(sub)}
                              className="px-3 py-2 bg-red-600 hover:bg-red-700 text-white font-bold text-xs rounded-xl shadow-xs transition-colors flex items-center justify-center gap-1.5 cursor-pointer shrink-0"
                            >
                              <Eye className="w-4 h-4" />
                              <span>Inspect Screenshot</span>
                            </button>
                          )}
                        </div>
                      </div>

                      {/* Offer Letter & LinkedIn Post */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs pt-1">
                        <div className="p-3 bg-blue-50/70 rounded-xl border border-blue-200">
                          <span className="font-bold text-[#0A66C2] block mb-1">1. Offer Letter Verification:</span>
                          <div className="flex items-center gap-1.5 text-slate-700">
                            <FileText className="w-4 h-4 text-[#0A66C2]" />
                            <span className="font-mono truncate">{sub.offerLetterFileName || 'Offer Letter Verified'}</span>
                            {sub.offerLetterUrl && (
                              <a
                                href={sub.offerLetterUrl}
                                target="_blank"
                                rel="noreferrer"
                                className="ml-auto text-[#0A66C2] font-bold underline"
                              >
                                View PDF
                              </a>
                            )}
                          </div>
                        </div>

                        <div className="p-3 bg-blue-50/70 rounded-xl border border-blue-200">
                          <span className="font-bold text-[#0A66C2] block mb-1">3. LinkedIn Commencement Post:</span>
                          {sub.socialProofUrl ? (
                            <a
                              href={sub.socialProofUrl}
                              target="_blank"
                              rel="noreferrer"
                              className="text-[#0A66C2] font-bold hover:underline inline-flex items-center gap-1 truncate max-w-full"
                            >
                              <Globe className="w-3.5 h-3.5 shrink-0" />
                              <span className="truncate">{sub.socialProofUrl}</span>
                              <ExternalLink className="w-3 h-3 shrink-0 ml-0.5" />
                            </a>
                          ) : (
                            <span className="text-slate-400 italic">No LinkedIn post link provided</span>
                          )}
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Tasks 2-5 Links & Attachments */}
                  {sub.taskNumber > 1 && (
                    <div className="space-y-3 text-xs">
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div>
                          <span className="text-slate-500 font-bold block mb-0.5">GitHub Repository URL:</span>
                          {sub.repositoryURL || sub.githubUrl ? (
                            <a
                              href={sub.repositoryURL || sub.githubUrl}
                              target="_blank"
                              rel="noreferrer"
                              className="text-[#0A66C2] font-bold hover:underline inline-flex items-center gap-1 truncate max-w-full"
                            >
                              <Github className="w-3.5 h-3.5 shrink-0" />
                              <span className="truncate">{sub.repositoryURL || sub.githubUrl}</span>
                              <ExternalLink className="w-3 h-3 shrink-0" />
                            </a>
                          ) : (
                            <span className="text-slate-400 italic">Not provided</span>
                          )}
                        </div>

                        <div>
                          <span className="text-slate-500 font-bold block mb-0.5">Live Demo / Deployed URL:</span>
                          {sub.demoURL || sub.projectUrl ? (
                            <a
                              href={sub.demoURL || sub.projectUrl}
                              target="_blank"
                              rel="noreferrer"
                              className="text-[#0A66C2] font-bold hover:underline inline-flex items-center gap-1 truncate max-w-full"
                            >
                              <Globe className="w-3.5 h-3.5 shrink-0" />
                              <span className="truncate">{sub.demoURL || sub.projectUrl}</span>
                              <ExternalLink className="w-3 h-3 shrink-0" />
                            </a>
                          ) : (
                            <span className="text-slate-400 italic">Not provided</span>
                          )}
                        </div>
                      </div>

                      {(sub.driveURL || sub.pdfUrl || (sub.fileUrls && sub.fileUrls.length > 0)) && (
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-slate-100">
                          {sub.driveURL && (
                            <div>
                              <span className="text-slate-500 font-bold block mb-0.5">Drive / Walkthrough Video Link:</span>
                              <a
                                href={sub.driveURL}
                                target="_blank"
                                rel="noreferrer"
                                className="text-[#0A66C2] font-bold hover:underline inline-flex items-center gap-1 truncate max-w-full"
                              >
                                <ExternalLink className="w-3.5 h-3.5 shrink-0" />
                                <span className="truncate">{sub.driveURL}</span>
                              </a>
                            </div>
                          )}

                          {sub.pdfUrl && (
                            <div>
                              <span className="text-slate-500 font-bold block mb-0.5">Report / Documentation PDF:</span>
                              <a
                                href={sub.pdfUrl}
                                target="_blank"
                                rel="noreferrer"
                                className="text-[#0A66C2] font-bold hover:underline inline-flex items-center gap-1 truncate max-w-full"
                              >
                                <FileText className="w-3.5 h-3.5 shrink-0" />
                                <span className="truncate">{sub.pdfUrl}</span>
                              </a>
                            </div>
                          )}

                          {sub.fileUrls && sub.fileUrls.filter(u => u !== sub.driveURL && u !== sub.pdfUrl).length > 0 && (
                            <div className="sm:col-span-2">
                              <span className="text-slate-500 font-bold block mb-0.5">Additional Proof Links:</span>
                              <div className="flex flex-wrap gap-2">
                                {sub.fileUrls
                                  .filter(u => u !== sub.driveURL && u !== sub.pdfUrl)
                                  .map((url, idx) => (
                                    <a
                                      key={idx}
                                      href={url}
                                      target="_blank"
                                      rel="noreferrer"
                                      className="px-2 py-1 bg-slate-100 hover:bg-slate-200 text-[#0A66C2] font-bold rounded-lg inline-flex items-center gap-1 truncate max-w-[260px]"
                                    >
                                      <ExternalLink className="w-3 h-3 shrink-0" />
                                      <span className="truncate">{url}</span>
                                    </a>
                                  ))}
                              </div>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  )}

                  {/* Intern Notes */}
                  {(sub.content || sub.notes) && (
                    <div className="pt-2 border-t border-slate-100 text-xs">
                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-0.5">
                        Intern Implementation Details:
                      </span>
                      <p className="text-slate-700 italic bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                        "{sub.content || sub.notes}"
                      </p>
                    </div>
                  )}
                </div>

                {/* Previous Admin Feedback if available */}
                {sub.adminFeedback && (
                  <div className="p-3 bg-purple-50/70 rounded-xl border border-purple-200 text-xs text-purple-950 space-y-1">
                    <span className="font-bold uppercase tracking-wider text-[10px] text-purple-800 block">
                      Previous Admin Review Feedback:
                    </span>
                    <p>{sub.adminFeedback}</p>
                    {sub.reviewedBy && (
                      <span className="text-[10px] text-purple-700 font-semibold block">
                        Reviewed by: {sub.reviewedBy} {sub.reviewedAt && `• ${new Date(sub.reviewedAt).toLocaleDateString()}`}
                      </span>
                    )}
                  </div>
                )}

                {/* Score Controls & Review Panel */}
                <div className="p-4 bg-gradient-to-r from-slate-50 via-purple-50/20 to-blue-50/20 rounded-2xl border border-purple-200 space-y-3">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 rounded-lg bg-purple-600 text-white flex items-center justify-center">
                        <Sliders className="w-3.5 h-3.5" />
                      </div>
                      <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                        Manual Score Assignment & Milestone Action
                      </h4>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-slate-600">Points Awarded:</span>
                      <span className="px-2.5 py-0.5 rounded-full text-xs font-black bg-purple-100 text-purple-800 border border-purple-200">
                        {previewPoints} / {maxPoints} pts
                      </span>
                    </div>
                  </div>

                  {/* Score Input Slider & Presets */}
                  <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 items-center">
                    <div className="sm:col-span-5 flex items-center gap-2">
                      <label className="text-xs font-bold text-slate-700 shrink-0">Official Score:</label>
                      <input
                        type="number"
                        min={0}
                        max={100}
                        value={currentScore}
                        onChange={(e) => {
                          const val = Math.max(0, Math.min(100, Number(e.target.value) || 0));
                          setManualScores(prev => ({ ...prev, [subKey]: val }));
                        }}
                        className="w-20 p-2 text-center text-sm font-black text-purple-900 bg-white border-2 border-purple-300 rounded-xl outline-none focus:border-purple-600"
                      />
                      <span className="text-xs font-bold text-slate-500">/ 100</span>
                      <span className={`px-2 py-0.5 rounded text-[10px] font-black ${
                        currentScore >= 70 ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
                      }`}>
                        {currentScore >= 70 ? 'PASSING' : 'FAILING'}
                      </span>
                    </div>

                    <div className="sm:col-span-7 flex flex-wrap items-center gap-1.5 justify-start sm:justify-end">
                      <span className="text-[10px] font-bold text-slate-400 mr-1">Presets:</span>
                      {[
                        { label: '70 (Pass)', score: 70 },
                        { label: '85 (Good)', score: 85 },
                        { label: '92 (Distinction)', score: 92 },
                        { label: '100 (Max)', score: 100 }
                      ].map((preset) => (
                        <button
                          key={preset.score}
                          type="button"
                          onClick={() => setManualScores(prev => ({ ...prev, [subKey]: preset.score }))}
                          className={`px-2.5 py-1 text-[11px] font-bold rounded-lg border transition-colors cursor-pointer ${
                            currentScore === preset.score
                              ? 'bg-purple-600 text-white border-purple-600'
                              : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                          }`}
                        >
                          {preset.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Feedback Input */}
                  <div>
                    <input
                      type="text"
                      placeholder="Enter administrator remarks / reason for score..."
                      value={feedbackText[subKey] || ''}
                      onChange={(e) => setFeedbackText(prev => ({ ...prev, [subKey]: e.target.value }))}
                      className="w-full text-xs px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl outline-none focus:border-purple-600"
                    />
                    {/* Quick suggestion chips */}
                    <div className="flex flex-wrap items-center gap-1 mt-1.5 text-[10px]">
                      <span className="text-slate-400">Quick suggestions:</span>
                      {[
                        sub.taskNumber === 1
                          ? 'YouTube subscription screenshot and offer letter verified.'
                          : 'All deliverables and live repository verified.',
                        'Excellent milestone execution and clean code.',
                        'Please re-upload a clear screenshot proof and resubmit.'
                      ].map((suggestion, sIdx) => (
                        <button
                          key={sIdx}
                          type="button"
                          onClick={() => setFeedbackText(prev => ({ ...prev, [subKey]: suggestion }))}
                          className="px-2 py-0.5 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-md transition-colors cursor-pointer truncate max-w-[220px]"
                        >
                          {suggestion}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-purple-100">
                    <button
                      type="button"
                      onClick={() => onOpenDetailedVerifyModal(sub, currentScore)}
                      className="px-3.5 py-2 bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer shadow-2xs"
                    >
                      <Eye className="w-3.5 h-3.5 text-purple-600" />
                      <span>Detailed Full-Screen Review</span>
                    </button>

                    <div className="flex flex-wrap items-center gap-2">
                      <button
                        type="button"
                        onClick={() => onReviewSubmission(subKey, 'approved', currentScore, feedbackText[subKey])}
                        className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-xs transition-all flex items-center gap-1.5 cursor-pointer active:scale-95"
                      >
                        <CheckCircle className="w-4 h-4" />
                        <span>✓ Approve & Award {previewPoints} pts</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => onReviewSubmission(subKey, 'revision_required', currentScore, feedbackText[subKey])}
                        className="px-3.5 py-2 bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs rounded-xl shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
                      >
                        <AlertCircle className="w-3.5 h-3.5" />
                        <span>Request Revision</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => onReviewSubmission(subKey, 'rejected', currentScore, feedbackText[subKey])}
                        className="px-3.5 py-2 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs rounded-xl shadow-xs transition-colors flex items-center gap-1.5 cursor-pointer"
                      >
                        <XCircle className="w-3.5 h-3.5" />
                        <span>Reject</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => onOpenFlagModal(sub)}
                        className="p-2 text-rose-600 hover:bg-rose-50 border border-rose-200 rounded-xl transition-colors cursor-pointer"
                        title="Flag suspicious submission"
                      >
                        <Flag className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
