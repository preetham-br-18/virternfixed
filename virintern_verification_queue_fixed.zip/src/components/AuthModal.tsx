import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import {
  X,
  Mail,
  Lock,
  User,
  ArrowRight,
  ShieldCheck,
  Sparkles,
  CheckCircle2,
  Eye,
  EyeOff,
  Award,
  FileText,
  Zap,
  Check,
  ChevronDown,
  ChevronUp,
  AlertCircle,
  Tag,
  KeyRound,
  GraduationCap,
  Building2,
  Trophy,
  Clock
} from 'lucide-react';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialMode: 'login' | 'signup';
  initialPortal?: 'student' | 'company';
}

export const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose, initialMode, initialPortal }) => {
  const { loginWithEmail, signUpWithEmail, loginWithGoogle, registerCompany } = useAuth();
  const [portalTab, setPortalTab] = useState<'student' | 'company'>(initialPortal || 'student');
  const [mode, setMode] = useState<'login' | 'signup'>(initialMode);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [referralCode, setReferralCode] = useState('');
  const [agreedToTerms, setAgreedToTerms] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [resetSent, setResetSent] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [showTermsDetails, setShowTermsDetails] = useState(false);

  // Company registration fields
  const [companyName, setCompanyName] = useState('');
  const [companyWebsite, setCompanyWebsite] = useState('');
  const [companyContact, setCompanyContact] = useState('');
  const [companyDesignation, setCompanyDesignation] = useState('');
  const [companyIndustry, setCompanyIndustry] = useState('Technology');
  const [companyDesc, setCompanyDesc] = useState('');
  const [companySkills, setCompanySkills] = useState('');
  const [companyHiringNeeds, setCompanyHiringNeeds] = useState('');

  useEffect(() => {
    setMode(initialMode);
    if (initialPortal) setPortalTab(initialPortal);
    setError(null);
    setResetSent(false);
    // Check if URL has ?ref= query
    const params = new URLSearchParams(window.location.search);
    const ref = params.get('ref');
    if (ref) {
      setReferralCode(ref.toUpperCase());
    }
  }, [initialMode, initialPortal, isOpen]);

  // Keyboard shortcut: Escape to close
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      if (portalTab === 'company') {
        if (mode === 'signup') {
          if (!companyName.trim()) throw new Error('Company name is required');
          if (!email.trim()) throw new Error('Official corporate email is required');
          if (password.length < 6) throw new Error('Password must be at least 6 characters');
          if (!companyContact.trim()) throw new Error('Primary contact person name is required');
          await registerCompany({
            name: companyName.trim(),
            officialEmail: email.trim(),
            password,
            contactPerson: companyContact.trim(),
            designation: companyDesignation.trim(),
            website: companyWebsite.trim(),
            industry: companyIndustry.trim(),
            description: companyDesc.trim(),
            hiringRequirements: companyHiringNeeds.split(',').map(s => s.trim()).filter(Boolean),
            preferredSkills: companySkills.split(',').map(s => s.trim()).filter(Boolean),
          });
        } else {
          if (!email.trim() || !password) throw new Error('Please enter both your corporate email and password');
          await loginWithEmail(email, password);
        }
      } else {
        if (mode === 'signup') {
          if (!name.trim()) throw new Error('Please enter your full name');
          if (!email.trim()) throw new Error('Please enter your email address');
          if (password.length < 6) throw new Error('Password must be at least 6 characters');
          if (!agreedToTerms) throw new Error('Please accept the VirIntern E-Agreement to continue');
          if (typeof window !== 'undefined') {
            localStorage.setItem(`virintern_user_name_${email.trim().toLowerCase()}`, name.trim());
          }
          await signUpWithEmail(name, email, password, referralCode.trim() || undefined);
        } else {
          if (!email.trim() || !password) throw new Error('Please enter both your email and password');
          await loginWithEmail(email, password);
        }
      }
      onClose();
    } catch (err: any) {
      setError(err.message || 'Authentication failed. Please check credentials.');
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleSignIn = async () => {
    setError(null);
    setLoading(true);
    try {
      await loginWithGoogle();
      onClose();
    } catch (err: any) {
      setError(err.message || 'Google Sign-in failed.');
    } finally {
      setLoading(false);
    }
  };

  const getPasswordStrength = (pass: string) => {
    if (!pass) return { score: 0, label: '', barWidth: '0%', color: '' };
    if (pass.length < 6) return { score: 1, label: 'Too short (min 6)', barWidth: '25%', color: 'bg-rose-500' };
    const hasNum = /\d/.test(pass);
    const hasSpecial = /[^A-Za-z0-9]/.test(pass);
    if (pass.length >= 8 && hasNum && hasSpecial) {
      return { score: 3, label: 'Strong password', barWidth: '100%', color: 'bg-emerald-500' };
    }
    if (pass.length >= 6 && (hasNum || hasSpecial)) {
      return { score: 2, label: 'Good password', barWidth: '60%', color: 'bg-amber-500' };
    }
    return { score: 1, label: 'Basic (add numbers/symbols)', barWidth: '35%', color: 'bg-blue-400' };
  };

  const strength = getPasswordStrength(password);

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-slate-900/70 backdrop-blur-sm animate-fadeIn overflow-y-auto"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="bg-white w-full max-w-lg md:max-w-4xl rounded-3xl shadow-2xl border border-slate-200/80 overflow-hidden relative my-auto animate-scaleIn">
        {/* Close Button */}
        <button
          onClick={onClose}
          type="button"
          aria-label="Close dialog"
          className="absolute top-4 right-4 z-20 w-9 h-9 flex items-center justify-center rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500 hover:text-slate-800 transition-colors cursor-pointer shadow-xs"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-12">
          {/* Left Column: Brand & Value Showcase (Desktop & Tablet) */}
          <div className="md:col-span-5 bg-gradient-to-br from-[#0A66C2] via-[#004182] to-[#002855] p-6 sm:p-8 text-white flex flex-col justify-between relative overflow-hidden">
            {/* Background geometric accents */}
            <div className="absolute -top-16 -left-16 w-48 h-48 bg-blue-400/20 rounded-full blur-2xl pointer-events-none" />
            <div className="absolute -bottom-20 -right-20 w-60 h-60 bg-indigo-500/20 rounded-full blur-3xl pointer-events-none" />

            {/* Top brand header */}
            <div className="relative z-10 space-y-4">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-xl bg-white text-[#0A66C2] font-black text-lg flex items-center justify-center shadow-md shrink-0">
                  VI
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="font-extrabold text-xl tracking-tight text-white">VirIntern</span>
                    <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-white/20 text-white border border-white/20">
                      {portalTab === 'company' ? 'Enterprise' : 'Official'}
                    </span>
                  </div>
                  <p className="text-[11px] text-blue-200 font-medium">
                    {portalTab === 'company' ? 'Talent Discovery & Hiring' : 'Virtual Internship Platform'}
                  </p>
                </div>
              </div>

              <div>
                <h3 className="text-xl sm:text-2xl font-black text-white tracking-tight leading-snug">
                  {portalTab === 'company'
                    ? (mode === 'signup' ? 'Hire Verified Technical Talent' : 'Welcome to Talent Discovery')
                    : (mode === 'signup' ? 'Launch Your Industry Internship' : 'Welcome Back to Your Internship')}
                </h3>
                <p className="text-xs text-blue-100/90 mt-1.5 leading-relaxed">
                  {portalTab === 'company'
                    ? 'Discover, evaluate, and shortlist top-performing students ranked by transparent, real-world project assessment scores.'
                    : 'Join students gaining practical project experience across 20 specialized domains with structured 4-level progression.'}
                </p>
              </div>

              {/* Dynamic Value Points */}
              {portalTab === 'company' ? (
                <div className="space-y-3 pt-3">
                  <div className="flex items-start gap-3">
                    <div className="w-7 h-7 rounded-lg bg-white/15 text-blue-200 flex items-center justify-center shrink-0 mt-0.5">
                      <Trophy className="w-4 h-4 text-amber-300" />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-white">Performance-Based Leaderboard</h4>
                      <p className="text-[11px] text-blue-100/80 leading-normal">
                        Pre-screened candidates ranked strictly by authentic project milestones and code quality.
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <div className="w-7 h-7 rounded-lg bg-white/15 text-blue-200 flex items-center justify-center shrink-0 mt-0.5">
                      <FileText className="w-4 h-4 text-white" />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-white">Verified Project Portfolios</h4>
                      <p className="text-[11px] text-blue-100/80 leading-normal">
                        Inspect faculty-reviewed GitHub code, live deployment links, and assessment scores.
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <div className="w-7 h-7 rounded-lg bg-white/15 text-blue-200 flex items-center justify-center shrink-0 mt-0.5">
                      <ShieldCheck className="w-4 h-4 text-emerald-300" />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-white">Admin-Verified Hiring Access</h4>
                      <p className="text-[11px] text-blue-100/80 leading-normal">
                        Post recruitment opportunities and manage private shortlisted candidate queues securely.
                      </p>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="space-y-3 pt-3">
                  <div className="flex items-start gap-3">
                    <div className="w-7 h-7 rounded-lg bg-white/15 text-blue-200 flex items-center justify-center shrink-0 mt-0.5">
                      <GraduationCap className="w-4 h-4 text-white" />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-white">4-Level Difficulty System</h4>
                      <p className="text-[11px] text-blue-100/80 leading-normal">
                        Structured path from Easy to Intermediate, Hard, and Final Capstone.
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <div className="w-7 h-7 rounded-lg bg-white/15 text-blue-200 flex items-center justify-center shrink-0 mt-0.5">
                      <FileText className="w-4 h-4 text-white" />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-white">Randomized Allocation</h4>
                      <p className="text-[11px] text-blue-100/80 leading-normal">
                        Unique project challenges assigned to every student with zero duplicates.
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <div className="w-7 h-7 rounded-lg bg-white/15 text-blue-200 flex items-center justify-center shrink-0 mt-0.5">
                      <Award className="w-4 h-4 text-white" />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-white">Verified Certificate</h4>
                      <p className="text-[11px] text-blue-100/80 leading-normal">
                        Tamper-proof verifiable credentials with unique QR code and serial number.
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Bottom Real-time Security Notice */}
            <div className="relative z-10 pt-4 mt-4 border-t border-white/20">
              <div className="flex items-center gap-2 text-xs text-blue-100/90 font-medium">
                <ShieldCheck className="w-4 h-4 text-emerald-300 shrink-0" />
                <span>Strict Role-Based Access Control & Encrypted Sessions</span>
              </div>
            </div>
          </div>

          {/* Right Column: Interactive Auth Form */}
          <div className="md:col-span-7 p-6 sm:p-8 flex flex-col justify-between bg-white max-h-[85vh] overflow-y-auto">
            <div>
              {/* Portal Selector Tab: Student vs Company */}
              <div className="flex items-center p-1 bg-slate-100 rounded-2xl mb-4 border border-slate-200">
                <button
                  type="button"
                  onClick={() => {
                    setPortalTab('student');
                    setError(null);
                  }}
                  className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                    portalTab === 'student'
                      ? 'bg-white text-[#0A66C2] shadow-sm'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <GraduationCap className="w-4 h-4" />
                  <span>Student Portal</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setPortalTab('company');
                    setError(null);
                  }}
                  className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                    portalTab === 'company'
                      ? 'bg-white text-[#0A66C2] shadow-sm'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <Building2 className="w-4 h-4" />
                  <span>Company Portal</span>
                  <span className="text-[9px] font-extrabold uppercase px-1.5 py-0.2 rounded-full bg-blue-100 text-[#0A66C2]">
                    Recruiters
                  </span>
                </button>
              </div>

              {/* Segmented Switch: Sign In vs Create Account */}
              <div className="flex items-center p-1 bg-slate-50 rounded-xl mb-4 border border-slate-200/80">
                <button
                  type="button"
                  onClick={() => {
                    setMode('login');
                    setError(null);
                    setResetSent(false);
                  }}
                  className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                    mode === 'login'
                      ? 'bg-white text-[#0A66C2] shadow-xs'
                      : 'text-slate-500 hover:text-slate-800'
                  }`}
                >
                  <KeyRound className="w-3.5 h-3.5" />
                  <span>{portalTab === 'company' ? 'Company Sign In' : 'Sign In'}</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setMode('signup');
                    setError(null);
                    setResetSent(false);
                  }}
                  className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                    mode === 'signup'
                      ? 'bg-white text-[#0A66C2] shadow-xs'
                      : 'text-slate-500 hover:text-slate-800'
                  }`}
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>{portalTab === 'company' ? 'Register Company' : 'Create Free Account'}</span>
                </button>
              </div>

              {/* Error Banner */}
              {error && (
                <div className="mb-4 p-3 bg-rose-50 border border-rose-200 text-rose-800 text-xs rounded-xl flex items-start justify-between gap-2 animate-fadeIn">
                  <div className="flex items-start gap-2">
                    <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                    <div>
                      <span className="font-bold">Authentication Notice:</span>
                      <p className="mt-0.5 leading-relaxed">{error}</p>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => setError(null)}
                    className="text-rose-500 hover:text-rose-800 cursor-pointer text-xs font-bold"
                  >
                    ✕
                  </button>
                </div>
              )}

              {/* Password Reset Notice */}
              {resetSent && (
                <div className="mb-4 p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs rounded-xl flex items-center gap-2 animate-fadeIn">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>
                    Password reset link dispatched to <strong>{email || 'your email'}</strong>. Please check your inbox.
                  </span>
                </div>
              )}

              {/* Google Sign In (for Student Portal only) */}
              {portalTab === 'student' && (
                <>
                  <button
                    type="button"
                    onClick={handleGoogleSignIn}
                    disabled={loading}
                    className="w-full flex items-center justify-center gap-3 py-2.5 px-4 bg-white hover:bg-slate-50 border border-slate-300 hover:border-slate-400 text-slate-800 text-xs sm:text-sm font-semibold rounded-xl shadow-2xs transition-all cursor-pointer min-h-[44px]"
                  >
                    <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
                      <path
                        fill="#4285F4"
                        d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                      />
                      <path
                        fill="#34A853"
                        d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                      />
                      <path
                        fill="#FBBC05"
                        d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                      />
                      <path
                        fill="#EA4335"
                        d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                      />
                    </svg>
                    <span>Continue with Google</span>
                  </button>

                  <div className="flex items-center my-3.5">
                    <div className="flex-1 border-t border-slate-200"></div>
                    <span className="px-3 text-[10px] uppercase tracking-wider text-slate-400 font-bold">
                      Or with email & password
                    </span>
                    <div className="flex-1 border-t border-slate-200"></div>
                  </div>
                </>
              )}

              {/* Main Form */}
              <form onSubmit={handleSubmit} className="space-y-3.5">
                {/* COMPANY SIGN UP FIELDS */}
                {portalTab === 'company' && mode === 'signup' && (
                  <>
                    <div>
                      <label className="block text-xs font-semibold text-slate-800 mb-1">
                        Company / Organization Name *
                      </label>
                      <div className="relative">
                        <Building2 className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                        <input
                          type="text"
                          required
                          value={companyName}
                          onChange={(e) => setCompanyName(e.target.value)}
                          placeholder="e.g. Acme Tech Solutions"
                          className="w-full pl-10 pr-3 py-2 text-xs sm:text-sm border border-slate-300 rounded-xl focus:border-[#0A66C2] focus:ring-2 focus:ring-[#0A66C2]/20 outline-none text-slate-900 min-h-[42px]"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-xs font-semibold text-slate-800 mb-1">
                          Contact Person *
                        </label>
                        <div className="relative">
                          <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                          <input
                            type="text"
                            required
                            value={companyContact}
                            onChange={(e) => setCompanyContact(e.target.value)}
                            placeholder="e.g. Sarah Jenkins"
                            className="w-full pl-10 pr-3 py-2 text-xs sm:text-sm border border-slate-300 rounded-xl focus:border-[#0A66C2] focus:ring-2 focus:ring-[#0A66C2]/20 outline-none text-slate-900 min-h-[42px]"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-slate-800 mb-1">
                          Designation
                        </label>
                        <input
                          type="text"
                          value={companyDesignation}
                          onChange={(e) => setCompanyDesignation(e.target.value)}
                          placeholder="e.g. Head of Talent Acquisition"
                          className="w-full px-3 py-2 text-xs sm:text-sm border border-slate-300 rounded-xl focus:border-[#0A66C2] focus:ring-2 focus:ring-[#0A66C2]/20 outline-none text-slate-900 min-h-[42px]"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-xs font-semibold text-slate-800 mb-1">
                          Company Website
                        </label>
                        <input
                          type="url"
                          value={companyWebsite}
                          onChange={(e) => setCompanyWebsite(e.target.value)}
                          placeholder="https://company.com"
                          className="w-full px-3 py-2 text-xs sm:text-sm border border-slate-300 rounded-xl focus:border-[#0A66C2] focus:ring-2 focus:ring-[#0A66C2]/20 outline-none text-slate-900 min-h-[42px]"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-slate-800 mb-1">
                          Industry / Domain
                        </label>
                        <select
                          value={companyIndustry}
                          onChange={(e) => setCompanyIndustry(e.target.value)}
                          className="w-full px-3 py-2 text-xs sm:text-sm border border-slate-300 rounded-xl focus:border-[#0A66C2] focus:ring-2 focus:ring-[#0A66C2]/20 outline-none text-slate-900 min-h-[42px] bg-white"
                        >
                          <option value="Technology">Technology & Software</option>
                          <option value="Fintech">Financial Technology (Fintech)</option>
                          <option value="AI & Data Science">AI, ML & Data Science</option>
                          <option value="Healthtech">Healthtech & Biotech</option>
                          <option value="E-Commerce">E-Commerce & Retail</option>
                          <option value="Cybersecurity">Cybersecurity & Cloud</option>
                          <option value="Edtech">Educational Technology</option>
                        </select>
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-800 mb-1">
                        Company Description
                      </label>
                      <textarea
                        rows={2}
                        value={companyDesc}
                        onChange={(e) => setCompanyDesc(e.target.value)}
                        placeholder="Brief overview of your company, mission, and hiring focus..."
                        className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl focus:border-[#0A66C2] focus:ring-2 focus:ring-[#0A66C2]/20 outline-none text-slate-900"
                      />
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-xs font-semibold text-slate-800 mb-1">
                          Hiring Roles (comma-separated)
                        </label>
                        <input
                          type="text"
                          value={companyHiringNeeds}
                          onChange={(e) => setCompanyHiringNeeds(e.target.value)}
                          placeholder="e.g. Frontend Intern, Full-Stack Dev"
                          className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl focus:border-[#0A66C2] focus:ring-2 focus:ring-[#0A66C2]/20 outline-none text-slate-900 min-h-[40px]"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-slate-800 mb-1">
                          Preferred Skills (comma-separated)
                        </label>
                        <input
                          type="text"
                          value={companySkills}
                          onChange={(e) => setCompanySkills(e.target.value)}
                          placeholder="e.g. React, Node.js, Python"
                          className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl focus:border-[#0A66C2] focus:ring-2 focus:ring-[#0A66C2]/20 outline-none text-slate-900 min-h-[40px]"
                        />
                      </div>
                    </div>
                  </>
                )}

                {/* STUDENT SIGN UP FIELDS */}
                {portalTab === 'student' && mode === 'signup' && (
                  <div>
                    <label className="block text-xs font-semibold text-slate-800 mb-1">
                      Full Legal Name <span className="text-slate-400 font-normal">(for offer letter & certificate)</span>
                    </label>
                    <div className="relative">
                      <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                      <input
                        type="text"
                        required
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="e.g. Aditi Sharma"
                        className="w-full pl-10 pr-3 py-2 text-xs sm:text-sm border border-slate-300 rounded-xl focus:border-[#0A66C2] focus:ring-2 focus:ring-[#0A66C2]/20 outline-none text-slate-900 min-h-[44px]"
                      />
                    </div>
                  </div>
                )}

                {/* EMAIL ADDRESS (BOTH PORTALS) */}
                <div>
                  <label className="block text-xs font-semibold text-slate-800 mb-1">
                    {portalTab === 'company' ? 'Official Corporate Email *' : 'Email Address *'}
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder={portalTab === 'company' ? 'recruiter@company.com' : 'student@example.com'}
                      className="w-full pl-10 pr-3 py-2 text-xs sm:text-sm border border-slate-300 rounded-xl focus:border-[#0A66C2] focus:ring-2 focus:ring-[#0A66C2]/20 outline-none text-slate-900 min-h-[44px]"
                    />
                  </div>
                </div>

                {/* PASSWORD (BOTH PORTALS) */}
                <div>
                  <div className="flex justify-between items-center mb-1">
                    <label className="block text-xs font-semibold text-slate-800">
                      Password *
                    </label>
                    {mode === 'login' && (
                      <button
                        type="button"
                        onClick={() => {
                          setResetSent(true);
                          setError(null);
                        }}
                        className="text-[11px] text-[#0A66C2] hover:underline font-semibold cursor-pointer"
                      >
                        Forgot password?
                      </button>
                    )}
                  </div>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                    <input
                      type={showPassword ? 'text' : 'password'}
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Enter at least 6 characters"
                      className="w-full pl-10 pr-10 py-2 text-xs sm:text-sm border border-slate-300 rounded-xl focus:border-[#0A66C2] focus:ring-2 focus:ring-[#0A66C2]/20 outline-none text-slate-900 min-h-[44px]"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-3 text-slate-400 hover:text-slate-700 cursor-pointer p-0.5"
                      title={showPassword ? 'Hide password' : 'Show password'}
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>

                  {mode === 'signup' && password.length > 0 && (
                    <div className="mt-1.5 space-y-1">
                      <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden">
                        <div
                          className={`h-full transition-all duration-300 ${strength.color}`}
                          style={{ width: strength.barWidth }}
                        />
                      </div>
                      <p className="text-[10px] text-slate-500 font-medium">
                        Strength: <span className="font-semibold text-slate-700">{strength.label}</span>
                      </p>
                    </div>
                  )}
                </div>

                {/* REFERRAL CODE (STUDENT SIGN UP ONLY) */}
                {portalTab === 'student' && mode === 'signup' && (
                  <div>
                    <label className="block text-xs font-semibold text-slate-800 mb-1">
                      Referral Code <span className="text-slate-400 font-normal">(Optional)</span>
                    </label>
                    <div className="relative">
                      <Tag className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                      <input
                        type="text"
                        value={referralCode}
                        onChange={(e) => setReferralCode(e.target.value.toUpperCase())}
                        placeholder="e.g. PRAJJU123"
                        className="w-full pl-10 pr-3 py-2 text-xs sm:text-sm border border-slate-300 rounded-xl focus:border-[#0A66C2] focus:ring-2 focus:ring-[#0A66C2]/20 outline-none uppercase font-mono text-slate-900 min-h-[44px]"
                      />
                    </div>
                  </div>
                )}

                {/* COMPANY PENDING VERIFICATION NOTICE */}
                {portalTab === 'company' && mode === 'signup' && (
                  <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-[11px] text-amber-900 space-y-1">
                    <div className="flex items-center gap-1.5 font-bold text-amber-800">
                      <Clock className="w-4 h-4 text-amber-600 shrink-0" />
                      <span>Account Verification Process</span>
                    </div>
                    <p className="text-amber-800/90 leading-relaxed">
                      Company registrations remain in <strong>Pending Verification</strong> status until reviewed by VirIntern Admin. Upon approval, your company unlocks the full Talent Discovery Dashboard and candidate recruitment actions.
                    </p>
                  </div>
                )}

                {/* STUDENT E-AGREEMENT CHECKBOX */}
                {portalTab === 'student' && mode === 'signup' && (
                  <div className="pt-2 border-t border-slate-200 space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5 text-xs font-bold text-slate-900">
                        <ShieldCheck className="w-4 h-4 text-[#0A66C2]" />
                        <span>VirIntern E-Agreement & Honor Policy</span>
                      </div>
                      <button
                        type="button"
                        onClick={() => setShowTermsDetails(!showTermsDetails)}
                        className="text-[11px] text-[#0A66C2] hover:underline font-semibold flex items-center gap-0.5 cursor-pointer"
                      >
                        <span>{showTermsDetails ? 'Hide terms' : 'View terms'}</span>
                        {showTermsDetails ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                      </button>
                    </div>

                    {showTermsDetails && (
                      <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl text-[11px] text-slate-600 space-y-1.5 max-h-32 overflow-y-auto animate-fadeIn">
                        <p className="font-bold text-slate-900">Code of Conduct & Honor Statement:</p>
                        <ul className="list-disc pl-4 space-y-1">
                          <li><strong>Independent Work:</strong> All milestone deliverables must reflect your authentic individual engineering.</li>
                          <li><strong>Domain Progress:</strong> Tasks 1 through 5 unlock sequentially per enrolled domain.</li>
                          <li><strong>Task 1 Verification:</strong> Verification of offer letter, YouTube community channel (@virintern), and LinkedIn post is verified per domain.</li>
                          <li><strong>100% Free:</strong> Self-paced virtual internship tracking and project tasks are completely free.</li>
                        </ul>
                      </div>
                    )}

                    <label className="flex items-start gap-2.5 p-2.5 rounded-xl bg-blue-50/60 border border-blue-200/80 cursor-pointer hover:bg-blue-50 transition-colors">
                      <input
                        type="checkbox"
                        checked={agreedToTerms}
                        onChange={(e) => setAgreedToTerms(e.target.checked)}
                        className="mt-0.5 w-4 h-4 rounded text-[#0A66C2] focus:ring-[#0A66C2] border-slate-300 shrink-0 cursor-pointer"
                      />
                      <span className="text-[11px] font-semibold text-slate-800 leading-tight">
                        I accept the VirIntern Internship E-Agreement, Honor Policy, and Code of Conduct.
                      </span>
                    </label>
                  </div>
                )}

                {/* SUBMIT BUTTON */}
                <button
                  type="submit"
                  disabled={loading || (portalTab === 'student' && mode === 'signup' && !agreedToTerms)}
                  className={`w-full py-3 mt-1 font-bold text-xs sm:text-sm rounded-xl shadow-md transition-all flex items-center justify-center gap-2 min-h-[46px] ${
                    portalTab === 'student' && mode === 'signup' && !agreedToTerms
                      ? 'bg-slate-200 text-slate-400 cursor-not-allowed border border-slate-300'
                      : 'bg-[#0A66C2] hover:bg-[#004182] text-white cursor-pointer active:scale-98 shadow-blue-500/20'
                  }`}
                >
                  {loading ? (
                    <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  ) : (
                    <>
                      <span>
                        {portalTab === 'company'
                          ? (mode === 'signup' ? 'Submit Company Registration' : 'Sign In to Talent Discovery')
                          : (mode === 'signup' ? 'Create Free Account & Start' : 'Sign In to Dashboard')}
                      </span>
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </form>
            </div>

            {/* Bottom Switch Link */}
            <div className="mt-5 pt-3 border-t border-slate-100 text-center">
              <p className="text-xs text-slate-600">
                {mode === 'signup' ? 'Already registered?' : 'Need an account?'}{' '}
                <button
                  type="button"
                  onClick={() => {
                    setMode(mode === 'signup' ? 'login' : 'signup');
                    setError(null);
                    setResetSent(false);
                  }}
                  className="font-bold text-[#0A66C2] hover:underline cursor-pointer"
                >
                  {mode === 'signup'
                    ? (portalTab === 'company' ? 'Company Sign In' : 'Sign In Here')
                    : (portalTab === 'company' ? 'Register New Company' : 'Join VirIntern Free')}
                </button>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
