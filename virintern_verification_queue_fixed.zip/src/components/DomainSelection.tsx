import React, { useState, useEffect } from 'react';
import { DomainItem } from '../types';
import { dataService } from '../services/dataService';
import { useAuth } from '../context/AuthContext';
import {
  Search,
  Sparkles,
  ArrowRight,
  Clock,
  Layers,
  CheckCircle2,
  AlertCircle,
  Cpu,
  Radio,
  Globe,
  Smartphone,
  Terminal,
  Coffee,
  BarChart2,
  Palette,
  ShieldCheck,
  Cloud,
  PieChart,
  Megaphone
} from 'lucide-react';

const DOMAIN_ICONS: Record<string, React.ReactNode> = {
  Globe: <Globe className="w-6 h-6 text-[#0A66C2]" />,
  Smartphone: <Smartphone className="w-6 h-6 text-emerald-600" />,
  Terminal: <Terminal className="w-6 h-6 text-amber-600" />,
  Coffee: <Coffee className="w-6 h-6 text-rose-600" />,
  BarChart2: <BarChart2 className="w-6 h-6 text-purple-600" />,
  Cpu: <Cpu className="w-6 h-6 text-indigo-600" />,
  Palette: <Palette className="w-6 h-6 text-pink-600" />,
  ShieldCheck: <ShieldCheck className="w-6 h-6 text-slate-700" />,
  Cloud: <Cloud className="w-6 h-6 text-sky-600" />,
  PieChart: <PieChart className="w-6 h-6 text-teal-600" />,
  Megaphone: <Megaphone className="w-6 h-6 text-orange-600" />,
  Radio: <Radio className="w-6 h-6 text-cyan-600" />
};

interface DomainSelectionProps {
  onSelectDomain: (domain: DomainItem) => void;
  openAgreementModal: (domain: DomainItem) => void;
  setCurrentView: (view: string) => void;
  initialSearch?: string;
}

export const DomainSelection: React.FC<DomainSelectionProps> = ({
  onSelectDomain,
  openAgreementModal,
  setCurrentView,
  initialSearch = ''
}) => {
  const { user, activeInternship } = useAuth();
  const [domains, setDomains] = useState<DomainItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState(initialSearch);
  const [selectedCategory, setSelectedCategory] = useState<string>('All');

  useEffect(() => {
    if (initialSearch) {
      setSearchTerm(initialSearch);
    }
  }, [initialSearch]);

  useEffect(() => {
    dataService.getDomains().then((list) => {
      setDomains(list.filter(d => d.isActive));
      setLoading(false);
    });
  }, []);

  // Once enrolled in a domain, opening the platform immediately opens their active internship
  useEffect(() => {
    if (user && user.role !== 'admin' && activeInternship && !initialSearch) {
      setCurrentView('dashboard');
    }
  }, [user, activeInternship, initialSearch, setCurrentView]);

  const handleEnrollClick = (domain: DomainItem) => {
    if (!user) {
      onSelectDomain(domain); // will prompt auth
      return;
    }

    if (!user.agreementAccepted) {
      openAgreementModal(domain);
    } else {
      onSelectDomain(domain);
    }
  };

  const filteredDomains = domains.filter((d) => {
    const matchesSearch = d.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      d.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      d.tags?.some(t => t.toLowerCase().includes(searchTerm.toLowerCase()));
    return matchesSearch;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto mb-10">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#EBF4FD] border border-[#0A66C2]/30 text-[#0A66C2] text-xs font-semibold mb-3">
          <Sparkles className="w-3.5 h-3.5 text-[#0A66C2]" />
          <span>Curated Tech Specializations</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-[#191919] tracking-tight">
          Choose Your Internship Domain
        </h1>
        <p className="text-[#666666] mt-2 text-sm sm:text-base">
          Select one domain to begin your structured 1-month virtual internship. You will complete 5 milestone projects with mentor verification.
        </p>

        {user && activeInternship && (
          <div className="mt-5 p-4 bg-[#E8F5E9] border border-[#C8E6C9] rounded-2xl text-xs sm:text-sm text-[#057642] flex flex-col sm:flex-row items-center justify-between gap-3 shadow-xs">
            <div className="flex items-center gap-2.5">
              <CheckCircle2 className="w-5 h-5 text-[#057642] shrink-0" />
              <span>
                You are enrolled in <strong className="font-bold text-[#057642]">{activeInternship.domainName}</strong> ({activeInternship.progress}% completed).
              </span>
            </div>
            <button
              onClick={() => setCurrentView('dashboard')}
              className="px-4 py-2 bg-[#057642] hover:bg-[#046237] text-white rounded-full font-bold text-xs flex items-center gap-1.5 shadow-xs transition-colors shrink-0 cursor-pointer"
            >
              <span>Go to Active Tasks</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        )}
      </div>

      {/* Search & Filter Bar */}
      <div className="max-w-2xl mx-auto mb-10">
        <div className="relative">
          <Search className="w-5 h-5 text-[#666666] absolute left-4 top-3.5" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search domains (e.g., ECE, Embedded Systems, IoT, React, Python, Cloud)..."
            className="w-full pl-11 pr-4 py-3 bg-white border border-[#E0DFDC] rounded-xl shadow-xs text-sm focus:border-[#0A66C2] focus:ring-1 focus:ring-[#0A66C2] outline-none text-[#191919]"
          />
        </div>
      </div>

      {/* Grid */}
      {loading ? (
        <div className="py-20 text-center">
          <div className="w-8 h-8 border-4 border-[#0A66C2] border-t-transparent rounded-full animate-spin mx-auto mb-3"></div>
          <p className="text-xs text-[#666666] font-medium">Loading domains from database...</p>
        </div>
      ) : filteredDomains.length === 0 ? (
        <div className="p-12 text-center bg-white rounded-xl border border-[#E0DFDC]">
          <p className="text-sm font-semibold text-[#191919]">No domains match your search query.</p>
          <button
            onClick={() => setSearchTerm('')}
            className="mt-2 text-xs text-[#0A66C2] font-bold hover:underline"
          >
            Clear filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredDomains.map((domain) => {
            const isEnrolled = Boolean(
              user &&
              user.role === 'student' &&
              activeInternship &&
              (
                activeInternship.domainId === domain.id ||
                activeInternship.domainSlug === domain.id ||
                activeInternship.domainId === domain.slug ||
                activeInternship.domainName?.toLowerCase() === domain.name.toLowerCase() ||
                activeInternship.domainId?.toLowerCase() === domain.name.toLowerCase()
              )
            );

            const hasOtherEnrollment = Boolean(user && user.role === 'student' && activeInternship && !isEnrolled);

            return (
              <div
                key={domain.id}
                className={`bg-white rounded-xl p-6 border transition-all flex flex-col justify-between ${
                  isEnrolled
                    ? 'border-[#057642] shadow-sm ring-2 ring-[#057642]/20 bg-gradient-to-b from-[#F9FDF9] to-white'
                    : 'border-[#E0DFDC] hover:border-[#0A66C2] hover:shadow-md'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <span className={`w-12 h-12 rounded-xl border flex items-center justify-center shadow-2xs ${
                      isEnrolled ? 'bg-[#E8F5E9] border-[#C8E6C9]' : 'bg-[#EBF4FD] border-[#D0E8FF]'
                    }`}>
                      {DOMAIN_ICONS[domain.icon || ''] || <Layers className={`w-6 h-6 ${isEnrolled ? 'text-[#057642]' : 'text-[#0A66C2]'}`} />}
                    </span>
                    <div className="flex items-center gap-1.5">
                      {isEnrolled && (
                        <span className="text-[11px] font-bold text-[#057642] bg-[#E8F5E9] border border-[#C8E6C9] px-2.5 py-0.5 rounded-full flex items-center gap-1 shadow-2xs">
                          <CheckCircle2 className="w-3.5 h-3.5 text-[#057642]" />
                          Enrolled Track
                        </span>
                      )}
                      <span className="text-[11px] font-semibold text-[#666666] bg-[#F4F2EE] px-2.5 py-0.5 rounded-full flex items-center gap-1">
                        <Clock className="w-3 h-3 text-[#666666]" />
                        {domain.durationDays || 30} Days
                      </span>
                    </div>
                  </div>

                  <h3 className="text-xl font-bold text-[#191919] mb-2">{domain.name}</h3>
                  <p className="text-xs text-[#666666] leading-relaxed mb-4">
                    {domain.description}
                  </p>

                  <div className="p-3 bg-[#F4F2EE] rounded-xl mb-4 text-xs text-[#191919] space-y-1 border border-[#E0DFDC]">
                    <div className="flex items-center justify-between">
                      <span className="text-[#666666]">Tasks:</span>
                      <span className="font-semibold text-[#191919]">5 Structured Projects</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-[#666666]">Milestone System:</span>
                      <span className="font-semibold text-[#057642]">Sequential (20% each)</span>
                    </div>
                  </div>

                  {domain.tags && (
                    <div className="flex flex-wrap gap-1.5 mb-6">
                      {domain.tags.map((tag) => (
                        <span
                          key={tag}
                          className="px-2 py-0.5 rounded text-[10px] font-medium bg-[#EBF4FD] text-[#0A66C2]"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>
                  )}
                </div>

                <div>
                  {isEnrolled ? (
                    <button
                      onClick={() => setCurrentView('dashboard')}
                      className="w-full py-2.5 px-4 rounded-full font-bold text-xs flex items-center justify-center gap-2 transition-all bg-[#057642] hover:bg-[#046237] text-white shadow-xs cursor-pointer"
                    >
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Enrolled • Continue Active Tasks ({activeInternship?.progress || user?.progress || 0}%)</span>
                      <ArrowRight className="w-4 h-4 ml-1" />
                    </button>
                  ) : !user ? (
                    <button
                      onClick={() => handleEnrollClick(domain)}
                      className="w-full py-2.5 px-4 rounded-full font-semibold text-xs flex items-center justify-center gap-2 transition-all bg-[#0A66C2] hover:bg-[#004182] text-white shadow-xs cursor-pointer"
                    >
                      <span>Join to Enroll</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  ) : hasOtherEnrollment ? (
                    <button
                      onClick={() => handleEnrollClick(domain)}
                      className="w-full py-2.5 px-4 rounded-full font-semibold text-xs flex items-center justify-center gap-2 transition-all bg-white border border-[#0A66C2] text-[#0A66C2] hover:bg-blue-50 shadow-xs cursor-pointer"
                    >
                      <span>Switch to this Domain</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  ) : (
                    <button
                      onClick={() => handleEnrollClick(domain)}
                      className="w-full py-2.5 px-4 rounded-full font-semibold text-xs flex items-center justify-center gap-2 transition-all bg-[#0A66C2] hover:bg-[#004182] text-white shadow-xs cursor-pointer"
                    >
                      <span>Select This Domain</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
