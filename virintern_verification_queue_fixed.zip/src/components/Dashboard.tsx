import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../context/AuthContext';
import { ProjectTask, TaskSubmission, InternshipRecord, GeminiTaskEvaluation, DomainLeaderboardEntry, TaskEvaluationRecord } from '../types';
import { dataService, isSameDomain } from '../services/dataService';
import { generateStudentTasks } from '../services/domainProjectsService';
import { YOUTUBE_CONFIG } from '../firebase/config';
import { youtubeService } from '../services/youtubeService';
import confetti from 'canvas-confetti';
import {
  AlertCircle,
  ArrowRight,
  Award,
  BookOpen,
  Calendar,
  Camera,
  Check,
  CheckCircle2,
  CheckSquare,
  ChevronRight,
  Clock,
  Copy,
  ExternalLink,
  Eye,
  FileCheck,
  FileText,
  Github,
  Globe,
  HelpCircle,
  Image,
  Layers,
  Lock,
  Medal,
  MessageSquare,
  Paperclip,
  Printer,
  RefreshCw,
  Send,
  Shield,
  Shuffle,
  Sliders,
  Sparkles,
  Target,
  Trash2,
  TrendingUp,
  Trophy,
  Upload,
  User,
  X,
  Youtube
} from 'lucide-react';
import { OfferLetterModal } from './OfferLetterModal';
import { StudentEvaluationModal } from './StudentEvaluationModal';
import { ProjectGuideModal } from './ProjectGuideModal';
import { TaskStatusBar } from './TaskStatusBar';

interface DashboardProps {
  setCurrentView: (view: string) => void;
  openEmailSimulator: () => void;
}

export const Dashboard: React.FC<DashboardProps> = ({ setCurrentView, openEmailSimulator }) => {
  const { user, activeInternship: rawActiveInternship, refreshProfile, updateProfilePhoto } = useAuth();

  // Guarantee resilient active internship record strictly for CURRENT user and track - NEVER null, always provides active track
  const activeInternship: InternshipRecord = (() => {
    const enrolledId = localStorage.getItem('virintern_enrolled_domain') || 'web-dev';
    const domainName = user?.selectedDomain || localStorage.getItem('virintern_enrolled_domain_name') || 'Web Development';
    const uid = user?.uid || 'student';

    if (rawActiveInternship && (rawActiveInternship.domainId === enrolledId || isSameDomain(rawActiveInternship.domainId, enrolledId, rawActiveInternship.domainName, domainName))) {
      return rawActiveInternship;
    }

    if (user?.uid) {
      try {
        const cached = localStorage.getItem('virintern_cached_internship');
        if (cached) {
          const parsed = JSON.parse(cached) as InternshipRecord;
          if (parsed && parsed.userId === user.uid && (parsed.domainId === enrolledId || isSameDomain(parsed.domainId, enrolledId, parsed.domainName, domainName))) {
            return parsed;
          }
        }
      } catch {}

      try {
        const raw = localStorage.getItem(`virintern_data_internship_${user.uid}_${enrolledId}`) ||
                    localStorage.getItem(`virintern_internship_${user.uid}_${enrolledId}`);
        if (raw) {
          const parsed = JSON.parse(raw) as InternshipRecord;
          if (parsed && parsed.userId === user.uid) {
            return parsed;
          }
        }
      } catch {}
    }

    return {
      id: `${uid}_${enrolledId}`,
      userId: uid,
      domainId: enrolledId,
      domainName: domainName,
      startDate: user?.internshipStartDate || new Date().toISOString(),
      endDate: user?.internshipEndDate || new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
      status: user?.internshipStatus === 'completed' ? 'completed' : 'active',
      progress: 0,
      currentTask: 1,
      completedTasks: [],
      task1VerificationCompleted: false,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
  })();

  const currentDomainId = activeInternship.domainId;
  const currentDomainName = activeInternship.domainName || currentDomainId;

  // Immediately initialize all 5 milestone tasks synchronously so tasks are 100% visible on first render
  const [tasks, setTasks] = useState<ProjectTask[]>(() => {
    if (currentDomainId && currentDomainName) {
      return generateStudentTasks(currentDomainId, currentDomainName, user?.uid);
    }
    return [];
  });

  const [submissions, setSubmissions] = useState<TaskSubmission[]>([]);
  const [domainLeaderboard, setDomainLeaderboard] = useState<DomainLeaderboardEntry[]>([]);
  const [evaluations, setEvaluations] = useState<TaskEvaluationRecord[]>([]);
  const [activeEvaluation, setActiveEvaluation] = useState<TaskEvaluationRecord | null>(null);
  const [evalModalOpen, setEvalModalOpen] = useState(false);
  const [selectedTaskNumber, setSelectedTaskNumber] = useState<number>(() => {
    try {
      const saved = localStorage.getItem(`virintern_selected_task_${user?.uid}`);
      if (saved && Number(saved) >= 1 && Number(saved) <= 5) return Number(saved);
    } catch {}
    return activeInternship?.currentTask || 1;
  });
  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);

  useEffect(() => {
    if (!user?.uid) return;
    const loadEvals = () => {
      dataService.getEvaluations(user.uid).then(setEvaluations).catch(() => {});
    };
    loadEvals();
    const unsubVer = dataService.on('submission_verified', loadEvals);
    const unsubLb = dataService.on('leaderboard_updated', loadEvals);
    return () => {
      unsubVer();
      unsubLb();
    };
  }, [user?.uid, submissions]);

  useEffect(() => {
    if (!activeInternship?.domainId) return;
    const unsubLb = dataService.subscribeDomainLeaderboard(
      activeInternship.domainId,
      user?.uid,
      setDomainLeaderboard
    );
    return () => {
      unsubLb();
    };
  }, [activeInternship?.domainId, user?.uid]);

  const userRankEntry = domainLeaderboard.find(e => e.isCurrentUser || e.userId === user?.uid);

  // Keep tasks strictly in sync whenever the active domain or user changes
  useEffect(() => {
    if (currentDomainId && currentDomainName) {
      const generated = generateStudentTasks(currentDomainId, currentDomainName, user?.uid);
      setTasks(generated);
    }
  }, [currentDomainId, currentDomainName, user?.uid]);

  // Profile Picture Upload State
  const [photoModalOpen, setPhotoModalOpen] = useState(false);
  const [photoUrlInput, setPhotoUrlInput] = useState('');
  const [uploadingPhoto, setUploadingPhoto] = useState(false);
  const [photoError, setPhotoError] = useState('');
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Submission Form State
  const [repoUrl, setRepoUrl] = useState('');
  const [demoUrl, setDemoUrl] = useState('');
  const [driveUrl, setDriveUrl] = useState('');
  const [pdfUrl, setPdfUrl] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [textAnswer, setTextAnswer] = useState('');
  const [notes, setNotes] = useState('');
  
  // Task 1 Special Verification & Offer Letter State
  const [task1Type, setTask1Type] = useState<'letter' | 'social'>('letter');
  const [letterFileName, setLetterFileName] = useState('');
  const [offerLetterFileName, setOfferLetterFileName] = useState('');
  const [offerLetterUrl, setOfferLetterUrl] = useState('');
  const [offerLetterDataUri, setOfferLetterDataUri] = useState('');
  const [isOfferLetterModalOpen, setIsOfferLetterModalOpen] = useState(false);
  const [hasViewedOfferLetter, setHasViewedOfferLetter] = useState(false);
  const [projectGuideModalOpen, setProjectGuideModalOpen] = useState(false);
  const [socialProofUrl, setSocialProofUrl] = useState('');
  const [linkedinVerifyError, setLinkedinVerifyError] = useState<string | null>(null);
  const [userYoutubeHandle, setUserYoutubeHandle] = useState('');
  const [youtubeScreenshotUrl, setYoutubeScreenshotUrl] = useState('');
  const [youtubeScreenshotFileName, setYoutubeScreenshotFileName] = useState('');
  const [youtubeScreenshotPreviewOpen, setYoutubeScreenshotPreviewOpen] = useState(false);
  const [showInstructionsGuide, setShowInstructionsGuide] = useState(false);
  const [youtubeProofNote, setYoutubeProofNote] = useState('');
  const [youtubeVerificationMsg, setYoutubeVerificationMsg] = useState<{ success: boolean; text: string } | null>(null);
  const [copiedShareText, setCopiedShareText] = useState(false);
  const [mobileTaskTab, setMobileTaskTab] = useState<'guide' | 'submission'>('guide');

  // Input editing guard refs to guarantee user typing is never interrupted or wiped out
  const userEditedYoutubeRef = useRef(false);
  const userEditedLinkedInRef = useRef(false);
  const prevDomainIdRef = useRef<string | null>(null);
  const prevTaskNumRef = useRef<number | null>(null);

  const openOfferLetterModal = () => {
    setHasViewedOfferLetter(true);
    try {
      window.history.pushState({ modal: 'offer_letter' }, '', window.location.href);
    } catch {}
    setIsOfferLetterModalOpen(true);
  };

  const handleYoutubeScreenshotUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 15 * 1024 * 1024) {
      setYoutubeVerificationMsg({
        success: false,
        text: 'Screenshot image size is too large (max 15MB). Please upload a smaller image file.'
      });
      return;
    }
    const reader = new FileReader();
    reader.onload = (event) => {
      const rawDataUrl = event.target?.result as string;
      if (!rawDataUrl) return;

      // Automatically compress & optimize screenshot to stay well under Firestore 1MB document limit
      const img = new window.Image();
      img.onload = () => {
        try {
          const canvas = document.createElement('canvas');
          const ctx = canvas.getContext('2d');
          let maxDim = 1100;
          let quality = 0.78;
          let compressed = rawDataUrl;

          if (ctx) {
            for (let attempt = 0; attempt < 4; attempt++) {
              let { width, height } = img;
              if (width > maxDim || height > maxDim) {
                if (width > height) {
                  height = Math.round((height * maxDim) / width);
                  width = maxDim;
                } else {
                  width = Math.round((width * maxDim) / height);
                  height = maxDim;
                }
              }
              canvas.width = Math.max(1, width);
              canvas.height = Math.max(1, height);
              ctx.clearRect(0, 0, canvas.width, canvas.height);
              ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
              compressed = canvas.toDataURL('image/jpeg', quality);
              if (compressed.length <= 550_000) break;
              maxDim = Math.round(maxDim * 0.75);
              quality = Math.max(0.45, quality - 0.14);
            }

            setYoutubeScreenshotUrl(compressed);
            setYoutubeScreenshotFileName(file.name.replace(/\.[^/.]+$/, "") + ".jpg");
            setYoutubeVerificationMsg(null);
            return;
          }
        } catch {
          // fallback to rawDataUrl if canvas fails
        }
        setYoutubeScreenshotUrl(rawDataUrl);
        setYoutubeScreenshotFileName(file.name);
        setYoutubeVerificationMsg(null);
      };
      img.onerror = () => {
        setYoutubeScreenshotUrl(rawDataUrl);
        setYoutubeScreenshotFileName(file.name);
        setYoutubeVerificationMsg(null);
      };
      img.src = rawDataUrl;
    };
    reader.readAsDataURL(file);
  };

  const normalizeLinkedInUrl = (raw: string): string => {
    let clean = (raw || '').trim().replace(/^[<"'\s]+|[>"'\s]+$/g, '');
    if (!clean) return '';
    if (!clean.match(/^https?:\/\//i)) {
      clean = 'https://' + clean;
    }
    return clean;
  };

  const isValidLinkedInPostUrl = (raw: string): boolean => {
    if (!raw || !raw.trim()) return false;
    const clean = normalizeLinkedInUrl(raw);
    try {
      const parsed = new URL(clean);
      const host = parsed.hostname.toLowerCase();
      // Valid LinkedIn domains including country subdomains (in.linkedin.com, uk.linkedin.com, etc.), mobile (m.linkedin.com), and shortlink lnkd.in
      const isLinkedInDomain =
        host === 'linkedin.com' ||
        host.endsWith('.linkedin.com') ||
        host === 'lnkd.in' ||
        host.endsWith('.lnkd.in');

      if (!isLinkedInDomain) {
        return false;
      }

      const path = (parsed.pathname || '').toLowerCase();
      // Bare domain homepage or empty path is not enough
      if (path === '/' || path === '' || path === '/feed' || path === '/feed/') {
        return false;
      }

      // Valid: posts, feed updates, activities, articles, profiles (/in/...)
      return path.length >= 3;
    } catch {
      return false;
    }
  };

  const handlePasteClipboard = async () => {
    try {
      if (navigator?.clipboard?.readText) {
        const clipText = await navigator.clipboard.readText();
        if (clipText && clipText.trim()) {
          const norm = normalizeLinkedInUrl(clipText.trim());
          userEditedLinkedInRef.current = true;
          setSocialProofUrl(norm);
          setLinkedinVerifyError(null);
        }
      }
    } catch {
      // clipboard permission fallback
    }
  };

  useEffect(() => {
    if (!user || !activeInternship) return;

    setLoading(true);

    // Pre-attach official offer letter by default for this active domain
    const domSlug = (activeInternship.domainSlug || activeInternship.domainId || 'tech').toUpperCase();
    const defaultOfferName = `VirIntern_Offer_Letter_${domSlug}.pdf`;
    const defaultOfferUrl = `virintern://offer-letters/VIR-OFFER-2026-${domSlug}-${(user?.uid || '2026').slice(-5)}`;
    setOfferLetterFileName(defaultOfferName);
    setLetterFileName(defaultOfferName);
    setOfferLetterUrl(defaultOfferUrl);

    // Only reset inputs when the active domain has genuinely changed
    const isDomainChange = prevDomainIdRef.current !== null && prevDomainIdRef.current !== activeInternship.domainId;
    prevDomainIdRef.current = activeInternship.domainId;

    if (isDomainChange) {
      userEditedYoutubeRef.current = false;
      userEditedLinkedInRef.current = false;
      setUserYoutubeHandle('');
      setYoutubeProofNote('');
      setYoutubeScreenshotUrl('');
      setYoutubeScreenshotFileName('');
      setSocialProofUrl('');
      setLinkedinVerifyError(null);
      setYoutubeVerificationMsg(null);
      setRepoUrl('');
      setDemoUrl('');
      setTextAnswer('');
      setNotes('');
    }

    const unsubProjects = dataService.subscribeProjects(activeInternship.domainId, (domainProjects) => {
      if (domainProjects && domainProjects.length > 0) {
        setTasks(domainProjects);
      }
    }, user.uid);

    const unsubSubmissions = dataService.subscribeSubmissions(user.uid, (userSubs) => {
      // Filter submissions strictly for this user and this active domain
      const domainSubs = (userSubs || []).filter(s =>
        s.userId === user.uid &&
        Boolean(s.domainId || s.domainName) &&
        isSameDomain(s.domainId, activeInternship.domainId, s.domainName, activeInternship.domainName)
      );
      setSubmissions(domainSubs);
      
      const t1 = domainSubs.find(s => s.taskNumber === 1);
      if (t1) {
        // Only adopt previously submitted values if user is not actively editing
        if (!userEditedYoutubeRef.current && t1.youtubeProofText) {
          setUserYoutubeHandle(t1.youtubeProofText);
          setYoutubeProofNote(t1.youtubeProofText);
        }
        if (!userEditedLinkedInRef.current && t1.socialProofUrl) {
          setSocialProofUrl(t1.socialProofUrl);
        }
        if (t1.youtubeScreenshotUrl && t1.youtubeScreenshotUrl !== '[STORED_IN_MEMORY_AND_SERVER]') {
          setYoutubeScreenshotUrl(t1.youtubeScreenshotUrl);
          setYoutubeScreenshotFileName(t1.youtubeScreenshotFileName || 'youtube_subscribe_screenshot.png');
        }
        if (t1.offerLetterFileName) {
          setOfferLetterFileName(t1.offerLetterFileName);
          setLetterFileName(t1.offerLetterFileName);
        }
        if (t1.offerLetterUrl) {
          setOfferLetterUrl(t1.offerLetterUrl);
        }
      }
      setLoading(false);
    });

    const handleSubUpdated = () => {
      refreshProfile();
      if (user?.uid) {
        dataService.getEvaluations(user.uid).then(setEvaluations).catch(() => {});
      }
    };
    if (typeof window !== 'undefined') {
      window.addEventListener('virintern_submission_updated', handleSubUpdated);
      window.addEventListener('virintern_internship_updated', handleSubUpdated);
    }

    // Auto-select the current active task (e.g. 1 to 5) if not explicitly set
    setSelectedTaskNumber(prev => {
      try {
        const saved = localStorage.getItem(`virintern_selected_task_${user?.uid}`);
        if (saved && Number(saved) >= 1 && Number(saved) <= 5) return Number(saved);
      } catch {}
      return prev || activeInternship.currentTask || 1;
    });

    return () => {
      unsubProjects();
      unsubSubmissions();
      if (typeof window !== 'undefined') {
        window.removeEventListener('virintern_submission_updated', handleSubUpdated);
        window.removeEventListener('virintern_internship_updated', handleSubUpdated);
      }
    };
  }, [user?.uid, activeInternship?.domainId, activeInternship?.currentTask]);

  // Sync / reset Task 2-5 submission form fields cleanly when switching selectedTaskNumber
  useEffect(() => {
    if (prevTaskNumRef.current === selectedTaskNumber) return;
    prevTaskNumRef.current = selectedTaskNumber;
    setSubmitSuccess(false);
    setSubmitError(null);

    if (selectedTaskNumber > 1 && user && activeInternship) {
      const existing = submissions.find(s =>
        s.userId === user.uid &&
        s.taskNumber === selectedTaskNumber &&
        Boolean(s.domainId || s.domainName) &&
        isSameDomain(s.domainId, activeInternship.domainId, s.domainName, activeInternship.domainName)
      );
      setRepoUrl(existing?.repositoryURL || existing?.githubUrl || '');
      setDemoUrl(existing?.demoURL || existing?.projectUrl || '');
      setDriveUrl(existing?.driveURL || '');
      setPdfUrl(existing?.pdfUrl || '');
      setTextAnswer('');
      setNotes(existing?.notes || '');
    }
  }, [selectedTaskNumber, activeInternship?.domainId, user?.uid, submissions]);

  // Smooth scroll to task workspace when active task changes or on redirect
  useEffect(() => {
    const el = document.getElementById('task-workspace');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  }, [selectedTaskNumber]);

  const handleSubscribeYouTube = () => {
    window.open(YOUTUBE_CONFIG.channelUrl, '_blank');
  };

  const handleTask1Submit = async (e?: React.FormEvent) => {
    if (e?.preventDefault) e.preventDefault();
    if (!user || !activeInternship || !currentTask) return;

    if (!userYoutubeHandle.trim()) {
      const msg = 'Please enter your YouTube handle or username (e.g. @yourhandle) to confirm channel subscription.';
      setYoutubeVerificationMsg({ success: false, text: msg });
      setSubmitError(msg);
      return;
    }

    if (!youtubeScreenshotUrl.trim() || youtubeScreenshotUrl === '[STORED_IN_MEMORY_AND_SERVER]') {
      const msg = 'Please upload a screenshot confirming you have subscribed to the official VirIntern YouTube channel for manual admin verification.';
      setYoutubeVerificationMsg({ success: false, text: msg });
      setSubmitError(msg);
      return;
    }

    const cleanLinkedIn = normalizeLinkedInUrl(socialProofUrl);
    if (!cleanLinkedIn || !isValidLinkedInPostUrl(cleanLinkedIn)) {
      const msg = 'Please enter a valid LinkedIn announcement post URL (e.g. https://www.linkedin.com/posts/... or lnkd.in/...) for manual mentor verification.';
      setLinkedinVerifyError(msg);
      setSubmitError(msg);
      return;
    }

    setSubmitting(true);
    setSubmitSuccess(false);
    setSubmitError(null);
    setLinkedinVerifyError(null);
    setYoutubeVerificationMsg(null);

    try {
      const finalSocialUrl = cleanLinkedIn;
      const domSlug = (activeInternship.domainSlug || activeInternship.domainId || 'tech').toUpperCase();
      const finalOfferName = offerLetterFileName || letterFileName || `VirIntern_Offer_Letter_${domSlug}.pdf`;
      const finalOfferUrl = offerLetterUrl || `virintern://offer-letters/VIR-OFFER-2026-${domSlug}-${(user?.uid || '2026').slice(-5)}`;

      const subResult = await dataService.submitTask({
        userId: user.uid,
        userEmail: user.email,
        userName: resolvedUserName,
        domainId: activeInternship.domainId,
        domainName: activeInternship.domainName,
        taskNumber: 1,
        projectId: currentTask.id,
        taskId: currentTask.id,
        projectTitle: currentTask.title,
        notes: notes.trim() || 'Task 1 Onboarding & Verification successfully completed: Official offer letter verified, YouTube subscribe screenshot submitted, and offer letter LinkedIn post verified.',
        task1VerificationType: 'offer_letter',
        offerLetterFileName: finalOfferName,
        offerLetterUrl: finalOfferUrl,
        letterFileUrl: `virintern://files/${finalOfferName}`,
        socialProofUrl: finalSocialUrl,
        linkedinVerified: true,
        linkedinProofUrl: finalSocialUrl,
        youtubeChannelChecked: true,
        youtubeProofText: userYoutubeHandle.trim(),
        youtubeScreenshotUrl: youtubeScreenshotUrl.trim(),
        youtubeScreenshotFileName: youtubeScreenshotFileName.trim() || 'youtube_subscribe_screenshot.png',
        submissionType: 'document_or_link'
      }, currentTask);

      if (subResult.evaluation) {
        setActiveEvaluation(subResult.evaluation);
        setEvalModalOpen(true);
      }

      if (subResult?.submission) {
        setSubmissions(prev => {
          const rest = prev.filter(s => !(isSameDomain(s.domainId, activeInternship.domainId, s.domainName, activeInternship.domainName) && s.taskNumber === 1));
          return [subResult.submission, ...rest];
        });
      }

      setSubmitSuccess(true);
      confetti({
        particleCount: 70,
        spread: 70,
        origin: { y: 0.6 }
      });

      await refreshProfile();

      // Refresh domain leaderboard rankings
      const updatedLeaderboard = await dataService.getDomainLeaderboard(activeInternship.domainId, user.uid);
      setDomainLeaderboard(updatedLeaderboard);
    } catch (err: any) {
      console.error('Task 1 submission error:', err);
      setSubmitError(err?.message || 'Failed to submit Task 1 deliverables. Please check your connection and try again.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 2.5 * 1024 * 1024) {
      setPhotoError('Image file is too large. Please select a photo under 2.5MB.');
      return;
    }
    setUploadingPhoto(true);
    setPhotoError('');
    const reader = new FileReader();
    reader.onload = async (event) => {
      const dataUrl = event.target?.result as string;
      if (dataUrl) {
        try {
          await updateProfilePhoto(dataUrl);
          await refreshProfile();
          setPhotoModalOpen(false);
          confetti({ particleCount: 30, spread: 50 });
        } catch (err: any) {
          setPhotoError(err.message || 'Could not save profile picture.');
        }
      }
      setUploadingPhoto(false);
    };
    reader.readAsDataURL(file);
  };

  const handleSavePhotoUrl = async () => {
    if (!photoUrlInput.trim()) return;
    setUploadingPhoto(true);
    setPhotoError('');
    try {
      await updateProfilePhoto(photoUrlInput.trim());
      await refreshProfile();
      setPhotoModalOpen(false);
      setPhotoUrlInput('');
      confetti({ particleCount: 30, spread: 50 });
    } catch (err: any) {
      setPhotoError(err.message || 'Could not update photo.');
    } finally {
      setUploadingPhoto(false);
    }
  };

  const handleRemovePhoto = async () => {
    await updateProfilePhoto('');
    await refreshProfile();
    setPhotoModalOpen(false);
  };

  const linkedInTrackSlug = String(activeInternship?.domainSlug || activeInternship?.domainId || 'tech').replace(/[^a-zA-Z0-9]/g, '');
  const linkedInAnnouncementText = `Excited to announce that I have officially joined VirIntern as a Virtual Intern in ${activeInternship?.domainName || 'Software Engineering'}! 🚀 Looking forward to this 1-month structured journey building industry-standard milestones. #VirIntern #VirtualInternship #${linkedInTrackSlug}`;
  const linkedInShareUrl = `https://www.linkedin.com/feed/?shareActive=true&text=${encodeURIComponent(linkedInAnnouncementText)}`;

  const handleCopyShareText = async () => {
    try {
      if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(linkedInAnnouncementText);
      }
      setCopiedShareText(true);
      setTimeout(() => setCopiedShareText(false), 2500);
    } catch {
      setCopiedShareText(true);
      setTimeout(() => setCopiedShareText(false), 2500);
    }
  };

  const handleShareLinkedIn = () => {
    try {
      window.open(linkedInShareUrl, '_blank', 'noopener,noreferrer');
    } catch {
      handleCopyShareText();
    }
    try {
      confetti({
        particleCount: 40,
        spread: 60,
        origin: { y: 0.6 }
      });
    } catch {
      // ignore
    }
  };

  const handleAutofillStarterRepo = () => {
    const username = String(user?.name || user?.email?.split('@')[0] || 'intern').toLowerCase().replace(/[^a-z0-9]/g, '');
    const slug = activeInternship?.domainSlug || activeInternship?.domainId || 'foundation';
    setRepoUrl(`https://github.com/${username}/virintern-${slug}`);
    if (!notes) {
      setNotes(`Completed Task 1 environment setup and core architecture scaffolding for ${activeInternship?.domainName || 'internship'}. Verified official offer letter and community onboarding.`);
    }
  };

  if (!user) {
    return (
      <div className="max-w-md mx-auto my-20 p-8 bg-white rounded-2xl border border-slate-200 text-center shadow-lg">
        <h2 className="text-xl font-bold text-slate-900 mb-2">Access Your Internship</h2>
        <p className="text-xs text-slate-600 mb-6">Please log in to track your tasks and submit projects.</p>
        <button
          onClick={() => setCurrentView('landing')}
          className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs rounded-xl"
        >
          Return Home
        </button>
      </div>
    );
  }

  const resolvedUserName = (user?.name && user.name.trim().toLowerCase() !== 'student' && user.name.trim().toLowerCase() !== 'intern')
    ? user.name
    : (typeof window !== 'undefined'
        ? (localStorage.getItem(`virintern_user_name_${(user?.email || '').toLowerCase()}`) ||
           (user?.uid ? localStorage.getItem(`virintern_user_name_${user.uid}`) : null) ||
           localStorage.getItem('virintern_last_signup_name') ||
           user?.name)
        : user?.name) || (user?.email ? user.email.split('@')[0] : 'Student');

  // Calculate days remaining
  const startDate = new Date(activeInternship.startDate);
  const endDate = new Date(activeInternship.endDate);
  const now = new Date();
  const diffTime = endDate.getTime() - now.getTime();
  const daysRemaining = Math.max(0, Math.ceil(diffTime / (1000 * 60 * 60 * 24)));

  const defaultFallbackTask: ProjectTask = {
    id: `${activeInternship.domainId}-task-${selectedTaskNumber}`,
    domainId: activeInternship.domainId,
    taskNumber: selectedTaskNumber as any,
    title: `Task ${selectedTaskNumber}: Foundation Project Track`,
    objective: 'Complete your assigned technical milestone.',
    description: `${activeInternship.domainName} Virtual Internship Track`,
    difficulty: 'Beginner',
    instructions: ['Follow the project roadmap guidelines provided.'],
    expectedOutput: 'Functional project submission with source repository link.',
    submissionType: selectedTaskNumber === 1 ? 'document_or_link' : 'github_and_demo',
    resources: [],
    isActive: true,
    createdAt: new Date().toISOString()
  };

  const currentTask: ProjectTask = tasks.find(t => t.taskNumber === selectedTaskNumber) || tasks[0] || defaultFallbackTask;
  const currentSubmission = submissions.find(s =>
    s.userId === user.uid &&
    s.taskNumber === selectedTaskNumber &&
    Boolean(s.domainId || s.domainName) &&
    isSameDomain(s.domainId, activeInternship.domainId, s.domainName, activeInternship.domainName)
  );
  const matchingEvaluation = evaluations.find(e =>
    e.userId === user.uid &&
    (e.taskId === currentTask.id || (e as any).taskNumber === selectedTaskNumber || (currentSubmission && e.submissionId === currentSubmission.id))
  );

  // Helper to fetch submission for any task in current domain
  const getSubmissionForTask = (taskNum: number): TaskSubmission | undefined => {
    return submissions.find(s =>
      s.userId === user.uid &&
      s.taskNumber === taskNum &&
      Boolean(s.domainId || s.domainName) &&
      isSameDomain(s.domainId, activeInternship.domainId, s.domainName, activeInternship.domainName)
    );
  };

  // Whether a task is currently submitted and kept under review by admin
  const isTaskUnderReview = (taskNum: number): boolean => {
    if (isTaskCompleted(taskNum)) return false;
    const sub = getSubmissionForTask(taskNum);
    if (!sub) return false;
    return sub.status === 'submitted' || sub.status === 'under_review' || sub.status === 'pending_review' || sub.status === 'revision_required';
  };

  // Real-time task completion status: Strictly requires admin manual verification of student submission
  const isTaskCompleted = (taskNum: number): boolean => {
    const sub = getSubmissionForTask(taskNum);
    if (sub && (sub.status === 'approved' || (sub.status === 'passed' && sub.isManuallyVerified === true))) {
      return true;
    }
    return false;
  };

  // Strict weekly sequential milestone unlocking:
  // Task 1: Unlocked by default for all domains (Offer Letter, YouTube & LinkedIn Verification)
  // Tasks 2 through 5: CANNOT be shown or accessed until previous task is verified by admin and marks are assigned!
  const isTaskUnlocked = (taskNum: number): boolean => {
    if (taskNum === 1) return true;
    return isTaskCompleted(taskNum - 1);
  };

  const completedCount = [1, 2, 3, 4, 5].filter(num => isTaskCompleted(num)).length;
  const verifiedProgress = completedCount * 20;
  const hasPendingReview = [1, 2, 3, 4, 5].some(num => isTaskUnderReview(num));
  const currentProgress = verifiedProgress + (hasPendingReview ? Math.min(10, 100 - verifiedProgress) : 0);
  const activeTaskNum = [1, 2, 3, 4, 5].find(num => !isTaskCompleted(num)) || 5;

  // Mobile Back-Swipe Interceptor: Close open modals / return to project guide before exiting
  useEffect(() => {
    const handleDashboardPopState = (e: PopStateEvent) => {
      // 1. If offer letter modal is open, close it on swipe-back!
      if (isOfferLetterModalOpen) {
        setIsOfferLetterModalOpen(false);
        e.stopImmediatePropagation();
        try { window.history.pushState({ view: 'dashboard' }, '', window.location.href); } catch {}
        return;
      }

      // 2. If student evaluation modal is open, close it!
      if (evalModalOpen) {
        setEvalModalOpen(false);
        e.stopImmediatePropagation();
        try { window.history.pushState({ view: 'dashboard' }, '', window.location.href); } catch {}
        return;
      }

      // 3. If photo upload modal is open, close it!
      if (photoModalOpen) {
        setPhotoModalOpen(false);
        e.stopImmediatePropagation();
        try { window.history.pushState({ view: 'dashboard' }, '', window.location.href); } catch {}
        return;
      }

      // 4. If mobile task tab is in submission view, switch back to project guide!
      if (mobileTaskTab === 'submission') {
        setMobileTaskTab('guide');
        e.stopImmediatePropagation();
        try { window.history.pushState({ view: 'dashboard' }, '', window.location.href); } catch {}
        return;
      }
    };

    window.addEventListener('popstate', handleDashboardPopState, true);
    return () => window.removeEventListener('popstate', handleDashboardPopState, true);
  }, [isOfferLetterModalOpen, evalModalOpen, photoModalOpen, mobileTaskTab]);

  const handleTaskSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentTask) return;

    if (selectedTaskNumber === 1) {
      return handleTask1Submit(e);
    }

    const normalizeHttpUrl = (raw: string): string => {
      const clean = (raw || '').trim().replace(/^[<"'\s]+|[>"'\s]+$/g, '');
      if (!clean) return '';
      return /^https?:\/\//i.test(clean) ? clean : `https://${clean}`;
    };

    const isValidHttpUrl = (val: string): boolean => {
      try {
        const parsed = new URL(val);
        return (parsed.protocol === 'http:' || parsed.protocol === 'https:') && parsed.hostname.includes('.');
      } catch {
        return false;
      }
    };

    const cleanRepoUrl = normalizeHttpUrl(repoUrl);
    const cleanDemoUrl = normalizeHttpUrl(demoUrl);
    const cleanDriveUrl = normalizeHttpUrl(driveUrl);
    const cleanPdfUrl = normalizeHttpUrl(pdfUrl);

    if (!cleanRepoUrl) {
      setSubmitError('Please provide your GitHub repository or project link (e.g. https://github.com/username/project) before submitting.');
      return;
    }
    if (!isValidHttpUrl(cleanRepoUrl)) {
      setSubmitError('Please enter a valid GitHub repository or project URL (e.g. https://github.com/username/project).');
      return;
    }
    if (cleanDemoUrl && !isValidHttpUrl(cleanDemoUrl)) {
      setSubmitError('The Live Demo URL format looks invalid. Include a full link like https://your-app.vercel.app or leave it blank.');
      return;
    }

    setSubmitting(true);
    setSubmitSuccess(false);
    setSubmitError(null);

    try {
      const files: string[] = [];
      if (cleanDriveUrl) files.push(cleanDriveUrl);
      if (cleanPdfUrl) files.push(cleanPdfUrl);
      if (imageUrl.trim()) files.push(imageUrl.trim());

      const fullContent = [
        textAnswer.trim() ? `Written Answer:\n${textAnswer.trim()}` : '',
        notes.trim() ? `Implementation Notes:\n${notes.trim()}` : ''
      ].filter(Boolean).join('\n\n');

      const subResult = await dataService.submitTask({
        userId: user.uid,
        userEmail: user.email,
        userName: resolvedUserName,
        domainId: activeInternship.domainId,
        domainName: activeInternship.domainName,
        taskNumber: selectedTaskNumber,
        projectId: currentTask.id,
        taskId: currentTask.id,
        projectTitle: currentTask.title,
        repositoryURL: cleanRepoUrl || undefined,
        githubUrl: cleanRepoUrl || undefined,
        demoURL: cleanDemoUrl || undefined,
        projectUrl: cleanDemoUrl || undefined,
        driveURL: cleanDriveUrl || undefined,
        pdfUrl: cleanPdfUrl || undefined,
        fileUrls: files.length > 0 ? files : undefined,
        content: fullContent || undefined,
        notes: notes.trim() || undefined,
        level: currentTask.difficulty as any,
        submissionType: currentTask.submissionType || 'all'
      }, currentTask);

      if (subResult.evaluation) {
        setActiveEvaluation(subResult.evaluation);
        setEvalModalOpen(true);
      }

      if (subResult?.submission) {
        setSubmissions(prev => {
          const rest = prev.filter(s => !(isSameDomain(s.domainId, activeInternship.domainId, s.domainName, activeInternship.domainName) && s.taskNumber === selectedTaskNumber));
          return [subResult.submission, ...rest];
        });
      }

      setSubmitSuccess(true);
      if (subResult.evaluation?.status === 'passed') {
        try {
          confetti({
            particleCount: 80,
            spread: 70,
            origin: { y: 0.6 }
          });
        } catch {
          // ignore
        }
      }
      await refreshProfile();

      // Refresh domain leaderboard immediately
      const updatedLeaderboard = await dataService.getDomainLeaderboard(activeInternship.domainId, user.uid);
      setDomainLeaderboard(updatedLeaderboard);
    } catch (err: any) {
      setSubmitError(err?.message || 'Failed to submit task deliverables. Please check your connection and try again.');
    } finally {
      setSubmitting(false);
    }
  };

  const currentUserLeaderboardEntry = domainLeaderboard.find(
    e => e.isCurrentUser || e.userId === user?.uid
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8 space-y-6 sm:space-y-8">
      {/* 1. Sleek, Compact Dashboard Top Bar with High-Fidelity Progress Card */}
      <div className="bg-white rounded-2xl border border-[#E0DFDC] p-4 sm:p-5 shadow-xs">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-5">
          {/* User & Domain info */}
          <div className="flex items-center gap-3.5">
            <div className="relative group shrink-0">
              {user.photoURL ? (
                <img
                  src={user.photoURL}
                  alt={resolvedUserName}
                  className="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl border border-[#EBF4FD] object-cover shadow-2xs"
                />
              ) : (
                <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl border border-dashed border-[#CED0D4] bg-[#F4F2EE] flex items-center justify-center text-[#666666]">
                  <User className="w-6 h-6 sm:w-7 sm:h-7 text-[#8C9AA7]" />
                </div>
              )}
              <button
                type="button"
                onClick={() => setPhotoModalOpen(true)}
                title="Change photo"
                className="absolute -bottom-1 -right-1 w-5 h-5 sm:w-6 sm:h-6 rounded-full bg-[#0A66C2] hover:bg-[#004182] text-white flex items-center justify-center shadow-xs cursor-pointer"
              >
                <Camera className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
              </button>
            </div>

            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h1 className="text-base sm:text-lg font-bold text-[#191919]">{resolvedUserName}</h1>
                <span className="px-2 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wider bg-[#EBF4FD] text-[#0A66C2] border border-[#0A66C2]/30">
                  Intern
                </span>
                <span className="px-2 py-0.5 rounded-md text-[10px] font-semibold bg-emerald-50 text-[#057642] border border-emerald-200 flex items-center gap-1">
                  <Clock className="w-3 h-3" />
                  <span>{daysRemaining} Days Left</span>
                </span>
              </div>
              <div className="flex flex-wrap items-center gap-2 mt-1 text-xs text-[#666666]">
                <span className="font-bold text-[#0A66C2]">{activeInternship.domainName} Virtual Internship</span>
                <span className="hidden sm:inline text-slate-300">•</span>
                <span className="text-[11px] text-slate-500">1-Month Structured Virtual Program</span>
                <button
                  type="button"
                  onClick={() => setProjectGuideModalOpen(true)}
                  className="inline-flex items-center gap-1 px-2.5 py-0.5 text-[10px] font-bold text-[#057642] hover:text-[#046237] bg-emerald-50 hover:bg-emerald-100 rounded-md border border-emerald-200 transition-colors cursor-pointer shadow-2xs"
                  title="View and download full project tasks and zero-cost guide as PDF"
                >
                  <BookOpen className="w-2.5 h-2.5 text-[#057642]" />
                  <span>Tasks Guide (PDF)</span>
                </button>
                <button
                  type="button"
                  onClick={openOfferLetterModal}
                  className="inline-flex items-center gap-1 px-2.5 py-0.5 text-[10px] font-bold text-[#0A66C2] hover:text-[#004182] bg-[#EBF4FD] hover:bg-[#D9EAF9] rounded-md border border-[#0A66C2]/30 transition-colors cursor-pointer shadow-2xs"
                  title="View and download your official internship offer letter"
                >
                  <FileText className="w-2.5 h-2.5 text-[#0A66C2]" />
                  <span>Official Offer Letter</span>
                </button>
              </div>
            </div>
          </div>

          {/* Attractive High-Fidelity Progress Bar Card */}
          <div className="w-full lg:w-auto lg:min-w-[420px] bg-gradient-to-br from-slate-50 via-white to-blue-50/50 p-4 rounded-2xl border border-slate-200/90 shadow-2xs">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded-lg bg-blue-100 text-[#0A66C2] flex items-center justify-center">
                  <Sparkles className="w-3.5 h-3.5" />
                </div>
                <div>
                  <span className="text-xs font-extrabold text-slate-900 block leading-tight">Internship Progress</span>
                  <span className="text-[10px] text-slate-500">
                    {completedCount === 5 ? 'All milestones achieved! 🎓' : `Milestone ${activeTaskNum} of 5 in progress`}
                  </span>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <span className={`px-3 py-1 rounded-full text-xs font-black shadow-2xs transition-all ${
                  currentProgress === 100
                    ? 'bg-emerald-600 text-white shadow-emerald-200'
                    : 'bg-gradient-to-r from-[#0A66C2] to-indigo-600 text-white'
                }`}>
                  {currentProgress}% Completed
                </span>
              </div>
            </div>

            {/* Glowing High-Fidelity Multi-Gradient Progress Track with Step Checkpoints */}
            <div className="relative pt-1 pb-1">
              <div className="relative w-full bg-slate-200/90 h-3.5 rounded-full overflow-hidden shadow-inner">
                <div
                  className="bg-gradient-to-r from-[#0A66C2] via-indigo-600 to-emerald-500 h-full rounded-full transition-all duration-700 ease-out relative shadow-[0_2px_10px_rgba(10,102,194,0.3)]"
                  style={{ width: `${Math.max(currentProgress === 0 ? 5 : currentProgress, 5)}%` }}
                >
                  <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/35 to-transparent animate-pulse" />
                </div>
              </div>

              {/* Interactive Milestone Step Nodes on Track */}
              <div className="absolute inset-x-0 top-1/2 -translate-y-1/2 flex justify-between px-1 pointer-events-none">
                {[1, 2, 3, 4, 5].map((step) => {
                  const pct = step * 20;
                  const isDone = isTaskCompleted(step);
                  const isActive = step === activeTaskNum;
                  return (
                    <button
                      key={`checkpoint-step-${step}`}
                      type="button"
                      onClick={() => isTaskUnlocked(step) && setSelectedTaskNumber(step)}
                      disabled={!isTaskUnlocked(step)}
                      title={`Task ${step}: ${pct}% completion`}
                      className={`pointer-events-auto w-5 h-5 rounded-full flex items-center justify-center text-[9px] font-black transition-all ${
                        isDone
                          ? 'bg-emerald-600 text-white shadow-xs scale-105'
                          : isActive
                          ? 'bg-[#0A66C2] text-white ring-4 ring-blue-300/60 scale-110 shadow-xs'
                          : 'bg-white text-slate-400 border border-slate-300'
                      }`}
                    >
                      {isDone ? (
                        <Check className="w-3 h-3 text-white stroke-[3]" />
                      ) : (
                        <span>{step}</span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Checkpoint milestone labels */}
            <div className="flex justify-between items-center text-[10px] font-bold text-slate-500 mt-2 px-0.5">
              <span className={currentProgress >= 20 ? 'text-[#057642]' : 'text-slate-500'}>
                <span className="sm:hidden">T1 (20%)</span>
                <span className="hidden sm:inline">Onboarding (20%)</span>
              </span>
              <span className={currentProgress >= 40 ? 'text-[#057642]' : 'text-slate-500'}>
                <span className="sm:hidden">T2 (40%)</span>
                <span className="hidden sm:inline">Foundation (40%)</span>
              </span>
              <span className={currentProgress >= 60 ? 'text-[#057642]' : 'text-slate-500'}>
                <span className="sm:hidden">T3 (60%)</span>
                <span className="hidden sm:inline">Core Dev (60%)</span>
              </span>
              <span className={currentProgress >= 80 ? 'text-[#057642]' : 'text-slate-500'}>
                <span className="sm:hidden">T4 (80%)</span>
                <span className="hidden sm:inline">Testing (80%)</span>
              </span>
              <span className={currentProgress === 100 ? 'text-[#057642] font-black' : 'text-slate-500'}>
                <span className="sm:hidden">T5 (100% 🎓)</span>
                <span className="hidden sm:inline">Capstone 🎓 (100%)</span>
              </span>
            </div>

            {currentProgress === 100 && (
              <button
                type="button"
                onClick={() => setCurrentView('completion')}
                className="mt-3 w-full py-2.5 bg-gradient-to-r from-[#057642] to-emerald-600 hover:from-[#046237] hover:to-emerald-700 text-white font-bold text-xs rounded-xl shadow-md transition-all flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Award className="w-4 h-4" />
                <span>Claim Official Completion Certificate & Recommendation</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* 2. Four-Level Difficulty Progression Cards (Master Prompt Section 6) */}
      <div className="bg-white rounded-2xl border border-[#E0DFDC] p-4 sm:p-5 shadow-xs space-y-3.5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
          <div>
            <span className="text-xs font-bold text-[#191919] uppercase tracking-wider flex items-center gap-1.5">
              <Layers className="w-4 h-4 text-[#0A66C2]" />
              <span>Internship Progression & Level Milestones</span>
            </span>
            <p className="text-[11px] text-slate-500 mt-0.5">
              Four sequential competency levels + Final Capstone project in {activeInternship.domainName}
            </p>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-[11px] font-semibold text-[#0A66C2] bg-blue-50 px-2.5 py-1 rounded-full border border-blue-100">
              Active: Task {selectedTaskNumber} ({isTaskCompleted(selectedTaskNumber) ? 'Approved' : 'In Progress'})
            </span>
          </div>
        </div>

        {/* 4 Difficulty Level Cards: Easy → Intermediate → Hard → Advanced + Capstone */}
        <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
          {[
            { levelNum: 1, name: 'Week 1: Level 1', sub: 'Onboarding & Verification', taskNum: 1, req: 1 },
            { levelNum: 2, name: 'Week 2: Level 2', sub: 'Core Architecture', taskNum: 2, req: 1 },
            { levelNum: 3, name: 'Week 3: Level 3', sub: 'Dynamic Integrations', taskNum: 3, req: 1 },
            { levelNum: 4, name: 'Week 4: Level 4', sub: 'Security & Testing', taskNum: 4, req: 1 },
            { levelNum: 5, name: 'Week 5: Capstone', sub: 'Production Cloud Release', taskNum: 5, req: 1 }
          ].map((lvl) => {
            const isDone = isTaskCompleted(lvl.taskNum);
            const isUnderReview = isTaskUnderReview(lvl.taskNum);
            const isUnlocked = isTaskUnlocked(lvl.taskNum);
            const isSelected = selectedTaskNumber === lvl.taskNum;
            const taskObj = tasks.find(t => t.taskNumber === lvl.taskNum);
            const subRecord = getSubmissionForTask(lvl.taskNum);

            return (
              <div
                key={`milestone-level-${lvl.levelNum}`}
                onClick={() => setSelectedTaskNumber(lvl.taskNum)}
                className={`p-3 rounded-xl border transition-all cursor-pointer flex flex-col justify-between gap-2 ${
                  isSelected
                    ? 'border-[#0A66C2] bg-[#EBF4FD] ring-2 ring-[#0A66C2]/20 shadow-xs'
                    : isDone
                    ? 'border-emerald-200 bg-emerald-50/40 hover:border-emerald-400'
                    : isUnderReview
                    ? 'border-amber-300 bg-amber-50/50 hover:border-amber-400'
                    : isUnlocked
                    ? 'border-[#0A66C2]/40 bg-blue-50/30 hover:border-[#0A66C2]'
                    : 'border-slate-200 bg-slate-50/80 opacity-75 hover:opacity-100 hover:border-slate-300'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between gap-1 mb-1">
                    <span className="text-[10px] font-extrabold text-[#0A66C2] uppercase tracking-wider">
                      {lvl.name}
                    </span>
                    {isDone ? (
                      <span className="text-[9px] px-1.5 py-0.5 bg-emerald-100 text-emerald-800 font-extrabold rounded-full flex items-center gap-0.5" title={`Verified by Admin • Score: ${subRecord?.rubricScore || 90}/100`}>
                        <Check className="w-2.5 h-2.5" />
                        <span>{subRecord?.rubricScore ? `${subRecord.rubricScore} Marks` : 'Approved'}</span>
                      </span>
                    ) : isUnderReview ? (
                      <span className="text-[9px] px-1.5 py-0.5 bg-amber-100 text-amber-900 font-extrabold rounded-full flex items-center gap-0.5" title="Under Admin Review: Awaiting Manual Verification & Marks">
                        <Clock className="w-2.5 h-2.5 text-amber-700 animate-pulse" />
                        <span>Review Pending</span>
                      </span>
                    ) : isUnlocked ? (
                      <span className="text-[9px] px-1.5 py-0.5 bg-blue-100 text-[#0A66C2] font-bold rounded-full">
                        Ready
                      </span>
                    ) : (
                      <span className="text-[9px] px-1.5 py-0.5 bg-slate-200 text-slate-600 font-semibold rounded-full flex items-center gap-0.5" title={`Locked until Task ${lvl.taskNum - 1} is verified by admin`}>
                        <Lock className="w-2.5 h-2.5" />
                        <span>Locked</span>
                      </span>
                    )}
                  </div>
                  <h4 className="text-xs font-bold text-slate-800 line-clamp-1">{lvl.sub}</h4>
                  <p className="text-[10px] text-slate-500 line-clamp-1 mt-0.5">
                    {taskObj?.title ? String(taskObj.title).replace(/^Task \d+:\s*/, '') : `Milestone ${lvl.taskNum}`}
                  </p>
                </div>

                <div className="space-y-1 pt-1 border-t border-slate-100">
                  <div className="flex items-center justify-between text-[10px] text-slate-500">
                    <span>{isDone ? 'Approved:' : isUnderReview ? 'Review Status:' : isUnlocked ? 'Status:' : 'Unlocks after:'}</span>
                    <span className="font-bold text-slate-700">
                      {isDone ? `${subRecord?.rubricScore || 90}/100 Marks` : isUnderReview ? 'Review Pending ⏳' : isUnlocked ? 'Ready to Work' : `Task ${lvl.taskNum - 1}`}
                    </span>
                  </div>
                  <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden">
                    <div
                      className={`h-full transition-all duration-500 ${isDone ? 'bg-emerald-500' : isUnderReview ? 'bg-amber-500' : isUnlocked ? 'bg-[#0A66C2]' : 'bg-slate-300'}`}
                      style={{ width: isDone ? '100%' : isUnderReview ? '70%' : isUnlocked ? '30%' : '0%' }}
                    />
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* 5-Milestone Quick Nav Buttons (Weekly progression with Lock indicator) */}
        <div className="flex sm:grid sm:grid-cols-5 gap-2 overflow-x-auto pb-1 scrollbar-none snap-x pt-1">
          {[1, 2, 3, 4, 5].map((num) => {
            const isDone = isTaskCompleted(num);
            const isUnderReview = isTaskUnderReview(num);
            const isUnlocked = isTaskUnlocked(num);
            const isSelected = selectedTaskNumber === num;
            const taskObj = tasks.find(t => t.taskNumber === num);
            const shortTitle = num === 1
              ? 'Offer Letter & Verification'
              : taskObj?.title ? String(taskObj.title).replace(/^Task \d+:\s*/, '') : `Milestone ${num}`;

            return (
              <button
                key={`nav-task-btn-${num}`}
                type="button"
                onClick={() => setSelectedTaskNumber(num)}
                className={`min-w-[150px] sm:min-w-0 snap-start p-2.5 rounded-xl border text-left transition-all flex items-center justify-between gap-2 cursor-pointer ${
                  isSelected
                    ? 'border-[#0A66C2] bg-[#EBF4FD] text-[#0A66C2] font-bold shadow-xs'
                    : isDone
                    ? 'border-emerald-200 bg-white hover:border-emerald-400 text-slate-800'
                    : isUnderReview
                    ? 'border-amber-300 bg-amber-50/60 hover:border-amber-400 text-amber-950'
                    : isUnlocked
                    ? 'border-slate-200 bg-white hover:border-[#0A66C2] text-slate-700'
                    : 'border-slate-200 bg-slate-50/70 opacity-75 hover:opacity-100 text-slate-500'
                }`}
              >
                <div className="truncate">
                  <div className="text-[10px] font-extrabold uppercase tracking-wider text-slate-500 flex items-center gap-1.5 flex-wrap">
                    <span>Task {num} (Week {num})</span>
                    {!isUnlocked && <Lock className="w-2.5 h-2.5 text-slate-400" />}
                    {isUnderReview && (
                      <span className="text-[9px] bg-amber-200 text-amber-950 font-black px-1.5 py-0.5 rounded-full inline-flex items-center gap-0.5">
                        <Clock className="w-2 h-2 text-amber-700 animate-pulse" />
                        <span>Review Pending</span>
                      </span>
                    )}
                    {isDone && (
                      <span className="text-[9px] bg-emerald-100 text-emerald-800 font-black px-1.5 py-0.5 rounded-full inline-flex items-center gap-0.5">
                        <Check className="w-2 h-2 text-emerald-700" />
                        <span>Approved</span>
                      </span>
                    )}
                  </div>
                  <div className="text-xs truncate">{shortTitle}</div>
                </div>
                {isDone ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                ) : isUnderReview ? (
                  <Clock className="w-4 h-4 text-amber-600 shrink-0" />
                ) : isUnlocked ? (
                  <ChevronRight className="w-4 h-4 text-[#0A66C2] shrink-0" />
                ) : (
                  <Lock className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Domain Performance & Cohort Leaderboard Banner */}
      <div className="bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 text-white rounded-2xl p-5 sm:p-6 shadow-md border border-blue-800">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-5">
          <div className="space-y-1.5 max-w-xl">
            <div className="flex flex-wrap items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-amber-400 text-amber-950 flex items-center gap-1 shadow-2xs">
                <Trophy className="w-3 h-3 text-amber-950" />
                <span>Domain Cohort Leaderboard</span>
              </span>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-white/15 text-blue-200 border border-white/10 flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-amber-300" />
                <span>Mentor Reviewed & Scored</span>
              </span>
            </div>
            <h2 className="text-lg sm:text-xl font-black text-white flex items-center gap-2">
              <span>{activeInternship.domainName} Leaderboard</span>
            </h2>
            <p className="text-xs text-blue-200 leading-relaxed">
              Every milestone task you submit is thoroughly reviewed and verified manually by senior industry mentors according to rigorous engineering standards. Compete with cohort peers across code architecture, deliverable completeness, and implementation quality.
            </p>
          </div>

          {/* User Performance Badges & Quick Rank */}
          <div className="flex flex-wrap sm:flex-nowrap items-center gap-3">
            <div className="px-4 py-2.5 bg-white/10 rounded-xl border border-white/15 backdrop-blur-xs text-center shrink-0">
              <span className="text-[10px] font-bold text-blue-200 uppercase tracking-wider block">Your Rank</span>
              <span className="text-xl font-black text-amber-300">
                {currentUserLeaderboardEntry ? `#${currentUserLeaderboardEntry.rank}` : '--'}
              </span>
              <span className="text-[10px] text-blue-200 block">
                {domainLeaderboard.length > 0 ? `in ${domainLeaderboard.length} Intern${domainLeaderboard.length === 1 ? '' : 's'}` : 'Live Cohort'}
              </span>
            </div>

            <div className="px-4 py-2.5 bg-white/10 rounded-xl border border-white/15 backdrop-blur-xs text-center shrink-0">
              <span className="text-[10px] font-bold text-blue-200 uppercase tracking-wider block">Mentor Score</span>
              <span className="text-xl font-black text-emerald-300">
                {currentUserLeaderboardEntry && currentUserLeaderboardEntry.averageScore > 0 ? `${currentUserLeaderboardEntry.averageScore}%` : 'Pending'}
              </span>
              <span className="text-[10px] text-blue-200 block">Milestone Average</span>
            </div>

            <div className="px-4 py-2.5 bg-white/10 rounded-xl border border-white/15 backdrop-blur-xs text-center shrink-0">
              <span className="text-[10px] font-bold text-blue-200 uppercase tracking-wider block">Total Points</span>
              <span className="text-xl font-black text-white">
                {currentUserLeaderboardEntry?.totalScore || 0}
              </span>
              <span className="text-[10px] text-blue-200 block">pts scored</span>
            </div>

            <button
              type="button"
              onClick={() => setCurrentView('leaderboard')}
              className="w-full sm:w-auto px-4 py-3 bg-amber-400 hover:bg-amber-300 text-amber-950 font-black text-xs rounded-xl shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer shrink-0 active:scale-95"
            >
              <Trophy className="w-4 h-4 text-amber-950" />
              <span>Full Domain Leaderboard →</span>
            </button>
          </div>
        </div>

        {/* Mini Preview of Top 3 in Current Domain */}
        {domainLeaderboard.length > 0 && (
          <div className="mt-4 pt-4 border-t border-white/10 grid grid-cols-1 sm:grid-cols-3 gap-2.5">
            {domainLeaderboard.slice(0, 3).map((entry, idx) => (
              <div
                key={`mini-lead-${entry.userId}`}
                className={`p-2.5 rounded-xl border flex items-center justify-between gap-2 text-xs ${
                  entry.isCurrentUser
                    ? 'bg-amber-400/20 border-amber-300/40 text-amber-200'
                    : 'bg-white/5 border-white/10 text-blue-100'
                }`}
              >
                <div className="flex items-center gap-2 truncate">
                  <span className={`w-5 h-5 rounded-full flex items-center justify-center font-black text-[10px] shrink-0 ${
                    idx === 0 ? 'bg-amber-400 text-amber-950' : idx === 1 ? 'bg-slate-300 text-slate-900' : 'bg-amber-700 text-white'
                  }`}>
                    {idx + 1}
                  </span>
                  <span className="font-bold truncate text-white">
                    {entry.userName} {entry.isCurrentUser ? '(You)' : ''}
                  </span>
                </div>
                <div className="text-right shrink-0">
                  <span className="font-extrabold text-amber-300 text-xs">{entry.totalScore} pts</span>
                  <span className="text-[10px] text-blue-300 block">{entry.averageScore}% avg</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Active Task Details & Submission Panel */}
      {currentTask && (
        <div id="task-workspace" className="scroll-mt-6 space-y-6">
          {/* Prominent LinkedIn-Themed Task Status Bar (Review Pending vs Approved) */}
          <TaskStatusBar
            taskNumber={selectedTaskNumber}
            totalTasks={5}
            currentSubmission={currentSubmission}
            isUnderReview={isTaskUnderReview(selectedTaskNumber)}
            isApproved={isTaskCompleted(selectedTaskNumber)}
            isUnlocked={isTaskUnlocked(selectedTaskNumber)}
            onProceedToNextTask={() => setSelectedTaskNumber(Math.min(5, selectedTaskNumber + 1))}
            onViewPreviousTask={() => setSelectedTaskNumber(Math.max(1, selectedTaskNumber - 1))}
            onViewCertificate={() => setCurrentView('completion')}
          />

          {selectedTaskNumber === 1 ? (
            /* Task 1: Dedicated Onboarding & Verification Workspace (Immediate, No scrolling down required) */
            <div className="space-y-6">
              {/* Task 1 Workspace Card */}
              <div className="bg-white rounded-2xl border border-[#E0DFDC] p-5 sm:p-8 shadow-xs space-y-6">
                {/* Header */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-[#E0DFDC] gap-3">
                  <div>
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="px-2.5 py-1 bg-[#EBF4FD] text-[#0A66C2] text-xs font-bold rounded-full border border-[#0A66C2]/20">
                        Task 1 of 5
                      </span>
                      <span className="px-2.5 py-1 bg-emerald-50 text-emerald-700 text-xs font-bold rounded-full border border-emerald-200">
                        Official Onboarding & Verification
                      </span>
                    </div>
                    <h2 className="text-xl sm:text-2xl font-extrabold text-[#191919] mt-2 tracking-tight">
                      Offer Letter & Community Verification
                    </h2>
                    <p className="text-xs sm:text-sm text-[#666666] mt-1 leading-relaxed">
                      Welcome to your <strong>{activeInternship.domainName}</strong> Virtual Internship! Complete the 3 genuine verification steps below to unlock your Task 2 Domain Project.
                    </p>
                  </div>
                  <div className="sm:text-right shrink-0">
                    <span className="text-[10px] font-bold text-[#666666] uppercase tracking-wider block">Requirements</span>
                    <span className="text-xs font-extrabold text-[#0A66C2] bg-[#EBF4FD] px-2.5 py-1 rounded-full border border-[#0A66C2]/30 inline-block mt-0.5">
                      3 Mandatory Verifications
                    </span>
                  </div>
                </div>

                {/* Task 1 Step-by-Step Micro Progress Indicator */}
                {(() => {
                  const hasOfferLetter = Boolean(hasViewedOfferLetter || currentSubmission?.offerLetterUrl);
                  const hasYouTube = Boolean(userYoutubeHandle.trim() && youtubeScreenshotUrl.trim());
                  const hasLinkedIn = Boolean(socialProofUrl.trim() && isValidLinkedInPostUrl(socialProofUrl));
                  const task1StepsComplete = (hasOfferLetter ? 1 : 0) + (hasYouTube ? 1 : 0) + (hasLinkedIn ? 1 : 0);

                  return (
                    <div className="bg-gradient-to-r from-blue-50 via-indigo-50/50 to-emerald-50/60 p-4 rounded-2xl border border-blue-200/80 shadow-2xs">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-2">
                        <div className="flex items-center gap-2">
                          <Sparkles className="w-4 h-4 text-[#0A66C2]" />
                          <span className="text-xs font-bold text-slate-900">Task 1 Deliverable Progress</span>
                          <span className="text-[11px] font-semibold text-slate-500">
                            ({task1StepsComplete} of 3 Steps Ready)
                          </span>
                        </div>
                        <span className={`text-[11px] font-extrabold px-2.5 py-0.5 rounded-full border self-start sm:self-auto ${
                          task1StepsComplete === 3
                            ? 'bg-emerald-100 text-emerald-800 border-emerald-300'
                            : task1StepsComplete > 0
                            ? 'bg-blue-100 text-[#0A66C2] border-blue-300'
                            : 'bg-slate-100 text-slate-700 border-slate-300'
                        }`}>
                          {Math.round((task1StepsComplete / 3) * 100)}% Ready for Mentor Review
                        </span>
                      </div>

                      {/* 3-Segment Progress Track */}
                      <div className="grid grid-cols-3 gap-2">
                        <div className={`h-2 rounded-full transition-all duration-500 ${
                          hasOfferLetter ? 'bg-emerald-500 shadow-xs' : 'bg-slate-200'
                        }`} title="Step 1: Offer Letter (Review Required)" />
                        <div className={`h-2 rounded-full transition-all duration-500 ${
                          hasYouTube ? 'bg-emerald-500 shadow-xs' : 'bg-slate-200'
                        }`} title="Step 2: YouTube Channel Handle & Screenshot" />
                        <div className={`h-2 rounded-full transition-all duration-500 ${
                          hasLinkedIn ? 'bg-emerald-500 shadow-xs' : 'bg-slate-200'
                        }`} title="Step 3: LinkedIn Post Link" />
                      </div>

                      <div className="grid grid-cols-3 gap-2 text-[10px] font-semibold text-slate-600 mt-2">
                        <span className={`flex items-center gap-1 truncate ${hasOfferLetter ? 'text-emerald-700 font-bold' : 'text-slate-500'}`}>
                          {hasOfferLetter ? <CheckCircle2 className="w-3 h-3 text-emerald-600 shrink-0" /> : <Clock className="w-3 h-3 text-amber-500 shrink-0" />}
                          <span className="truncate">1. Offer Letter</span>
                        </span>
                        <span className={`flex items-center gap-1 truncate ${hasYouTube ? 'text-emerald-700 font-bold' : 'text-slate-500'}`}>
                          {hasYouTube ? <CheckCircle2 className="w-3 h-3 text-emerald-600 shrink-0" /> : <Clock className="w-3 h-3 text-amber-500 shrink-0" />}
                          <span className="truncate">2. YouTube Handle & Proof</span>
                        </span>
                        <span className={`flex items-center gap-1 truncate ${hasLinkedIn ? 'text-emerald-700 font-bold' : 'text-slate-500'}`}>
                          {hasLinkedIn ? <CheckCircle2 className="w-3 h-3 text-emerald-600 shrink-0" /> : <Clock className="w-3 h-3 text-amber-500 shrink-0" />}
                          <span className="truncate">3. LinkedIn Post</span>
                        </span>
                      </div>
                    </div>
                  );
                })()}

                {/* The 3 Verification Milestones */}
                <div className="space-y-4">
                  {/* Milestone 1: Official Internship Offer Letter */}
                  <div className="p-4 sm:p-5 bg-slate-50/90 rounded-2xl border border-slate-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-2xs">
                    <div className="flex items-center gap-3.5">
                      <div className="w-11 h-11 rounded-xl bg-blue-100 text-[#0A66C2] flex items-center justify-center shrink-0 shadow-2xs">
                        <FileCheck className="w-6 h-6 text-[#0A66C2]" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs sm:text-sm font-bold text-slate-900">1. Official Internship Offer Letter</span>
                          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border flex items-center gap-1 ${
                            hasViewedOfferLetter || Boolean(currentSubmission?.offerLetterUrl)
                              ? 'bg-emerald-100 text-emerald-800 border-emerald-200'
                              : 'bg-amber-100 text-amber-800 border-amber-200'
                          }`}>
                            {hasViewedOfferLetter || Boolean(currentSubmission?.offerLetterUrl) ? (
                              <>
                                <CheckCircle2 className="w-2.5 h-2.5 text-emerald-700" />
                                <span>Reviewed & Ready</span>
                              </>
                            ) : (
                              <>
                                <Clock className="w-2.5 h-2.5 text-amber-700" />
                                <span>Preview & Verify Required</span>
                              </>
                            )}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-600 mt-0.5 font-mono truncate max-w-[280px] sm:max-w-md">
                          {offerLetterFileName || `VirIntern_Offer_Letter_${(activeInternship.domainSlug || activeInternship.domainId || 'TECH').toUpperCase()}.pdf`}
                        </p>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={openOfferLetterModal}
                      className="w-full sm:w-auto px-4 py-2 bg-white hover:bg-slate-100 text-[#0A66C2] font-bold text-xs rounded-xl border border-slate-200 transition-colors flex items-center justify-center gap-1.5 shadow-2xs shrink-0 cursor-pointer"
                    >
                      <Eye className="w-4 h-4" />
                      <span>Preview / Download Offer Letter</span>
                    </button>
                  </div>

                  {/* Milestone 2: YouTube Community Channel (@virintern) */}
                  <div className="p-4 sm:p-5 bg-red-50/60 rounded-2xl border border-red-200/90 space-y-4 shadow-2xs">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                      <div className="flex items-start sm:items-center gap-3.5">
                        <div className="w-11 h-11 rounded-xl bg-red-100 text-red-600 flex items-center justify-center shrink-0 shadow-2xs">
                          <Youtube className="w-7 h-7 text-red-600" />
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-xs sm:text-sm font-bold text-slate-900">2. Subscribe to VirIntern YouTube Channel</span>
                            <span className="text-[10px] bg-red-100 text-red-800 font-bold px-2 py-0.5 rounded-full border border-red-200">
                              Mandatory Verification
                            </span>
                          </div>
                          <p className="text-[11px] text-slate-600 mt-0.5 leading-relaxed">
                            Subscribe to our official channel (<span className="text-red-700 font-semibold">@virintern</span>), enter your channel handle, and upload your subscription screenshot for verification.
                          </p>
                        </div>
                      </div>

                      <a
                        href={`${YOUTUBE_CONFIG.channelUrl}?sub_confirmation=1`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="w-full sm:w-auto px-4 py-2.5 bg-red-600 hover:bg-red-700 text-white font-bold text-xs rounded-xl transition-all flex items-center justify-center gap-2 shadow-xs cursor-pointer shrink-0"
                      >
                        <Youtube className="w-4 h-4" />
                        <span>Open & Subscribe to @virintern</span>
                        <ExternalLink className="w-3 h-3 ml-0.5" />
                      </a>
                    </div>

                    {/* YouTube Handle & Screenshot Upload Grid */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-3 border-t border-red-100">
                      <div>
                        <label className="block text-[11px] font-bold text-slate-700 mb-1">
                          Your YouTube Channel Handle: <span className="text-red-500">*</span>
                        </label>
                        <input
                          type="text"
                          value={userYoutubeHandle}
                          onFocus={() => {
                            userEditedYoutubeRef.current = true;
                          }}
                          onChange={(e) => {
                            userEditedYoutubeRef.current = true;
                            setUserYoutubeHandle(e.target.value);
                            setYoutubeVerificationMsg(null);
                            setSubmitError(null);
                          }}
                          placeholder="@yourchannelname"
                          className="w-full text-xs p-3 bg-white border border-slate-300 rounded-xl outline-none transition-colors focus:border-red-500 font-medium"
                        />
                        <span className="text-[10px] text-slate-500 mt-1 block">
                          Enter the handle of the YouTube channel you subscribed with (e.g. @yourhandle).
                        </span>
                      </div>

                      <div>
                        <label className="block text-[11px] font-bold text-slate-700 mb-1">
                          Upload Subscription Proof Screenshot: <span className="text-red-500">*</span>
                        </label>
                        {!youtubeScreenshotUrl ? (
                          <div className="relative border-2 border-dashed border-red-200 hover:border-red-400 bg-white rounded-xl p-3 text-center transition-colors cursor-pointer">
                            <input
                              type="file"
                              accept="image/*"
                              onChange={handleYoutubeScreenshotUpload}
                              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                            />
                            <div className="flex items-center justify-center gap-2 text-xs text-slate-600 font-medium">
                              <Camera className="w-4 h-4 text-red-600" />
                              <span>Click to upload subscribe screenshot</span>
                            </div>
                            <span className="text-[10px] text-slate-400 block mt-0.5">PNG, JPG, WEBP up to 5MB</span>
                          </div>
                        ) : (
                          <div className="flex items-center justify-between p-2 bg-white rounded-xl border border-red-200 shadow-2xs">
                            <div className="flex items-center gap-2.5 overflow-hidden">
                              <img
                                src={youtubeScreenshotUrl}
                                alt="Subscribe Screenshot"
                                className="w-10 h-10 rounded-lg object-cover border border-red-200 shrink-0 cursor-pointer hover:opacity-80"
                                onClick={() => setYoutubeScreenshotPreviewOpen(true)}
                              />
                              <div className="truncate text-left">
                                <p className="text-xs font-bold text-slate-800 truncate">{youtubeScreenshotFileName || 'youtube_subscribe_proof.png'}</p>
                                <span className="text-[10px] text-emerald-600 font-semibold flex items-center gap-1">
                                  <CheckCircle2 className="w-2.5 h-2.5" />
                                  <span>Ready for Admin Review</span>
                                </span>
                              </div>
                            </div>
                            <div className="flex items-center gap-1 shrink-0 ml-2">
                              <button
                                type="button"
                                onClick={() => setYoutubeScreenshotPreviewOpen(true)}
                                className="px-2 py-1 text-[11px] text-[#0A66C2] hover:bg-blue-50 rounded-lg font-semibold"
                              >
                                View
                              </button>
                              <button
                                type="button"
                                onClick={() => {
                                  setYoutubeScreenshotUrl('');
                                  setYoutubeScreenshotFileName('');
                                }}
                                className="p-1 text-slate-400 hover:text-rose-600 rounded-lg"
                                title="Remove screenshot"
                              >
                                <X className="w-4 h-4" />
                              </button>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>

                    {youtubeVerificationMsg && !youtubeVerificationMsg.success && (
                      <p className="text-xs text-rose-600 mt-1 flex items-center gap-1 font-semibold">
                        <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                        <span>{youtubeVerificationMsg.text}</span>
                      </p>
                    )}
                  </div>

                  {/* Milestone 3: Offer Letter LinkedIn Commencement Post */}
                  <div className="p-4 sm:p-5 bg-blue-50/70 rounded-2xl border border-blue-200/90 space-y-3.5 shadow-2xs">
                    <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                      <div className="flex items-start sm:items-center gap-3.5">
                        <div className="w-11 h-11 rounded-xl bg-blue-100 text-[#0A66C2] flex items-center justify-center shrink-0 shadow-2xs">
                          <Globe className="w-6 h-6 text-[#0A66C2]" />
                        </div>
                        <div>
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="text-xs sm:text-sm font-bold text-slate-900">3. Offer Letter Commencement Post (LinkedIn)</span>
                            <span className="text-[10px] bg-blue-100 text-[#0A66C2] font-bold px-2 py-0.5 rounded-full border border-blue-200">
                              Post URL
                            </span>
                          </div>
                          <p className="text-[11px] text-slate-600 mt-0.5 leading-relaxed">
                            Publish your appointment announcement on LinkedIn, then paste your post link below for mentor verification.
                          </p>
                        </div>
                      </div>

                      {/* Action buttons: 1-Click Share & Copy Text */}
                      <div className="flex flex-wrap sm:flex-nowrap items-center gap-2 w-full lg:w-auto">
                        <a
                          href={linkedInShareUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex-1 sm:flex-initial px-4 py-2.5 bg-[#0A66C2] hover:bg-[#004182] text-white font-bold text-xs rounded-xl transition-colors flex items-center justify-center gap-1.5 shadow-xs cursor-pointer min-h-[42px]"
                        >
                          <Globe className="w-3.5 h-3.5" />
                          <span>1-Click Share on LinkedIn</span>
                        </a>

                        <button
                          type="button"
                          onClick={handleCopyShareText}
                          className={`flex-1 sm:flex-initial px-3.5 py-2.5 font-bold text-xs rounded-xl border transition-colors flex items-center justify-center gap-1.5 shrink-0 cursor-pointer min-h-[42px] ${
                            copiedShareText
                              ? 'bg-emerald-50 text-emerald-700 border-emerald-300'
                              : 'bg-white hover:bg-slate-50 text-slate-700 border-slate-300'
                          }`}
                          title="Copy suggested announcement caption to clipboard"
                        >
                          {copiedShareText ? (
                            <>
                              <Check className="w-3.5 h-3.5 text-emerald-600" />
                              <span>Copied Caption!</span>
                            </>
                          ) : (
                            <>
                              <Copy className="w-3.5 h-3.5 text-slate-500" />
                              <span>Copy Suggested Caption</span>
                            </>
                          )}
                        </button>
                      </div>
                    </div>

                    {/* URL Input */}
                    <div className="pt-2 border-t border-blue-100 flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
                      <div className="relative flex-1">
                        <input
                          type="url"
                          value={socialProofUrl}
                          onFocus={() => {
                            userEditedLinkedInRef.current = true;
                          }}
                          onChange={(e) => {
                            userEditedLinkedInRef.current = true;
                            setSocialProofUrl(e.target.value);
                            setLinkedinVerifyError(null);
                            setSubmitError(null);
                          }}
                          placeholder="https://www.linkedin.com/posts/..."
                          className={`w-full text-xs p-3 sm:p-2.5 bg-white border rounded-xl outline-none transition-colors min-h-[44px] sm:min-h-0 ${
                            linkedinVerifyError
                              ? 'border-rose-400 bg-rose-50/20'
                              : socialProofUrl && isValidLinkedInPostUrl(socialProofUrl)
                              ? 'border-emerald-500 bg-emerald-50/20 text-emerald-900'
                              : 'border-slate-300 focus:border-[#0A66C2]'
                          }`}
                        />
                      </div>

                      <button
                        type="button"
                        onClick={handlePasteClipboard}
                        className="px-3.5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl border border-slate-300 transition-colors flex items-center justify-center gap-1.5 shrink-0 cursor-pointer min-h-[44px] sm:min-h-0"
                        title="Paste link from clipboard"
                      >
                        <Copy className="w-3.5 h-3.5" />
                        <span>Paste</span>
                      </button>
                    </div>

                    {/* Supported link helper */}
                    <div className="pt-1 text-[11px] text-slate-500 flex items-center justify-between">
                      <span>Supported: <code className="font-mono bg-blue-50 px-1 py-0.5 rounded text-[#0A66C2]">linkedin.com/posts/...</code> or <code className="font-mono bg-blue-50 px-1 py-0.5 rounded text-[#0A66C2]">lnkd.in/...</code></span>
                      {socialProofUrl && isValidLinkedInPostUrl(socialProofUrl) && (
                        <span className="text-emerald-700 font-bold flex items-center gap-1 text-[10px]">
                          <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                          <span>Valid Link Format</span>
                        </span>
                      )}
                    </div>

                    {linkedinVerifyError && (
                      <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-800 flex items-start gap-2 animate-fadeIn">
                        <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                        <div className="flex-1">
                          <p className="font-bold">Notice:</p>
                          <p className="mt-0.5 leading-relaxed">{linkedinVerifyError}</p>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Optional Onboarding Notes / Intent */}
                  <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-1.5">
                    <label className="block text-xs font-bold text-slate-700">
                      Onboarding Notes & Learning Goals (Optional):
                    </label>
                    <textarea
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      rows={2}
                      placeholder="Share your goals for this virtual internship track, tech stack aspirations, or reflections..."
                      className="w-full text-xs p-3 bg-white border border-slate-300 rounded-xl outline-none focus:border-[#0A66C2]"
                    />
                  </div>
                </div>

                {/* Task 1 Final Submission Action */}
                <div className="pt-2 space-y-3">
                  {submitError && (
                    <div className="p-3.5 bg-rose-50 border border-rose-300 text-rose-900 text-xs rounded-xl flex items-center gap-2.5">
                      <AlertCircle className="w-5 h-5 text-rose-600 shrink-0" />
                      <div>
                        <p className="font-bold">Task 1 Submission Error</p>
                        <p className="text-[11px] text-rose-800 mt-0.5">{submitError}</p>
                      </div>
                    </div>
                  )}
                  {currentSubmission?.status === 'approved' || isTaskCompleted(1) ? (
                    <div className="space-y-2">
                      <div className="w-full py-4 px-4 bg-emerald-600 text-white font-extrabold text-xs sm:text-sm rounded-xl shadow-md flex items-center justify-center gap-2 border-2 border-emerald-400">
                        <CheckCircle2 className="w-4 h-4 text-emerald-200" />
                        <span>Task 1 Approved & Verified ✓ (Score: {currentSubmission?.rubricScore || 90}/100)</span>
                      </div>
                      <p className="text-[11px] text-center text-emerald-700 font-medium">
                        Verified by VirIntern Admin Mentor. Milestone 1 complete — Task 2 is now unlocked!
                      </p>
                    </div>
                  ) : Boolean(currentSubmission) && (currentSubmission?.status === 'submitted' || currentSubmission?.status === 'pending_review' || currentSubmission?.status === 'under_review' || !currentSubmission?.isManuallyVerified) ? (
                    <div className="space-y-3">
                      <button
                        type="button"
                        className="w-full py-4 px-4 bg-gradient-to-r from-amber-500 to-amber-600 text-white font-extrabold text-xs sm:text-sm rounded-xl shadow-md flex items-center justify-center gap-2 border-2 border-amber-300 cursor-default"
                      >
                        <Clock className="w-4 h-4 animate-spin text-amber-100" />
                        <span>Submitted — Waiting for Admin Review ⏳</span>
                      </button>
                      <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-xs text-amber-900 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                        <p className="text-[11px] leading-relaxed">
                          Your Task 1 deliverables (Offer Letter, YouTube Screenshot & LinkedIn URL) have been received and are waiting in the admin verification queue. You will receive marks and feedback once reviewed.
                        </p>
                        <button
                          type="button"
                          onClick={handleTask1Submit}
                          disabled={submitting || !userYoutubeHandle.trim() || !socialProofUrl.trim()}
                          className="px-3.5 py-1.5 bg-amber-200 hover:bg-amber-300 text-amber-950 font-bold rounded-lg text-xs transition-colors cursor-pointer shrink-0"
                        >
                          {submitting ? 'Updating...' : 'Update & Resubmit'}
                        </button>
                      </div>
                    </div>
                  ) : (
                    <>
                      <button
                        type="button"
                        onClick={handleTask1Submit}
                        disabled={submitting}
                        className={`w-full py-4 font-bold text-xs sm:text-sm rounded-xl shadow-xs transition-all flex items-center justify-center gap-2 ${
                          !userYoutubeHandle.trim() || !socialProofUrl.trim() || !youtubeScreenshotUrl.trim()
                            ? 'bg-[#0A66C2]/85 hover:bg-[#0A66C2] text-white cursor-pointer shadow-sm'
                            : 'bg-[#0A66C2] hover:bg-[#004182] text-white cursor-pointer shadow-md hover:shadow-lg active:scale-[0.99]'
                        }`}
                      >
                        {submitting ? (
                          <div className="flex items-center gap-2">
                            <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                            <span>Submitting Deliverables & Screenshot for Admin Verification...</span>
                          </div>
                        ) : (
                          <>
                            <Shield className="w-4 h-4 text-amber-300" />
                            <span>Submit Task 1 for Admin Verification & Scoring</span>
                            <Send className="w-4 h-4 ml-1" />
                          </>
                        )}
                      </button>
                      {(!userYoutubeHandle.trim() || !socialProofUrl.trim() || !youtubeScreenshotUrl.trim()) && (
                        <p className="text-[11px] text-center text-slate-500 mt-2 font-medium">
                          Please ensure YouTube handle, subscription screenshot, and LinkedIn post URL are provided before submitting.
                        </p>
                      )}
                    </>
                  )}
                </div>

                {/* Task 1 Mentor Review & Evaluation Score Card if already evaluated */}
                {currentSubmission?.geminiEvaluation && (
                  <div className="bg-gradient-to-br from-blue-50/90 via-white to-indigo-50/60 rounded-2xl border border-blue-200 p-5 shadow-xs space-y-4 animate-fadeIn">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2.5">
                        <div className="w-9 h-9 rounded-xl bg-[#0A66C2] text-white flex items-center justify-center shadow-xs">
                          <Sparkles className="w-5 h-5 text-amber-300" />
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <h4 className="text-sm font-black text-slate-900">Task 1 Mentor Review & Evaluation</h4>
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-blue-100 text-[#0A66C2]">
                              Grade {currentSubmission.geminiEvaluation.grade}
                            </span>
                          </div>
                          <p className="text-[10px] text-slate-500 font-medium">Evaluation Mode: Verified Faculty Review • Objective Rubric</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <span className="text-2xl font-black text-[#0A66C2]">{currentSubmission.geminiEvaluation.score}</span>
                        <span className="text-xs text-slate-400 font-semibold"> / 100</span>
                        <span className="block text-[9px] font-bold text-emerald-700 uppercase tracking-wider">Passed (≥70%)</span>
                      </div>
                    </div>

                    <p className="text-xs text-slate-700 leading-relaxed bg-white/80 p-3 rounded-xl border border-blue-100/90 italic">
                      "{currentSubmission.geminiEvaluation.summary}"
                    </p>

                    {/* 4 Pillars Breakdown Gauges */}
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 pt-1">
                      <div className="p-2.5 bg-white rounded-xl border border-slate-200/90 shadow-2xs">
                        <div className="flex justify-between text-[11px] font-bold text-slate-700 mb-1">
                          <span>Orientation</span>
                          <span className="text-[#0A66C2]">{currentSubmission.geminiEvaluation.breakdown.codeArchitecture} / 25</span>
                        </div>
                        <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                          <div
                            className="bg-[#0A66C2] h-full rounded-full transition-all"
                            style={{ width: `${(currentSubmission.geminiEvaluation.breakdown.codeArchitecture / 25) * 100}%` }}
                          />
                        </div>
                      </div>

                      <div className="p-2.5 bg-white rounded-xl border border-slate-200/90 shadow-2xs">
                        <div className="flex justify-between text-[11px] font-bold text-slate-700 mb-1">
                          <span>Completeness</span>
                          <span className="text-emerald-700">{currentSubmission.geminiEvaluation.breakdown.deliverableCompleteness} / 25</span>
                        </div>
                        <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                          <div
                            className="bg-emerald-600 h-full rounded-full transition-all"
                            style={{ width: `${(currentSubmission.geminiEvaluation.breakdown.deliverableCompleteness / 25) * 100}%` }}
                          />
                        </div>
                      </div>

                      <div className="p-2.5 bg-white rounded-xl border border-slate-200/90 shadow-2xs">
                        <div className="flex justify-between text-[11px] font-bold text-slate-700 mb-1">
                          <span>Outreach</span>
                          <span className="text-purple-700">{currentSubmission.geminiEvaluation.breakdown.practicalImplementation} / 25</span>
                        </div>
                        <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                          <div
                            className="bg-purple-600 h-full rounded-full transition-all"
                            style={{ width: `${(currentSubmission.geminiEvaluation.breakdown.practicalImplementation / 25) * 100}%` }}
                          />
                        </div>
                      </div>

                      <div className="p-2.5 bg-white rounded-xl border border-slate-200/90 shadow-2xs">
                        <div className="flex justify-between text-[11px] font-bold text-slate-700 mb-1">
                          <span>Readiness</span>
                          <span className="text-amber-700">{currentSubmission.geminiEvaluation.breakdown.documentationAndReadiness} / 25</span>
                        </div>
                        <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                          <div
                            className="bg-amber-500 h-full rounded-full transition-all"
                            style={{ width: `${(currentSubmission.geminiEvaluation.breakdown.documentationAndReadiness / 25) * 100}%` }}
                          />
                        </div>
                      </div>
                    </div>

                    {/* Identified Strengths */}
                    {currentSubmission.geminiEvaluation.strengths && currentSubmission.geminiEvaluation.strengths.length > 0 && (
                      <div className="space-y-1 text-xs text-slate-700">
                        <span className="font-bold text-slate-900 text-[11px] uppercase tracking-wider block">Observed Strengths:</span>
                        <ul className="space-y-1 pl-4 list-disc text-[11px] text-slate-600">
                          {currentSubmission.geminiEvaluation.strengths.map((str, sIdx) => (
                            <li key={sIdx}>{str}</li>
                          ))}
                        </ul>
                      </div>
                    )}

                    {/* Actionable Recommendations */}
                    {currentSubmission.geminiEvaluation.recommendations && currentSubmission.geminiEvaluation.recommendations.length > 0 && (
                      <div className="space-y-1 text-xs text-slate-700 pt-1">
                        <span className="font-bold text-slate-900 text-[11px] uppercase tracking-wider block">Recommendations:</span>
                        <ul className="space-y-1 pl-4 list-disc text-[11px] text-slate-600">
                          {currentSubmission.geminiEvaluation.recommendations.map((rec, rIdx) => (
                            <li key={rIdx}>{rec}</li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                )}

                {/* Optional Collapsible Guidelines & Instructions (Eliminates excessive scrolling!) */}
                <details className="group bg-[#F4F2EE] border border-[#E0DFDC] rounded-xl p-4 transition-all">
                  <summary className="text-xs font-bold text-[#191919] cursor-pointer flex items-center justify-between list-none">
                    <span className="flex items-center gap-2">
                      <BookOpen className="w-4 h-4 text-[#0A66C2]" />
                      <span>Task 1 Guidelines, Objectives & Onboarding FAQ (Optional Reference)</span>
                    </span>
                    <span className="text-[#666666] text-xs font-normal group-open:rotate-180 transition-transform">▼</span>
                  </summary>
                  <div className="mt-4 pt-3 border-t border-[#E0DFDC] space-y-4 text-xs text-[#666666]">
                    <div>
                      <h4 className="font-bold text-[#191919] uppercase tracking-wider text-[11px] mb-1">Project Objective</h4>
                      <p className="leading-relaxed">{currentTask.objective}</p>
                    </div>
                    <div>
                      <h4 className="font-bold text-[#191919] uppercase tracking-wider text-[11px] mb-1">Step-by-Step Instructions</h4>
                      <ul className="list-decimal pl-4 space-y-1">
                        {currentTask.instructions.map((inst, i) => (
                          <li key={i} className="leading-relaxed">{inst}</li>
                        ))}
                      </ul>
                    </div>
                    <div>
                      <h4 className="font-bold text-[#0A66C2] uppercase tracking-wider text-[11px] mb-1">Expected Deliverable</h4>
                      <p className="leading-relaxed">{currentTask.expectedOutput}</p>
                    </div>
                  </div>
                </details>
              </div>
            </div>
          ) : !isTaskUnlocked(selectedTaskNumber) ? (
            /* Locked State for Tasks 2 to 5: Do NOT show the next task until previous task is verified and marks assigned! */
            <div className="bg-white rounded-3xl border border-amber-200 p-8 sm:p-12 shadow-sm text-center space-y-6 animate-fadeIn">
              <div className="w-16 h-16 rounded-2xl bg-amber-100 text-amber-700 flex items-center justify-center mx-auto border border-amber-300 shadow-sm">
                <Lock className="w-8 h-8 text-amber-700" />
              </div>

              <div className="max-w-xl mx-auto space-y-3">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-amber-100 text-amber-900 border border-amber-200">
                  <Clock className="w-3.5 h-3.5" />
                  <span>Task {selectedTaskNumber} Locked • Pending Admin Verification & Marks</span>
                </div>

                <h3 className="text-xl sm:text-2xl font-black text-slate-900">
                  Task {selectedTaskNumber} is Kept Locked
                </h3>

                {isTaskUnderReview(selectedTaskNumber - 1) ? (
                  <div className="p-4 sm:p-5 bg-amber-50 rounded-2xl border border-amber-200 text-left space-y-3">
                    <div className="flex items-center justify-between text-xs font-bold text-amber-900">
                      <span className="flex items-center gap-1.5">
                        <Clock className="w-4 h-4 text-amber-600 animate-pulse" />
                        <span>Task {selectedTaskNumber - 1} Submitted — Kept Under Review ⏳</span>
                      </span>
                      <span className="bg-amber-200/80 text-amber-950 px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase">
                        Under Admin Review
                      </span>
                    </div>
                    <p className="text-xs text-amber-900 leading-relaxed font-medium">
                      The tasks which is submitted should be kept under review until unless it is verified by admin and marks is assigned it should not show the next task. Admin should verify manually and then the user can access next task.
                    </p>
                    <div className="p-3 bg-white/90 rounded-xl border border-amber-200 text-xs text-slate-700 space-y-1">
                      <div className="flex items-center justify-between text-[11px] font-semibold text-slate-600">
                        <span>Status of Task {selectedTaskNumber - 1}:</span>
                        <span className="font-bold text-amber-800">Awaiting Admin Verification</span>
                      </div>
                      <div className="flex items-center justify-between text-[11px] font-semibold text-slate-600">
                        <span>Marks Status:</span>
                        <span className="font-bold text-amber-800">Pending Marks Assignment</span>
                      </div>
                      <p className="text-[10px] text-slate-500 pt-1 border-t border-slate-100">
                        Once the administrator manually inspects your deliverables in the Admin Portal and assigns your score/marks, Task {selectedTaskNumber} will automatically unlock.
                      </p>
                    </div>
                  </div>
                ) : (
                  <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 text-left space-y-2">
                    <p className="text-xs text-slate-700 leading-relaxed">
                      Tasks unlock sequentially. You must first complete and submit <strong>Task {selectedTaskNumber - 1}</strong>, and have it verified by the admin with marks assigned, before Task {selectedTaskNumber} can be shown or accessed.
                    </p>
                  </div>
                )}
              </div>

              <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setSelectedTaskNumber(selectedTaskNumber - 1)}
                  className="px-5 py-2.5 bg-[#0A66C2] hover:bg-[#004182] text-white font-bold text-xs rounded-xl shadow-sm transition-all flex items-center gap-2 cursor-pointer"
                >
                  <span>← View Task {selectedTaskNumber - 1} Submission Status</span>
                </button>
                <button
                  type="button"
                  onClick={() => setCurrentView('leaderboard')}
                  className="px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition-all flex items-center gap-2 cursor-pointer"
                >
                  <Trophy className="w-4 h-4 text-amber-600" />
                  <span>View Cohort Standings</span>
                </button>
              </div>
            </div>
          ) : (
            /* Tasks 2 to 5: Virtual Internship Project Workspace (Mobile Responsive + Laptop Side-by-Side) */
            <div className="space-y-4">
              {/* Mobile View Toggle Switch: Enables 50-50 mobile users to quickly toggle between Guide and Submission */}
              <div className="lg:hidden flex items-center p-1 bg-slate-200/80 rounded-xl border border-slate-300 shadow-2xs">
                <button
                  type="button"
                  onClick={() => setMobileTaskTab('guide')}
                  className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-1.5 ${
                    mobileTaskTab === 'guide'
                      ? 'bg-white text-[#0A66C2] shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <BookOpen className="w-3.5 h-3.5" />
                  <span>1. Project Guide & Spec</span>
                </button>
                <button
                  type="button"
                  onClick={() => setMobileTaskTab('submission')}
                  className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-1.5 ${
                    mobileTaskTab === 'submission'
                      ? 'bg-white text-[#0A66C2] shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>2. Submit Proof of Work</span>
                </button>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8 items-start">
                {/* Left Column: Instructions & Objectives */}
                <div
                  id="task-guide-container"
                  className={`lg:col-span-7 bg-white rounded-2xl border border-[#E0DFDC] p-5 sm:p-6 space-y-6 shadow-xs scroll-mt-24 ${
                    mobileTaskTab === 'guide' ? 'block' : 'hidden lg:block'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold uppercase tracking-wider text-[#0A66C2] bg-[#EBF4FD] px-2.5 py-1 rounded-full">
                        Task {currentTask.taskNumber} of 5
                      </span>
                      <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-[#F4F2EE] text-[#666666]">
                        Difficulty: {currentTask.difficulty}
                      </span>
                    </div>
                    <h2 className="text-lg sm:text-xl font-extrabold text-[#191919] mt-2">
                      {currentTask.title}
                    </h2>
                    <p className="text-xs text-[#666666] mt-1 leading-relaxed">
                      {currentTask.description}
                    </p>
                  </div>

                  {/* Assigned Unique Track Banner for Tasks 2 to 5 */}
                  <div className="p-3.5 bg-gradient-to-r from-blue-50/90 via-indigo-50/70 to-purple-50/80 border border-blue-200/90 rounded-xl flex items-center gap-3 shadow-2xs">
                    <div className="w-9 h-9 rounded-lg bg-[#0A66C2] text-white flex items-center justify-center font-bold text-xs shrink-0 shadow-2xs">
                      <Sparkles className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] uppercase font-bold tracking-wider text-[#0A66C2] bg-white px-2 py-0.5 rounded-full border border-blue-200">
                          Assigned Virtual Internship Track
                        </span>
                      </div>
                      <p className="text-xs font-bold text-slate-900 mt-0.5">
                        {currentTask?.description && currentTask.description.includes(':')
                          ? currentTask.description.split(':')[0]
                          : (activeInternship?.domainName || 'Engineering Track')}
                      </p>
                      <p className="text-[10px] text-slate-600 mt-0.5">
                        Assigned uniquely to student <strong>{resolvedUserName}</strong> • Project tracks are rotated dynamically across students to ensure unique, non-repeating assignments.
                      </p>
                    </div>
                  </div>

                  {/* Objective */}
                  <div className="bg-[#F4F2EE] p-4 rounded-xl border border-[#E0DFDC]">
                    <h4 className="text-xs font-bold uppercase tracking-wider text-[#191919] mb-1">
                      Project Objective
                    </h4>
                    <p className="text-xs text-[#666666] leading-relaxed">
                      {currentTask.objective}
                    </p>
                  </div>

                  {/* Zero-Cost Project Blueprint (100% Free Tools) */}
                  <div className="p-4 bg-gradient-to-br from-emerald-50 via-teal-50 to-blue-50 rounded-xl border border-emerald-200/90 shadow-2xs space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="p-1 rounded bg-[#057642] text-white">
                          <Sparkles className="w-3.5 h-3.5" />
                        </span>
                        <h4 className="text-xs font-bold uppercase tracking-wider text-emerald-950">
                          Industry-Standard Project Blueprint • 100% Free Tools
                        </h4>
                      </div>
                      <span className="text-[10px] font-bold text-[#057642] bg-emerald-100/90 px-2.5 py-0.5 rounded-full border border-emerald-300">
                        ₹0 / $0 Cost Required
                      </span>
                    </div>

                    <p className="text-xs text-emerald-900 leading-relaxed font-medium">
                      Built to give you genuine portfolio-grade industry experience with zero expenses. Complete this task using standard free-tier tools:
                    </p>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                      <div className="p-2.5 bg-white/85 rounded-xl border border-emerald-100 flex items-start gap-2 shadow-2xs">
                        <div className="w-5 h-5 rounded-full bg-emerald-100 text-[#057642] font-bold text-[10px] flex items-center justify-center shrink-0 mt-0.5">1</div>
                        <div>
                          <p className="font-bold text-slate-900 text-[11px]">Free Workspace Setup</p>
                          <p className="text-[10px] text-slate-600 leading-tight">Use VS Code, GitHub Desktop, Google Colab (Free GPU), Wokwi (Free IoT sim), or Figma (Free starter).</p>
                        </div>
                      </div>
                      <div className="p-2.5 bg-white/85 rounded-xl border border-emerald-100 flex items-start gap-2 shadow-2xs">
                        <div className="w-5 h-5 rounded-full bg-emerald-100 text-[#057642] font-bold text-[10px] flex items-center justify-center shrink-0 mt-0.5">2</div>
                        <div>
                          <p className="font-bold text-slate-900 text-[11px]">Core Implementation</p>
                          <p className="text-[10px] text-slate-600 leading-tight">Develop the functional project logic following standard coding conventions and modular design.</p>
                        </div>
                      </div>
                      <div className="p-2.5 bg-white/85 rounded-xl border border-emerald-100 flex items-start gap-2 shadow-2xs">
                        <div className="w-5 h-5 rounded-full bg-emerald-100 text-[#057642] font-bold text-[10px] flex items-center justify-center shrink-0 mt-0.5">3</div>
                        <div>
                          <p className="font-bold text-slate-900 text-[11px]">Local Testing & Verification</p>
                          <p className="text-[10px] text-slate-600 leading-tight">Test your project locally, verifying responsive views, error states, and documentation.</p>
                        </div>
                      </div>
                      <div className="p-2.5 bg-white/85 rounded-xl border border-emerald-100 flex items-start gap-2 shadow-2xs">
                        <div className="w-5 h-5 rounded-full bg-emerald-100 text-[#057642] font-bold text-[10px] flex items-center justify-center shrink-0 mt-0.5">4</div>
                        <div>
                          <p className="font-bold text-slate-900 text-[11px]">Free Push & Delivery</p>
                          <p className="text-[10px] text-slate-600 leading-tight">Push to free GitHub repository. Host live on free services (Vercel, Netlify, Render, or GitHub Pages).</p>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Instructions */}
                  <div>
                    <h4 className="text-xs font-bold uppercase tracking-wider text-[#191919] mb-2">
                      Step-by-Step Instructions
                    </h4>
                    <ul className="space-y-2 text-xs text-[#666666] pl-4 list-decimal">
                      {(currentTask?.instructions || []).map((inst, idx) => (
                        <li key={idx} className="leading-relaxed">
                          {inst}
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Expected Output */}
                  <div className="bg-[#EBF4FD] p-4 rounded-xl border border-[#D0E8FF]">
                    <h4 className="text-xs font-bold uppercase tracking-wider text-[#0A66C2] mb-1">
                      Expected Deliverable
                    </h4>
                    <p className="text-xs text-[#004182] leading-relaxed">
                      {currentTask.expectedOutput}
                    </p>
                  </div>

                  {/* Reference Resources */}
                  {currentTask.resources && currentTask.resources.length > 0 && (
                    <div>
                      <h4 className="text-xs font-bold uppercase tracking-wider text-[#191919] mb-2">
                        Learning Resources & Guides
                      </h4>
                      <div className="flex flex-wrap gap-2">
                        {currentTask.resources.map((res, i) => (
                          <a
                            key={i}
                            href={res.url}
                            target="_blank"
                            rel="noreferrer"
                            className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#F4F2EE] hover:bg-[#EBF4FD] text-[#191919] hover:text-[#0A66C2] text-xs font-medium rounded-full border border-[#E0DFDC] transition-colors"
                          >
                            <ExternalLink className="w-3.5 h-3.5" />
                            <span>{res.title}</span>
                          </a>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Mobile Quick Action to switch to submission */}
                  <div className="lg:hidden pt-4 border-t border-[#E0DFDC]">
                    <button
                      type="button"
                      onClick={() => {
                        try {
                          window.history.pushState({ tab: 'submission' }, '', window.location.href);
                        } catch {}
                        setMobileTaskTab('submission');
                        setTimeout(() => {
                          const target = document.getElementById('task-submission-container');
                          if (target) {
                            target.scrollIntoView({ behavior: 'smooth', block: 'start' });
                          }
                        }, 50);
                      }}
                      className="w-full py-3.5 bg-[#0A66C2] hover:bg-[#004182] active:bg-[#003366] text-white font-bold text-xs sm:text-sm rounded-xl shadow-sm transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-95"
                    >
                      <Send className="w-4 h-4" />
                      <span>Ready to Submit? Switch to Submission Form</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Right Column: Submission Form */}
                <div
                  id="task-submission-container"
                  className={`lg:col-span-5 space-y-6 scroll-mt-24 ${
                    mobileTaskTab === 'submission' ? 'block' : 'hidden lg:block'
                  }`}
                >
                  {/* Mobile Back Switch */}
                  <div className="lg:hidden">
                    <button
                      type="button"
                      onClick={() => {
                        setMobileTaskTab('guide');
                        setTimeout(() => {
                          const guideEl = document.getElementById('task-guide-container');
                          if (guideEl) {
                            guideEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
                          }
                        }, 50);
                      }}
                      className="w-full py-2.5 px-3 bg-[#F4F2EE] hover:bg-[#EAE8E4] text-[#191919] text-xs font-bold rounded-xl border border-[#E0DFDC] flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                    >
                      <span>← Back to Project Guide & Specifications</span>
                    </button>
                  </div>
                {/* Status Feedback Banner if submission exists */}
                {currentSubmission && (
                  <div
                    className={`p-5 rounded-xl border text-xs ${
                      currentSubmission.status === 'approved'
                        ? 'bg-[#E8F5E9] border-[#C8E6C9] text-[#057642]'
                        : currentSubmission.status === 'rejected'
                        ? 'bg-[#FCE8E6] border-[#F5C6CB] text-[#CC1016]'
                        : 'bg-[#FFF3E0] border-[#FFE0B2] text-[#915907]'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-bold uppercase tracking-wider">
                        Submission Status: {currentSubmission.status}
                      </span>
                      <span className="text-[10px] text-slate-500">
                        {new Date(currentSubmission.submittedAt).toLocaleDateString()}
                      </span>
                    </div>

                    {currentSubmission.adminFeedback && (
                      <div className="mt-2 p-3 bg-white/70 rounded-xl border border-current/20">
                        <p className="font-semibold text-[11px] mb-0.5">Mentor Feedback:</p>
                        <p className="italic">{currentSubmission.adminFeedback}</p>
                      </div>
                    )}

                    {currentSubmission.status === 'approved' && (
                      <p className="mt-2 text-emerald-700 font-medium">
                        ✓ Task verified! Your progress has been updated and the next task is unlocked.
                      </p>
                    )}

                    {currentSubmission.status === 'submitted' && (
                      <div className="mt-2.5 pt-2 border-t border-amber-200/80 flex items-center gap-2">
                        <Clock className="w-3.5 h-3.5 text-amber-700 shrink-0 animate-pulse" />
                        <p className="text-[11px] text-amber-900 font-medium">
                          Milestone submitted! Awaiting manual administrator verification and score assignment in the Admin Portal.
                        </p>
                      </div>
                    )}

                    {currentSubmission.status === 'rejected' && (
                      <p className="mt-2 text-rose-700 font-medium">
                        Please review the mentor feedback above, make the requested adjustments, and resubmit using the form below.
                      </p>
                    )}
                  </div>
                )}

                {/* Performance Evaluation & Score Card */}
                {(currentSubmission?.rubricScore !== undefined || currentSubmission?.geminiEvaluation) && (
                  <div className="bg-gradient-to-br from-blue-50/90 via-white to-indigo-50/60 rounded-2xl border border-blue-200 p-5 shadow-xs space-y-4 animate-fadeIn">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2.5">
                        <div className="w-9 h-9 rounded-xl bg-[#0A66C2] text-white flex items-center justify-center shadow-xs">
                          <Sparkles className="w-5 h-5 text-amber-300" />
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <h4 className="text-sm font-black text-slate-900">
                              {currentSubmission.isManuallyVerified ? 'Admin Mentor Task Verification' : 'Milestone Evaluation Score'}
                            </h4>
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-blue-100 text-[#0A66C2]">
                              Grade {(currentSubmission.rubricScore ?? currentSubmission.geminiEvaluation?.score ?? 85) >= 90 ? 'A+' : (currentSubmission.rubricScore ?? currentSubmission.geminiEvaluation?.score ?? 85) >= 80 ? 'A' : 'B'}
                            </span>
                          </div>
                          <p className="text-[10px] text-slate-500 font-medium">
                            {currentSubmission.reviewedBy ? `Verified by ${currentSubmission.reviewedBy} • Official Rubric` : 'Verified & Evaluated via Official Engineering Rubric'}
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <span className="text-2xl font-black text-[#0A66C2]">
                          {currentSubmission.rubricScore ?? currentSubmission.geminiEvaluation?.score ?? 85}
                        </span>
                        <span className="text-xs text-slate-400 font-semibold"> / 100</span>
                        <span className="block text-[9px] font-bold text-emerald-700 uppercase tracking-wider">
                          {(currentSubmission.rubricScore ?? currentSubmission.geminiEvaluation?.score ?? 85) >= 70 ? 'Passed (≥70%)' : 'Needs Revision'}
                        </span>
                      </div>
                    </div>

                    <p className="text-xs text-slate-700 leading-relaxed bg-white/80 p-3 rounded-xl border border-blue-100/90 italic">
                      "{currentSubmission.adminFeedback || currentSubmission.geminiEvaluation?.summary || 'Deliverable successfully verified against milestone specifications.'}"
                    </p>

                    {/* 4 Pillars Breakdown Gauges */}
                    {(() => {
                      const gBreakdown = currentSubmission.geminiEvaluation?.breakdown || {
                        codeArchitecture: Math.round(((currentSubmission.rubricScore ?? 85) * 0.25)),
                        deliverableCompleteness: Math.round(((currentSubmission.rubricScore ?? 85) * 0.25)),
                        practicalImplementation: Math.round(((currentSubmission.rubricScore ?? 85) * 0.25)),
                        documentationAndReadiness: Math.round(((currentSubmission.rubricScore ?? 85) * 0.25))
                      };
                      const gStrengths = currentSubmission.geminiEvaluation?.strengths || [];
                      const gRecs = currentSubmission.geminiEvaluation?.recommendations || [];

                      return (
                        <>
                          <div className="grid grid-cols-2 gap-2.5 pt-1">
                            <div className="p-2.5 bg-white rounded-xl border border-slate-200/90 shadow-2xs">
                              <div className="flex justify-between text-[11px] font-bold text-slate-700 mb-1">
                                <span>Architecture</span>
                                <span className="text-[#0A66C2]">{gBreakdown.codeArchitecture} / 25</span>
                              </div>
                              <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                                <div
                                  className="bg-[#0A66C2] h-full rounded-full transition-all"
                                  style={{ width: `${(gBreakdown.codeArchitecture / 25) * 100}%` }}
                                />
                              </div>
                            </div>

                            <div className="p-2.5 bg-white rounded-xl border border-slate-200/90 shadow-2xs">
                              <div className="flex justify-between text-[11px] font-bold text-slate-700 mb-1">
                                <span>Completeness</span>
                                <span className="text-emerald-700">{gBreakdown.deliverableCompleteness} / 25</span>
                              </div>
                              <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                                <div
                                  className="bg-emerald-600 h-full rounded-full transition-all"
                                  style={{ width: `${(gBreakdown.deliverableCompleteness / 25) * 100}%` }}
                                />
                              </div>
                            </div>

                            <div className="p-2.5 bg-white rounded-xl border border-slate-200/90 shadow-2xs">
                              <div className="flex justify-between text-[11px] font-bold text-slate-700 mb-1">
                                <span>Implementation</span>
                                <span className="text-purple-700">{gBreakdown.practicalImplementation} / 25</span>
                              </div>
                              <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                                <div
                                  className="bg-purple-600 h-full rounded-full transition-all"
                                  style={{ width: `${(gBreakdown.practicalImplementation / 25) * 100}%` }}
                                />
                              </div>
                            </div>

                            <div className="p-2.5 bg-white rounded-xl border border-slate-200/90 shadow-2xs">
                              <div className="flex justify-between text-[11px] font-bold text-slate-700 mb-1">
                                <span>Documentation</span>
                                <span className="text-amber-700">{gBreakdown.documentationAndReadiness} / 25</span>
                              </div>
                              <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                                <div
                                  className="bg-amber-500 h-full rounded-full transition-all"
                                  style={{ width: `${(gBreakdown.documentationAndReadiness / 25) * 100}%` }}
                                />
                              </div>
                            </div>
                          </div>

                          {gStrengths.length > 0 && (
                            <div className="space-y-1 text-xs text-slate-700">
                              <span className="font-bold text-slate-900 text-[11px] uppercase tracking-wider block">Observed Strengths:</span>
                              <ul className="space-y-1 pl-4 list-disc text-[11px] text-slate-600">
                                {gStrengths.map((str, sIdx) => (
                                  <li key={sIdx}>{str}</li>
                                ))}
                              </ul>
                            </div>
                          )}

                          {gRecs.length > 0 && (
                            <div className="space-y-1 text-xs text-slate-700 pt-1">
                              <span className="font-bold text-slate-900 text-[11px] uppercase tracking-wider block">Recommendations:</span>
                              <ul className="space-y-1 pl-4 list-disc text-[11px] text-slate-600">
                                {gRecs.map((rec, rIdx) => (
                                  <li key={rIdx}>{rec}</li>
                                ))}
                              </ul>
                            </div>
                          )}
                        </>
                      );
                    })()}

                    {/* View Full AI Rubric Evaluation Report Button */}
                    {(matchingEvaluation || currentSubmission?.geminiEvaluation) && (
                      <button
                        type="button"
                        onClick={() => {
                          if (matchingEvaluation) {
                            setActiveEvaluation(matchingEvaluation);
                          } else if (currentSubmission?.geminiEvaluation) {
                            setActiveEvaluation({
                              evaluationId: `eval_${currentSubmission.id}`,
                              submissionId: currentSubmission.id,
                              userId: user.uid,
                              taskId: currentTask.id,
                              totalScore: currentSubmission.geminiEvaluation.score,
                              criteriaScores: {
                                functionality: currentSubmission.geminiEvaluation.breakdown?.codeArchitecture || 25,
                                requirements: currentSubmission.geminiEvaluation.breakdown?.deliverableCompleteness || 25,
                                quality: currentSubmission.geminiEvaluation.breakdown?.practicalImplementation || 20,
                                documentation: currentSubmission.geminiEvaluation.breakdown?.documentationAndReadiness || 10,
                                errorHandling: 10,
                                originality: 10
                              },
                              requirementResults: [],
                              strengths: currentSubmission.geminiEvaluation.strengths || [],
                              weaknesses: currentSubmission.geminiEvaluation.recommendations || [],
                              detectedIssues: [],
                              improvementSuggestions: currentSubmission.geminiEvaluation.recommendations || [],
                              confidence: 94,
                              status: currentSubmission.status === 'approved' ? 'passed' : 'revision_required',
                              evaluatedAt: currentSubmission.submittedAt,
                              evaluatorType: 'AI'
                            });
                          }
                          setEvalModalOpen(true);
                        }}
                        className="w-full py-2.5 bg-gradient-to-r from-[#0A66C2] to-indigo-600 hover:from-[#004182] hover:to-indigo-700 text-white font-bold text-xs rounded-xl shadow-xs transition-all flex items-center justify-center gap-2 cursor-pointer"
                      >
                        <Sparkles className="w-4 h-4 text-amber-300" />
                        <span>View Detailed Mentor Evaluation & Rubric Feedback</span>
                      </button>
                    )}

                    {/* View Leaderboard Button */}
                    <button
                      type="button"
                      onClick={() => setCurrentView('leaderboard')}
                      className="w-full py-2.5 bg-white hover:bg-blue-50 text-[#0A66C2] font-bold text-xs rounded-xl border border-blue-200 transition-colors flex items-center justify-center gap-1.5 cursor-pointer shadow-2xs"
                    >
                      <Trophy className="w-3.5 h-3.5 text-amber-500" />
                      <span>View Track Leaderboard & Your Performance Standing</span>
                    </button>
                  </div>
                )}

                {/* Virtual Internship Project Submission Form / Locked Notice */}
                {!isTaskUnlocked(selectedTaskNumber) ? (
                  <div className="bg-white rounded-2xl border border-amber-200 p-6 sm:p-7 text-center space-y-4 shadow-xs">
                    <div className="w-14 h-14 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center mx-auto border border-amber-200 shadow-2xs">
                      <Lock className="w-7 h-7 text-amber-600" />
                    </div>
                    <div>
                      <span className="text-[10px] uppercase font-extrabold tracking-wider text-amber-800 bg-amber-100 px-2.5 py-0.5 rounded-full border border-amber-200">
                        Milestone Locked
                      </span>
                      <h3 className="text-base font-bold text-slate-900 mt-2">
                        Week {selectedTaskNumber} Submissions Locked
                      </h3>
                      <p className="text-xs text-slate-600 mt-1 max-w-sm mx-auto leading-relaxed">
                        To maintain structured internship quality, every task unlocks sequentially one after the other. Please submit your work for <strong>Task {selectedTaskNumber - 1}</strong> first to unlock this milestone.
                      </p>
                    </div>
                    <div className="pt-2">
                      <button
                        type="button"
                        onClick={() => setSelectedTaskNumber(activeTaskNum)}
                        className="w-full py-3 bg-[#0A66C2] hover:bg-[#004182] text-white font-bold text-xs rounded-xl shadow-xs transition-colors flex items-center justify-center gap-2 cursor-pointer"
                      >
                        <span>Work on Active Task {activeTaskNum} ({activeTaskNum === 1 ? 'Orientation & Verification' : `Week ${activeTaskNum} Milestone`})</span>
                        <ArrowRight className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="bg-white rounded-xl border border-[#E0DFDC] p-6 shadow-xs">
                    <div className="flex items-center justify-between mb-1">
                      <h3 className="text-base sm:text-lg font-extrabold text-[#191919] flex items-center gap-2">
                        <Send className="w-4 h-4 text-[#0A66C2]" />
                        <span>{currentSubmission?.status === 'approved' ? `Resubmit Task ${selectedTaskNumber} (Optional)` : `Submit Task ${selectedTaskNumber} Proof of Work`}</span>
                      </h3>
                      <span className="px-2.5 py-0.5 bg-[#EBF4FD] text-[#0A66C2] text-[10px] font-bold rounded-full border border-[#0A66C2]/30">
                        Week {selectedTaskNumber} Deliverable
                      </span>
                    </div>
                    <p className="text-xs text-[#666666] mb-4">
                      Submit your public repository link, deployed live demo, PDF/images, or written answers for manual mentor verification.
                    </p>

                    {submitError && (
                      <div className="mb-4 p-3.5 bg-rose-50 border border-rose-300 text-rose-900 text-xs rounded-xl flex items-center gap-2.5">
                        <AlertCircle className="w-5 h-5 text-rose-600 shrink-0" />
                        <div>
                          <p className="font-bold">Submission Error</p>
                          <p className="text-[11px] text-rose-800 mt-0.5">{submitError}</p>
                        </div>
                      </div>
                    )}

                    {submitSuccess && (
                      <div className="mb-4 p-3.5 bg-amber-50 border border-amber-300 text-amber-900 text-xs rounded-xl flex items-center gap-2.5">
                        <Clock className="w-5 h-5 text-amber-600 shrink-0 animate-pulse" />
                        <div>
                          <p className="font-bold">✓ Task {selectedTaskNumber} Submitted for Admin Review!</p>
                          <p className="text-[11px] text-amber-800 mt-0.5">
                            Your deliverables have been submitted and are queued for manual verification in the Admin Portal. An administrator will inspect your repository and demo to assign your score and unlock the next milestone.
                          </p>
                        </div>
                      </div>
                    )}

                    {currentSubmission?.status === 'submitted' && !submitSuccess && (
                      <div className="mb-4 p-3.5 bg-amber-50 border border-amber-300 text-amber-900 text-xs rounded-xl flex items-center gap-2.5">
                        <Clock className="w-5 h-5 text-amber-600 shrink-0 animate-pulse" />
                        <div>
                          <p className="font-bold">⏳ Milestone Under Review: Pending Admin Manual Verification</p>
                          <p className="text-[11px] text-amber-800 mt-0.5">
                            Your code repository, demo URL, and documentation are awaiting manual review and score assignment by the VirIntern Admin team.
                          </p>
                        </div>
                      </div>
                    )}

                    {currentSubmission?.status === 'approved' && (
                      <div className="mb-4 p-3.5 bg-emerald-50 border border-emerald-300 text-emerald-900 text-xs rounded-xl flex items-center gap-2.5">
                        <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                        <div>
                          <p className="font-bold">✓ Milestone Approved by Admin! (Score: {currentSubmission.rubricScore || 90}/100)</p>
                          <p className="text-[11px] text-emerald-800 mt-0.5">
                            {currentSubmission.adminFeedback || 'All technical requirements and deliverables verified and accepted by administrator.'}
                          </p>
                        </div>
                      </div>
                    )}

                    {currentSubmission?.status === 'revision_required' && (
                      <div className="mb-4 p-3.5 bg-amber-50 border border-amber-300 text-amber-900 text-xs rounded-xl flex items-center gap-2.5">
                        <AlertCircle className="w-5 h-5 text-amber-600 shrink-0" />
                        <div>
                          <p className="font-bold">⚠️ Revision Required by Admin Mentor (Score: {currentSubmission.rubricScore || 60}/100)</p>
                          <p className="text-[11px] text-amber-800 mt-0.5">
                            <strong>Feedback:</strong> {currentSubmission.adminFeedback || 'Please update your repository code or live demo to meet specifications and resubmit.'}
                          </p>
                        </div>
                      </div>
                    )}

                    <form onSubmit={handleTaskSubmit} noValidate className="space-y-4">
                      {/* 1. Primary Repository / Project Source Link */}
                      <div>
                        <label className="block text-xs font-semibold text-[#191919] mb-1">
                          GitHub Repository or Project Link <span className="text-[#CC1016]">*</span>
                        </label>
                        <div className="relative">
                          <Github className="w-4 h-4 text-[#666666] absolute left-3 top-3" />
                          <input
                            type="url"
                            value={repoUrl}
                            onChange={(e) => {
                              setRepoUrl(e.target.value);
                              setSubmitError(null);
                            }}
                            placeholder="https://github.com/your-username/project-repo (or Colab / Figma / public link)"
                            className="w-full pl-9 pr-3 py-2.5 text-xs border border-[#E0DFDC] rounded-xl focus:border-[#0A66C2] focus:ring-1 focus:ring-[#0A66C2] outline-none text-[#191919] bg-white transition-all"
                          />
                        </div>
                        <span className="text-[10px] text-slate-500 mt-1 block">
                          Provide your public GitHub repository, Google Colab notebook, Figma URL, or live source link.
                        </span>
                      </div>

                      {/* 2. Optional Live Demo or Output Link */}
                      <div>
                        <label className="block text-xs font-semibold text-[#191919] mb-1">
                          Live Demo or Output Link <span className="text-slate-400 font-normal">(Optional)</span>
                        </label>
                        <div className="relative">
                          <Globe className="w-4 h-4 text-[#666666] absolute left-3 top-3" />
                          <input
                            type="url"
                            value={demoUrl}
                            onChange={(e) => {
                              setDemoUrl(e.target.value);
                              setSubmitError(null);
                            }}
                            placeholder="https://your-project.vercel.app or video/demo link"
                            className="w-full pl-9 pr-3 py-2.5 text-xs border border-[#E0DFDC] rounded-xl focus:border-[#0A66C2] focus:ring-1 focus:ring-[#0A66C2] outline-none text-[#191919] bg-white transition-all"
                          />
                        </div>
                        <span className="text-[10px] text-slate-500 mt-1 block">
                          Live hosted deployment (e.g. Vercel, Netlify, GitHub Pages, Render, or Loom walkthrough).
                        </span>
                      </div>

                      {/* 3. Brief Summary / Implementation Notes */}
                      <div>
                        <label className="block text-xs font-semibold text-[#191919] mb-1">
                          Brief Implementation Summary <span className="text-slate-400 font-normal">(Optional)</span>
                        </label>
                        <textarea
                          rows={2}
                          value={notes}
                          onChange={(e) => setNotes(e.target.value)}
                          placeholder="Briefly state what you implemented, key features, and tools used..."
                          className="w-full p-2.5 text-xs border border-[#E0DFDC] rounded-xl focus:border-[#0A66C2] focus:ring-1 focus:ring-[#0A66C2] outline-none text-[#191919] bg-white transition-all"
                        ></textarea>
                      </div>

                      {submitError && (
                        <div className="p-3 bg-rose-50 border border-rose-300 text-rose-900 text-xs rounded-xl flex items-center gap-2">
                          <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                          <span className="font-semibold">{submitError}</span>
                        </div>
                      )}

                      {isTaskCompleted(selectedTaskNumber) ? (
                        <div className="w-full py-4 px-4 bg-emerald-600 text-white font-extrabold text-xs sm:text-sm rounded-2xl shadow-md flex items-center justify-center gap-2 border-2 border-emerald-400">
                          <CheckCircle2 className="w-4 h-4 text-emerald-200" />
                          <span>Task {selectedTaskNumber} Approved & Verified ✓ (Score: {currentSubmission?.rubricScore || 90}/100)</span>
                        </div>
                      ) : isTaskUnderReview(selectedTaskNumber) ? (
                        <div className="space-y-3">
                          <button
                            type="button"
                            className="w-full py-4 px-4 bg-gradient-to-r from-amber-500 to-amber-600 text-white font-extrabold text-xs sm:text-sm rounded-2xl shadow-md flex items-center justify-center gap-2 border-2 border-amber-300 cursor-default"
                          >
                            <Clock className="w-4 h-4 animate-spin text-amber-100" />
                            <span>Submitted — Waiting for Admin Review ⏳</span>
                          </button>
                          <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-xs text-amber-900 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                            <span className="text-[11px] leading-relaxed">
                              Your Task {selectedTaskNumber} deliverables are queued in the admin verification queue. You can update links or files anytime before mentor approval.
                            </span>
                            <button
                              type="submit"
                              disabled={submitting}
                              className="px-3.5 py-1.5 bg-amber-200 hover:bg-amber-300 text-amber-950 font-bold rounded-lg text-xs transition-colors cursor-pointer shrink-0"
                            >
                              {submitting ? 'Updating...' : 'Update & Resubmit'}
                            </button>
                          </div>
                        </div>
                      ) : (
                        <button
                          type="submit"
                          disabled={submitting}
                          className="w-full py-3.5 font-bold text-xs sm:text-sm rounded-xl shadow-xs transition-colors flex items-center justify-center gap-2 bg-[#0A66C2] hover:bg-[#004182] text-white cursor-pointer active:scale-98"
                        >
                          {submitting ? (
                            <div className="flex items-center gap-2">
                              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                              <span>Submitting for Mentor Review & Scoring...</span>
                            </div>
                          ) : (
                            <>
                              <Send className="w-4 h-4" />
                              <span>Submit Task {selectedTaskNumber} Proof of Work</span>
                            </>
                          )}
                        </button>
                      )}
                    </form>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Milestone Quick Switcher Footer */}
        <div className="flex items-center justify-between pt-4 border-t border-slate-200">
          <button
            type="button"
            onClick={() => {
              if (selectedTaskNumber > 1) {
                setSelectedTaskNumber(selectedTaskNumber - 1);
              }
            }}
            disabled={selectedTaskNumber === 1}
            className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all ${
              selectedTaskNumber === 1
                ? 'opacity-40 cursor-not-allowed bg-slate-100 text-slate-400'
                : 'bg-white hover:bg-slate-50 text-[#0A66C2] border border-[#0A66C2] shadow-2xs cursor-pointer'
            }`}
          >
            <span>← Previous Task</span>
          </button>

          <span className="text-xs font-semibold text-slate-500">
            Task {selectedTaskNumber} of 5 • {currentTask.difficulty} Level
          </span>

          <button
            type="button"
            onClick={() => {
              if (selectedTaskNumber < 5 && isTaskUnlocked(selectedTaskNumber + 1)) {
                setSelectedTaskNumber(selectedTaskNumber + 1);
              }
            }}
            disabled={selectedTaskNumber === 5 || !isTaskUnlocked(selectedTaskNumber + 1)}
            title={
              selectedTaskNumber === 5
                ? 'Final capstone milestone'
                : !isTaskUnlocked(selectedTaskNumber + 1)
                ? `Next task is locked until Task ${selectedTaskNumber} is verified by admin and marks are assigned`
                : 'Next Task'
            }
            className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-all ${
              selectedTaskNumber === 5 || !isTaskUnlocked(selectedTaskNumber + 1)
                ? 'opacity-40 cursor-not-allowed bg-slate-200 text-slate-500'
                : 'bg-[#0A66C2] hover:bg-[#004182] text-white shadow-xs cursor-pointer'
            }`}
          >
            <span>Next Task →</span>
          </button>
        </div>
        </div>
      )}

      {/* 3. Comprehensive All 5-Milestone Track Curriculum (Guarantees ALL tasks are visible and interactive) */}
      <div className="bg-white rounded-2xl border border-[#E0DFDC] p-5 sm:p-6 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
          <div>
            <h3 className="text-sm sm:text-base font-extrabold text-[#191919] flex items-center gap-2">
              <BookOpen className="w-4 h-4 text-[#0A66C2]" />
              <span>Complete 5-Milestone Track Curriculum & Deliverables</span>
            </h3>
            <p className="text-xs text-[#666666] mt-0.5">
              All 5 practical milestones for {activeInternship.domainName}. Click any milestone card to open its dedicated workspace and submit your work.
            </p>
          </div>
          <div className="flex items-center gap-2 text-xs font-bold text-[#057642] bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>{completedCount} of 5 Milestones Approved ({currentProgress}%)</span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[1, 2, 3, 4, 5].map((num) => {
            const isDone = isTaskCompleted(num);
            const isUnlocked = isTaskUnlocked(num);
            const isSelected = selectedTaskNumber === num;
            const taskObj = tasks.find(t => t.taskNumber === num);
            const submissionForTask = getSubmissionForTask(num);

            return (
              <div
                key={`curriculum-task-card-${num}`}
                className={`p-4 rounded-2xl border transition-all flex flex-col justify-between gap-3 ${
                  isSelected
                    ? 'border-[#0A66C2] bg-[#EBF4FD]/40 ring-2 ring-[#0A66C2]/20 shadow-xs'
                    : isDone
                    ? 'border-emerald-200 bg-white hover:border-emerald-400 shadow-2xs'
                    : isUnlocked
                    ? 'border-[#0A66C2]/40 bg-white hover:border-[#0A66C2] shadow-2xs'
                    : 'border-slate-200 bg-slate-50/70 opacity-80 hover:opacity-100 shadow-2xs'
                }`}
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between gap-1">
                    <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-blue-100 text-[#0A66C2] uppercase tracking-wider">
                      Task {num} • Week {num}
                    </span>
                    {isDone ? (
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 flex items-center gap-1">
                        <Check className="w-3 h-3 text-emerald-700" />
                        <span>Approved</span>
                      </span>
                    ) : isUnlocked ? (
                      submissionForTask ? (
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-100 text-amber-800">
                          {submissionForTask.status === 'submitted' ? 'Under Review' : submissionForTask.status}
                        </span>
                      ) : (
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-100 text-[#0A66C2]">
                          Active • Ready to Work
                        </span>
                      )
                    ) : (
                      <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-slate-200 text-slate-600 flex items-center gap-1">
                        <Lock className="w-2.5 h-2.5" />
                        <span>Locked</span>
                      </span>
                    )}
                  </div>

                  <h4 className="text-sm font-bold text-slate-900 leading-snug line-clamp-2">
                    {num === 1
                      ? 'Task 1: Week 1 — Official Onboarding & Verification (Offer Letter, YouTube & LinkedIn)'
                      : taskObj?.title || `Task ${num}: Week ${num} — Assigned Domain Project Milestone`}
                  </h4>

                  <p className="text-xs text-slate-600 line-clamp-3 leading-relaxed">
                    {num === 1
                      ? 'Review pre-attached official offer letter, auto-verify YouTube community channel membership (@virintern), and share LinkedIn commencement post.'
                      : taskObj?.objective || 'Complete functional deliverables with clean architecture and repository code.'}
                  </p>
                </div>

                <div className="pt-2 border-t border-slate-100 flex items-center justify-between gap-2">
                  <span className="text-[11px] font-semibold text-slate-500">
                    {isDone ? 'Completed (100%)' : isUnlocked ? 'Unlocked Milestone' : `Unlocks after Task ${num - 1}`}
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedTaskNumber(num);
                      const el = document.getElementById('task-workspace');
                      if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
                    }}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1 cursor-pointer ${
                      isSelected
                        ? 'bg-[#0A66C2] text-white shadow-2xs'
                        : isUnlocked
                        ? 'bg-slate-100 hover:bg-[#0A66C2] hover:text-white text-slate-700'
                        : 'bg-slate-200/80 hover:bg-slate-300 text-slate-600'
                    }`}
                  >
                    <span>{isSelected ? 'Currently Viewing' : isUnlocked ? 'Open Workspace' : 'Preview (Locked)'}</span>
                    <ArrowRight className="w-3 h-3" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Profile Picture Upload & Customization Modal */}
      {photoModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-fadeIn">
          <div className="bg-white max-w-md w-full rounded-2xl shadow-2xl border border-slate-200 p-6 relative">
            <button
              onClick={() => {
                setPhotoModalOpen(false);
                setPhotoError('');
              }}
              className="absolute top-4 right-4 p-1.5 text-slate-400 hover:text-slate-600 rounded-full hover:bg-slate-100 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="text-center mb-5">
              <div className="w-16 h-16 rounded-full bg-blue-50 text-[#0A66C2] flex items-center justify-center mx-auto mb-3 border border-blue-200 shadow-2xs">
                {user.photoURL ? (
                  <img
                    src={user.photoURL}
                    alt={resolvedUserName}
                    className="w-16 h-16 rounded-full object-cover"
                  />
                ) : (
                  <Camera className="w-8 h-8 text-[#0A66C2]" />
                )}
              </div>
              <h3 className="text-lg font-bold text-slate-900">
                {user.photoURL ? 'Update Profile Picture' : 'Add Profile Picture'}
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Upload a personal avatar from your computer or paste an image link.
              </p>
            </div>

            {photoError && (
              <div className="mb-4 p-2.5 bg-rose-50 text-rose-700 text-xs rounded-xl border border-rose-200 flex items-center gap-1.5">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{photoError}</span>
              </div>
            )}

            <div className="space-y-4">
              {/* Option 1: File Upload */}
              <div
                onClick={() => fileInputRef.current?.click()}
                className="p-6 border-2 border-dashed border-[#0A66C2]/40 rounded-xl hover:bg-blue-50/40 transition-colors text-center cursor-pointer group"
              >
                <input
                  type="file"
                  ref={fileInputRef}
                  accept="image/*"
                  onChange={handleFileUpload}
                  className="hidden"
                />
                <Upload className="w-8 h-8 text-[#0A66C2] mx-auto mb-2 group-hover:scale-110 transition-transform" />
                <p className="text-xs font-bold text-slate-800">
                  {uploadingPhoto ? 'Processing photo...' : 'Click to Upload from Device'}
                </p>
                <p className="text-[11px] text-slate-500 mt-1">PNG, JPG, or WebP up to 2.5MB</p>
              </div>

              {/* Option 2: Image URL input */}
              <div className="pt-2 border-t border-slate-100">
                <label className="block text-[11px] font-semibold text-slate-700 mb-1.5">
                  Or Paste Direct Image URL:
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="url"
                    value={photoUrlInput}
                    onChange={(e) => setPhotoUrlInput(e.target.value)}
                    placeholder="https://example.com/my-photo.jpg"
                    className="flex-1 p-2 text-xs border border-slate-300 rounded-lg outline-none focus:border-[#0A66C2]"
                  />
                  <button
                    type="button"
                    onClick={handleSavePhotoUrl}
                    disabled={!photoUrlInput.trim() || uploadingPhoto}
                    className="px-3.5 py-2 bg-[#0A66C2] hover:bg-[#004182] text-white text-xs font-bold rounded-lg transition-colors disabled:opacity-50 cursor-pointer"
                  >
                    Save URL
                  </button>
                </div>
              </div>

              {/* Option 3: Remove photo (leave blank) */}
              {user.photoURL && (
                <div className="pt-2 border-t border-slate-100 flex justify-center">
                  <button
                    type="button"
                    onClick={handleRemovePhoto}
                    className="text-xs text-rose-600 hover:text-rose-800 font-semibold flex items-center gap-1.5 hover:underline cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Remove Profile Photo (Leave Blank)</span>
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Offer Letter Modal for Generating, Viewing & Attaching */}
      <OfferLetterModal
        isOpen={isOfferLetterModalOpen}
        onClose={() => setIsOfferLetterModalOpen(false)}
        user={user ? { ...user, name: resolvedUserName } : undefined}
        internship={activeInternship || undefined}
        onAttachToTask1={(offerData) => {
          setOfferLetterFileName(offerData.fileName);
          setLetterFileName(offerData.fileName);
          setOfferLetterUrl(offerData.url);
          setTask1Type('letter');
          setHasViewedOfferLetter(true);
        }}
      />

      {/* Student AI Evaluation Modal */}
      <StudentEvaluationModal
        isOpen={evalModalOpen}
        onClose={() => setEvalModalOpen(false)}
        evaluation={activeEvaluation}
        isLoading={submitting}
        taskTitle={currentTask?.title}
        taskNumber={selectedTaskNumber}
      />

      {/* Official Project Tasks Guide & Syllabus PDF Modal */}
      {user && activeInternship && (
        <ProjectGuideModal
          isOpen={projectGuideModalOpen}
          onClose={() => setProjectGuideModalOpen(false)}
          user={user}
          internship={activeInternship}
        />
      )}
    </div>
  );
};
