import React from 'react';
import { GraduationCap, Youtube, Github, Linkedin, ShieldCheck, Heart } from 'lucide-react';
import { YOUTUBE_CONFIG } from '../firebase/config';

interface FooterProps {
  setCurrentView: (view: string) => void;
  onSelectDomainByName?: (domainName: string) => void;
  onOpenLegal?: (tab: 'privacy' | 'disclaimer' | 'terms' | 'refund') => void;
}

export const Footer: React.FC<FooterProps> = ({ setCurrentView, onSelectDomainByName, onOpenLegal }) => {
  const handleDomainClick = (domainKeyword: string) => {
    if (onSelectDomainByName) {
      onSelectDomainByName(domainKeyword);
    } else {
      setCurrentView('domains');
    }
  };

  const handleLegalClick = (tab: 'privacy' | 'disclaimer' | 'terms' | 'refund') => {
    if (onOpenLegal) {
      onOpenLegal(tab);
    }
  };

  return (
    <footer className="bg-[#1D2226] text-[#E0DFDC] border-t border-[#38434F]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand info */}
          <div className="space-y-4 md:col-span-1">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-md bg-[#0A66C2] flex items-center justify-center text-white font-black text-sm">
                VI
              </div>
              <span className="text-xl font-bold text-white tracking-tight">VirIntern</span>
            </div>
            <p className="text-sm text-[#A0AAB4] leading-relaxed">
              Empowering students worldwide with practical, project-based virtual internships across high-demand engineering and technology disciplines.
            </p>
            <div className="flex items-center gap-3 pt-2">
              <a
                href={YOUTUBE_CONFIG.channelUrl}
                target="_blank"
                rel="noreferrer"
                className="w-9 h-9 rounded-full bg-[#28333E] hover:bg-red-600 hover:text-white flex items-center justify-center text-[#A0AAB4] transition-colors"
                title="Official YouTube Channel"
              >
                <Youtube className="w-5 h-5" />
              </a>
              <a
                href="https://github.com"
                target="_blank"
                rel="noreferrer"
                className="w-9 h-9 rounded-full bg-[#28333E] hover:bg-[#38434F] hover:text-white flex items-center justify-center text-[#A0AAB4] transition-colors"
                title="GitHub"
              >
                <Github className="w-5 h-5" />
              </a>
              <a
                href="https://linkedin.com"
                target="_blank"
                rel="noreferrer"
                className="w-9 h-9 rounded-full bg-[#28333E] hover:bg-[#0A66C2] hover:text-white flex items-center justify-center text-[#A0AAB4] transition-colors"
                title="LinkedIn"
              >
                <Linkedin className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Internship Domains */}
          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wider text-white mb-3">
              Popular Domains
            </h3>
            <ul className="space-y-2 text-sm text-[#A0AAB4]">
              <li>
                <button
                  onClick={() => handleDomainClick('Web Development')}
                  className="hover:text-white hover:underline transition-colors text-left"
                >
                  Web Development (React/TS)
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleDomainClick('Artificial Intelligence')}
                  className="hover:text-white hover:underline transition-colors text-left"
                >
                  Artificial Intelligence & ML
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleDomainClick('Python')}
                  className="hover:text-white hover:underline transition-colors text-left"
                >
                  Python Programming
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleDomainClick('Java')}
                  className="hover:text-white hover:underline transition-colors text-left"
                >
                  Java Enterprise Services
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleDomainClick('Cybersecurity')}
                  className="hover:text-white hover:underline transition-colors text-left"
                >
                  Cybersecurity Operations
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleDomainClick('Electronics')}
                  className="hover:text-white hover:underline transition-colors text-left"
                >
                  Electronics & Communication (ECE)
                </button>
              </li>
              <li>
                <button
                  onClick={() => setCurrentView('domains')}
                  className="text-xs text-[#0A66C2] hover:text-white hover:underline transition-colors font-semibold pt-1 flex items-center gap-1"
                >
                  Explore All 12+ Tracks →
                </button>
              </li>
            </ul>
          </div>

          {/* Platform Features & Compliance */}
          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wider text-white mb-3">
              Features & Legal
            </h3>
            <ul className="space-y-2 text-sm text-[#A0AAB4]">
              <li>
                <button onClick={() => setCurrentView('premium')} className="hover:text-white hover:underline transition-colors text-left font-medium text-amber-300">
                  ★ Premium Career Suite
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentView('interview_prep')} className="hover:text-white hover:underline transition-colors text-left">
                  1000+ Interview Questions Bank
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentView('resume_builder')} className="hover:text-white hover:underline transition-colors text-left">
                  ATS Resume Builder Kit
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentView('verify_cert')} className="hover:text-white hover:underline transition-colors text-left">
                  Public Certificate Verification
                </button>
              </li>
              <li className="pt-2 border-t border-[#38434F]/80">
                <button
                  onClick={() => handleLegalClick('privacy')}
                  className="text-xs text-white hover:underline transition-colors text-left font-medium"
                >
                  Privacy Policy
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleLegalClick('disclaimer')}
                  className="text-xs text-white hover:underline transition-colors text-left font-medium"
                >
                  Program Disclaimer
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleLegalClick('terms')}
                  className="text-xs text-white hover:underline transition-colors text-left font-medium"
                >
                  Terms & Conditions
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleLegalClick('refund')}
                  className="text-xs text-white hover:underline transition-colors text-left font-medium"
                >
                  Refund Policy
                </button>
              </li>
            </ul>
          </div>

          {/* YouTube & Verification Badge */}
          <div className="bg-[#28333E] p-4 rounded-xl border border-[#38434F] flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 text-red-400 mb-2">
                <Youtube className="w-5 h-5" />
                <span className="text-xs font-bold uppercase tracking-wider text-white">YouTube Community</span>
              </div>
              <p className="text-xs text-[#A0AAB4] mb-3">
                Subscribe to official VirIntern tutorials and task walk-throughs to fulfill Task 1 verification criteria.
              </p>
              <a
                href={YOUTUBE_CONFIG.channelUrl}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-2 px-4 py-2 bg-red-600 hover:bg-red-700 text-white text-xs font-semibold rounded-full transition-colors mb-4"
              >
                Subscribe Now
              </a>
            </div>

            <div className="pt-3 border-t border-[#38434F] text-[11px] text-slate-400">
              <span className="block font-semibold text-slate-300">Support & Compliance:</span>
              <a href="mailto:virintern.in@gmail.com" className="text-blue-400 hover:underline font-mono">
                virintern.in@gmail.com
              </a>
            </div>
          </div>
        </div>

        <div className="border-t border-[#38434F] mt-10 pt-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#8C9AA7]">
          <p>© {new Date().getFullYear()} VirIntern Virtual Internship Portal. All rights reserved.</p>
          <div className="flex flex-wrap items-center gap-4">
            <button
              onClick={() => handleLegalClick('privacy')}
              className="text-white hover:underline transition-colors font-medium"
            >
              Privacy Policy
            </button>
            <span className="text-slate-500">•</span>
            <button
              onClick={() => handleLegalClick('disclaimer')}
              className="text-white hover:underline transition-colors font-medium"
            >
              Disclaimer
            </button>
            <span className="text-slate-500">•</span>
            <button
              onClick={() => handleLegalClick('terms')}
              className="text-white hover:underline transition-colors font-medium"
            >
              Terms
            </button>
            <span className="text-slate-600">•</span>
            <button
              onClick={() => setCurrentView('verify_cert')}
              className="hover:text-white hover:underline transition-colors"
            >
              Verify Certificate
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};
