import React, { useState, useEffect, useMemo } from 'react';
import { useAuth } from '../../context/AuthContext';
import { dataService } from '../../services/dataService';
import {
  CandidateProfileView,
  ShortlistRecord,
  RecruitmentOpportunity,
  CompanyProfile,
  DomainItem,
  ShortlistStatus
} from '../../types';
import {
  Building2,
  Users,
  Trophy,
  Briefcase,
  Search,
  Filter,
  CheckCircle2,
  Clock,
  ShieldAlert,
  ShieldCheck,
  ExternalLink,
  Github,
  Globe,
  FileText,
  Mail,
  UserCheck,
  PlusCircle,
  Download,
  Trash2,
  Edit3,
  ChevronRight,
  ArrowUpDown,
  Sparkles,
  Info,
  X,
  AlertCircle
} from 'lucide-react';

interface CompanyPortalProps {
  setCurrentView: (view: string) => void;
}

export const CompanyPortal: React.FC<CompanyPortalProps> = ({ setCurrentView }) => {
  const { user, companyProfile: authCompanyProfile, logout } = useAuth();
  const [activeTab, setActiveTab] = useState<'leaderboard' | 'discover' | 'shortlisted' | 'opportunities' | 'profile'>('leaderboard');

  // Company state
  const [company, setCompany] = useState<CompanyProfile | null>(authCompanyProfile);
  const [loadingCompany, setLoadingCompany] = useState<boolean>(!authCompanyProfile);

  // Candidates & Leaderboard state
  const [candidates, setCandidates] = useState<CandidateProfileView[]>([]);
  const [loadingCandidates, setLoadingCandidates] = useState<boolean>(true);
  const [domains, setDomains] = useState<DomainItem[]>([]);

  // Filters & Search state
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDomain, setSelectedDomain] = useState<string>('all');
  const [minScoreFilter, setMinScoreFilter] = useState<number>(0);
  const [statusFilter, setStatusFilter] = useState<'all' | 'completed' | 'active'>('all');
  const [sortBy, setSortBy] = useState<'rank' | 'score' | 'progress' | 'recent'>('rank');

  // Shortlists state
  const [shortlists, setShortlists] = useState<ShortlistRecord[]>([]);
  const [loadingShortlists, setLoadingShortlists] = useState<boolean>(true);

  // Opportunities state
  const [opportunities, setOpportunities] = useState<RecruitmentOpportunity[]>([]);
  const [loadingOpps, setLoadingOpps] = useState<boolean>(true);
  const [oppModalOpen, setOppModalOpen] = useState(false);
  const [newOppTitle, setNewOppTitle] = useState('');
  const [newOppDomain, setNewOppDomain] = useState('');
  const [newOppSkills, setNewOppSkills] = useState('');
  const [newOppDesc, setNewOppDesc] = useState('');
  const [newOppLocationType, setNewOppLocationType] = useState<'Remote' | 'Hybrid' | 'On-site'>('Remote');
  const [newOppLocation, setNewOppLocation] = useState('');
  const [newOppStipend, setNewOppStipend] = useState('');
  const [newOppDeadline, setNewOppDeadline] = useState('');
  const [savingOpp, setSavingOpp] = useState(false);

  // Candidate detail modal state
  const [selectedCandidate, setSelectedCandidate] = useState<CandidateProfileView | null>(null);
  const [candidateModalOpen, setCandidateModalOpen] = useState(false);

  // Shortlist action modal
  const [shortlistModalOpen, setShortlistModalOpen] = useState(false);
  const [shortlistCandidateTarget, setShortlistCandidateTarget] = useState<CandidateProfileView | null>(null);
  const [shortlistRoleTitle, setShortlistRoleTitle] = useState('Junior Software Engineer / Intern');
  const [shortlistNotes, setShortlistNotes] = useState('');
  const [savingShortlist, setSavingShortlist] = useState(false);

  // Profile Edit State
  const [editingProfile, setEditingProfile] = useState(false);
  const [profileName, setProfileName] = useState('');
  const [profileWebsite, setProfileWebsite] = useState('');
  const [profileIndustry, setProfileIndustry] = useState('');
  const [profileDesc, setProfileDesc] = useState('');
  const [profileContact, setProfileContact] = useState('');
  const [profileDesignation, setProfileDesignation] = useState('');
  const [profileSkills, setProfileSkills] = useState('');
  const [profileHiringNeeds, setProfileHiringNeeds] = useState('');
  const [savingProfile, setSavingProfile] = useState(false);
  const [saveSuccessMsg, setSaveSuccessMsg] = useState('');

  // Toast / feedback message
  const [toastMsg, setToastMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const showToast = (text: string, type: 'success' | 'error' = 'success') => {
    setToastMsg({ type, text });
    setTimeout(() => setToastMsg(null), 4000);
  };

  const companyId = company?.id || user?.companyId || user?.uid || '';

  // 1. Load Company Profile
  useEffect(() => {
    if (user?.uid) {
      dataService.getCompany(user.companyId || user.uid).then(comp => {
        if (comp) {
          setCompany(comp);
          setProfileName(comp.name);
          setProfileWebsite(comp.website);
          setProfileIndustry(comp.industry);
          setProfileDesc(comp.description);
          setProfileContact(comp.contactPerson);
          setProfileDesignation(comp.designation);
          setProfileSkills(comp.preferredSkills?.join(', ') || '');
          setProfileHiringNeeds(comp.hiringRequirements?.join(', ') || '');
        }
        setLoadingCompany(false);
      });
    }
  }, [user?.uid, user?.companyId]);

  // 2. Load Domains
  useEffect(() => {
    dataService.getDomains().then(setDomains);
  }, []);

  // 3. Load Candidates
  useEffect(() => {
    setLoadingCandidates(true);
    const unsub = dataService.subscribeCandidates((data) => {
      setCandidates(data);
      setLoadingCandidates(false);
    });
    return () => unsub();
  }, []);

  // 4. Load Shortlists
  useEffect(() => {
    if (companyId) {
      setLoadingShortlists(true);
      const unsub = dataService.subscribeShortlists(companyId, (list) => {
        setShortlists(list);
        setLoadingShortlists(false);
      });
      return () => unsub();
    }
  }, [companyId]);

  // 5. Load Opportunities
  useEffect(() => {
    if (companyId) {
      setLoadingOpps(true);
      dataService.getOpportunities(companyId).then(list => {
        setOpportunities(list);
        setLoadingOpps(false);
      });
    }
  }, [companyId]);

  // Status check: Is company approved?
  const isApproved = company?.verificationStatus === 'approved';
  const isPending = !company || company.verificationStatus === 'pending_verification';
  const isSuspended = company?.verificationStatus === 'suspended';

  // Filtered and Sorted Candidates
  const filteredCandidates = useMemo(() => {
    return candidates
      .filter((c) => {
        // Domain Filter
        if (selectedDomain !== 'all' && c.domainId !== selectedDomain) {
          return false;
        }
        // Score Filter
        if (minScoreFilter > 0 && c.averageScore < minScoreFilter) {
          return false;
        }
        // Status Filter
        if (statusFilter !== 'all' && c.internshipStatus !== statusFilter) {
          return false;
        }
        // Search Filter
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          const matchName = c.displayName.toLowerCase().includes(q);
          const matchDomain = c.domainName.toLowerCase().includes(q);
          const matchSkills = c.skills.some((s) => s.toLowerCase().includes(q));
          if (!matchName && !matchDomain && !matchSkills) return false;
        }
        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'rank') return a.rank - b.rank;
        if (sortBy === 'score') return b.averageScore - a.averageScore;
        if (sortBy === 'progress') return b.progress - a.progress;
        if (sortBy === 'recent') {
          return new Date(b.lastActive).getTime() - new Date(a.lastActive).getTime();
        }
        return 0;
      });
  }, [candidates, selectedDomain, minScoreFilter, statusFilter, searchQuery, sortBy]);

  // Handle Shortlist Submission
  const handleConfirmShortlist = async () => {
    if (!shortlistCandidateTarget || !companyId) return;
    setSavingShortlist(true);
    try {
      await dataService.addToShortlist({
        companyId,
        companyName: company?.name || 'Verified Corporate Partner',
        studentId: shortlistCandidateTarget.studentId,
        studentName: shortlistCandidateTarget.displayName,
        studentEmail: isApproved ? `${shortlistCandidateTarget.studentId.slice(0, 6)}@student.virintern.com` : 'Contact protected until verified',
        studentDomain: shortlistCandidateTarget.domainName,
        roleOrOpportunityTitle: shortlistRoleTitle.trim() || 'Internship / Junior Role',
        status: 'shortlisted',
        privateNotes: shortlistNotes.trim()
      });
      showToast(`Added ${shortlistCandidateTarget.displayName} to your talent shortlist!`);
      setShortlistModalOpen(false);
      setShortlistCandidateTarget(null);
      setShortlistNotes('');
    } catch {
      showToast('Failed to shortlist student candidate.', 'error');
    } finally {
      setSavingShortlist(false);
    }
  };

  // Remove Shortlist
  const handleRemoveShortlist = async (id: string, name: string) => {
    try {
      await dataService.removeFromShortlist(id, companyId);
      showToast(`Removed ${name} from your shortlist.`);
    } catch {
      showToast('Failed to remove candidate.', 'error');
    }
  };

  // Update Shortlist Status
  const handleUpdateShortlistStatus = async (id: string, status: ShortlistStatus) => {
    try {
      await dataService.updateShortlist(id, { status });
      showToast('Candidate shortlist status updated.');
    } catch {
      showToast('Failed to update status.', 'error');
    }
  };

  // Post Recruitment Opportunity
  const handleCreateOpportunity = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!companyId || !newOppTitle.trim() || !newOppDesc.trim()) {
      showToast('Title and Description are required.', 'error');
      return;
    }
    setSavingOpp(true);
    try {
      const skillsArr = newOppSkills.split(',').map(s => s.trim()).filter(Boolean);
      await dataService.createOpportunity({
        companyId,
        companyName: company?.name || 'Corporate Partner',
        title: newOppTitle.trim(),
        domainId: newOppDomain || undefined,
        domainName: domains.find(d => d.id === newOppDomain)?.name,
        requiredSkills: skillsArr,
        description: newOppDesc.trim(),
        locationType: newOppLocationType,
        location: newOppLocation.trim() || undefined,
        stipendOrSalary: newOppStipend.trim() || undefined,
        deadline: newOppDeadline || new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
      });
      const refreshed = await dataService.getOpportunities(companyId);
      setOpportunities(refreshed);
      setOppModalOpen(false);
      setNewOppTitle('');
      setNewOppDesc('');
      setNewOppSkills('');
      setNewOppLocation('');
      setNewOppStipend('');
      showToast('Recruitment opportunity submitted! It is now pending admin approval.');
    } catch {
      showToast('Failed to submit recruitment opportunity.', 'error');
    } finally {
      setSavingOpp(false);
    }
  };

  // Save Profile Changes
  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!companyId) return;
    setSavingProfile(true);
    try {
      const updated = await dataService.updateCompany(companyId, {
        name: profileName.trim(),
        website: profileWebsite.trim(),
        industry: profileIndustry.trim(),
        description: profileDesc.trim(),
        contactPerson: profileContact.trim(),
        designation: profileDesignation.trim(),
        preferredSkills: profileSkills.split(',').map(s => s.trim()).filter(Boolean),
        hiringRequirements: profileHiringNeeds.split(',').map(s => s.trim()).filter(Boolean)
      });
      setCompany(updated);
      setEditingProfile(false);
      setSaveSuccessMsg('Company profile updated successfully.');
      setTimeout(() => setSaveSuccessMsg(''), 4000);
      showToast('Company profile updated.');
    } catch {
      showToast('Failed to update company profile.', 'error');
    } finally {
      setSavingProfile(false);
    }
  };

  // Export Shortlisted Candidates to CSV
  const handleExportCSV = () => {
    if (shortlists.length === 0) {
      showToast('No candidates currently shortlisted to export.', 'error');
      return;
    }
    const headers = ['Student ID', 'Student Name', 'Target Domain', 'Recruitment Role', 'Status', 'Private Notes', 'Shortlisted Date'];
    const rows = shortlists.map(s => [
      `"${s.studentId}"`,
      `"${s.studentName}"`,
      `"${s.studentDomain || ''}"`,
      `"${s.roleOrOpportunityTitle}"`,
      `"${s.status}"`,
      `"${(s.privateNotes || '').replace(/"/g, '""')}"`,
      `"${new Date(s.createdAt).toLocaleDateString()}"`
    ]);
    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `VirIntern_Talent_Shortlist_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast('Exported candidate shortlist to CSV.');
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 pb-20">
      {/* Toast Feedback */}
      {toastMsg && (
        <div
          className={`fixed bottom-6 right-6 z-50 flex items-center gap-2 px-4 py-3 rounded-xl shadow-lg text-sm font-semibold transition-all ${
            toastMsg.type === 'success'
              ? 'bg-emerald-800 text-white border border-emerald-700'
              : 'bg-rose-800 text-white border border-rose-700'
          }`}
        >
          {toastMsg.type === 'success' ? <CheckCircle2 className="w-4 h-4 text-emerald-300" /> : <AlertCircle className="w-4 h-4 text-rose-300" />}
          <span>{toastMsg.text}</span>
        </div>
      )}

      {/* Corporate Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-30 shadow-2xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-[#004182] to-[#0A66C2] flex items-center justify-center text-white font-bold shadow-xs">
                <Building2 className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h1 className="text-base sm:text-lg font-bold text-slate-900 tracking-tight">
                    {company?.name || 'Corporate Partner Portal'}
                  </h1>
                  {isApproved && (
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
                      <ShieldCheck className="w-3.5 h-3.5" />
                      Verified Partner
                    </span>
                  )}
                  {isPending && (
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-semibold bg-amber-50 text-amber-800 border border-amber-200">
                      <Clock className="w-3.5 h-3.5" />
                      Verification Pending
                    </span>
                  )}
                  {isSuspended && (
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-semibold bg-rose-50 text-rose-800 border border-rose-200">
                      <ShieldAlert className="w-3.5 h-3.5" />
                      Account Suspended
                    </span>
                  )}
                </div>
                <p className="text-xs text-slate-500 font-medium">VirIntern Talent Discovery & Recruitment Workspace</p>
              </div>
            </div>

            {/* Quick Actions & Exit */}
            <div className="flex items-center gap-2 sm:gap-3">
              <button
                type="button"
                onClick={() => setOppModalOpen(true)}
                className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg bg-[#0A66C2] text-white hover:bg-[#004182] transition-colors shadow-2xs cursor-pointer"
              >
                <PlusCircle className="w-3.5 h-3.5" />
                Post Role
              </button>
              <button
                type="button"
                onClick={logout}
                className="px-3 py-1.5 text-xs font-medium text-slate-600 hover:text-rose-600 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
              >
                Sign Out
              </button>
            </div>
          </div>

          {/* Navigation Tabs */}
          <nav className="flex space-x-1 sm:space-x-4 border-t border-slate-100 overflow-x-auto py-1">
            <button
              type="button"
              onClick={() => setActiveTab('leaderboard')}
              className={`px-3 py-2 text-xs sm:text-sm font-semibold transition-colors border-b-2 whitespace-nowrap cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'leaderboard'
                  ? 'border-[#0A66C2] text-[#0A66C2]'
                  : 'border-transparent text-slate-600 hover:text-slate-900'
              }`}
            >
              <Trophy className="w-4 h-4" />
              <span>Talent Leaderboard</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('discover')}
              className={`px-3 py-2 text-xs sm:text-sm font-semibold transition-colors border-b-2 whitespace-nowrap cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'discover'
                  ? 'border-[#0A66C2] text-[#0A66C2]'
                  : 'border-transparent text-slate-600 hover:text-slate-900'
              }`}
            >
              <Users className="w-4 h-4" />
              <span>Discover Candidates</span>
              <span className="text-[11px] font-mono text-slate-500">({candidates.length})</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('shortlisted')}
              className={`px-3 py-2 text-xs sm:text-sm font-semibold transition-colors border-b-2 whitespace-nowrap cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'shortlisted'
                  ? 'border-[#0A66C2] text-[#0A66C2]'
                  : 'border-transparent text-slate-600 hover:text-slate-900'
              }`}
            >
              <UserCheck className="w-4 h-4" />
              <span>Shortlisted</span>
              {shortlists.length > 0 && (
                <span className="px-1.5 py-0.2 rounded text-[10px] font-bold bg-[#0A66C2] text-white">
                  {shortlists.length}
                </span>
              )}
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('opportunities')}
              className={`px-3 py-2 text-xs sm:text-sm font-semibold transition-colors border-b-2 whitespace-nowrap cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'opportunities'
                  ? 'border-[#0A66C2] text-[#0A66C2]'
                  : 'border-transparent text-slate-600 hover:text-slate-900'
              }`}
            >
              <Briefcase className="w-4 h-4" />
              <span>Recruitment Postings</span>
              {opportunities.length > 0 && (
                <span className="text-[11px] font-mono text-slate-500">({opportunities.length})</span>
              )}
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('profile')}
              className={`px-3 py-2 text-xs sm:text-sm font-semibold transition-colors border-b-2 whitespace-nowrap cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'profile'
                  ? 'border-[#0A66C2] text-[#0A66C2]'
                  : 'border-transparent text-slate-600 hover:text-slate-900'
              }`}
            >
              <Building2 className="w-4 h-4" />
              <span>Company Profile</span>
            </button>
          </nav>
        </div>
      </header>

      {/* Main Workspace */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6">
        {/* Verification Alert Banner for Pending/Suspended Accounts */}
        {isPending && (
          <div className="mb-6 p-4 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 flex items-start gap-3">
            <Clock className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
            <div className="flex-1">
              <h3 className="text-sm font-bold text-amber-900">Company Account Pending Admin Verification</h3>
              <p className="text-xs text-amber-800 mt-0.5 leading-relaxed">
                Thank you for registering with VirIntern! Your corporate account is currently being reviewed by the VirIntern Admin team.
                To maintain ethical student recruitment and protect privacy, direct contact details and full resumes will unlock once verified.
                You can explore the verified performance leaderboard, build your shortlist, and post hiring opportunities in the meantime.
              </p>
            </div>
          </div>
        )}

        {isSuspended && (
          <div className="mb-6 p-4 rounded-xl bg-rose-50 border border-rose-200 text-rose-900 flex items-start gap-3">
            <ShieldAlert className="w-5 h-5 text-rose-700 shrink-0 mt-0.5" />
            <div>
              <h3 className="text-sm font-bold text-rose-900">Corporate Access Suspended</h3>
              <p className="text-xs text-rose-800 mt-0.5">
                Your company's recruitment access has been temporarily suspended by an administrator. Please reach out to <a href="mailto:admin@virintern.com" className="underline font-semibold">admin@virintern.com</a> to appeal.
              </p>
            </div>
          </div>
        )}

        {/* TAB 1: TALENT LEADERBOARD */}
        {activeTab === 'leaderboard' && (
          <div className="space-y-6">
            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-2">
                  <Trophy className="w-5 h-5 text-amber-600" />
                  <h2 className="text-lg font-bold text-slate-900">Verified Talent Leaderboard</h2>
                </div>
                <p className="text-xs text-slate-500 mt-1">
                  Transparent, performance-based ranking calculated strictly from approved milestone submissions, rubrics, and project deliverables.
                </p>
              </div>

              {/* Domain Switcher */}
              <div className="flex items-center gap-2">
                <span className="text-xs font-semibold text-slate-600">Track:</span>
                <select
                  value={selectedDomain}
                  onChange={(e) => setSelectedDomain(e.target.value)}
                  className="px-3 py-1.5 text-xs font-medium bg-slate-50 border border-slate-300 rounded-lg text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#0A66C2]"
                >
                  <option value="all">All Internship Tracks</option>
                  {domains.map((d) => (
                    <option key={d.id} value={d.id}>{d.name}</option>
                  ))}
                </select>
              </div>
            </div>

            {/* Leaderboard Table */}
            <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
              {loadingCandidates ? (
                <div className="py-16 text-center text-slate-500 text-sm">
                  <div className="w-6 h-6 border-2 border-[#0A66C2] border-t-transparent rounded-full animate-spin mx-auto mb-2" />
                  Loading verified student standings...
                </div>
              ) : filteredCandidates.length === 0 ? (
                <div className="py-16 text-center text-slate-500 text-sm">
                  <p className="font-semibold text-slate-700">No candidates found for this track.</p>
                  <p className="text-xs text-slate-400 mt-1">Students will appear here as soon as their projects are verified by VirIntern mentors.</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 uppercase font-bold tracking-wider text-[11px]">
                      <tr>
                        <th className="py-3 px-4 w-14 text-center">Rank</th>
                        <th className="py-3 px-4">Student Candidate</th>
                        <th className="py-3 px-4">Track</th>
                        <th className="py-3 px-4 text-center">Progress</th>
                        <th className="py-3 px-4 text-center">Avg Score</th>
                        <th className="py-3 px-4 text-center">Verified Tasks</th>
                        <th className="py-3 px-4">Demonstrated Skills</th>
                        <th className="py-3 px-4 text-right">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 font-medium">
                      {filteredCandidates.map((c) => {
                        const isShortlisted = shortlists.some(s => s.studentId === c.studentId);
                        return (
                          <tr key={c.studentId} className="hover:bg-slate-50/70 transition-colors">
                            {/* Rank */}
                            <td className="py-3.5 px-4 text-center font-bold">
                              {c.rank === 1 ? (
                                <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-amber-100 text-amber-800 text-xs">🥇</span>
                              ) : c.rank === 2 ? (
                                <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-slate-200 text-slate-700 text-xs">🥈</span>
                              ) : c.rank === 3 ? (
                                <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-orange-100 text-orange-800 text-xs">🥉</span>
                              ) : (
                                <span className="text-slate-500 font-mono">#{c.rank}</span>
                              )}
                            </td>

                            {/* Student */}
                            <td className="py-3.5 px-4">
                              <div className="flex items-center gap-2.5">
                                <div className="w-8 h-8 rounded-full bg-blue-100 text-[#0A66C2] font-bold text-xs flex items-center justify-center shrink-0">
                                  {c.displayName.charAt(0).toUpperCase()}
                                </div>
                                <div>
                                  <button
                                    type="button"
                                    onClick={() => {
                                      setSelectedCandidate(c);
                                      setCandidateModalOpen(true);
                                    }}
                                    className="font-bold text-slate-900 hover:text-[#0A66C2] transition-colors text-left"
                                  >
                                    {c.displayName}
                                  </button>
                                  <div className="flex items-center gap-1.5 text-[11px] text-slate-500">
                                    <span>Verified Fellow</span>
                                    {c.internshipStatus === 'completed' && (
                                      <>
                                        <span aria-hidden="true">·</span>
                                        <span className="text-emerald-600 font-semibold">Completed</span>
                                      </>
                                    )}
                                  </div>
                                </div>
                              </div>
                            </td>

                            {/* Domain */}
                            <td className="py-3.5 px-4 text-slate-700">
                              {c.domainName}
                            </td>

                            {/* Progress */}
                            <td className="py-3.5 px-4 text-center">
                              <div className="inline-flex flex-col items-center">
                                <span className="font-bold text-slate-900">{c.progress}%</span>
                                <div className="w-16 bg-slate-200 h-1.5 rounded-full overflow-hidden mt-1">
                                  <div
                                    className="bg-[#0A66C2] h-full"
                                    style={{ width: `${c.progress}%` }}
                                  />
                                </div>
                              </div>
                            </td>

                            {/* Score */}
                            <td className="py-3.5 px-4 text-center">
                              <span className={`font-bold ${c.averageScore >= 85 ? 'text-emerald-700' : 'text-slate-800'}`}>
                                {c.averageScore}/100
                              </span>
                            </td>

                            {/* Tasks Completed */}
                            <td className="py-3.5 px-4 text-center font-mono text-slate-700">
                              {c.completedTasksCount} / 5
                            </td>

                            {/* Skills */}
                            <td className="py-3.5 px-4">
                              <div className="flex items-center gap-1 text-[11px] text-slate-600 max-w-xs truncate">
                                <span>{c.skills.slice(0, 3).join(', ')}</span>
                                {c.skills.length > 3 && <span className="text-slate-400">+{c.skills.length - 3}</span>}
                              </div>
                            </td>

                            {/* Actions */}
                            <td className="py-3.5 px-4 text-right">
                              <div className="flex items-center justify-end gap-1.5">
                                <button
                                  type="button"
                                  onClick={() => {
                                    setSelectedCandidate(c);
                                    setCandidateModalOpen(true);
                                  }}
                                  className="px-2.5 py-1 text-[11px] font-semibold text-slate-700 hover:text-slate-900 hover:bg-slate-100 rounded-md transition-colors cursor-pointer"
                                >
                                  View
                                </button>

                                <button
                                  type="button"
                                  onClick={() => {
                                    setShortlistCandidateTarget(c);
                                    setShortlistModalOpen(true);
                                  }}
                                  disabled={isShortlisted}
                                  className={`px-3 py-1 text-[11px] font-bold rounded-md transition-colors cursor-pointer ${
                                    isShortlisted
                                      ? 'bg-slate-100 text-slate-400 cursor-not-allowed'
                                      : 'bg-[#0A66C2] text-white hover:bg-[#004182]'
                                  }`}
                                >
                                  {isShortlisted ? 'Shortlisted' : 'Shortlist'}
                                </button>
                              </div>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        )}

        {/* TAB 2: DISCOVER CANDIDATES */}
        {activeTab === 'discover' && (
          <div className="space-y-6">
            {/* Search & Filter Bar */}
            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs space-y-4">
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
                <div className="relative flex-1">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search candidates by name, tech stack, or skills (e.g. React, Python, ML)..."
                    className="w-full pl-9 pr-4 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0A66C2] focus:bg-white"
                  />
                  {searchQuery && (
                    <button
                      type="button"
                      onClick={() => setSearchQuery('')}
                      className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-600"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-xs font-semibold text-slate-500 whitespace-nowrap">Sort:</span>
                  <select
                    value={sortBy}
                    onChange={(e) => setSortBy(e.target.value as any)}
                    className="px-3 py-2 text-xs font-medium bg-slate-50 border border-slate-300 rounded-lg text-slate-800 focus:outline-none focus:ring-2 focus:ring-[#0A66C2]"
                  >
                    <option value="rank">Leaderboard Rank</option>
                    <option value="score">Assessment Score</option>
                    <option value="progress">Completion %</option>
                    <option value="recent">Recent Activity</option>
                  </select>
                </div>
              </div>

              {/* Sub-Filters */}
              <div className="flex flex-wrap items-center gap-3 pt-3 border-t border-slate-100 text-xs">
                <div className="flex items-center gap-1.5">
                  <Filter className="w-3.5 h-3.5 text-slate-400" />
                  <span className="font-semibold text-slate-700">Filters:</span>
                </div>

                {/* Domain Selector */}
                <select
                  value={selectedDomain}
                  onChange={(e) => setSelectedDomain(e.target.value)}
                  className="px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-md font-medium text-slate-700"
                >
                  <option value="all">All Domains</option>
                  {domains.map((d) => (
                    <option key={d.id} value={d.id}>{d.name}</option>
                  ))}
                </select>

                {/* Min Score Selector */}
                <select
                  value={minScoreFilter}
                  onChange={(e) => setMinScoreFilter(Number(e.target.value))}
                  className="px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-md font-medium text-slate-700"
                >
                  <option value={0}>Any Score</option>
                  <option value={70}>70%+ (Passing)</option>
                  <option value={80}>80%+ (High Performing)</option>
                  <option value={90}>90%+ (Top Tier)</option>
                </select>

                {/* Completion Status */}
                <select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value as any)}
                  className="px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-md font-medium text-slate-700"
                >
                  <option value="all">All Internship Statuses</option>
                  <option value="completed">Completed Internships</option>
                  <option value="active">Active & In-Progress</option>
                </select>

                {(selectedDomain !== 'all' || minScoreFilter > 0 || statusFilter !== 'all' || searchQuery) && (
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedDomain('all');
                      setMinScoreFilter(0);
                      setStatusFilter('all');
                      setSearchQuery('');
                    }}
                    className="text-xs text-[#0A66C2] font-semibold hover:underline"
                  >
                    Reset filters
                  </button>
                )}

                <span className="ml-auto text-xs text-slate-500 font-medium">
                  Showing <strong>{filteredCandidates.length}</strong> eligible candidates
                </span>
              </div>
            </div>

            {/* Candidate Grid */}
            {filteredCandidates.length === 0 ? (
              <div className="bg-white p-12 rounded-xl border border-slate-200 text-center text-slate-500">
                <Users className="w-10 h-10 text-slate-300 mx-auto mb-2" />
                <h3 className="text-sm font-bold text-slate-700">No matching candidates found</h3>
                <p className="text-xs text-slate-400 mt-1">Try adjusting your search terms or filters.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                {filteredCandidates.map((c) => {
                  const isShortlisted = shortlists.some(s => s.studentId === c.studentId);
                  return (
                    <div
                      key={c.studentId}
                      className="bg-white rounded-xl border border-slate-200 p-5 shadow-2xs hover:shadow-xs transition-shadow flex flex-col justify-between"
                    >
                      <div>
                        {/* Top Meta */}
                        <div className="flex items-start justify-between gap-3">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-full bg-blue-100 text-[#0A66C2] font-bold text-sm flex items-center justify-center shrink-0">
                              {c.displayName.charAt(0).toUpperCase()}
                            </div>
                            <div>
                              <h4 className="font-bold text-slate-900 text-sm leading-snug">
                                {c.displayName}
                              </h4>
                              <div className="flex items-center gap-1.5 text-xs text-slate-500">
                                <span>Rank #{c.rank}</span>
                                <span aria-hidden="true">·</span>
                                <span>{c.domainName}</span>
                              </div>
                            </div>
                          </div>

                          <div className="text-right">
                            <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                              {c.averageScore}/100
                            </span>
                          </div>
                        </div>

                        {/* Bio / Summary */}
                        <p className="text-xs text-slate-600 mt-3 line-clamp-2 leading-relaxed">
                          {c.bio || `Specialized in ${c.domainName} with verified deliverables.`}
                        </p>

                        {/* Practical Deliverables Highlights */}
                        <div className="mt-4 pt-3 border-t border-slate-100">
                          <div className="flex items-center justify-between text-xs text-slate-500 mb-1.5">
                            <span className="font-medium">Milestones Completed:</span>
                            <span className="font-mono font-bold text-slate-800">{c.completedTasksCount} / 5</span>
                          </div>
                          <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                            <div
                              className="bg-[#0A66C2] h-full transition-all"
                              style={{ width: `${c.progress}%` }}
                            />
                          </div>
                        </div>

                        {/* Skills */}
                        <div className="mt-3.5 flex flex-wrap gap-1 text-[11px] text-slate-700">
                          {c.skills.slice(0, 4).map((skill) => (
                            <span key={skill} className="px-2 py-0.5 bg-slate-100 rounded text-slate-700">
                              {skill}
                            </span>
                          ))}
                          {c.skills.length > 4 && (
                            <span className="px-1.5 py-0.5 text-slate-400 font-medium">+{c.skills.length - 4}</span>
                          )}
                        </div>
                      </div>

                      {/* Footer Actions */}
                      <div className="mt-5 pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
                        <button
                          type="button"
                          onClick={() => {
                            setSelectedCandidate(c);
                            setCandidateModalOpen(true);
                          }}
                          className="px-3 py-1.5 text-xs font-semibold text-slate-700 hover:text-[#0A66C2] hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
                        >
                          View Full Portfolio
                        </button>

                        <button
                          type="button"
                          onClick={() => {
                            setShortlistCandidateTarget(c);
                            setShortlistModalOpen(true);
                          }}
                          disabled={isShortlisted}
                          className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-colors cursor-pointer flex items-center gap-1.5 ${
                            isShortlisted
                              ? 'bg-slate-100 text-slate-400 cursor-not-allowed'
                              : 'bg-[#0A66C2] text-white hover:bg-[#004182]'
                          }`}
                        >
                          <UserCheck className="w-3.5 h-3.5" />
                          <span>{isShortlisted ? 'Shortlisted' : 'Shortlist'}</span>
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* TAB 3: SHORTLISTED CANDIDATES */}
        {activeTab === 'shortlisted' && (
          <div className="space-y-6">
            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-2">
                  <UserCheck className="w-5 h-5 text-[#0A66C2]" />
                  <h2 className="text-lg font-bold text-slate-900">Shortlisted Candidates</h2>
                </div>
                <p className="text-xs text-slate-500 mt-1">
                  Manage candidate pipeline, update recruitment statuses, record private evaluation notes, and export reports.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleExportCSV}
                  className="px-3.5 py-1.5 text-xs font-semibold rounded-lg bg-white border border-slate-300 text-slate-700 hover:bg-slate-50 transition-colors shadow-2xs flex items-center gap-1.5 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5 text-slate-500" />
                  <span>Export to CSV</span>
                </button>
              </div>
            </div>

            {loadingShortlists ? (
              <div className="bg-white p-12 rounded-xl border border-slate-200 text-center text-slate-500 text-sm">
                <div className="w-6 h-6 border-2 border-[#0A66C2] border-t-transparent rounded-full animate-spin mx-auto mb-2" />
                Loading your shortlist pipeline...
              </div>
            ) : shortlists.length === 0 ? (
              <div className="bg-white p-12 rounded-xl border border-slate-200 text-center text-slate-500">
                <Users className="w-10 h-10 text-slate-300 mx-auto mb-2" />
                <h3 className="text-sm font-bold text-slate-700">No candidates shortlisted yet</h3>
                <p className="text-xs text-slate-400 mt-1">
                  Explore the <strong>Talent Leaderboard</strong> or <strong>Discover Candidates</strong> tab to review and shortlist students.
                </p>
                <button
                  type="button"
                  onClick={() => setActiveTab('discover')}
                  className="mt-4 px-4 py-2 text-xs font-bold rounded-lg bg-[#0A66C2] text-white hover:bg-[#004182] transition-colors cursor-pointer"
                >
                  Discover Candidates Now
                </button>
              </div>
            ) : (
              <div className="bg-white rounded-xl border border-slate-200 shadow-2xs overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 uppercase font-bold tracking-wider text-[11px]">
                      <tr>
                        <th className="py-3 px-4">Candidate</th>
                        <th className="py-3 px-4">Track</th>
                        <th className="py-3 px-4">Opportunity / Role</th>
                        <th className="py-3 px-4">Pipeline Status</th>
                        <th className="py-3 px-4">Private Company Notes</th>
                        <th className="py-3 px-4">Shortlisted Date</th>
                        <th className="py-3 px-4 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 font-medium">
                      {shortlists.map((s) => {
                        const matchedCandidate = candidates.find(c => c.studentId === s.studentId);
                        return (
                          <tr key={s.id} className="hover:bg-slate-50/70 transition-colors">
                            <td className="py-3.5 px-4">
                              <div className="font-bold text-slate-900">{s.studentName}</div>
                              <div className="text-[11px] text-slate-500">{s.studentEmail}</div>
                            </td>

                            <td className="py-3.5 px-4 text-slate-700">
                              {s.studentDomain || 'Web Development'}
                            </td>

                            <td className="py-3.5 px-4 font-semibold text-slate-800">
                              {s.roleOrOpportunityTitle}
                            </td>

                            <td className="py-3.5 px-4">
                              <select
                                value={s.status}
                                onChange={(e) => handleUpdateShortlistStatus(s.id, e.target.value as ShortlistStatus)}
                                className="px-2 py-1 text-xs rounded border border-slate-300 bg-white font-medium text-slate-800 focus:outline-none focus:ring-1 focus:ring-[#0A66C2]"
                              >
                                <option value="shortlisted">Shortlisted</option>
                                <option value="under_review">Under Review</option>
                                <option value="contacted">Contacted / Interview</option>
                                <option value="rejected">Not Moving Forward</option>
                              </select>
                            </td>

                            <td className="py-3.5 px-4 max-w-xs">
                              <p className="text-slate-600 italic text-xs truncate">
                                {s.privateNotes || <span className="text-slate-400 not-italic">No private notes recorded.</span>}
                              </p>
                            </td>

                            <td className="py-3.5 px-4 text-slate-500">
                              {new Date(s.createdAt).toLocaleDateString()}
                            </td>

                            <td className="py-3.5 px-4 text-right">
                              <div className="flex items-center justify-end gap-2">
                                {matchedCandidate && (
                                  <button
                                    type="button"
                                    onClick={() => {
                                      setSelectedCandidate(matchedCandidate);
                                      setCandidateModalOpen(true);
                                    }}
                                    className="p-1 text-slate-500 hover:text-[#0A66C2] rounded transition-colors"
                                    title="View Portfolio"
                                  >
                                    <ExternalLink className="w-4 h-4" />
                                  </button>
                                )}
                                <button
                                  type="button"
                                  onClick={() => handleRemoveShortlist(s.id, s.studentName)}
                                  className="p-1 text-slate-400 hover:text-rose-600 rounded transition-colors cursor-pointer"
                                  title="Remove from shortlist"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </button>
                              </div>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
        )}

        {/* TAB 4: RECRUITMENT OPPORTUNITIES */}
        {activeTab === 'opportunities' && (
          <div className="space-y-6">
            <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-2">
                  <Briefcase className="w-5 h-5 text-[#0A66C2]" />
                  <h2 className="text-lg font-bold text-slate-900">Recruitment Opportunities</h2>
                </div>
                <p className="text-xs text-slate-500 mt-1">
                  Post open virtual internships, junior engineering roles, or apprenticeships. VirIntern Admin approves listings for student visibility.
                </p>
              </div>

              <button
                type="button"
                onClick={() => setOppModalOpen(true)}
                className="px-4 py-2 text-xs font-bold rounded-lg bg-[#0A66C2] text-white hover:bg-[#004182] transition-colors shadow-2xs flex items-center gap-1.5 cursor-pointer self-start sm:self-auto"
              >
                <PlusCircle className="w-4 h-4" />
                <span>Create New Posting</span>
              </button>
            </div>

            {loadingOpps ? (
              <div className="bg-white p-12 rounded-xl border border-slate-200 text-center text-slate-500 text-sm">
                <div className="w-6 h-6 border-2 border-[#0A66C2] border-t-transparent rounded-full animate-spin mx-auto mb-2" />
                Loading your recruitment opportunities...
              </div>
            ) : opportunities.length === 0 ? (
              <div className="bg-white p-12 rounded-xl border border-slate-200 text-center text-slate-500">
                <Briefcase className="w-10 h-10 text-slate-300 mx-auto mb-2" />
                <h3 className="text-sm font-bold text-slate-700">No recruitment postings yet</h3>
                <p className="text-xs text-slate-400 mt-1">
                  Create your first opportunity to discover and hire top-performing VirIntern students.
                </p>
                <button
                  type="button"
                  onClick={() => setOppModalOpen(true)}
                  className="mt-4 px-4 py-2 text-xs font-bold rounded-lg bg-[#0A66C2] text-white hover:bg-[#004182] transition-colors cursor-pointer"
                >
                  Create Opportunity
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                {opportunities.map((opp) => (
                  <div
                    key={opp.id}
                    className="bg-white rounded-xl border border-slate-200 p-5 shadow-2xs flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-start justify-between gap-3">
                        <div>
                          <h3 className="font-bold text-base text-slate-900">{opp.title}</h3>
                          <div className="flex items-center gap-2 text-xs text-slate-500 mt-0.5">
                            <span>{opp.locationType}</span>
                            {opp.location && (
                              <>
                                <span aria-hidden="true">·</span>
                                <span>{opp.location}</span>
                              </>
                            )}
                            {opp.stipendOrSalary && (
                              <>
                                <span aria-hidden="true">·</span>
                                <span className="font-semibold text-slate-700">{opp.stipendOrSalary}</span>
                              </>
                            )}
                          </div>
                        </div>

                        {/* Approval Status Badge */}
                        <div>
                          {opp.approvalStatus === 'approved' && (
                            <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
                              Approved & Live
                            </span>
                          )}
                          {opp.approvalStatus === 'pending' && (
                            <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-amber-50 text-amber-800 border border-amber-200">
                              Pending Review
                            </span>
                          )}
                          {opp.approvalStatus === 'rejected' && (
                            <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-rose-50 text-rose-800 border border-rose-200">
                              Revision Needed
                            </span>
                          )}
                        </div>
                      </div>

                      <p className="text-xs text-slate-600 mt-3 leading-relaxed line-clamp-3">
                        {opp.description}
                      </p>

                      {opp.requiredSkills && opp.requiredSkills.length > 0 && (
                        <div className="mt-3 flex flex-wrap gap-1 text-[11px]">
                          {opp.requiredSkills.map((sk) => (
                            <span key={sk} className="px-2 py-0.5 bg-slate-100 rounded text-slate-700 font-medium">
                              {sk}
                            </span>
                          ))}
                        </div>
                      )}
                    </div>

                    <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
                      <span>Deadline: {opp.deadline}</span>
                      <span>Posted: {new Date(opp.createdAt).toLocaleDateString()}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* TAB 5: COMPANY PROFILE & VERIFICATION */}
        {activeTab === 'profile' && (
          <div className="max-w-3xl mx-auto space-y-6">
            <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-2xs">
              <div className="flex items-center justify-between pb-4 border-b border-slate-100">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-blue-100 text-[#0A66C2] flex items-center justify-center font-bold text-lg">
                    <Building2 className="w-6 h-6" />
                  </div>
                  <div>
                    <h2 className="text-lg font-bold text-slate-900">{company?.name || 'Corporate Profile'}</h2>
                    <p className="text-xs text-slate-500">{company?.officialEmail || user?.email}</p>
                  </div>
                </div>

                {!editingProfile ? (
                  <button
                    type="button"
                    onClick={() => setEditingProfile(true)}
                    className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors flex items-center gap-1.5 cursor-pointer"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                    <span>Edit Profile</span>
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={() => setEditingProfile(false)}
                    className="px-3 py-1.5 text-xs font-semibold text-slate-500 hover:text-slate-800"
                  >
                    Cancel
                  </button>
                )}
              </div>

              {saveSuccessMsg && (
                <div className="mt-4 p-3 rounded-lg bg-emerald-50 border border-emerald-200 text-xs text-emerald-800 font-semibold flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>{saveSuccessMsg}</span>
                </div>
              )}

              {/* View / Edit Mode */}
              {!editingProfile ? (
                <div className="mt-6 space-y-4 text-xs">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <span className="font-bold text-slate-400 uppercase text-[10px] tracking-wider block">Official Website</span>
                      <a
                        href={company?.website || '#'}
                        target="_blank"
                        rel="noreferrer"
                        className="text-[#0A66C2] hover:underline font-semibold mt-0.5 inline-flex items-center gap-1"
                      >
                        {company?.website || 'Not specified'}
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    </div>

                    <div>
                      <span className="font-bold text-slate-400 uppercase text-[10px] tracking-wider block">Industry</span>
                      <span className="text-slate-800 font-semibold mt-0.5 block">{company?.industry || 'Technology'}</span>
                    </div>

                    <div>
                      <span className="font-bold text-slate-400 uppercase text-[10px] tracking-wider block">Primary Contact Person</span>
                      <span className="text-slate-800 font-semibold mt-0.5 block">{company?.contactPerson || 'Company Representative'}</span>
                    </div>

                    <div>
                      <span className="font-bold text-slate-400 uppercase text-[10px] tracking-wider block">Designation / Role</span>
                      <span className="text-slate-800 font-semibold mt-0.5 block">{company?.designation || 'Talent Acquisition'}</span>
                    </div>
                  </div>

                  <div className="pt-3 border-t border-slate-100">
                    <span className="font-bold text-slate-400 uppercase text-[10px] tracking-wider block">About Company</span>
                    <p className="text-slate-700 leading-relaxed mt-1">{company?.description || 'No description provided.'}</p>
                  </div>

                  <div className="pt-3 border-t border-slate-100">
                    <span className="font-bold text-slate-400 uppercase text-[10px] tracking-wider block">Hiring Requirements</span>
                    <div className="flex flex-wrap gap-1.5 mt-1.5">
                      {company?.hiringRequirements && company.hiringRequirements.length > 0 ? (
                        company.hiringRequirements.map((r) => (
                          <span key={r} className="px-2.5 py-1 bg-slate-100 rounded text-slate-700 font-medium">
                            {r}
                          </span>
                        ))
                      ) : (
                        <span className="text-slate-400 italic">No specific hiring requirements listed yet.</span>
                      )}
                    </div>
                  </div>

                  <div className="pt-3 border-t border-slate-100">
                    <span className="font-bold text-slate-400 uppercase text-[10px] tracking-wider block">Preferred Skills</span>
                    <div className="flex flex-wrap gap-1.5 mt-1.5">
                      {company?.preferredSkills && company.preferredSkills.length > 0 ? (
                        company.preferredSkills.map((s) => (
                          <span key={s} className="px-2.5 py-1 bg-blue-50 text-[#0A66C2] rounded font-medium border border-blue-100">
                            {s}
                          </span>
                        ))
                      ) : (
                        <span className="text-slate-400 italic">No preferred skills listed.</span>
                      )}
                    </div>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleSaveProfile} className="mt-6 space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">Company Name</label>
                      <input
                        type="text"
                        value={profileName}
                        onChange={(e) => setProfileName(e.target.value)}
                        required
                        className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0A66C2]"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">Website URL</label>
                      <input
                        type="url"
                        value={profileWebsite}
                        onChange={(e) => setProfileWebsite(e.target.value)}
                        placeholder="https://company.com"
                        className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0A66C2]"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">Industry</label>
                      <input
                        type="text"
                        value={profileIndustry}
                        onChange={(e) => setProfileIndustry(e.target.value)}
                        placeholder="e.g. Fintech, SaaS, HealthTech"
                        className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0A66C2]"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">Contact Person</label>
                      <input
                        type="text"
                        value={profileContact}
                        onChange={(e) => setProfileContact(e.target.value)}
                        className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0A66C2]"
                      />
                    </div>

                    <div className="sm:col-span-2">
                      <label className="block text-xs font-semibold text-slate-700 mb-1">Designation</label>
                      <input
                        type="text"
                        value={profileDesignation}
                        onChange={(e) => setProfileDesignation(e.target.value)}
                        placeholder="e.g. Head of Talent Acquisition"
                        className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0A66C2]"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">Company Description</label>
                    <textarea
                      rows={3}
                      value={profileDesc}
                      onChange={(e) => setProfileDesc(e.target.value)}
                      placeholder="Brief overview of your company, team culture, and projects..."
                      className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0A66C2]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Preferred Skills <span className="text-slate-400 font-normal">(comma-separated)</span>
                    </label>
                    <input
                      type="text"
                      value={profileSkills}
                      onChange={(e) => setProfileSkills(e.target.value)}
                      placeholder="React, TypeScript, Python, Node.js, Machine Learning"
                      className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0A66C2]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Hiring Requirements <span className="text-slate-400 font-normal">(comma-separated)</span>
                    </label>
                    <input
                      type="text"
                      value={profileHiringNeeds}
                      onChange={(e) => setProfileHiringNeeds(e.target.value)}
                      placeholder="Frontend Intern, Junior ML Engineer, Cloud Associate"
                      className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0A66C2]"
                    />
                  </div>

                  <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                    <button
                      type="button"
                      onClick={() => setEditingProfile(false)}
                      className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-800"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      disabled={savingProfile}
                      className="px-4 py-2 text-xs font-bold rounded-lg bg-[#0A66C2] text-white hover:bg-[#004182] transition-colors"
                    >
                      {savingProfile ? 'Saving...' : 'Save Profile'}
                    </button>
                  </div>
                </form>
              )}
            </div>
          </div>
        )}
      </main>

      {/* MODAL 1: CANDIDATE DETAILED PORTFOLIO MODAL */}
      {candidateModalOpen && selectedCandidate && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-fadeIn">
          <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-slate-200">
            {/* Header */}
            <div className="p-5 border-b border-slate-200 flex items-center justify-between sticky top-0 bg-white z-10">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-blue-100 text-[#0A66C2] font-bold text-sm flex items-center justify-center">
                  {selectedCandidate.displayName.charAt(0).toUpperCase()}
                </div>
                <div>
                  <h3 className="font-bold text-base text-slate-900">{selectedCandidate.displayName}</h3>
                  <div className="flex items-center gap-2 text-xs text-slate-500">
                    <span>Rank #{selectedCandidate.rank}</span>
                    <span aria-hidden="true">·</span>
                    <span>{selectedCandidate.domainName}</span>
                  </div>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setCandidateModalOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-6 space-y-6 text-xs">
              {/* Overview Metrics */}
              <div className="grid grid-cols-3 gap-3 p-4 bg-slate-50 rounded-xl border border-slate-200 text-center">
                <div>
                  <span className="font-bold text-slate-400 uppercase text-[10px] tracking-wider block">Average Score</span>
                  <span className="text-base font-extrabold text-emerald-700 mt-0.5 block">{selectedCandidate.averageScore}/100</span>
                </div>
                <div>
                  <span className="font-bold text-slate-400 uppercase text-[10px] tracking-wider block">Completion</span>
                  <span className="text-base font-extrabold text-slate-900 mt-0.5 block">{selectedCandidate.progress}%</span>
                </div>
                <div>
                  <span className="font-bold text-slate-400 uppercase text-[10px] tracking-wider block">Verified Milestones</span>
                  <span className="text-base font-extrabold text-[#0A66C2] mt-0.5 block">{selectedCandidate.completedTasksCount} / 5</span>
                </div>
              </div>

              {/* Bio */}
              <div>
                <h4 className="font-bold text-slate-900 uppercase text-[10px] tracking-wider text-slate-500 mb-1.5">Candidate Summary</h4>
                <p className="text-slate-700 leading-relaxed text-xs">
                  {selectedCandidate.bio || `Specialized virtual intern in ${selectedCandidate.domainName}. Completed verified deliverables under mentor review.`}
                </p>
              </div>

              {/* Skills */}
              <div>
                <h4 className="font-bold text-slate-900 uppercase text-[10px] tracking-wider text-slate-500 mb-2">Demonstrated Skills</h4>
                <div className="flex flex-wrap gap-1.5">
                  {selectedCandidate.skills.map((sk) => (
                    <span key={sk} className="px-2.5 py-1 bg-slate-100 text-slate-800 rounded font-medium">
                      {sk}
                    </span>
                  ))}
                </div>
              </div>

              {/* Verified Projects Portfolio */}
              <div>
                <h4 className="font-bold text-slate-900 uppercase text-[10px] tracking-wider text-slate-500 mb-2.5">
                  Verified Milestone Deliverables
                </h4>
                {selectedCandidate.verifiedProjects.length === 0 ? (
                  <p className="text-slate-400 italic">No milestone submissions verified yet for this student.</p>
                ) : (
                  <div className="space-y-3">
                    {selectedCandidate.verifiedProjects.map((p) => (
                      <div key={p.taskNumber} className="p-3.5 bg-slate-50 rounded-xl border border-slate-200">
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-slate-900 text-xs">
                            Milestone {p.taskNumber}: {p.title}
                          </span>
                          <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                            Score: {p.score || 90}/100
                          </span>
                        </div>
                        <div className="flex items-center gap-3 mt-2">
                          {p.githubUrl && (
                            <a
                              href={p.githubUrl}
                              target="_blank"
                              rel="noreferrer"
                              className="text-[11px] font-semibold text-slate-700 hover:text-black flex items-center gap-1"
                            >
                              <Github className="w-3.5 h-3.5" />
                              <span>GitHub Code</span>
                            </a>
                          )}
                          {p.projectUrl && (
                            <a
                              href={p.projectUrl}
                              target="_blank"
                              rel="noreferrer"
                              className="text-[11px] font-semibold text-[#0A66C2] hover:underline flex items-center gap-1"
                            >
                              <Globe className="w-3.5 h-3.5" />
                              <span>Live Deployment</span>
                            </a>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Resume / Consent */}
              {selectedCandidate.resumeUrl && isApproved && (
                <div className="p-4 bg-blue-50/60 rounded-xl border border-blue-200 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <FileText className="w-4 h-4 text-[#0A66C2]" />
                    <span className="font-semibold text-slate-900">Student Resume Attached</span>
                  </div>
                  <a
                    href={selectedCandidate.resumeUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="px-3 py-1.5 text-xs font-bold rounded-lg bg-[#0A66C2] text-white hover:bg-[#004182]"
                  >
                    View Resume
                  </a>
                </div>
              )}
            </div>

            {/* Modal Footer */}
            <div className="p-4 border-t border-slate-200 bg-slate-50 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setCandidateModalOpen(false)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-800"
              >
                Close
              </button>
              <button
                type="button"
                onClick={() => {
                  setCandidateModalOpen(false);
                  setShortlistCandidateTarget(selectedCandidate);
                  setShortlistModalOpen(true);
                }}
                className="px-4 py-2 text-xs font-bold rounded-lg bg-[#0A66C2] text-white hover:bg-[#004182] transition-colors"
              >
                Shortlist Candidate
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 2: SHORTLIST ACTION MODAL */}
      {shortlistModalOpen && shortlistCandidateTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-fadeIn">
          <div className="bg-white rounded-2xl max-w-md w-full shadow-2xl border border-slate-200 p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="font-bold text-base text-slate-900">Shortlist Candidate</h3>
              <button
                type="button"
                onClick={() => setShortlistModalOpen(false)}
                className="text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-slate-600">
              Add <strong>{shortlistCandidateTarget.displayName}</strong> to your talent pipeline for potential interviews or opportunities.
            </p>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Target Role / Opportunity</label>
                <input
                  type="text"
                  value={shortlistRoleTitle}
                  onChange={(e) => setShortlistRoleTitle(e.target.value)}
                  placeholder="e.g. Junior Frontend Developer / ML Intern"
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0A66C2]"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Private Company Notes <span className="text-slate-400 font-normal">(Visible only to your team)</span>
                </label>
                <textarea
                  rows={3}
                  value={shortlistNotes}
                  onChange={(e) => setShortlistNotes(e.target.value)}
                  placeholder="e.g. Strong React skills, clean code architecture in Task 3, schedule initial screening..."
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0A66C2]"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setShortlistModalOpen(false)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-800"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmShortlist}
                disabled={savingShortlist}
                className="px-4 py-2 text-xs font-bold rounded-lg bg-[#0A66C2] text-white hover:bg-[#004182] transition-colors"
              >
                {savingShortlist ? 'Saving...' : 'Confirm Shortlist'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 3: POST RECRUITMENT OPPORTUNITY MODAL */}
      {oppModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-fadeIn">
          <div className="bg-white rounded-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-slate-200 p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="font-bold text-base text-slate-900">Post Recruitment Opportunity</h3>
              <button
                type="button"
                onClick={() => setOppModalOpen(false)}
                className="text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-slate-600">
              Post an opening for VirIntern students. New opportunities are reviewed by an administrator before appearing live to candidates.
            </p>

            <form onSubmit={handleCreateOpportunity} className="space-y-3.5 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Opportunity Title *</label>
                <input
                  type="text"
                  value={newOppTitle}
                  onChange={(e) => setNewOppTitle(e.target.value)}
                  placeholder="e.g. Full-Stack Engineering Intern, AI/ML Trainee"
                  required
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0A66C2]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Relevant Track</label>
                  <select
                    value={newOppDomain}
                    onChange={(e) => setNewOppDomain(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-[#0A66C2]"
                  >
                    <option value="">Any / General</option>
                    {domains.map(d => (
                      <option key={d.id} value={d.id}>{d.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Location Type</label>
                  <select
                    value={newOppLocationType}
                    onChange={(e) => setNewOppLocationType(e.target.value as any)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-[#0A66C2]"
                  >
                    <option value="Remote">Remote</option>
                    <option value="Hybrid">Hybrid</option>
                    <option value="On-site">On-site</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Location (City/Country)</label>
                  <input
                    type="text"
                    value={newOppLocation}
                    onChange={(e) => setNewOppLocation(e.target.value)}
                    placeholder="e.g. Bangalore, India or Global"
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0A66C2]"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Stipend / Compensation</label>
                  <input
                    type="text"
                    value={newOppStipend}
                    onChange={(e) => setNewOppStipend(e.target.value)}
                    placeholder="e.g. ₹15,000/mo or Competitive"
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0A66C2]"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Required Skills <span className="text-slate-400 font-normal">(comma-separated)</span>
                </label>
                <input
                  type="text"
                  value={newOppSkills}
                  onChange={(e) => setNewOppSkills(e.target.value)}
                  placeholder="React, TypeScript, Node.js, REST APIs"
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0A66C2]"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Role Description *</label>
                <textarea
                  rows={4}
                  value={newOppDesc}
                  onChange={(e) => setNewOppDesc(e.target.value)}
                  required
                  placeholder="Responsibilities, project context, team environment, and expected deliverables..."
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0A66C2]"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Application Deadline</label>
                <input
                  type="date"
                  value={newOppDeadline}
                  onChange={(e) => setNewOppDeadline(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0A66C2]"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setOppModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={savingOpp}
                  className="px-4 py-2 text-xs font-bold rounded-lg bg-[#0A66C2] text-white hover:bg-[#004182] transition-colors"
                >
                  {savingOpp ? 'Submitting...' : 'Submit for Review'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
