import React, { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { DomainItem } from '../types';
import { dataService } from '../services/dataService';
import { YOUTUBE_CONFIG } from '../firebase/config';
import {
  ArrowRight,
  Award,
  CheckCircle2,
  Clock,
  Code2,
  Cpu,
  FileCheck2,
  Globe,
  GraduationCap,
  Layers,
  Lock,
  Play,
  ShieldCheck,
  Sparkles,
  Users,
  Youtube,
  BookOpen,
  FileText,
  Building2,
  Trophy,
  Briefcase
} from 'lucide-react';

interface LandingPageProps {
  setCurrentView: (view: string) => void;
  openAuthModal: (mode: 'login' | 'signup', portal?: 'student' | 'company') => void;
  onSelectDomain: (domain: DomainItem) => void;
  onOpenLegal?: (tab: 'privacy' | 'disclaimer' | 'terms' | 'refund') => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({
  setCurrentView,
  openAuthModal,
  onSelectDomain,
  onOpenLegal
}) => {
  const { user, activeInternship } = useAuth();
  const [domains, setDomains] = useState<DomainItem[]>([]);
  const [loadingDomains, setLoadingDomains] = useState(true);

  useEffect(() => {
    dataService.getDomains().then((res) => {
      setDomains(res);
      setLoadingDomains(false);
    });
  }, []);

  const handleStartCTA = () => {
    if (!user) {
      openAuthModal('signup');
    } else if (user.role === 'admin') {
      setCurrentView('admin');
    } else if (user.role === 'company') {
      setCurrentView('company');
    } else if (activeInternship) {
      setCurrentView('dashboard');
    } else {
      setCurrentView('domains');
    }
  };

  return (
    <div className="min-h-screen bg-[#F4F2EE]">
      {/* 4.1 Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-b from-[#004182] via-[#0A66C2] to-[#0A66C2] text-white pt-16 pb-24 lg:pt-20 lg:pb-28">
        {/* Subtle grid pattern background */}
        <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#ffffff_1px,transparent_1px)] [background-size:24px_24px]"></div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            {/* Left Column: Copy */}
            <div className="lg:col-span-7 space-y-6 text-center lg:text-left">
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/15 border border-white/25 text-white text-xs font-semibold backdrop-blur-xs">
                <Sparkles className="w-4 h-4 text-[#F3F2F0]" />
                <span>Professional Virtual Internship Platform</span>
              </div>

              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight leading-[1.15] text-white">
                Build Skills.{' '}
                <span className="text-[#EBF4FD] underline decoration-white/40">
                  Complete Projects.
                </span>{' '}
                Gain Experience.
              </h1>

              <p className="text-base sm:text-lg text-blue-50 max-w-2xl leading-relaxed">
                Free virtual internships designed to help students build practical project experience and strengthen their resumes and professional profiles with verifiable proof of work.
              </p>

              {/* CTAs */}
              <div className="flex flex-col sm:flex-row flex-wrap items-center justify-center lg:justify-start gap-3.5 pt-2">
                <button
                  onClick={handleStartCTA}
                  className="w-full sm:w-auto px-7 py-3.5 bg-white hover:bg-[#F3F2F0] text-[#0A66C2] font-bold text-base rounded-full shadow-lg hover:shadow-xl hover:scale-[1.02] transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <span>
                    {!user
                      ? 'Start Your Internship'
                      : user.role === 'admin'
                      ? 'Admin Control Portal'
                      : user.role === 'company'
                      ? 'Talent Discovery Portal'
                      : activeInternship
                      ? 'Go to My Dashboard'
                      : 'Choose Domain'}
                  </span>
                  <ArrowRight className="w-5 h-5 text-[#0A66C2]" />
                </button>

                {(!user || user.role === 'student') && (
                  <button
                    onClick={() => setCurrentView('domains')}
                    className="w-full sm:w-auto px-6 py-3.5 bg-transparent hover:bg-white/10 text-white border-2 border-white/80 hover:border-white font-bold text-base rounded-full transition-all flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <span>Explore Domains</span>
                  </button>
                )}

                {(!user || user.role === 'company') && (
                  <button
                    onClick={() => {
                      if (user?.role === 'company') setCurrentView('company');
                      else openAuthModal('login', 'company');
                    }}
                    className="w-full sm:w-auto px-6 py-3.5 bg-white/15 hover:bg-white/25 text-white border border-white/40 font-bold text-sm sm:text-base rounded-full backdrop-blur-xs transition-all flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <Building2 className="w-4 h-4 text-blue-200" />
                    <span>Hire Talent (Company Portal)</span>
                  </button>
                )}
              </div>

              {/* Badges / Metrics */}
              <div className="grid grid-cols-3 gap-4 pt-6 border-t border-white/20 text-left">
                <div>
                  <p className="text-2xl font-bold text-white">100% Free</p>
                  <p className="text-xs text-blue-100">Virtual Internship</p>
                </div>
                <div>
                  <p className="text-2xl font-bold text-white">5 Tasks</p>
                  <p className="text-xs text-blue-100">Structured Projects</p>
                </div>
                <div>
                  <p className="text-2xl font-bold text-white">30 Days</p>
                  <p className="text-xs text-blue-100">Duration</p>
                </div>
              </div>
            </div>

            {/* Right Column: Program Structure Card (No progress bar before signing in) */}
            <div className="lg:col-span-5">
              <div className="bg-white rounded-2xl border border-[#E0DFDC] shadow-xl p-6 relative overflow-hidden text-[#191919]">
                <div className="flex items-center justify-between pb-4 border-b border-[#E0DFDC]">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-[#0A66C2] flex items-center justify-center text-white font-bold text-base shadow-xs">
                      VI
                    </div>
                    <div>
                      <p className="text-sm font-bold text-[#191919]">VirIntern Program Overview</p>
                      <p className="text-xs text-[#666666]">Structured Virtual Internship Journey</p>
                    </div>
                  </div>
                  <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-[#E8F5E9] text-[#057642] border border-[#C8E6C9]">
                    Verified
                  </span>
                </div>

                {/* 4 Clear Program Pillars */}
                <div className="mt-5 space-y-3 text-xs">
                  <div className="p-3 bg-[#F4F2EE] rounded-xl border border-[#E0DFDC] flex items-center gap-3">
                    <div className="w-7 h-7 rounded-lg bg-[#0A66C2] text-white flex items-center justify-center font-bold text-xs shrink-0">
                      1
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-bold text-[#191919]">Choose Tech Specialization</p>
                      <p className="text-[11px] text-[#666666]">12+ curated tracks including Web, AI/ML, Python, Cloud, & ECE</p>
                    </div>
                  </div>

                  <div className="p-3 bg-[#F4F2EE] rounded-xl border border-[#E0DFDC] flex items-center gap-3">
                    <div className="w-7 h-7 rounded-lg bg-[#0A66C2] text-white flex items-center justify-center font-bold text-xs shrink-0">
                      2
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-bold text-[#191919]">Sign Virtual E-Agreement</p>
                      <p className="text-[11px] text-[#666666]">Professional code of conduct & verified student honor policy</p>
                    </div>
                  </div>

                  <div className="p-3 bg-[#F4F2EE] rounded-xl border border-[#E0DFDC] flex items-center gap-3">
                    <div className="w-7 h-7 rounded-lg bg-[#0A66C2] text-white flex items-center justify-center font-bold text-xs shrink-0">
                      3
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-bold text-[#191919]">Build 5 Milestone Tasks</p>
                      <p className="text-[11px] text-[#666666]">Sequential real-world projects with GitHub & live link submissions</p>
                    </div>
                  </div>

                  <div className="p-3 bg-[#F4F2EE] rounded-xl border border-[#E0DFDC] flex items-center gap-3">
                    <div className="w-7 h-7 rounded-lg bg-[#057642] text-white flex items-center justify-center font-bold text-xs shrink-0">
                      4
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-bold text-[#191919]">Mentor Review & Credential</p>
                      <p className="text-[11px] text-[#666666]">Official completion certificate with online verifiable QR code</p>
                    </div>
                  </div>
                </div>

                {/* Bottom Callout */}
                <div className="mt-5 pt-4 border-t border-[#E0DFDC] flex items-center justify-between text-xs text-[#666666]">
                  <span>Duration: 1 Month (Flexible)</span>
                  <span className="text-[#0A66C2] font-semibold">100% Free Enrollment</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 4.2 How VirIntern Works */}
      <section className="py-20 bg-white border-b border-[#E0DFDC]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-xs font-bold uppercase tracking-wider text-[#0A66C2] mb-2">
              Structured & Transparent
            </h2>
            <p className="text-3xl sm:text-4xl font-extrabold text-[#191919] tracking-tight">
              How VirIntern Works
            </p>
            <p className="text-[#666666] mt-3 text-base">
              A clear 5-step journey that gives you hands-on experience, verified proof of work, and career momentum.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-5 gap-6 relative">
            {/* Step 1 */}
            <div className="bg-[#F4F2EE] rounded-2xl p-6 border border-[#E0DFDC] hover:border-[#0A66C2] hover:shadow-md transition-all group">
              <div className="w-12 h-12 rounded-xl bg-[#EBF4FD] text-[#0A66C2] font-bold text-lg flex items-center justify-center mb-4 group-hover:bg-[#0A66C2] group-hover:text-white transition-colors">
                1
              </div>
              <h3 className="font-bold text-[#191919] text-base mb-1.5">Sign Up</h3>
              <p className="text-xs text-[#666666] leading-relaxed">
                Create your VirIntern account using Email or Google authentication in seconds.
              </p>
            </div>

            {/* Step 2 */}
            <div className="bg-[#F4F2EE] rounded-2xl p-6 border border-[#E0DFDC] hover:border-[#0A66C2] hover:shadow-md transition-all group">
              <div className="w-12 h-12 rounded-xl bg-[#EBF4FD] text-[#0A66C2] font-bold text-lg flex items-center justify-center mb-4 group-hover:bg-[#0A66C2] group-hover:text-white transition-colors">
                2
              </div>
              <h3 className="font-bold text-[#191919] text-base mb-1.5">Choose Domain</h3>
              <p className="text-xs text-[#666666] leading-relaxed">
                Select your area of specialization—Web Dev, AI/ML, Python, Java, Data Science, and more.
              </p>
            </div>

            {/* Step 3 */}
            <div className="bg-[#F4F2EE] rounded-2xl p-6 border border-[#E0DFDC] hover:border-[#0A66C2] hover:shadow-md transition-all group">
              <div className="w-12 h-12 rounded-xl bg-[#EBF4FD] text-[#0A66C2] font-bold text-lg flex items-center justify-center mb-4 group-hover:bg-[#0A66C2] group-hover:text-white transition-colors">
                3
              </div>
              <h3 className="font-bold text-[#191919] text-base mb-1.5">Complete Projects</h3>
              <p className="text-xs text-[#666666] leading-relaxed">
                Work through five structured milestone tasks, unlocking new challenges sequentially.
              </p>
            </div>

            {/* Step 4 */}
            <div className="bg-[#F4F2EE] rounded-2xl p-6 border border-[#E0DFDC] hover:border-[#0A66C2] hover:shadow-md transition-all group">
              <div className="w-12 h-12 rounded-xl bg-[#EBF4FD] text-[#0A66C2] font-bold text-lg flex items-center justify-center mb-4 group-hover:bg-[#0A66C2] group-hover:text-white transition-colors">
                4
              </div>
              <h3 className="font-bold text-[#191919] text-base mb-1.5">Submit & Verify</h3>
              <p className="text-xs text-[#666666] leading-relaxed">
                Submit GitHub URLs, demo links, and task proof for evaluation and mentor feedback.
              </p>
            </div>

            {/* Step 5 */}
            <div className="bg-[#F4F2EE] rounded-2xl p-6 border border-[#E0DFDC] hover:border-[#0A66C2] hover:shadow-md transition-all group">
              <div className="w-12 h-12 rounded-xl bg-[#E8F5E9] text-[#057642] font-bold text-lg flex items-center justify-center mb-4 group-hover:bg-[#057642] group-hover:text-white transition-colors">
                5
              </div>
              <h3 className="font-bold text-[#191919] text-base mb-1.5">Complete Internship</h3>
              <p className="text-xs text-[#666666] leading-relaxed">
                Reach 100% completion and access verified certificates, badge, resume kit & question bank.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Domain Catalog Preview */}
      <section className="py-20 bg-[#F4F2EE]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-12">
            <div>
              <h2 className="text-xs font-bold uppercase tracking-wider text-[#0A66C2] mb-2">
                Industry-Aligned Fields
              </h2>
              <p className="text-3xl font-extrabold text-[#191919] tracking-tight">
                Explore Internship Domains
              </p>
              <p className="text-[#666666] mt-2 text-sm max-w-xl">
                Every domain is carefully structured into 5 practical milestone tasks with starter templates and guidance.
              </p>
            </div>
            <button
              onClick={() => setCurrentView('domains')}
              className="mt-4 md:mt-0 inline-flex items-center gap-1.5 text-sm font-semibold text-[#0A66C2] hover:text-[#004182]"
            >
              <span>View All 12+ Domains</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {domains.slice(0, 9).map((domain) => {
              // Only mark a domain as enrolled if an authenticated student has a verified ongoing internship in this specific domain
              const isEnrolled = Boolean(
                user &&
                user.role === 'student' &&
                activeInternship &&
                (
                  activeInternship.domainId === domain.id ||
                  activeInternship.domainSlug === domain.id ||
                  activeInternship.domainId === domain.slug ||
                  activeInternship.domainName?.toLowerCase() === domain.name.toLowerCase() ||
                  activeInternship.domainId?.toLowerCase() === domain.name.toLowerCase()
                )
              );

              const hasAnyEnrollment = Boolean(user && user.role === 'student' && activeInternship);

              return (
                <div
                  key={domain.id}
                  className={`bg-white rounded-2xl p-6 border transition-all duration-200 flex flex-col justify-between ${
                    isEnrolled
                      ? 'border-[#057642] ring-2 ring-[#057642]/30 shadow-md bg-gradient-to-b from-[#F7FCF8] to-white'
                      : 'border-[#E0DFDC] hover:border-[#0A66C2] hover:shadow-lg'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between mb-4">
                      <span className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold text-white shadow-xs ${
                        isEnrolled ? 'bg-[#057642]' : 'bg-[#0A66C2]'
                      }`}>
                        {domain.name.charAt(0)}
                      </span>
                      <div className="flex items-center gap-1.5">
                        {isEnrolled && (
                          <span className="text-[10px] font-bold text-[#057642] bg-[#E8F5E9] border border-[#C8E6C9] px-2.5 py-0.5 rounded-full flex items-center gap-1 shadow-2xs">
                            <CheckCircle2 className="w-3 h-3 text-[#057642]" />
                            Enrolled Track
                          </span>
                        )}
                        <span className="text-[11px] font-semibold text-[#666666] bg-[#F4F2EE] px-2.5 py-0.5 rounded-full flex items-center gap-1">
                          <Clock className="w-3 h-3 text-[#666666]" />
                          30 Days (1 Mo)
                        </span>
                      </div>
                    </div>
                    <h3 className="text-lg font-bold text-[#191919] mb-2">{domain.name}</h3>
                    <p className="text-xs text-[#666666] line-clamp-3 leading-relaxed mb-4">
                      {domain.description}
                    </p>

                    {domain.tags && (
                      <div className="flex flex-wrap gap-1.5 mb-6">
                        {domain.tags.map((tag) => (
                          <span
                            key={tag}
                            className="px-2 py-0.5 rounded text-[10px] font-medium bg-[#EBF4FD] text-[#0A66C2]"
                          >
                            {tag}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>

                  {isEnrolled ? (
                    <button
                      onClick={() => setCurrentView('dashboard')}
                      className="w-full py-2.5 px-4 bg-[#057642] hover:bg-[#046237] text-white font-bold text-xs rounded-full transition-colors flex items-center justify-center gap-2 group shadow-xs cursor-pointer active:scale-98"
                    >
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Enrolled • Continue Tasks ({activeInternship?.progress || user?.progress || 0}%)</span>
                      <ArrowRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
                    </button>
                  ) : !user ? (
                    <button
                      onClick={() => onSelectDomain(domain)}
                      className="w-full py-2.5 px-4 bg-white border border-[#0A66C2] text-[#0A66C2] hover:bg-[#0A66C2] hover:text-white font-semibold text-xs rounded-full transition-colors flex items-center justify-center gap-2 group shadow-xs cursor-pointer active:scale-98"
                    >
                      <span>Join & Select Domain</span>
                      <ArrowRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
                    </button>
                  ) : hasAnyEnrollment ? (
                    <button
                      onClick={() => onSelectDomain(domain)}
                      className="w-full py-2.5 px-4 bg-white border border-slate-300 text-slate-700 hover:border-[#0A66C2] hover:text-[#0A66C2] hover:bg-blue-50 font-semibold text-xs rounded-full transition-colors flex items-center justify-center gap-2 group shadow-xs cursor-pointer active:scale-98"
                    >
                      <span>Switch to this Domain</span>
                      <ArrowRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
                    </button>
                  ) : (
                    <button
                      onClick={() => onSelectDomain(domain)}
                      className="w-full py-2.5 px-4 bg-[#0A66C2] hover:bg-[#004182] text-white font-semibold text-xs rounded-full transition-colors flex items-center justify-center gap-2 group shadow-xs cursor-pointer active:scale-98"
                    >
                      <span>Select Domain</span>
                      <ArrowRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
                    </button>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Task 1 Special Verification & YouTube Community Feature */}
      <section className="py-16 bg-white border-y border-[#E0DFDC]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-[#004182] rounded-2xl text-white p-8 lg:p-12 relative overflow-hidden shadow-lg border border-[#0A66C2]">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
              <div className="lg:col-span-8 space-y-4">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-red-500/20 text-red-200 border border-red-500/30 text-xs font-semibold">
                  <Youtube className="w-4 h-4 text-red-400" />
                  <span>Official Learning & Community Resource</span>
                </div>
                <h3 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
                  VirIntern Official Community Verification
                </h3>
                <p className="text-sm text-blue-100 leading-relaxed max-w-2xl">
                  Connect with the official VirIntern channel for hands-on project tutorials, milestone walkthroughs, and official internship updates throughout your program.
                </p>
                <div className="flex flex-wrap items-center gap-4 pt-2">
                  <a
                    href={YOUTUBE_CONFIG.channelUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-2 px-6 py-2.5 bg-red-600 hover:bg-red-700 text-white font-semibold text-xs rounded-full shadow-md transition-colors"
                  >
                    <Youtube className="w-4 h-4" />
                    <span>Visit VirIntern on YouTube</span>
                  </a>
                  <span className="text-xs text-blue-200">
                    Official Channel: {YOUTUBE_CONFIG.channelName}
                  </span>
                </div>
              </div>

              <div className="lg:col-span-4 bg-white/10 rounded-2xl p-6 border border-white/15 backdrop-blur-xs">
                <h4 className="text-xs font-bold uppercase tracking-wider text-blue-200 mb-3">
                  What You Receive
                </h4>
                <div className="space-y-3">
                  <div className="p-3 bg-white/10 rounded-xl flex items-center justify-between text-xs">
                    <span className="font-medium text-white">Starter Code & Project Templates</span>
                    <CheckCircle2 className="w-4 h-4 text-[#EBF4FD]" />
                  </div>
                  <div className="p-3 bg-white/10 rounded-xl flex items-center justify-between text-xs">
                    <span className="font-medium text-white">Milestone Verification Guidelines</span>
                    <CheckCircle2 className="w-4 h-4 text-[#EBF4FD]" />
                  </div>
                  <div className="p-3 bg-white/15 rounded-xl flex items-center justify-between text-xs font-bold border border-white/20">
                    <span className="text-white">Mentor Review & Code Feedback</span>
                    <Award className="w-4 h-4 text-[#E8F5E9]" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Completion Package & Career Tools Showcase */}
      <section className="py-20 bg-[#F4F2EE]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-xs font-bold uppercase tracking-wider text-[#0A66C2] mb-2">
              Career Readiness
            </h2>
            <p className="text-3xl sm:text-4xl font-extrabold text-[#191919] tracking-tight">
              Everything You Need to Succeed
            </p>
            <p className="text-[#666666] mt-3 text-base">
              The internship is completely free to complete. Upon reaching completion, students can optionally unlock our verified completion kit.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Feature 1 */}
            <div className="bg-white rounded-xl p-8 border border-[#E0DFDC] shadow-xs hover:shadow-md hover:border-[#0A66C2] transition-all">
              <div className="w-12 h-12 rounded-xl bg-[#EBF4FD] text-[#0A66C2] flex items-center justify-center mb-6">
                <Award className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold text-[#191919] mb-2">Verifiable Certificates</h3>
              <p className="text-sm text-[#666666] leading-relaxed mb-4">
                Receive official Completion and Appreciation Certificates with unique IDs (e.g. VI-2026-WD-XXXXX) verifiable online by employers anytime.
              </p>
              <button
                onClick={() => setCurrentView('verify_cert')}
                className="text-xs font-semibold text-[#0A66C2] hover:text-[#004182] flex items-center gap-1"
              >
                <span>Try Public Credential Lookup</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Feature 2 */}
            <div className="bg-white rounded-xl p-8 border border-[#E0DFDC] shadow-xs hover:shadow-md hover:border-[#0A66C2] transition-all">
              <div className="w-12 h-12 rounded-xl bg-[#EBF4FD] text-[#0A66C2] flex items-center justify-center mb-6">
                <FileText className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold text-[#191919] mb-2">Resume Builder Kit</h3>
              <p className="text-sm text-[#666666] leading-relaxed mb-4">
                Generate an ATS-friendly, professional resume with your newly completed internship projects and key metrics formatted for recruiters.
              </p>
              <button
                onClick={() => setCurrentView('resume_builder')}
                className="text-xs font-semibold text-[#0A66C2] hover:text-[#004182] flex items-center gap-1"
              >
                <span>Launch Resume Builder</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Feature 3 */}
            <div className="bg-white rounded-xl p-8 border border-[#E0DFDC] shadow-xs hover:shadow-md hover:border-[#0A66C2] transition-all">
              <div className="w-12 h-12 rounded-xl bg-[#E8F5E9] text-[#057642] flex items-center justify-center mb-6">
                <BookOpen className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold text-[#191919] mb-2">1000+ Interview QA Bank</h3>
              <p className="text-sm text-[#666666] leading-relaxed mb-4">
                Access curated interview questions across HR, Technical, AI/ML, Web, DBMS, OS, Networking, and Aptitude with answers and code solutions.
              </p>
              <button
                onClick={() => setCurrentView('interview_prep')}
                className="text-xs font-semibold text-[#057642] hover:underline flex items-center gap-1"
              >
                <span>Explore Question Bank</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Referral Banner */}
      <section className="py-12 bg-[#FFF3E0] border-y border-[#FFE0B2] text-[#191919]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-1 text-center md:text-left">
            <span className="text-xs font-bold uppercase tracking-wider bg-[#915907] text-white px-2.5 py-0.5 rounded-full">
              Earn with VirIntern
            </span>
            <h3 className="text-2xl font-extrabold tracking-tight text-[#191919]">
              Refer Friends & Earn 10% Cash Rewards
            </h3>
            <p className="text-sm text-[#666666] font-medium">
              Share your custom referral code. When a referred friend purchases a completion package, receive 10% instant reward.
            </p>
          </div>
          <button
            onClick={() => {
              if (!user) openAuthModal('signup');
              else setCurrentView('referrals');
            }}
            className="px-6 py-2.5 bg-[#0A66C2] hover:bg-[#004182] text-white font-semibold text-sm rounded-full shadow-xs transition-colors whitespace-nowrap"
          >
            {user ? 'View My Referral Dashboard' : 'Get Referral Link'}
          </button>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-xs font-bold uppercase tracking-wider text-[#0A66C2] mb-2">
              Common Questions
            </h2>
            <p className="text-3xl font-extrabold text-[#191919] tracking-tight">
              Frequently Asked Questions
            </p>
          </div>

          <div className="space-y-4">
            <div className="p-5 rounded-xl bg-[#F4F2EE] border border-[#E0DFDC]">
              <h4 className="font-bold text-[#191919] text-sm mb-1.5">Is the VirIntern internship truly free?</h4>
              <p className="text-xs text-[#666666] leading-relaxed">
                Yes! Enrolling in an internship domain, completing all 5 tasks, receiving mentor reviews, and reaching completion is 100% free. An optional completion package is available at the end for students who want verifiable certificates, digital badges, and resume tools.
              </p>
            </div>
            <div className="p-5 rounded-xl bg-[#F4F2EE] border border-[#E0DFDC]">
              <h4 className="font-bold text-[#191919] text-sm mb-1.5">How long is the internship duration?</h4>
              <p className="text-xs text-[#666666] leading-relaxed">
                The virtual internship is configured for a 1-Month (30 Days) duration with flexible milestone pacing so you can balance it alongside college or full-time studies.
              </p>
            </div>
            <div className="p-5 rounded-xl bg-[#F4F2EE] border border-[#E0DFDC]">
              <h4 className="font-bold text-[#191919] text-sm mb-1.5">Can certificates be verified by recruiters?</h4>
              <p className="text-xs text-[#666666] leading-relaxed">
                Yes, every issued certificate contains a tamper-proof unique certificate ID (e.g. VI-2026-WD-XXXXX) and verification link that can be checked on our public verification page.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Official Legal & Transparency Disclaimer Section */}
      <section className="py-12 bg-slate-900 text-white border-t border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-slate-800/80 rounded-2xl p-6 sm:p-8 border border-slate-700/80 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
            <div className="space-y-2 max-w-2xl">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-emerald-400" />
                <span className="text-xs uppercase font-extrabold tracking-wider text-emerald-400">
                  Trust, Transparency & Compliance Guarantee
                </span>
              </div>
              <h3 className="text-lg sm:text-xl font-bold text-white">
                Official Privacy Policy & Educational Disclaimers
              </h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                VirIntern is an applied engineering skill-development initiative. We strictly protect candidate personal data and source code submissions. We do not sell student information to third parties. All milestone projects are built using 100% free industry tools and are evaluated manually by faculty mentors. Participation does not guarantee third-party corporate hiring.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-3 shrink-0">
              <button
                type="button"
                onClick={() => onOpenLegal?.('privacy')}
                className="px-4 py-2 bg-slate-700 hover:bg-slate-600 text-white text-xs font-bold rounded-xl transition-colors cursor-pointer border border-slate-600"
              >
                Privacy Policy
              </button>
              <button
                type="button"
                onClick={() => onOpenLegal?.('disclaimer')}
                className="px-4 py-2 bg-slate-700 hover:bg-slate-600 text-white text-xs font-bold rounded-xl transition-colors cursor-pointer border border-slate-600"
              >
                Program Disclaimer
              </button>
              <button
                type="button"
                onClick={() => onOpenLegal?.('terms')}
                className="px-4 py-2 bg-slate-700 hover:bg-slate-600 text-white text-xs font-bold rounded-xl transition-colors cursor-pointer border border-slate-600"
              >
                Terms & Conditions
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
