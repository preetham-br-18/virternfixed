import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import {
  FileText,
  Download,
  Printer,
  Sparkles,
  Plus,
  Trash2,
  CheckCircle2,
  Briefcase,
  GraduationCap,
  Code,
  Lock,
  ArrowRight
} from 'lucide-react';

interface ResumeBuilderProps {
  setCurrentView?: (view: string) => void;
}

export const ResumeBuilder: React.FC<ResumeBuilderProps> = ({ setCurrentView }) => {
  const { user, activeInternship } = useAuth();
  const isLocked = !user?.hasPaidPackage && user?.role !== 'admin';

  const domainName = activeInternship?.domainName || 'Software Development';

  const [fullName, setFullName] = useState(user?.name || 'Aditi Sharma');
  const [email, setEmail] = useState(user?.email || 'aditi.intern@virintern.com');
  const [phone, setPhone] = useState('+91 98765 43210');
  const [location, setLocation] = useState('Bangalore, India');
  const [github, setGithub] = useState('github.com/intern-engineer');
  const [linkedin, setLinkedin] = useState('linkedin.com/in/intern-profile');
  const [summary, setSummary] = useState(
    `Driven and results-oriented ${domainName} Intern with hands-on experience building full-stack and modular solutions. Completed 5 comprehensive practical projects at VirIntern adhering to industry best practices, testing, and modern frameworks.`
  );

  const [skills, setSkills] = useState(
    'JavaScript, TypeScript, React, Node.js, Python, Git, REST APIs, Tailwind CSS, SQL, Docker'
  );

  const [projects, setProjects] = useState([
    {
      title: `${domainName} Capstone Platform`,
      tech: 'React, TypeScript, Node.js, Cloud Services',
      description: 'Architected and deployed a production-grade full-stack solution featuring authentication, role-based workflows, and automated CI/CD deployment pipelines.'
    },
    {
      title: 'High-Performance API & State Service',
      tech: 'FastAPI / Express, RESTful APIs, SQLite',
      description: 'Engineered responsive backend endpoints with input sanitization, error handling, query optimization, and sub-100ms response latencies.'
    },
    {
      title: 'Interactive Frontend Dashboard & Component System',
      tech: 'React, Tailwind CSS, Lucide Icons',
      description: 'Designed accessible, mobile-first UI components achieving 95+ Lighthouse accessibility and performance ratings.'
    }
  ]);

  const [education, setEducation] = useState('Bachelor of Technology in Computer Science & Engineering (2023 - 2027)');

  const handlePrint = () => {
    if (isLocked) {
      if (setCurrentView) setCurrentView('completion');
      return;
    }
    window.print();
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      {/* Locked Benefit Callout Banner */}
      {isLocked && (
        <div className="bg-gradient-to-r from-amber-50 to-orange-50 border border-amber-200 rounded-2xl p-6 shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-start gap-3.5">
            <div className="w-11 h-11 rounded-xl bg-amber-100 text-amber-800 border border-amber-300 flex items-center justify-center shrink-0 shadow-2xs">
              <Lock className="w-6 h-6 text-amber-700" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-slate-900">
                  Resume Builder is a Locked Completion Benefit
                </h3>
                <span className="px-2.5 py-0.5 bg-amber-200 text-amber-900 font-bold text-[10px] rounded-full uppercase tracking-wider">
                  Locked
                </span>
              </div>
              <p className="text-xs text-slate-600 mt-1 max-w-2xl leading-relaxed">
                This ATS-optimized resume generator is unlocked when you purchase the VirIntern Completion Package. Complete all milestones and activate your credentials to unlock full editing and PDF exports.
              </p>
            </div>
          </div>

          <button
            onClick={() => setCurrentView?.('completion')}
            className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl shadow-md transition-all hover:scale-[1.02] flex items-center gap-2 shrink-0"
          >
            <Sparkles className="w-4 h-4 text-amber-300" />
            <span>Unlock Package (₹99)</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Header */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 bg-white p-6 rounded-xl border border-[#E0DFDC] shadow-xs">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#EBF4FD] text-[#0A66C2] text-xs font-semibold mb-2 border border-[#0A66C2]/30">
            <Sparkles className="w-3.5 h-3.5 text-[#0A66C2]" />
            <span>ATS-Friendly Career Kit</span>
          </div>
          <h1 className="text-2xl font-bold text-[#191919]">VirIntern Resume Builder Kit</h1>
          <p className="text-xs text-[#666666]">
            Edit your details and download a clean, ATS-compliant resume highlighting your virtual internship achievements.
          </p>
        </div>

        <button
          onClick={handlePrint}
          className={`px-5 py-2.5 font-semibold text-xs rounded-full shadow-xs flex items-center gap-2 transition-all ${
            isLocked
              ? 'bg-amber-500 hover:bg-amber-600 text-white'
              : 'bg-[#0A66C2] hover:bg-[#004182] text-white'
          }`}
        >
          {isLocked ? (
            <>
              <Lock className="w-4 h-4" />
              <span>Unlock to Export PDF</span>
            </>
          ) : (
            <>
              <Printer className="w-4 h-4" />
              <span>Print / Save as PDF</span>
            </>
          )}
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Editor Form */}
        <div className="lg:col-span-5 bg-white p-6 rounded-2xl border border-slate-200 space-y-5 shadow-sm">
          <h2 className="text-sm font-bold uppercase tracking-wider text-slate-700 pb-2 border-b border-slate-100">
            Customize Content
          </h2>

          <div className="space-y-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Full Name</label>
              <input
                type="text"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                className="w-full text-xs p-2.5 border border-slate-300 rounded-xl outline-none"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Email</label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full text-xs p-2.5 border border-slate-300 rounded-xl outline-none"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Phone</label>
                <input
                  type="text"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full text-xs p-2.5 border border-slate-300 rounded-xl outline-none"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Location</label>
                <input
                  type="text"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  className="w-full text-xs p-2.5 border border-slate-300 rounded-xl outline-none"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">LinkedIn</label>
                <input
                  type="text"
                  value={linkedin}
                  onChange={(e) => setLinkedin(e.target.value)}
                  className="w-full text-xs p-2.5 border border-slate-300 rounded-xl outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Professional Summary</label>
              <textarea
                rows={3}
                value={summary}
                onChange={(e) => setSummary(e.target.value)}
                className="w-full text-xs p-2.5 border border-slate-300 rounded-xl outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Skills (comma separated)</label>
              <textarea
                rows={2}
                value={skills}
                onChange={(e) => setSkills(e.target.value)}
                className="w-full text-xs p-2.5 border border-slate-300 rounded-xl outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Education</label>
              <input
                type="text"
                value={education}
                onChange={(e) => setEducation(e.target.value)}
                className="w-full text-xs p-2.5 border border-slate-300 rounded-xl outline-none"
              />
            </div>
          </div>
        </div>

        {/* Live Resume Sheet Preview */}
        <div className="lg:col-span-7">
          <div className="bg-white p-8 sm:p-12 rounded-2xl border border-slate-300 shadow-xl space-y-6 text-slate-900 font-sans print:m-0 print:border-none print:shadow-none print:p-4">
            {/* Header */}
            <div className="border-b border-slate-300 pb-4 text-center">
              <h1 className="text-2xl font-bold uppercase tracking-wide text-slate-950">{fullName}</h1>
              <p className="text-xs text-slate-600 mt-1 flex flex-wrap items-center justify-center gap-2">
                <span>{email}</span> • <span>{phone}</span> • <span>{location}</span>
              </p>
              <p className="text-xs text-indigo-700 font-medium mt-0.5">
                <span>{linkedin}</span> • <span>{github}</span>
              </p>
            </div>

            {/* Summary */}
            <div>
              <h2 className="text-xs font-bold uppercase tracking-wider text-slate-900 border-b border-slate-200 pb-1 mb-2">
                Professional Summary
              </h2>
              <p className="text-xs text-slate-700 leading-relaxed text-justify">
                {summary}
              </p>
            </div>

            {/* VirIntern Experience */}
            <div>
              <h2 className="text-xs font-bold uppercase tracking-wider text-slate-900 border-b border-slate-200 pb-1 mb-2">
                Virtual Internship Experience
              </h2>
              <div className="space-y-1">
                <div className="flex justify-between items-baseline">
                  <h3 className="text-xs font-bold text-slate-900">
                    VirIntern — {domainName} Virtual Intern
                  </h3>
                  <span className="text-[11px] text-slate-500 font-medium">1 Month Intensive (2026)</span>
                </div>
                <ul className="list-disc pl-4 text-xs text-slate-700 space-y-1">
                  <li>Completed 5 rigorous, practical milestone projects in {domainName} under senior mentor evaluation.</li>
                  <li>Fulfilled code reviews, documentation, unit testing, and continuous deployment criteria.</li>
                  <li>Achieved 100% course progression and received verified digital credential honors.</li>
                </ul>
              </div>
            </div>

            {/* Projects */}
            <div>
              <h2 className="text-xs font-bold uppercase tracking-wider text-slate-900 border-b border-slate-200 pb-1 mb-2">
                Key Technical Projects
              </h2>
              <div className="space-y-3">
                {projects.map((proj, idx) => (
                  <div key={idx} className="space-y-0.5">
                    <div className="flex justify-between items-baseline">
                      <span className="text-xs font-bold text-slate-900">{proj.title}</span>
                      <span className="text-[10px] text-slate-500 italic">{proj.tech}</span>
                    </div>
                    <p className="text-xs text-slate-700 leading-relaxed">
                      {proj.description}
                    </p>
                  </div>
                ))}
              </div>
            </div>

            {/* Skills */}
            <div>
              <h2 className="text-xs font-bold uppercase tracking-wider text-slate-900 border-b border-slate-200 pb-1 mb-2">
                Technical Skills & Tools
              </h2>
              <p className="text-xs text-slate-700 leading-relaxed">
                {skills}
              </p>
            </div>

            {/* Education */}
            <div>
              <h2 className="text-xs font-bold uppercase tracking-wider text-slate-900 border-b border-slate-200 pb-1 mb-2">
                Education
              </h2>
              <p className="text-xs text-slate-700">
                {education}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
