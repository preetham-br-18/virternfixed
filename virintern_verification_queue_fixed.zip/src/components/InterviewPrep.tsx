import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { InterviewQuestionItem } from '../types';
import { dataService } from '../services/dataService';
import {
  BookOpen,
  Search,
  Filter,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  Sparkles,
  HelpCircle,
  Code,
  Lock,
  ArrowRight
} from 'lucide-react';

interface InterviewPrepProps {
  setCurrentView?: (view: string) => void;
}

export const InterviewPrep: React.FC<InterviewPrepProps> = ({ setCurrentView }) => {
  const { user } = useAuth();
  const isLocked = !user?.hasPaidPackage && user?.role !== 'admin';

  const [questions, setQuestions] = useState<InterviewQuestionItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const categories = [
    'All',
    'HR',
    'Technical',
    'Programming',
    'AI/ML',
    'Web Development',
    'DBMS',
    'Operating Systems',
    'Networking',
    'Data Structures',
    'ECE & Embedded',
    'Aptitude'
  ];

  useEffect(() => {
    loadQuestions();
  }, [selectedCategory, search]);

  const loadQuestions = async () => {
    setLoading(true);
    const data = await dataService.getInterviewQuestions(selectedCategory, search);
    setQuestions(data);
    setLoading(false);
  };

  const toggleExpand = (id: string, index: number) => {
    if (isLocked && index >= 2) {
      if (setCurrentView) setCurrentView('completion');
      return;
    }
    setExpandedId(expandedId === id ? null : id);
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      {/* Locked Benefit Banner */}
      {isLocked && (
        <div className="bg-gradient-to-r from-amber-50 to-orange-50 border border-amber-200 rounded-2xl p-6 shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-start gap-3.5">
            <div className="w-11 h-11 rounded-xl bg-amber-100 text-amber-800 border border-amber-300 flex items-center justify-center shrink-0 shadow-2xs">
              <Lock className="w-6 h-6 text-amber-700" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-slate-900">
                  1000+ Interview Question Bank is a Locked Benefit
                </h3>
                <span className="px-2.5 py-0.5 bg-amber-200 text-amber-900 font-bold text-[10px] rounded-full uppercase tracking-wider">
                  Locked
                </span>
              </div>
              <p className="text-xs text-slate-600 mt-1 max-w-2xl leading-relaxed">
                Viewing 2 preview questions. Unlock the full 1,000+ question library across all 12 domains, with system design answers and HR frameworks, by purchasing the VirIntern Completion Package.
              </p>
            </div>
          </div>

          <button
            onClick={() => setCurrentView?.('completion')}
            className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl shadow-md transition-all hover:scale-[1.02] flex items-center gap-2 shrink-0"
          >
            <Sparkles className="w-4 h-4 text-amber-300" />
            <span>Unlock Full 1000+ Bank (₹99)</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Header */}
      <div className="bg-white p-6 sm:p-8 rounded-xl border border-[#E0DFDC] shadow-xs text-center max-w-3xl mx-auto">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#EBF4FD] text-[#0A66C2] text-xs font-semibold mb-3 border border-[#0A66C2]/30">
          <BookOpen className="w-3.5 h-3.5 text-[#0A66C2]" />
          <span>Curated Interview Preparation Bank</span>
        </div>
        <h1 className="text-3xl font-extrabold text-[#191919] tracking-tight">
          1000+ Interview Questions Bank
        </h1>
        <p className="text-[#666666] mt-2 text-xs sm:text-sm">
          Comprehensive collection of technical, system design, HR, and coding questions across 10 engineering domains with detailed answers and model explanations.
        </p>
      </div>

      {/* Search & Categories Bar */}
      <div className="space-y-4">
        <div className="max-w-xl mx-auto relative">
          <Search className="w-4 h-4 text-[#666666] absolute left-3.5 top-3.5" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search questions by topic, keyword, or query..."
            className="w-full pl-10 pr-4 py-2.5 text-xs bg-white border border-[#E0DFDC] rounded-xl shadow-xs focus:border-[#0A66C2] focus:ring-1 focus:ring-[#0A66C2] outline-none text-[#191919]"
          />
        </div>

        {/* Category Pills */}
        <div className="flex flex-wrap items-center justify-center gap-1.5 pt-2">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3.5 py-1.5 rounded-full text-xs font-semibold transition-colors ${
                selectedCategory === cat
                  ? 'bg-[#0A66C2] text-white shadow-xs'
                  : 'bg-white text-[#666666] hover:bg-[#F4F2EE] border border-[#E0DFDC]'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Question Accordion List */}
      <div className="space-y-3">
        {loading ? (
          <div className="py-12 text-center text-xs text-[#666666]">
            Loading curated questions...
          </div>
        ) : questions.length === 0 ? (
          <div className="p-8 text-center bg-white rounded-xl border border-[#E0DFDC] text-xs text-[#666666]">
            No questions found for the selected filter.
          </div>
        ) : (
          questions.map((q, idx) => {
            const isExpanded = expandedId === q.id;
            const itemLocked = isLocked && idx >= 2;

            if (itemLocked) {
              return (
                <div
                  key={q.id}
                  className="bg-slate-50/80 rounded-xl border border-dashed border-amber-300 p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-2xs hover:bg-amber-50/30 transition-all"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-amber-100 text-amber-700 flex items-center justify-center shrink-0">
                      <Lock className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2 mb-0.5">
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-slate-200 text-slate-600">
                          {q.category}
                        </span>
                        <span className="text-[10px] font-bold text-amber-700 bg-amber-100 px-2 py-0.2 rounded-full">
                          🔒 Locked Question #{idx + 1}
                        </span>
                      </div>
                      <p className="text-xs font-bold text-slate-700 line-clamp-1">
                        {q.question}
                      </p>
                    </div>
                  </div>

                  <button
                    onClick={() => setCurrentView?.('completion')}
                    className="px-3.5 py-1.5 bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs rounded-lg transition-colors flex items-center gap-1.5 shrink-0"
                  >
                    <Lock className="w-3 h-3" />
                    <span>Unlock Answer</span>
                  </button>
                </div>
              );
            }

            return (
              <div
                key={q.id}
                className="bg-white rounded-xl border border-[#E0DFDC] shadow-xs overflow-hidden transition-all hover:border-[#0A66C2]"
              >
                <button
                  onClick={() => toggleExpand(q.id, idx)}
                  className="w-full p-4 text-left flex items-start justify-between gap-4"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-slate-100 text-slate-700">
                        {q.category}
                      </span>
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          q.difficulty === 'Easy'
                            ? 'bg-emerald-50 text-emerald-700'
                            : q.difficulty === 'Medium'
                            ? 'bg-amber-50 text-amber-700'
                            : 'bg-rose-50 text-rose-700'
                        }`}
                      >
                        {q.difficulty}
                      </span>
                      {isLocked && idx < 2 && (
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-300">
                          Free Preview
                        </span>
                      )}
                    </div>
                    <h3 className="text-sm font-bold text-slate-900 leading-snug">
                      {q.question}
                    </h3>
                  </div>

                  <span className="p-1 rounded-lg bg-slate-100 text-slate-600 hover:bg-slate-200 transition-colors shrink-0">
                    {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                  </span>
                </button>

                {isExpanded && (
                  <div className="px-4 pb-4 pt-1 border-t border-slate-100 bg-slate-50/50 space-y-3 text-xs">
                    <div>
                      <h4 className="font-bold text-slate-800 mb-1 flex items-center gap-1.5">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                        Model Answer:
                      </h4>
                      <p className="text-slate-700 leading-relaxed bg-white p-3.5 rounded-xl border border-slate-200">
                        {q.answer}
                      </p>
                    </div>

                    {q.explanation && (
                      <div>
                        <h4 className="font-bold text-indigo-900 mb-1 flex items-center gap-1.5">
                          <HelpCircle className="w-3.5 h-3.5 text-indigo-600" />
                          Key Concept & Explanation:
                        </h4>
                        <p className="text-slate-600 leading-relaxed bg-indigo-50/50 p-3 rounded-xl border border-indigo-100">
                          {q.explanation}
                        </p>
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
