import React, { useState, useEffect } from 'react';
import { X, ShieldCheck, Scale, FileText, RefreshCw, Mail, Globe, Printer, Search, CheckCircle2, ChevronRight, AlertTriangle } from 'lucide-react';

export type LegalTab = 'privacy' | 'disclaimer' | 'terms' | 'refund';

interface LegalModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialTab?: LegalTab;
}

export const LegalModal: React.FC<LegalModalProps> = ({
  isOpen,
  onClose,
  initialTab = 'privacy'
}) => {
  const [activeTab, setActiveTab] = useState<LegalTab>(initialTab);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    if (initialTab) {
      setActiveTab(initialTab);
    }
  }, [initialTab, isOpen]);

  if (!isOpen) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/75 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-fadeIn">
      <div className="bg-white rounded-2xl max-w-4xl w-full border border-slate-200 shadow-2xl overflow-hidden my-4 max-h-[94vh] flex flex-col">
        {/* Modal Header */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-slate-900 via-indigo-950 to-blue-950 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#0A66C2] text-white flex items-center justify-center font-black text-sm shadow-xs">
              VI
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-200 border border-blue-400/30">
                  Official Legal & Compliance Center
                </span>
                <span className="text-[10px] text-slate-300 hidden sm:inline">
                  Updated: 10 October 2026
                </span>
              </div>
              <h2 className="text-base sm:text-lg font-black text-white mt-0.5">
                VirIntern Policies & Disclaimers
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="hidden sm:flex px-3 py-1.5 bg-white/10 hover:bg-white/20 text-slate-200 text-xs font-semibold rounded-lg items-center gap-1.5 transition-colors cursor-pointer border border-white/10"
              title="Print Policy Document"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print / Save PDF</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-white/10 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab Navigation Bar */}
        <div className="bg-slate-50 border-b border-slate-200 px-4 py-2 flex flex-wrap items-center justify-between gap-2 shrink-0">
          <div className="flex flex-wrap items-center gap-1.5">
            <button
              onClick={() => setActiveTab('privacy')}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer ${
                activeTab === 'privacy'
                  ? 'bg-[#0A66C2] text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
              }`}
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Privacy Policy</span>
            </button>
            <button
              onClick={() => setActiveTab('disclaimer')}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer ${
                activeTab === 'disclaimer'
                  ? 'bg-[#0A66C2] text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
              }`}
            >
              <AlertTriangle className="w-3.5 h-3.5" />
              <span>Disclaimer</span>
            </button>
            <button
              onClick={() => setActiveTab('terms')}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer ${
                activeTab === 'terms'
                  ? 'bg-[#0A66C2] text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
              }`}
            >
              <Scale className="w-3.5 h-3.5" />
              <span>Terms & Conditions</span>
            </button>
            <button
              onClick={() => setActiveTab('refund')}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer ${
                activeTab === 'refund'
                  ? 'bg-[#0A66C2] text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
              }`}
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Refund & Cancellation</span>
            </button>
          </div>

          <div className="text-[11px] font-mono text-slate-500">
            virintern.in@gmail.com
          </div>
        </div>

        {/* Policy Document Content Body */}
        <div className="overflow-y-auto p-4 sm:p-8 flex-1 bg-white space-y-6 text-[#191919] font-sans leading-relaxed text-xs sm:text-sm">
          
          {/* TAB 1: PRIVACY POLICY */}
          {activeTab === 'privacy' && (
            <div className="space-y-6 animate-fadeIn max-w-3xl mx-auto">
              <div className="border-b border-slate-200 pb-4">
                <span className="text-[11px] font-bold text-[#0A66C2] uppercase tracking-wider block">
                  Official Legal Document
                </span>
                <h1 className="text-xl sm:text-2xl font-black text-slate-900 mt-1">
                  Privacy Policy — VirIntern
                </h1>
                <p className="text-xs text-slate-500 mt-1">
                  Last Updated: 10 October 2026
                </p>
              </div>

              {/* Section 1 */}
              <section className="space-y-2">
                <h3 className="text-sm sm:text-base font-bold text-slate-900">
                  1. Introduction
                </h3>
                <p className="text-slate-700 leading-relaxed">
                  VirIntern ("we," "our," or "the Platform") respects your privacy and is committed to protecting the personal information of users who access our website and services.
                </p>
                <p className="text-slate-700 leading-relaxed">
                  This Privacy Policy explains how we collect, use, store, and protect information when you use VirIntern.
                </p>
              </section>

              {/* Section 2 */}
              <section className="space-y-2">
                <h3 className="text-sm sm:text-base font-bold text-slate-900">
                  2. Information We Collect
                </h3>
                <p className="text-slate-700 leading-relaxed">
                  Depending on the features you use, we may collect:
                </p>
                <ul className="space-y-1.5 pl-5 list-disc text-slate-700">
                  <li><strong>Personal information:</strong> Name, email address, phone number, and account details.</li>
                  <li><strong>Profile information:</strong> Educational details, selected domain, skills, and learning preferences.</li>
                  <li><strong>Task and project information:</strong> Task submissions, project links, GitHub URLs, feedback, scores, and progress records.</li>
                  <li><strong>Payment information:</strong> Payment status, transaction reference, and related records. Payment credentials are handled by the applicable payment provider where supported.</li>
                  <li><strong>Referral information:</strong> Referral codes and eligible referral transaction records.</li>
                  <li><strong>Technical information:</strong> Browser type, device information, usage logs, and security-related data where collected.</li>
                </ul>
                <p className="text-slate-700 leading-relaxed pt-1">
                  We aim to collect only information reasonably necessary to operate and improve the Platform.
                </p>
              </section>

              {/* Section 3 */}
              <section className="space-y-2">
                <h3 className="text-sm sm:text-base font-bold text-slate-900">
                  3. How We Use Your Information
                </h3>
                <p className="text-slate-700 leading-relaxed">
                  We may use your information to:
                </p>
                <ul className="space-y-1.5 pl-5 list-disc text-slate-700">
                  <li>Create and manage user accounts.</li>
                  <li>Assign tasks and manage learning progress.</li>
                  <li>Review submissions and provide feedback.</li>
                  <li>Maintain leaderboards, where applicable.</li>
                  <li>Process payments and eligible referral benefits.</li>
                  <li>Respond to support requests.</li>
                  <li>Prevent fraud, abuse, and unauthorized access.</li>
                  <li>Improve website functionality, security, and user experience.</li>
                  <li>Meet applicable legal and regulatory obligations.</li>
                </ul>
              </section>

              {/* Section 4 */}
              <section className="space-y-2">
                <h3 className="text-sm sm:text-base font-bold text-slate-900">
                  4. Sharing of Information
                </h3>
                <p className="text-slate-700 leading-relaxed">
                  We do not sell personal information to third parties.
                </p>
                <p className="text-slate-700 leading-relaxed">
                  Information may be shared with service providers when necessary to operate the Platform, including hosting, authentication, database, analytics, email, and payment services. Information may also be disclosed when legally required or when necessary to protect the rights and security of users and the Platform.
                </p>
                <p className="text-slate-700 leading-relaxed">
                  If a task, leaderboard, or partnership feature makes information visible to other users or external organizations, the applicable visibility and sharing arrangements should be explained before participation.
                </p>
              </section>

              {/* Section 5 */}
              <section className="space-y-2">
                <h3 className="text-sm sm:text-base font-bold text-slate-900">
                  5. Data Storage and Security
                </h3>
                <p className="text-slate-700 leading-relaxed">
                  We use reasonable technical and organizational measures to protect information against unauthorized access, loss, alteration, or disclosure. However, no online service can guarantee absolute security.
                </p>
                <p className="text-slate-700 leading-relaxed">
                  Access to personal information should be limited to authorized persons and service providers who need it for legitimate purposes.
                </p>
              </section>

              {/* Section 6 */}
              <section className="space-y-2">
                <h3 className="text-sm sm:text-base font-bold text-slate-900">
                  6. Data Retention and Deletion
                </h3>
                <p className="text-slate-700 leading-relaxed">
                  We retain information for as long as reasonably necessary to provide services, maintain records, resolve disputes, prevent fraud, or comply with applicable legal requirements.
                </p>
                <p className="text-slate-700 leading-relaxed">
                  You may request access to, correction of, or deletion of your personal information by contacting us. Some records may need to be retained where legally required or necessary for legitimate security and financial purposes.
                </p>
              </section>

              {/* Section 7 */}
              <section className="space-y-2">
                <h3 className="text-sm sm:text-base font-bold text-slate-900">
                  7. Cookies and Similar Technologies
                </h3>
                <p className="text-slate-700 leading-relaxed">
                  The Platform may use cookies or similar technologies for essential functionality, authentication, security, preferences, and analytics where implemented. You can manage cookies through your browser settings, although disabling certain cookies may affect website functionality.
                </p>
              </section>

              {/* Section 8 */}
              <section className="space-y-2">
                <h3 className="text-sm sm:text-base font-bold text-slate-900">
                  8. Third-Party Services
                </h3>
                <p className="text-slate-700 leading-relaxed">
                  VirIntern may rely on third-party services such as Firebase, payment providers, or external project-hosting websites. Their services may be governed by their own privacy policies and terms.
                </p>
                <p className="text-slate-700 leading-relaxed">
                  Users should review those policies when using the relevant services.
                </p>
              </section>

              {/* Section 9 */}
              <section className="space-y-2">
                <h3 className="text-sm sm:text-base font-bold text-slate-900">
                  9. Children's Privacy
                </h3>
                <p className="text-slate-700 leading-relaxed">
                  Users should provide accurate age information where requested. Where applicable law requires parental consent or other safeguards for minors, VirIntern will follow the relevant requirements.
                </p>
              </section>

              {/* Section 10 */}
              <section className="space-y-2">
                <h3 className="text-sm sm:text-base font-bold text-slate-900">
                  10. Your Rights
                </h3>
                <p className="text-slate-700 leading-relaxed">
                  Subject to applicable law, you may request access to, correction of, or deletion of your personal information, raise a privacy concern, or withdraw consent where processing is based on consent.
                </p>
              </section>

              {/* Section 11 */}
              <section className="space-y-2">
                <h3 className="text-sm sm:text-base font-bold text-slate-900">
                  11. Changes to This Policy
                </h3>
                <p className="text-slate-700 leading-relaxed">
                  We may update this Privacy Policy when our services, practices, or legal obligations change. The updated version will be published on this page with a revised date.
                </p>
              </section>

              {/* Section 12 */}
              <section className="space-y-3 p-4 bg-slate-50 rounded-xl border border-slate-200">
                <h3 className="text-sm sm:text-base font-bold text-slate-900">
                  12. Contact Us
                </h3>
                <p className="text-slate-700">
                  For privacy-related questions or requests:
                </p>
                <div className="space-y-1 text-slate-800 font-medium">
                  <p><strong>Organization:</strong> VirIntern</p>
                  <p><strong>Contact Email:</strong> <a href="mailto:virintern.in@gmail.com" className="text-[#0A66C2] hover:underline font-mono">virintern.in@gmail.com</a></p>
                  <p><strong>Website:</strong> <a href="https://virintern.vercel.app" target="_blank" rel="noreferrer" className="text-[#0A66C2] hover:underline font-mono">virintern.vercel.app</a></p>
                </div>
              </section>
            </div>
          )}

          {/* TAB 2: DISCLAIMER */}
          {activeTab === 'disclaimer' && (
            <div className="space-y-6 animate-fadeIn max-w-3xl mx-auto">
              <div className="border-b border-slate-200 pb-4">
                <span className="text-[11px] font-bold text-amber-700 uppercase tracking-wider block">
                  Important Notice
                </span>
                <h1 className="text-xl sm:text-2xl font-black text-slate-900 mt-1">
                  Disclaimer — VirIntern
                </h1>
                <p className="text-xs text-slate-500 mt-1">
                  Last Updated: 10 October 2026
                </p>
              </div>

              {/* Section 1 */}
              <section className="space-y-2">
                <h3 className="text-sm sm:text-base font-bold text-slate-900">
                  1. General Information
                </h3>
                <p className="text-slate-700 leading-relaxed">
                  VirIntern is a project-based learning initiative intended to help participants develop practical skills through structured tasks, project work, and learning activities.
                </p>
                <p className="text-slate-700 leading-relaxed">
                  Information provided on this website is for general informational and educational purposes. While we make reasonable efforts to maintain accurate information, we do not guarantee that all content will always be complete, current, or error-free.
                </p>
              </section>

              {/* Section 2 */}
              <section className="space-y-2 p-4 bg-amber-50/70 border border-amber-200 rounded-xl">
                <h3 className="text-sm sm:text-base font-bold text-amber-950 flex items-center gap-1.5">
                  <AlertTriangle className="w-4 h-4 text-amber-600" />
                  <span>2. No Guarantee of Employment</span>
                </h3>
                <p className="text-amber-900 leading-relaxed">
                  Participation in VirIntern does not guarantee employment, a job offer, a paid internship, placement, promotion, or selection by any company.
                </p>
                <p className="text-amber-900 leading-relaxed">
                  Career outcomes depend on individual skills, performance, qualifications, market conditions, and decisions made by employers or other organizations.
                </p>
              </section>

              {/* Section 3 */}
              <section className="space-y-2">
                <h3 className="text-sm sm:text-base font-bold text-slate-900">
                  3. No Guaranteed Learning or Performance Outcomes
                </h3>
                <p className="text-slate-700 leading-relaxed">
                  VirIntern provides learning activities and opportunities to practise skills. Individual outcomes depend on each participant's effort, prior knowledge, and engagement. We do not guarantee a particular level of proficiency, academic result, or professional outcome.
                </p>
              </section>

              {/* Section 4 */}
              <section className="space-y-2">
                <h3 className="text-sm sm:text-base font-bold text-slate-900">
                  4. Certificates and Completion Records
                </h3>
                <p className="text-slate-700 leading-relaxed">
                  Any certificate, completion record, badge, or recognition will be issued only where applicable under the Platform's actual program rules. Such documents are not equivalent to an academic degree, government accreditation, or professional licence unless explicitly authorized and verified.
                </p>
              </section>

              {/* Section 5 */}
              <section className="space-y-2">
                <h3 className="text-sm sm:text-base font-bold text-slate-900">
                  5. Company Affiliations and Endorsements
                </h3>
                <p className="text-slate-700 leading-relaxed">
                  References to companies, tools, technologies, or external organizations do not necessarily imply sponsorship, partnership, endorsement, or affiliation.
                </p>
                <p className="text-slate-700 leading-relaxed">
                  Any claimed partnership or selection opportunity will be communicated only when it has been confirmed. VirIntern does not promise that participants will be connected with companies or recruiters.
                </p>
              </section>

              {/* Section 6 */}
              <section className="space-y-2">
                <h3 className="text-sm sm:text-base font-bold text-slate-900">
                  6. User Submissions
                </h3>
                <p className="text-slate-700 leading-relaxed">
                  Users are responsible for ensuring that submitted projects, documents, code, and other materials comply with applicable laws and respect intellectual property rights. Users should not submit confidential information, unauthorized personal data, or material they do not have permission to share.
                </p>
              </section>

              {/* Section 7 */}
              <section className="space-y-2">
                <h3 className="text-sm sm:text-base font-bold text-slate-900">
                  7. External Links and Services
                </h3>
                <p className="text-slate-700 leading-relaxed">
                  The website may contain links to third-party platforms, including code repositories and payment services. VirIntern does not control all third-party content, availability, policies, or security practices.
                </p>
              </section>

              {/* Section 8 */}
              <section className="space-y-2">
                <h3 className="text-sm sm:text-base font-bold text-slate-900">
                  8. Website Availability
                </h3>
                <p className="text-slate-700 leading-relaxed">
                  We may update, modify, suspend, or discontinue features for maintenance, security, operational, or other legitimate reasons. We do not guarantee uninterrupted or error-free website availability.
                </p>
              </section>

              {/* Section 9 */}
              <section className="space-y-2">
                <h3 className="text-sm sm:text-base font-bold text-slate-900">
                  9. Limitation of Responsibility
                </h3>
                <p className="text-slate-700 leading-relaxed">
                  To the extent permitted by applicable law, VirIntern is not responsible for indirect losses arising from reliance on general website information, third-party services, or outcomes that are outside our reasonable control. Nothing in this Disclaimer excludes rights or liabilities that cannot lawfully be excluded.
                </p>
              </section>

              {/* Section 10 */}
              <section className="space-y-2 p-4 bg-slate-50 rounded-xl border border-slate-200">
                <h3 className="text-sm sm:text-base font-bold text-slate-900">
                  10. Contact
                </h3>
                <p className="text-slate-700">
                  For questions regarding this Disclaimer, contact:
                </p>
                <div className="space-y-0.5 text-slate-800 font-medium">
                  <p><strong>VirIntern</strong></p>
                  <p><strong>Email:</strong> <a href="mailto:virintern.in@gmail.com" className="text-[#0A66C2] hover:underline font-mono">virintern.in@gmail.com</a></p>
                </div>
              </section>
            </div>
          )}

          {/* TAB 3: TERMS & CONDITIONS */}
          {activeTab === 'terms' && (
            <div className="space-y-6 animate-fadeIn max-w-3xl mx-auto">
              <div className="border-b border-slate-200 pb-4">
                <span className="text-[11px] font-bold text-indigo-700 uppercase tracking-wider block">
                  User Agreement
                </span>
                <h1 className="text-xl sm:text-2xl font-black text-slate-900 mt-1">
                  Terms & Conditions — VirIntern
                </h1>
                <p className="text-xs text-slate-500 mt-1">
                  Last Updated: 10 October 2026
                </p>
              </div>

              {/* Section 1 */}
              <section className="space-y-2">
                <h3 className="text-sm sm:text-base font-bold text-slate-900">
                  1. Acceptance of Terms
                </h3>
                <p className="text-slate-700 leading-relaxed">
                  By accessing or using VirIntern, you agree to these Terms & Conditions and the applicable Privacy Policy. If you do not agree, please discontinue use of the Platform.
                </p>
              </section>

              {/* Section 2 */}
              <section className="space-y-2">
                <h3 className="text-sm sm:text-base font-bold text-slate-900">
                  2. Eligibility and Accounts
                </h3>
                <p className="text-slate-700 leading-relaxed">
                  Users must provide accurate information, keep their login credentials secure, and use the Platform lawfully. Users are responsible for activity conducted through their accounts, subject to applicable law.
                </p>
              </section>

              {/* Section 3 */}
              <section className="space-y-2">
                <h3 className="text-sm sm:text-base font-bold text-slate-900">
                  3. Platform Services
                </h3>
                <p className="text-slate-700 leading-relaxed">
                  VirIntern may provide learning tasks, project submissions, progress tracking, feedback, leaderboards, and related features. Available features, eligibility requirements, timelines, and evaluation procedures may change as the Platform develops.
                </p>
              </section>

              {/* Section 4 */}
              <section className="space-y-2">
                <h3 className="text-sm sm:text-base font-bold text-slate-900">
                  4. Task Completion and Evaluation
                </h3>
                <p className="text-slate-700 leading-relaxed">
                  Users must follow task instructions and submission requirements. Evaluation may consider relevance, completeness, originality, quality, and compliance with the task criteria.
                </p>
                <p className="text-slate-700 leading-relaxed">
                  Submission of a task does not automatically guarantee approval, a particular score, a certificate, or any external opportunity.
                </p>
              </section>

              {/* Section 5 */}
              <section className="space-y-2">
                <h3 className="text-sm sm:text-base font-bold text-slate-900">
                  5. Acceptable Use
                </h3>
                <p className="text-slate-700 leading-relaxed">
                  Users must not:
                </p>
                <ul className="space-y-1.5 pl-5 list-disc text-slate-700">
                  <li>Submit plagiarized work or misrepresent another person's work as their own.</li>
                  <li>Attempt to access another user's account or private information without authorization.</li>
                  <li>Exploit vulnerabilities, interfere with website operations, or misuse the Platform.</li>
                  <li>Upload unlawful, harmful, infringing, or unauthorized content.</li>
                  <li>Manipulate scores, referrals, payments, or leaderboards.</li>
                  <li>Use the Platform for fraudulent or misleading purposes.</li>
                </ul>
                <p className="text-slate-700 leading-relaxed pt-1">
                  VirIntern may investigate suspected violations and take proportionate action consistent with applicable law and these Terms.
                </p>
              </section>

              {/* Section 6 */}
              <section className="space-y-2">
                <h3 className="text-sm sm:text-base font-bold text-slate-900">
                  6. Payments and Referral Benefits
                </h3>
                <p className="text-slate-700 leading-relaxed">
                  Where paid features are offered, their price, scope, eligibility, and applicable terms will be displayed before payment.
                </p>
                <p className="text-slate-700 leading-relaxed">
                  Referral benefits, where available, are subject to the published referral rules, eligibility criteria, verification, and prevention of fraudulent activity. No referral reward is guaranteed unless the stated conditions have been satisfied.
                </p>
                <p className="text-slate-700 leading-relaxed">
                  Any refund, cancellation, or payment dispute will be handled under the published Refund & Cancellation Policy and applicable law.
                </p>
              </section>

              {/* Section 7 */}
              <section className="space-y-2">
                <h3 className="text-sm sm:text-base font-bold text-slate-900">
                  7. Intellectual Property
                </h3>
                <p className="text-slate-700 leading-relaxed">
                  VirIntern's original website design, branding, and materials are protected by applicable intellectual property laws. Users retain rights they own in their original submissions, subject to any separate, clearly disclosed licence or permission granted to VirIntern.
                </p>
                <p className="text-slate-700 leading-relaxed">
                  Users must have the necessary rights to any third-party content included in their submissions.
                </p>
              </section>

              {/* Section 8 */}
              <section className="space-y-2">
                <h3 className="text-sm sm:text-base font-bold text-slate-900">
                  8. Suspension and Termination
                </h3>
                <p className="text-slate-700 leading-relaxed">
                  VirIntern may restrict or suspend access where reasonably necessary to address suspected fraud, security risks, serious violations, or unlawful activity. Where appropriate and legally permissible, users may be given notice and an opportunity to resolve the issue.
                </p>
              </section>

              {/* Section 9 */}
              <section className="space-y-2">
                <h3 className="text-sm sm:text-base font-bold text-slate-900">
                  9. Changes to Services or Terms
                </h3>
                <p className="text-slate-700 leading-relaxed">
                  We may revise the Platform or these Terms when necessary. Material changes will be published on the website, with an updated date and any additional notice required by law.
                </p>
              </section>

              {/* Section 10 */}
              <section className="space-y-2">
                <h3 className="text-sm sm:text-base font-bold text-slate-900">
                  10. Liability and Legal Rights
                </h3>
                <p className="text-slate-700 leading-relaxed">
                  These Terms do not exclude consumer rights or other legal protections that cannot be excluded under applicable law. Any limitation of liability will apply only to the extent permitted by law.
                </p>
              </section>

              {/* Section 11 */}
              <section className="space-y-2">
                <h3 className="text-sm sm:text-base font-bold text-slate-900">
                  11. Governing Law
                </h3>
                <p className="text-slate-700 leading-relaxed">
                  These Terms are subject to applicable laws of India. Any jurisdiction or dispute-resolution provision will operate subject to mandatory legal requirements.
                </p>
              </section>

              {/* Section 12 */}
              <section className="space-y-3 p-4 bg-slate-50 rounded-xl border border-slate-200">
                <h3 className="text-sm sm:text-base font-bold text-slate-900">
                  12. Contact
                </h3>
                <div className="space-y-1 text-slate-800 font-medium">
                  <p><strong>VirIntern</strong></p>
                  <p><strong>Email:</strong> <a href="mailto:virintern.in@gmail.com" className="text-[#0A66C2] hover:underline font-mono">virintern.in@gmail.com</a></p>
                  <p><strong>Website:</strong> <a href="https://virintern.vercel.app" target="_blank" rel="noreferrer" className="text-[#0A66C2] hover:underline font-mono">virintern.vercel.app</a></p>
                </div>
                <p className="text-[11px] text-slate-500 pt-1">
                  By using the website, you acknowledge that you have read this Disclaimer.
                </p>
              </section>
            </div>
          )}

          {/* TAB 4: REFUND & CANCELLATION POLICY */}
          {activeTab === 'refund' && (
            <div className="space-y-6 animate-fadeIn max-w-3xl mx-auto">
              <div className="border-b border-slate-200 pb-4">
                <span className="text-[11px] font-bold text-emerald-700 uppercase tracking-wider block">
                  Payment Protection
                </span>
                <h1 className="text-xl sm:text-2xl font-black text-slate-900 mt-1">
                  Refund & Cancellation Policy — VirIntern
                </h1>
                <p className="text-xs text-slate-500 mt-1">
                  Last Updated: 10 October 2026
                </p>
              </div>

              {/* Section 1 */}
              <section className="space-y-2">
                <h3 className="text-sm sm:text-base font-bold text-slate-900">
                  1. Scope
                </h3>
                <p className="text-slate-700 leading-relaxed">
                  This policy applies to paid services offered through VirIntern, where applicable. The specific service, price, deliverables, and eligibility conditions will be disclosed before payment.
                </p>
              </section>

              {/* Section 2 */}
              <section className="space-y-2">
                <h3 className="text-sm sm:text-base font-bold text-slate-900">
                  2. Refund Requests
                </h3>
                <p className="text-slate-700 leading-relaxed">
                  If you believe you have been charged incorrectly, paid more than once for the same transaction, or experienced a payment failure despite a debit, contact VirIntern with your registered email address and transaction reference.
                </p>
                <p className="text-slate-700 leading-relaxed">
                  We will review the request and coordinate with the payment provider where necessary.
                </p>
              </section>

              {/* Section 3 */}
              <section className="space-y-2">
                <h3 className="text-sm sm:text-base font-bold text-slate-900">
                  3. Duplicate or Failed Transactions
                </h3>
                <p className="text-slate-700 leading-relaxed">
                  Verified duplicate payments or payments debited without a corresponding successful order will be reviewed for correction or refund, as appropriate under applicable law and the payment provider's process.
                </p>
              </section>

              {/* Section 4 */}
              <section className="space-y-2">
                <h3 className="text-sm sm:text-base font-bold text-slate-900">
                  4. Service-Related Requests
                </h3>
                <p className="text-slate-700 leading-relaxed">
                  Requests relating to non-delivery, significant differences between the advertised and supplied service, or other legitimate concerns will be assessed based on the circumstances, published offer terms, and applicable consumer law.
                </p>
                <p className="text-slate-700 leading-relaxed">
                  A blanket refusal of refunds will not apply where a refund or other remedy is legally required.
                </p>
              </section>

              {/* Section 5 */}
              <section className="space-y-2">
                <h3 className="text-sm sm:text-base font-bold text-slate-900">
                  5. Cancellation
                </h3>
                <p className="text-slate-700 leading-relaxed">
                  If cancellation is available for a particular service, the applicable deadline and conditions will be displayed before purchase. Contact support promptly if you wish to cancel.
                </p>
              </section>

              {/* Section 6 */}
              <section className="space-y-2">
                <h3 className="text-sm sm:text-base font-bold text-slate-900">
                  6. Processing Time
                </h3>
                <p className="text-slate-700 leading-relaxed">
                  Approved refunds will be initiated within a reasonable period. The time required for the amount to appear in your account may depend on the payment provider and banking system.
                </p>
              </section>

              {/* Section 7 */}
              <section className="space-y-3 p-4 bg-slate-50 rounded-xl border border-slate-200">
                <h3 className="text-sm sm:text-base font-bold text-slate-900">
                  7. How to Request Help
                </h3>
                <p className="text-slate-700">
                  Please provide:
                </p>
                <ul className="space-y-1 pl-5 list-disc text-slate-700">
                  <li>Registered email address</li>
                  <li>Transaction reference or order ID</li>
                  <li>Date and amount of payment</li>
                  <li>Brief description of the issue</li>
                </ul>
                <div className="pt-2 text-slate-800 font-medium">
                  <p><strong>Support Email:</strong> <a href="mailto:virintern.in@gmail.com" className="text-[#0A66C2] hover:underline font-mono">virintern.in@gmail.com</a></p>
                </div>
              </section>
            </div>
          )}

        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0">
          <div className="text-xs text-slate-500 flex items-center gap-1.5">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>VirIntern is governed under the laws of India.</span>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              onClick={handlePrint}
              className="flex-1 sm:flex-initial px-4 py-2 border border-slate-300 hover:bg-slate-100 text-slate-700 text-xs font-semibold rounded-xl flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print Policy</span>
            </button>
            <button
              onClick={onClose}
              className="flex-1 sm:flex-initial px-5 py-2 bg-[#0A66C2] hover:bg-[#004182] text-white text-xs font-bold rounded-xl cursor-pointer shadow-xs transition-colors"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
