import React, { useRef } from 'react';
import { X, Download, Printer, CheckCircle2, ShieldCheck, Sparkles, Building2, Calendar, User, FileText, ArrowRight } from 'lucide-react';
import { UserProfile, InternshipRecord } from '../types';
import { generateStudentTasks } from '../services/domainProjectsService';

interface OfferLetterModalProps {
  isOpen: boolean;
  onClose: () => void;
  user?: UserProfile | null;
  internship?: InternshipRecord | null;
  onAttachToTask1?: (offerData: { fileName: string; url: string; dataUri?: string }) => void;
}

export const OfferLetterModal: React.FC<OfferLetterModalProps> = ({
  isOpen,
  onClose,
  user,
  internship,
  onAttachToTask1
}) => {
  const printRef = useRef<HTMLDivElement>(null);

  if (!isOpen) return null;

  const currentUser = user || {
    uid: 'student_2026',
    name: 'Intern Candidate',
    email: 'intern@virintern.com',
    role: 'student' as const,
    referralCode: 'VIR2026',
    internshipStatus: 'active' as const,
    progress: 0,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };

  const currentInternship = internship || {
    id: 'internship_2026',
    userId: currentUser.uid,
    domainId: 'tech',
    domainName: 'Virtual Internship Track',
    startDate: new Date().toISOString(),
    endDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
    status: 'active' as const,
    progress: 0,
    currentTask: 1,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };

  const startDateFormatted = currentInternship.startDate ? new Date(currentInternship.startDate).toLocaleDateString('en-US', {
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  }) : 'Current Cohort';

  const endDateFormatted = currentInternship.endDate ? new Date(currentInternship.endDate).toLocaleDateString('en-US', {
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  }) : '30 Days Tenure';

  const issueDateFormatted = new Date(currentInternship.createdAt || currentInternship.startDate || Date.now()).toLocaleDateString('en-US', {
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  });

  const rawDomain = currentInternship.domainId || (currentInternship as any)?.domainSlug || (currentInternship as any)?.domain || 'TECH';
  const domainSlug = String(rawDomain).toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 4) || 'TECH';
  const cleanUid = String(currentUser.uid || '2026').replace(/[^a-zA-Z0-9]/g, '').slice(-5).toUpperCase() || '2026';
  const referenceNo = `VIR-OFFER-2026-${domainSlug}-${cleanUid}`;

  const resolvedStudentName = (currentUser.name && currentUser.name.trim().toLowerCase() !== 'student' && currentUser.name.trim().toLowerCase() !== 'intern')
    ? currentUser.name.trim()
    : (typeof window !== 'undefined'
        ? (localStorage.getItem(`virintern_user_name_${(currentUser.email || '').toLowerCase()}`) ||
           (currentUser.uid ? localStorage.getItem(`virintern_user_name_${currentUser.uid}`) : null) ||
           localStorage.getItem('virintern_last_signup_name') ||
           currentUser.name)
        : currentUser.name) || (currentUser.email ? currentUser.email.split('@')[0] : 'Student');

  const userNameSafe = String(resolvedStudentName).replace(/\s+/g, '_');
  const defaultFileName = `VirIntern_Offer_Letter_${userNameSafe}_${domainSlug}.pdf`;

  const assignedTasks = generateStudentTasks(
    currentInternship.domainId || 'tech',
    currentInternship.domainName || 'Engineering Track',
    currentUser.uid
  );

  const handlePrint = () => {
    window.print();
  };

  const handleDownload = () => {
    try {
      const element = printRef.current;
      if (!element) {
        window.print();
        return;
      }
      const printContents = element.innerHTML;
      const htmlDoc = `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>${defaultFileName}</title>
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; padding: 40px; color: #191919; max-width: 800px; margin: 0 auto; }
    table { width: 100%; border-collapse: collapse; margin: 16px 0; }
    th, td { border: 1px solid #cbd5e1; padding: 10px 12px; text-align: left; }
    .header { border-bottom: 3px solid #0A66C2; padding-bottom: 20px; margin-bottom: 24px; }
  </style>
</head>
<body>
  ${printContents}
</body>
</html>`;
      const blob = new Blob([htmlDoc], { type: 'text/html' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = defaultFileName.replace('.pdf', '.html');
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch {
      window.print();
    }
  };

  const handleAttach = () => {
    if (onAttachToTask1) {
      onAttachToTask1({
        fileName: defaultFileName,
        url: `virintern://offer-letters/${referenceNo}`
      });
    }
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/70 backdrop-blur-sm overflow-y-auto animate-fadeIn">
      <div className="bg-white w-full max-w-3xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-6 flex flex-col max-h-[92vh]">
        {/* Top Control Bar */}
        <div className="bg-slate-900 text-white px-5 py-3.5 flex items-center justify-between border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-indigo-600 flex items-center justify-center text-white">
              <FileText className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
                <span>Official Internship Offer Letter</span>
                <span className="px-2 py-0.2 bg-emerald-500/20 text-emerald-300 text-[10px] font-semibold rounded-full border border-emerald-500/30">
                  Verified
                </span>
              </h3>
              <p className="text-[11px] text-slate-400">Ref: {referenceNo}</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-colors"
              title="Print or Save as PDF"
            >
              <Printer className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Print / Save PDF</span>
            </button>
            {onAttachToTask1 && (
              <button
                onClick={handleAttach}
                className="px-3 py-1.5 bg-[#0A66C2] hover:bg-[#004182] text-white text-xs font-bold rounded-lg flex items-center gap-1.5 transition-colors shadow-xs"
              >
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Attach to Task 1</span>
              </button>
            )}
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Offer Letter Document View */}
        <div className="overflow-y-auto p-6 sm:p-10 bg-slate-50 flex-1">
          <div
            ref={printRef}
            className="bg-white p-8 sm:p-12 rounded-xl border border-slate-200 shadow-sm max-w-2xl mx-auto space-y-7 text-[#191919] font-sans"
          >
            {/* Header Letterhead */}
            <div className="border-b-2 border-[#0A66C2] pb-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-2 text-[#0A66C2]">
                  <div className="w-9 h-9 rounded-lg bg-[#0A66C2] text-white flex items-center justify-center font-bold text-lg">
                    VI
                  </div>
                  <div>
                    <h1 className="text-xl font-extrabold tracking-tight text-[#0A66C2]">
                      VirIntern Global Labs
                    </h1>
                    <p className="text-[10px] uppercase font-bold tracking-wider text-slate-500">
                      Virtual Internship & Applied Engineering Initiative
                    </p>
                  </div>
                </div>
                <p className="text-[11px] text-slate-500 mt-2">
                  CIN: U72900KA2026PTC184920 • ISO 9001:2015 Quality Verified
                </p>
              </div>

              <div className="text-right text-xs space-y-1">
                <p className="font-semibold text-slate-800">Corporate Innovation Park</p>
                <p className="text-slate-500">Tech Corridor, Phase 2, Bangalore - 560103</p>
                <p className="text-slate-500">contact@virintern.com • www.virintern.com</p>
              </div>
            </div>

            {/* Date & Ref */}
            <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-600 border-b border-slate-100 pb-3">
              <div>
                <span className="font-bold text-slate-700">Ref ID:</span>{' '}
                <span className="font-mono text-[#0A66C2] font-semibold">{referenceNo}</span>
              </div>
              <div>
                <span className="font-bold text-slate-700">Date of Issuance:</span>{' '}
                <span>{issueDateFormatted}</span>
              </div>
            </div>

            {/* Candidate Info */}
            <div className="space-y-1 text-xs text-slate-800">
              <p className="text-[11px] uppercase font-bold text-slate-400">To,</p>
              <p className="text-base font-bold text-[#191919]">{currentUser.name || 'Intern Candidate'}</p>
              <p className="text-slate-600">{currentUser.email || 'intern@virintern.com'}</p>
              <p className="text-slate-600 font-medium">Candidate ID: {cleanUid}</p>
            </div>

            {/* Subject */}
            <div className="bg-[#EBF4FD] p-3.5 rounded-lg border border-[#0A66C2]/20">
              <p className="text-xs font-bold text-[#0A66C2]">
                SUBJECT: LETTER OF APPOINTMENT - VIRTUAL INTERNSHIP IN {(currentInternship.domainName || 'Engineering').toUpperCase()}
              </p>
            </div>

            {/* Main Body */}
            <div className="space-y-3.5 text-xs text-slate-700 leading-relaxed">
              <p>
                Dear <strong>{resolvedStudentName}</strong>,
              </p>
              <p>
                Following your application and profile registration on the VirIntern platform, we are pleased to offer you an appointment as a{' '}
                <strong>Virtual Research & Development Intern</strong> in our <strong>{currentInternship.domainName || 'Engineering'}</strong> track.
              </p>
              <p>
                This intensive 1-month structured virtual internship commences on <strong>{startDateFormatted}</strong> and is scheduled for completion on <strong>{endDateFormatted}</strong>. During this tenure, you will work on 5 hands-on milestone projects designed to build practical, production-level engineering capability under industry mentorship.
              </p>

              {/* Terms Table */}
              <div className="border border-slate-200 rounded-lg overflow-hidden my-3">
                <table className="w-full text-[11px]">
                  <tbody>
                    <tr className="border-b border-slate-200 bg-slate-50">
                      <td className="p-2.5 font-bold text-slate-700 w-1/3">Assigned Track</td>
                      <td className="p-2.5 text-slate-900 font-semibold">{currentInternship.domainName || 'Engineering'} Virtual Internship</td>
                    </tr>
                    <tr className="border-b border-slate-200">
                      <td className="p-2.5 font-bold text-slate-700">Internship Duration</td>
                      <td className="p-2.5 text-slate-900">1 Month ({startDateFormatted} – {endDateFormatted})</td>
                    </tr>
                    <tr className="border-b border-slate-200 bg-slate-50">
                      <td className="p-2.5 font-bold text-slate-700">Mode of Internship</td>
                      <td className="p-2.5 text-slate-900">100% Virtual / Remote Flexible Learning</td>
                    </tr>
                    <tr className="border-b border-slate-200">
                      <td className="p-2.5 font-bold text-slate-700">Milestone Requirements</td>
                      <td className="p-2.5 text-slate-900">5 Milestone Tasks with verified GitHub repositories & live demos</td>
                    </tr>
                    <tr className="bg-slate-50">
                      <td className="p-2.5 font-bold text-slate-700">Certification & Perks</td>
                      <td className="p-2.5 text-slate-900">ISO-verified Completion Certificate, Letter of Commendation & Verified Digital Badge</td>
                    </tr>
                  </tbody>
                </table>
              </div>

              <p>
                <strong>Onboarding Next Steps:</strong> To formalize your onboarding, please attach or link this official Offer Letter as your verification proof under <strong>Task 1</strong> on your student dashboard.
              </p>
              <p>
                We congratulate you on this appointment and look forward to your dedication and outstanding engineering contributions throughout the curriculum.
              </p>
            </div>

            {/* Signatures & Seal */}
            <div className="pt-6 border-t border-slate-200 flex items-end justify-between">
              <div className="space-y-1">
                <div className="font-serif italic text-lg text-slate-800 font-bold tracking-wider">
                  Arjun Mehta
                </div>
                <div className="w-32 h-0.5 bg-slate-400"></div>
                <p className="text-xs font-bold text-slate-900 mt-1">Dr. Arjun Mehta, Ph.D.</p>
                <p className="text-[10px] text-slate-500">Director, Academic & Industry Partnerships</p>
                <p className="text-[10px] text-[#0A66C2] font-semibold">VirIntern Global Labs</p>
              </div>

              {/* Official Seal Badge */}
              <div className="w-24 h-24 rounded-full border-2 border-dashed border-[#0A66C2] flex flex-col items-center justify-center text-center p-2 text-[#0A66C2] bg-blue-50/50">
                <ShieldCheck className="w-5 h-5 text-[#0A66C2]" />
                <span className="text-[9px] font-extrabold uppercase tracking-tight mt-0.5">OFFICIAL SEAL</span>
                <span className="text-[8px] text-slate-500 font-mono">VERIFIED</span>
              </div>
            </div>

            {/* Annexure A: Official Curriculum & Project Tasks (Embedded in PDF) */}
            <div className="pt-8 border-t-2 border-slate-300 space-y-4">
              <div className="border-b border-slate-200 pb-2">
                <span className="text-[10px] uppercase font-bold text-[#0A66C2] tracking-wider block">
                  ANNEXURE A — OFFICIAL PROJECT TASKS & MILESTONE ROADMAP
                </span>
                <h3 className="text-sm font-bold text-slate-900 mt-0.5">
                  {currentInternship.domainName || 'Engineering'} Virtual Internship Project Deliverables
                </h3>
                <p className="text-[11px] text-slate-500 mt-1 leading-relaxed">
                  The following 5 structured project milestones must be completed during the 30-day internship tenure. All projects are designed using 100% free, industry-standard tools (Zero Cost Required). All deliverables are reviewed and verified manually by faculty mentors.
                </p>
              </div>

              <div className="space-y-3">
                {assignedTasks.map((t) => (
                  <div key={t.id} className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-xs space-y-1.5">
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-bold text-slate-900 text-xs">
                        {t.title}
                      </span>
                      <span className="text-[10px] font-bold text-[#0A66C2] bg-blue-50 px-2 py-0.5 rounded-full border border-blue-200 shrink-0">
                        Milestone {t.taskNumber} • 20%
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-600">
                      <strong>Objective:</strong> {t.objective}
                    </p>
                    <div className="text-[11px] text-slate-700 pl-2.5 border-l-2 border-[#0A66C2]">
                      <span className="font-semibold block text-[10px] text-slate-500 uppercase">Step-by-Step Instructions:</span>
                      <p className="leading-relaxed">{(t.instructions || []).slice(0, 3).join(' • ')}</p>
                    </div>
                    <p className="text-[10px] text-emerald-800 font-medium">
                      ✓ Deliverable: {t.expectedOutput} (GitHub / Free Hosting / Demo link)
                    </p>
                  </div>
                ))}
              </div>

              <div className="p-3 bg-blue-50/60 rounded-lg border border-blue-200/80 text-[11px] text-slate-700">
                <span className="font-bold text-[#0A66C2] block mb-0.5">Evaluation Policy:</span>
                All deliverables are manually verified and scored out of 100 points by assigned technical mentors based on Code Architecture, Deliverable Completeness, Practical Implementation, and Documentation (Passing Grade ≥ 70%).
              </div>
            </div>

            {/* Annexure B: Official Compliance, Privacy Policy & Program Disclaimer (Embedded in PDF) */}
            <div className="pt-8 border-t-2 border-slate-300 space-y-4">
              <div className="border-b border-slate-200 pb-2">
                <span className="text-[10px] uppercase font-bold text-[#0A66C2] tracking-wider block">
                  ANNEXURE B — COMPLIANCE, PRIVACY POLICY & PROGRAM DISCLAIMER
                </span>
                <h3 className="text-sm font-bold text-slate-900 mt-0.5">
                  VirIntern Privacy Policy, Educational Disclaimers & Code of Conduct
                </h3>
                <p className="text-[11px] text-slate-500 mt-0.5">
                  Official Terms governing candidate participation, evaluation standards, and data protection.
                </p>
              </div>

              <div className="space-y-3 text-[11px] text-slate-700 leading-relaxed">
                {/* 1. Privacy Policy */}
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-1">
                  <h4 className="font-bold text-slate-900 text-xs flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#0A66C2]"></span>
                    1. Privacy Policy & Candidate Data Protection
                  </h4>
                  <p>
                    VirIntern respects user privacy and handles personal and academic data strictly for learning verification, milestone review, and credential issuance.
                  </p>
                  <ul className="list-disc pl-4 space-y-0.5 text-slate-600 text-[10px]">
                    <li>We do not sell, rent, or monetize candidate data, source code repositories, or contact details to third parties.</li>
                    <li>Candidate submissions (GitHub links, hosted projects, reports) are accessed solely by authorized evaluation faculty.</li>
                    <li>Candidates may request profile record correction or deletion anytime by emailing <strong className="text-slate-800">virintern.in@gmail.com</strong>.</li>
                  </ul>
                </div>

                {/* 2. Educational Disclaimer */}
                <div className="p-3 bg-amber-50/70 rounded-lg border border-amber-200/80 space-y-1">
                  <h4 className="font-bold text-amber-950 text-xs flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-amber-600"></span>
                    2. Program Disclaimer & Educational Scope
                  </h4>
                  <p className="text-amber-900">
                    VirIntern is an educational and applied engineering skill development initiative. Participation in this virtual internship does not constitute an offer of salaried employment, nor does it guarantee job placement, hiring, or interview selection by external corporations. Professional outcomes depend on individual student competence, market hiring conditions, and employer evaluations.
                  </p>
                </div>

                {/* 3. Manual Mentor Evaluation (No Automated AI Scores) */}
                <div className="p-3 bg-emerald-50/70 rounded-lg border border-emerald-200/80 space-y-1">
                  <h4 className="font-bold text-emerald-950 text-xs flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#057642]"></span>
                    3. 100% Manual Mentor Evaluation Standard
                  </h4>
                  <p className="text-emerald-900">
                    All milestone submissions (Tasks 1 through 5) are manually examined, verified, and scored by our academic review board and designated industry mentors. No automated AI algorithm assigns student grades. Scores are calibrated on a strict 100-point rubric across Code Architecture (25 pts), Completeness (25 pts), Practical Implementation (25 pts), and Documentation (25 pts).
                  </p>
                </div>

                {/* 4. Zero-Cost & Anti-Plagiarism Guarantee */}
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-1">
                  <h4 className="font-bold text-slate-900 text-xs flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-indigo-600"></span>
                    4. Zero-Cost Tools & Academic Integrity Policy
                  </h4>
                  <p>
                    All project milestones utilize 100% free, open-source, and cloud-tier software (₹0 / $0 Cost). Submissions must represent original, authentic student engineering work. Replicating or copying uncredited source code constitutes a breach of our honor code and will require resubmission.
                  </p>
                </div>
              </div>

              {/* Compliance & Contact Stamp */}
              <div className="pt-2 flex flex-wrap items-center justify-between gap-2 text-[10px] text-slate-500 border-t border-slate-200">
                <span>Official Legal Notice • VirIntern Academic Board</span>
                <span className="font-mono text-[#0A66C2]">virintern.in@gmail.com • virintern.vercel.app</span>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Footer Actions */}
        <div className="bg-white p-4 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0">
          <div className="text-xs text-slate-500 flex items-center gap-1.5">
            <Sparkles className="w-4 h-4 text-indigo-600" />
            <span>This offer letter can be saved as PDF or attached directly to your Task 1 submission.</span>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              onClick={handlePrint}
              className="flex-1 sm:flex-none px-4 py-2 border border-slate-300 hover:bg-slate-50 text-slate-700 text-xs font-semibold rounded-xl flex items-center justify-center gap-1.5"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print / Download</span>
            </button>
            {onAttachToTask1 && (
              <button
                onClick={handleAttach}
                className="flex-1 sm:flex-none px-5 py-2 bg-[#0A66C2] hover:bg-[#004182] text-white text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 shadow-sm"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Attach to Task 1 Form</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
