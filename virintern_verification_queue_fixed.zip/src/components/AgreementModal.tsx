import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { ShieldCheck, FileCheck, AlertCircle, ArrowRight } from 'lucide-react';

interface AgreementModalProps {
  isOpen: boolean;
  onAccepted: () => void;
  onCancel: () => void;
  onOpenLegal?: (tab: 'privacy' | 'disclaimer' | 'terms' | 'refund') => void;
}

export const AgreementModal: React.FC<AgreementModalProps> = ({ isOpen, onAccepted, onCancel, onOpenLegal }) => {
  const { user, acceptAgreement } = useAuth();
  const [isChecked, setIsChecked] = useState(true);
  const [submitting, setSubmitting] = useState(false);

  if (!isOpen) return null;

  const handleConfirm = async () => {
    setSubmitting(true);
    try {
      await acceptAgreement();
      window.scrollTo({ top: 0, left: 0, behavior: 'instant' });
      onAccepted();
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-sm animate-fadeIn">
      <div className="bg-white w-full max-w-lg rounded-2xl shadow-2xl border border-slate-200 overflow-hidden">
        {/* Header */}
        <div className="bg-[#0A66C2] px-6 py-5 text-white flex items-center gap-3">
          <div className="w-10 h-10 rounded-md bg-white text-[#0A66C2] flex items-center justify-center font-bold shadow-xs">
            <FileCheck className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-white">VirIntern E-Agreement</h3>
            <p className="text-xs text-blue-100">Virtual Internship Code of Conduct & Honor Policy</p>
          </div>
        </div>

        {/* Body */}
        <div className="p-6 space-y-4">
          <div className="p-4 bg-[#F4F2EE] border border-[#E0DFDC] rounded-xl text-xs text-[#191919] leading-relaxed italic">
            “I understand that the VirIntern virtual internship is provided for educational and skill-development purposes. I agree to complete the assigned tasks honestly and submit my own work.”
          </div>

          <div className="text-xs text-[#666666] space-y-2.5 bg-[#F4F2EE] p-4 rounded-xl border border-[#E0DFDC]">
            <p className="font-semibold text-[#191919]">Key Internship Principles:</p>
            <ul className="list-disc pl-4 space-y-1.5 text-[#666666]">
              <li>
                <strong>Academic & Professional Integrity:</strong> All task submissions must represent your genuine effort and practical engineering implementation.
              </li>
              <li>
                <strong>Sequential Milestones:</strong> Tasks 1 through 5 unlock progressively as previous submissions are reviewed and approved.
              </li>
              <li>
                <strong>Verification Standards:</strong> Task 1 includes mentor verification (joining letter or social proof + official YouTube channel subscribe proof).
              </li>
              <li>
                <strong>Free Virtual Experience:</strong> The virtual internship is 100% free to enroll, complete, and track.
              </li>
            </ul>
          </div>

          <div className="text-[11px] text-[#666666] bg-[#F4F2EE] px-3 py-2 rounded-lg flex items-center justify-between border border-[#E0DFDC]">
            <span>Agreement Version: <span className="font-mono font-medium text-[#191919]">v1.0-2026</span></span>
            <span>User ID: <span className="font-mono font-medium text-[#191919]">{user?.uid.slice(0, 12)}...</span></span>
          </div>

          {/* Legal Links */}
          <div className="flex items-center justify-center gap-2 text-[11px] text-slate-500 py-0.5">
            <span>Review official:</span>
            <button
              type="button"
              onClick={() => onOpenLegal?.('privacy')}
              className="text-[#0A66C2] font-semibold hover:underline cursor-pointer"
            >
              Privacy Policy
            </button>
            <span>•</span>
            <button
              type="button"
              onClick={() => onOpenLegal?.('disclaimer')}
              className="text-[#0A66C2] font-semibold hover:underline cursor-pointer"
            >
              Disclaimer
            </button>
            <span>•</span>
            <button
              type="button"
              onClick={() => onOpenLegal?.('terms')}
              className="text-[#0A66C2] font-semibold hover:underline cursor-pointer"
            >
              Terms
            </button>
          </div>

          {/* Checkbox */}
          <label className="flex items-start gap-3 p-3 rounded-xl border border-[#0A66C2]/30 bg-[#EBF4FD]/50 cursor-pointer hover:bg-[#EBF4FD] transition-colors">
            <input
              type="checkbox"
              checked={isChecked}
              onChange={(e) => setIsChecked(e.target.checked)}
              className="mt-0.5 w-4 h-4 rounded text-[#0A66C2] focus:ring-[#0A66C2] border-[#E0DFDC]"
            />
            <span className="text-xs font-medium text-[#191919]">
              I have read, understood, and accept the VirIntern Virtual Internship E-Agreement and Compliance Policies.
            </span>
          </label>
        </div>

        {/* Footer Actions */}
        <div className="px-6 py-4 bg-[#F4F2EE] border-t border-[#E0DFDC] flex items-center justify-between gap-3">
          <button
            onClick={onCancel}
            className="px-4 py-2 text-xs font-semibold text-[#666666] hover:text-[#191919] rounded-full hover:bg-white transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={handleConfirm}
            disabled={!isChecked || submitting}
            className={`px-6 py-2.5 text-xs font-bold rounded-full flex items-center gap-2 transition-all cursor-pointer ${
              isChecked && !submitting
                ? 'bg-[#057642] hover:bg-[#046237] text-white shadow-xs'
                : 'bg-[#E0DFDC] text-[#666666] cursor-not-allowed'
            }`}
          >
            {submitting ? 'Saving...' : 'I Agree & Continue'}
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
