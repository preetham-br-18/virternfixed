import React from 'react';
import {
  CheckCircle2,
  AlertCircle,
  Clock,
  Sparkles,
  Award,
  ChevronRight,
  TrendingUp,
  X,
  ShieldCheck,
  Calendar,
  AlertTriangle,
  Lightbulb,
  ExternalLink,
  Target
} from 'lucide-react';
import { TaskEvaluationRecord } from '../types';

interface StudentEvaluationModalProps {
  isOpen: boolean;
  onClose: () => void;
  evaluation: TaskEvaluationRecord | null;
  isLoading?: boolean;
  taskTitle?: string;
  taskNumber?: number;
}

export const StudentEvaluationModal: React.FC<StudentEvaluationModalProps> = ({
  isOpen,
  onClose,
  evaluation,
  isLoading = false,
  taskTitle,
  taskNumber
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-fadeIn">
      <div className="bg-white rounded-3xl max-w-3xl w-full border border-slate-200 shadow-2xl overflow-hidden my-6 max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="p-4 sm:p-6 bg-gradient-to-r from-slate-900 via-indigo-950 to-blue-950 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white/10 text-blue-200 flex items-center justify-center border border-white/15">
              <Sparkles className="w-5 h-5 text-amber-400" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-extrabold uppercase tracking-wider px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-200 border border-blue-400/30">
                  Official Technical Reviewer & Faculty Board
                </span>
                {evaluation?.evaluatedAt && (
                  <span className="text-[10px] text-slate-400 flex items-center gap-1">
                    <Calendar className="w-3 h-3" />
                    {new Date(evaluation.evaluatedAt).toLocaleDateString()}
                  </span>
                )}
              </div>
              <h2 className="text-base sm:text-lg font-black text-white mt-0.5">
                Task {taskNumber || evaluation?.taskNumber || 1} Evaluation & Rubric Feedback
              </h2>
              <p className="text-xs text-blue-100/80 truncate max-w-md">
                {taskTitle || evaluation?.taskTitle || 'Objective Performance Assessment'}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 text-white/70 hover:text-white hover:bg-white/10 rounded-full transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="overflow-y-auto p-4 sm:p-6 space-y-6 text-slate-800 flex-1">
          {isLoading ? (
            <div className="py-16 text-center space-y-4">
              <div className="w-16 h-16 rounded-full bg-blue-50 border-4 border-[#0A66C2] border-t-transparent animate-spin mx-auto flex items-center justify-center">
                <Sparkles className="w-6 h-6 text-[#0A66C2]" />
              </div>
              <div>
                <h3 className="text-base font-black text-slate-900">Mentor Review In Progress</h3>
                <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
                  Your submission is being reviewed and verified against objective technical standards and deliverable specifications.
                </p>
              </div>
            </div>
          ) : !evaluation ? (
            <div className="py-12 text-center text-slate-500 text-xs">
              No evaluation data found for this submission.
            </div>
          ) : (
            <>
              {/* Score & Verdict Banner */}
              <div className={`p-4 sm:p-5 rounded-2xl border flex flex-col sm:flex-row sm:items-center justify-between gap-4 ${
                evaluation.status === 'passed'
                  ? 'bg-gradient-to-br from-emerald-50 via-teal-50/50 to-white border-emerald-300'
                  : 'bg-gradient-to-br from-amber-50 via-rose-50/50 to-white border-amber-300'
              }`}>
                <div className="flex items-center gap-4">
                  <div className={`w-16 h-16 rounded-2xl flex flex-col items-center justify-center font-black shadow-xs shrink-0 ${
                    evaluation.status === 'passed'
                      ? 'bg-emerald-600 text-white'
                      : 'bg-amber-600 text-white'
                  }`}>
                    <span className="text-2xl leading-none">{evaluation.totalScore}</span>
                    <span className="text-[10px] uppercase font-bold opacity-80 mt-0.5">/ 100</span>
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className={`px-2.5 py-0.5 rounded-full text-[11px] font-extrabold uppercase tracking-wider ${
                        evaluation.status === 'passed'
                          ? 'bg-emerald-100 text-emerald-900 border border-emerald-300'
                          : 'bg-amber-100 text-amber-900 border border-amber-300'
                      }`}>
                        {evaluation.status === 'passed' ? 'PASSED' : 'REVISION REQUIRED'}
                      </span>
                      {evaluation.evaluatorType === 'ADMIN_OVERRIDE' && (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-purple-100 text-purple-800 border border-purple-200">
                          Mentor Verified
                        </span>
                      )}
                    </div>
                    <h3 className="text-sm sm:text-base font-black text-slate-900 mt-1">
                      {evaluation.status === 'passed'
                        ? 'Milestone Verified Successfully!'
                        : 'Action Items Needed to Meet Passing Threshold (70/100)'}
                    </h3>
                    <p className="text-xs text-slate-600 mt-0.5">
                      Earned Leaderboard Points:{' '}
                      <strong className="text-slate-900 font-black">
                        +{evaluation.earnedPoints || 0} pts
                      </strong>{' '}
                      ({evaluation.difficulty || 'Intermediate'} Track Weighting)
                    </p>
                  </div>
                </div>

                <div className="text-right sm:border-l sm:border-slate-200 sm:pl-5">
                  <span className="text-[10px] font-bold uppercase text-slate-400 block tracking-wider">
                    Confidence Rating
                  </span>
                  <span className="text-sm font-extrabold text-slate-800">
                    {Math.round((evaluation.confidence || 0.95) * 100)}% Match
                  </span>
                  <span className="text-[10px] text-slate-500 block">Strict Rubric Engine</span>
                </div>
              </div>

              {/* Criteria-Wise Breakdown */}
              <div className="space-y-3">
                <h4 className="text-xs font-black uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                  <Award className="w-4 h-4 text-[#0A66C2]" />
                  <span>Rubric Criteria Breakdown</span>
                </h4>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                    <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
                      Functionality (Max 30)
                    </span>
                    <span className="text-base font-black text-slate-900">
                      {evaluation.criteriaScores?.functionality ?? '--'}
                    </span>
                    <span className="text-xs text-slate-500"> / 30 pts</span>
                  </div>

                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                    <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
                      Requirements (Max 25)
                    </span>
                    <span className="text-base font-black text-slate-900">
                      {evaluation.criteriaScores?.requirements ?? '--'}
                    </span>
                    <span className="text-xs text-slate-500"> / 25 pts</span>
                  </div>

                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                    <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
                      Code Quality (Max 20)
                    </span>
                    <span className="text-base font-black text-slate-900">
                      {evaluation.criteriaScores?.quality ?? '--'}
                    </span>
                    <span className="text-xs text-slate-500"> / 20 pts</span>
                  </div>

                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                    <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
                      Documentation (Max 10)
                    </span>
                    <span className="text-base font-black text-slate-900">
                      {evaluation.criteriaScores?.documentation ?? '--'}
                    </span>
                    <span className="text-xs text-slate-500"> / 10 pts</span>
                  </div>

                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                    <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
                      Error Handling (Max 10)
                    </span>
                    <span className="text-base font-black text-slate-900">
                      {evaluation.criteriaScores?.errorHandling ?? '--'}
                    </span>
                    <span className="text-xs text-slate-500"> / 10 pts</span>
                  </div>

                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                    <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
                      Originality (Max 5)
                    </span>
                    <span className="text-base font-black text-slate-900">
                      {evaluation.criteriaScores?.originality ?? '--'}
                    </span>
                    <span className="text-xs text-slate-500"> / 5 pts</span>
                  </div>
                </div>
              </div>

              {/* Requirements Checklist */}
              {Array.isArray(evaluation.requirementResults) && evaluation.requirementResults.length > 0 && (
                <div className="space-y-3">
                  <h4 className="text-xs font-black uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                    <Target className="w-4 h-4 text-[#0A66C2]" />
                    <span>Requirements Evidence Checklist</span>
                  </h4>
                  <div className="space-y-2">
                    {evaluation.requirementResults.map((req, idx) => (
                      <div
                        key={idx}
                        className="p-3 rounded-xl border border-slate-200 bg-slate-50/70 flex flex-col sm:flex-row sm:items-start justify-between gap-2"
                      >
                        <div className="flex-1">
                          <p className="text-xs font-bold text-slate-900">{req.requirement}</p>
                          <p className="text-[11px] text-slate-600 mt-0.5">{req.feedback}</p>
                        </div>
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider self-start shrink-0 ${
                            req.status === 'verified'
                              ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                              : req.status === 'unmet'
                              ? 'bg-rose-100 text-rose-800 border border-rose-300'
                              : 'bg-amber-100 text-amber-900 border border-amber-300'
                          }`}
                        >
                          {req.status === 'verified'
                            ? 'VERIFIED'
                            : req.status === 'unmet'
                            ? 'UNMET'
                            : 'UNABLE TO VERIFY'}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Strengths & Weaknesses */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="p-4 bg-emerald-50/60 rounded-2xl border border-emerald-200 space-y-2">
                  <h5 className="text-xs font-extrabold uppercase text-emerald-900 flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Verified Strengths</span>
                  </h5>
                  <ul className="space-y-1.5 text-xs text-emerald-950">
                    {evaluation.strengths.map((s, i) => (
                      <li key={i} className="flex items-start gap-1.5">
                        <span className="text-emerald-600 font-bold">•</span>
                        <span>{s}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="p-4 bg-amber-50/60 rounded-2xl border border-amber-200 space-y-2">
                  <h5 className="text-xs font-extrabold uppercase text-amber-900 flex items-center gap-1.5">
                    <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
                    <span>Areas for Improvement</span>
                  </h5>
                  <ul className="space-y-1.5 text-xs text-amber-950">
                    {evaluation.weaknesses.length > 0 ? (
                      evaluation.weaknesses.map((w, i) => (
                        <li key={i} className="flex items-start gap-1.5">
                          <span className="text-amber-600 font-bold">•</span>
                          <span>{w}</span>
                        </li>
                      ))
                    ) : (
                      <li className="text-xs text-slate-500 italic">No major deficiencies detected.</li>
                    )}
                  </ul>
                </div>
              </div>

              {/* Detected Issues */}
              {evaluation.detectedIssues.length > 0 && (
                <div className="p-4 bg-rose-50/70 rounded-2xl border border-rose-200 space-y-2">
                  <h5 className="text-xs font-extrabold uppercase text-rose-900 flex items-center gap-1.5">
                    <AlertCircle className="w-3.5 h-3.5 text-rose-600" />
                    <span>Detected Technical Issues</span>
                  </h5>
                  <ul className="space-y-1 text-xs text-rose-950">
                    {evaluation.detectedIssues.map((issue, i) => (
                      <li key={i} className="flex items-start gap-1.5">
                        <span className="text-rose-600 font-bold">•</span>
                        <span>{issue}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Improvement Suggestions */}
              {evaluation.improvementSuggestions.length > 0 && (
                <div className="p-4 bg-blue-50/70 rounded-2xl border border-blue-200 space-y-2">
                  <h5 className="text-xs font-extrabold uppercase text-[#0A66C2] flex items-center gap-1.5">
                    <Lightbulb className="w-3.5 h-3.5 text-[#0A66C2]" />
                    <span>Engineering Recommendations</span>
                  </h5>
                  <ul className="space-y-1.5 text-xs text-slate-700">
                    {evaluation.improvementSuggestions.map((rec, i) => (
                      <li key={i} className="flex items-start gap-1.5">
                        <span className="text-[#0A66C2] font-bold">•</span>
                        <span>{rec}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Admin Override Reason if present */}
              {evaluation.adminOverride && (
                <div className="p-4 bg-purple-50 rounded-2xl border border-purple-200 space-y-1 text-xs">
                  <span className="font-extrabold text-purple-900 uppercase text-[10px] tracking-wider block">
                    Mentor Override Note
                  </span>
                  <p className="text-purple-950">
                    Score updated from {evaluation.adminOverride.previousScore} to {evaluation.adminOverride.newScore}.
                  </p>
                  <p className="text-purple-800 italic">"{evaluation.adminOverride.reason}"</p>
                </div>
              )}
            </>
          )}
        </div>

        {/* Footer Actions */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-end gap-3 shrink-0">
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 rounded-xl text-xs font-bold bg-[#0A66C2] hover:bg-[#004182] text-white shadow transition-colors"
          >
            Close Evaluation
          </button>
        </div>
      </div>
    </div>
  );
};
