import React, { useRef } from 'react';
import { X, Printer, Download, CheckCircle2, ShieldCheck, Sparkles, Layers, Terminal, BookOpen, ExternalLink } from 'lucide-react';
import { UserProfile, InternshipRecord, ProjectTask } from '../types';
import { generateStudentTasks } from '../services/domainProjectsService';

interface ProjectGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: UserProfile;
  internship: InternshipRecord;
}

export const ProjectGuideModal: React.FC<ProjectGuideModalProps> = ({
  isOpen,
  onClose,
  user,
  internship
}) => {
  const printRef = useRef<HTMLDivElement>(null);

  if (!isOpen) return null;

  const tasks: ProjectTask[] = generateStudentTasks(
    internship.domainId,
    internship.domainName,
    user.uid
  );

  const domainName = internship.domainName || 'Engineering Track';
  const resolvedStudentName = (user.name && user.name.trim().toLowerCase() !== 'student' && user.name.trim().toLowerCase() !== 'intern')
    ? user.name.trim()
    : (typeof window !== 'undefined'
        ? (localStorage.getItem(`virintern_user_name_${(user.email || '').toLowerCase()}`) ||
           (user.uid ? localStorage.getItem(`virintern_user_name_${user.uid}`) : null) ||
           localStorage.getItem('virintern_last_signup_name') ||
           user.name)
        : user.name) || (user.email ? user.email.split('@')[0] : 'Student');

  const fileName = `VirIntern_${domainName.replace(/\s+/g, '_')}_Project_Guide_${resolvedStudentName.replace(/\s+/g, '_')}.pdf`;

  const handlePrint = () => {
    window.print();
  };

  const handleDownload = () => {
    try {
      const element = printRef.current;
      if (!element) {
        window.print();
        return;
      }
      const printContents = element.innerHTML;
      const htmlDoc = `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>${fileName}</title>
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; padding: 40px; color: #191919; max-width: 860px; margin: 0 auto; background: #ffffff; }
    table { width: 100%; border-collapse: collapse; margin: 16px 0; }
    th, td { border: 1px solid #cbd5e1; padding: 10px 12px; text-align: left; }
    .header { border-bottom: 3px solid #0A66C2; padding-bottom: 20px; margin-bottom: 24px; }
  </style>
</head>
<body>
  ${printContents}
</body>
</html>`;
      const blob = new Blob([htmlDoc], { type: 'text/html' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = fileName.replace('.pdf', '_Guide.html');
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch {
      window.print();
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-fadeIn">
      <div className="bg-white rounded-2xl max-w-4xl w-full border border-slate-200 shadow-2xl overflow-hidden my-6 max-h-[92vh] flex flex-col">
        {/* Top Header Bar */}
        <div className="p-4 sm:p-5 bg-slate-900 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#0A66C2] text-white flex items-center justify-center font-bold text-sm shadow-xs">
              VI
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-300 border border-blue-400/30">
                  Official Project Guide & Syllabus PDF
                </span>
                <span className="text-[10px] text-emerald-400 font-semibold flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3" />
                  100% Free Tools
                </span>
              </div>
              <h2 className="text-base sm:text-lg font-bold text-white mt-0.5">
                {domainName} • 1-Month Milestone Roadmap
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleDownload}
              className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-lg flex items-center gap-1.5 transition-colors shadow-xs cursor-pointer"
              title="Download Guide HTML/PDF Document"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download File</span>
            </button>
            <button
              onClick={handlePrint}
              className="px-3.5 py-2 bg-[#0A66C2] hover:bg-[#004182] text-white text-xs font-bold rounded-lg flex items-center gap-1.5 transition-colors shadow-xs cursor-pointer"
              title="Print or Save as PDF"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print / Save PDF</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Scrollable Printable Content */}
        <div className="overflow-y-auto p-4 sm:p-8 bg-slate-100 flex-1">
          <div
            ref={printRef}
            id="printable-guide"
            className="bg-white p-6 sm:p-10 rounded-xl border border-slate-200 shadow-sm max-w-3xl mx-auto space-y-6 text-[#191919] font-sans"
          >
            {/* Document Header Letterhead */}
            <div className="border-b-2 border-[#0A66C2] pb-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-2 text-[#0A66C2]">
                  <div className="w-9 h-9 rounded-lg bg-[#0A66C2] text-white flex items-center justify-center font-bold text-lg">
                    VI
                  </div>
                  <div>
                    <h1 className="text-xl font-extrabold tracking-tight text-[#0A66C2]">
                      VirIntern Global Labs
                    </h1>
                    <p className="text-[10px] uppercase font-bold tracking-wider text-slate-500">
                      Virtual Internship & Applied Engineering Initiative
                    </p>
                  </div>
                </div>
                <p className="text-[11px] text-slate-500 mt-1.5">
                  ISO 9001:2015 Quality Verified • Academic & Industry Syllabus
                </p>
              </div>

              <div className="text-left sm:text-right text-xs space-y-0.5">
                <span className="inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-[#EBF4FD] text-[#0A66C2] border border-blue-200">
                  Official Project Curriculum
                </span>
                <p className="font-semibold text-slate-800 mt-1">{domainName} Virtual Track</p>
                <p className="text-slate-500">Duration: 1 Month (30 Days)</p>
              </div>
            </div>

            {/* Candidate & Enrollment Meta */}
            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
              <div>
                <span className="text-[10px] uppercase font-bold text-slate-400 block">Intern Name</span>
                <span className="font-bold text-slate-900">{resolvedStudentName}</span>
              </div>
              <div>
                <span className="text-[10px] uppercase font-bold text-slate-400 block">Candidate UID</span>
                <span className="font-mono text-[#0A66C2] font-semibold">{user.uid.slice(-6).toUpperCase()}</span>
              </div>
              <div>
                <span className="text-[10px] uppercase font-bold text-slate-400 block">Evaluation Mode</span>
                <span className="font-bold text-emerald-800">Manual Mentor Verification</span>
              </div>
            </div>

            {/* Zero-Cost Guarantee Banner */}
            <div className="p-4 bg-emerald-50/80 rounded-xl border border-emerald-200 space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-emerald-950 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-[#057642]" />
                  Zero-Cost Industry Project Guarantee (₹0 / $0 Cost Required)
                </span>
                <span className="text-[10px] font-bold bg-[#E8F5E9] text-[#057642] px-2 py-0.5 rounded-full border border-emerald-300">
                  100% Free Tools
                </span>
              </div>
              <p className="text-[11px] text-emerald-900 leading-relaxed">
                All projects are strictly designed using free, industry-standard tools: Visual Studio Code, GitHub Desktop / Free Repositories, Google Colab (Free GPU), Figma Starter, Postman, and Free Cloud Hosting (Vercel, Netlify, Render, or GitHub Pages). No paid software, proprietary subscriptions, or fee-based services are needed.
              </p>
            </div>

            {/* Evaluation & Grading Policy */}
            <div className="p-3.5 bg-blue-50/70 rounded-xl border border-blue-200/80 text-xs text-slate-700 space-y-1">
              <p className="font-bold text-[#0A66C2] text-xs">
                Official Mentor Evaluation & Verification Policy:
              </p>
              <p className="text-[11px] leading-relaxed text-slate-600">
                All milestone submissions are reviewed and verified manually by our assigned technical mentors. Deliverables are scored on a 100-point scale across Code Architecture (25 pts), Deliverable Completeness (25 pts), Practical Implementation (25 pts), and Documentation & Readiness (25 pts). The passing mark is 70% or above.
              </p>
            </div>

            {/* Tasks Roadmap List */}
            <div className="space-y-5">
              <h3 className="text-sm font-extrabold uppercase tracking-wider text-slate-900 border-b border-slate-200 pb-2 flex items-center justify-between">
                <span>Curriculum Milestones (5 Structured Tasks)</span>
                <span className="text-xs text-[#0A66C2] font-semibold lowercase">sequential progression • 20% each</span>
              </h3>

              {tasks.map((task) => (
                <div
                  key={task.id}
                  className="p-4 rounded-xl border border-slate-200 bg-white hover:border-[#0A66C2]/40 transition-colors space-y-2.5"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <span className="w-6 h-6 rounded-md bg-[#0A66C2] text-white font-bold text-xs flex items-center justify-center shrink-0">
                        {task.taskNumber}
                      </span>
                      <h4 className="text-xs sm:text-sm font-bold text-slate-900">
                        {task.title}
                      </h4>
                    </div>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 w-fit">
                      {task.difficulty || 'Intermediate'} • 20% Milestone
                    </span>
                  </div>

                  <p className="text-xs text-slate-600 leading-relaxed">
                    <strong>Objective:</strong> {task.objective}
                  </p>

                  {/* 4-Step Brief Roadmap */}
                  <div className="bg-slate-50 p-3 rounded-lg border border-slate-200/80">
                    <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider block mb-1.5">
                      Brief Execution Instructions (4 Steps):
                    </span>
                    <ol className="space-y-1 text-[11px] text-slate-700 pl-4 list-decimal">
                      {(task.instructions || []).slice(0, 4).map((inst, i) => (
                        <li key={i} className="leading-relaxed">
                          {inst}
                        </li>
                      ))}
                    </ol>
                  </div>

                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pt-1 border-t border-slate-100 text-[11px]">
                    <div className="text-slate-600">
                      <strong>Deliverable:</strong> {task.expectedOutput}
                    </div>
                    <div className="text-emerald-700 font-semibold shrink-0">
                      Zero-Cost Setup: GitHub + Free Hosting
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Privacy Policy & Program Disclaimer Notice in Guide */}
            <div className="pt-6 border-t-2 border-slate-200 space-y-3">
              <div className="flex items-center gap-2">
                <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-blue-100 text-[#0A66C2]">
                  Compliance Notice
                </span>
                <span className="text-[11px] font-bold text-slate-800">
                  VirIntern Privacy Policy & Program Disclaimer
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-[11px] text-slate-600">
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 space-y-1">
                  <span className="font-bold text-slate-900 block text-xs">Privacy & Data Handling</span>
                  <p>
                    All candidate submissions, repository URLs, and credentials are protected. VirIntern does not sell or distribute student data to outside vendors. Data inquiries: <strong className="text-slate-800 font-mono">virintern.in@gmail.com</strong>.
                  </p>
                </div>
                <div className="p-3 bg-amber-50/60 rounded-lg border border-amber-200/80 space-y-1 text-amber-900">
                  <span className="font-bold text-amber-950 block text-xs">Educational Disclaimer</span>
                  <p>
                    This virtual internship is an applied learning project. It does not constitute salaried employment or guarantee hiring by partner firms. Certificates verify completed project competency.
                  </p>
                </div>
              </div>
            </div>

            {/* Mentor Sign-off Footer */}
            <div className="pt-6 border-t-2 border-slate-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-xs">
              <div className="space-y-1">
                <p className="font-serif italic text-base font-bold text-slate-900">Dr. Arjun Mehta, Ph.D.</p>
                <p className="text-[10px] text-slate-500">Director of Academic & Industry Partnerships</p>
                <p className="text-[10px] text-[#0A66C2] font-semibold">VirIntern Global Labs</p>
              </div>

              <div className="flex items-center gap-2 p-2.5 bg-blue-50/70 rounded-xl border border-blue-200 text-[#0A66C2]">
                <ShieldCheck className="w-5 h-5" />
                <div>
                  <p className="text-[10px] font-bold uppercase tracking-wider">OFFICIAL CURRICULUM</p>
                  <p className="text-[9px] text-slate-500">Verified for 2026 Cohort</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Action Bar */}
        <div className="p-4 bg-white border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0">
          <p className="text-xs text-slate-500">
            Print or save as PDF to keep your assigned project track and milestone roadmap handy.
          </p>
          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              onClick={handlePrint}
              className="flex-1 sm:flex-initial px-5 py-2.5 bg-[#0A66C2] hover:bg-[#004182] text-white text-xs font-bold rounded-xl flex items-center justify-center gap-2 shadow-xs cursor-pointer transition-colors"
            >
              <Printer className="w-4 h-4" />
              <span>Print / Download PDF</span>
            </button>
            <button
              onClick={onClose}
              className="flex-1 sm:flex-initial px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-xl cursor-pointer transition-colors"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
