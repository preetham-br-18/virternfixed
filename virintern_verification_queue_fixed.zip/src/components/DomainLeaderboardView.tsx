import React, { useState, useEffect } from 'react';
import {
  Trophy,
  Medal,
  Award,
  Sparkles,
  Search,
  Filter,
  ArrowUpRight,
  TrendingUp,
  User,
  CheckCircle2,
  Star,
  ChevronDown,
  Layers,
  ArrowLeft,
  Flame,
  ShieldCheck
} from 'lucide-react';
import { DomainLeaderboardEntry, DomainItem } from '../types';
import { dataService } from '../services/dataService';
import { useAuth } from '../context/AuthContext';

interface DomainLeaderboardViewProps {
  onBackToDashboard?: () => void;
  defaultDomainId?: string;
}

export const DomainLeaderboardView: React.FC<DomainLeaderboardViewProps> = ({
  onBackToDashboard,
  defaultDomainId
}) => {
  const { user, activeInternship } = useAuth();
  const [domains, setDomains] = useState<DomainItem[]>([]);
  const [selectedDomainId, setSelectedDomainId] = useState<string>(
    defaultDomainId || activeInternship?.domainId || 'web-development'
  );
  const [leaderboard, setLeaderboard] = useState<DomainLeaderboardEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterTier, setFilterTier] = useState<string>('all');

  useEffect(() => {
    dataService.getDomains().then((allDomains) => {
      setDomains(allDomains);
      if (!selectedDomainId && allDomains.length > 0) {
        setSelectedDomainId(allDomains[0].id);
      }
    });
  }, []);

  useEffect(() => {
    if (!selectedDomainId) return;
    setLoading(true);
    const unsub = dataService.subscribeDomainLeaderboard(selectedDomainId, user?.uid, (entries) => {
      setLeaderboard(entries);
      setLoading(false);
    });
    return () => {
      unsub();
    };
  }, [selectedDomainId, user?.uid]);

  const selectedDomain = domains.find(d => d.id === selectedDomainId || d.slug === selectedDomainId) || domains[0];
  const currentUserEntry = leaderboard.find(e => e.isCurrentUser || e.userId === user?.uid);

  const filteredEntries = leaderboard.filter(e => {
    const matchesSearch = e.userName.toLowerCase().includes(searchQuery.toLowerCase());
    if (filterTier === 'all') return matchesSearch;
    if (filterTier === 'top3') return matchesSearch && e.rank <= 3;
    if (filterTier === 'completed') return matchesSearch && e.completedTasksCount === 5;
    return matchesSearch;
  });

  const top3 = leaderboard.slice(0, 3);
  const domainAverageScore = leaderboard.length > 0
    ? Math.round(leaderboard.reduce((acc, curr) => acc + curr.averageScore, 0) / leaderboard.length)
    : 0;
  const topScore = leaderboard.length > 0 ? Math.max(...leaderboard.map(e => e.totalScore)) : 0;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8 space-y-6 sm:space-y-8 animate-fadeIn">
      {/* Top Header & Navigation */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex flex-wrap items-center gap-2 mb-1">
            {onBackToDashboard && (
              <button
                type="button"
                onClick={onBackToDashboard}
                className="inline-flex items-center gap-1 text-xs font-bold text-slate-500 hover:text-[#0A66C2] mr-2 transition-colors cursor-pointer"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Dashboard</span>
              </button>
            )}
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wider bg-amber-100 text-amber-900 border border-amber-200 flex items-center gap-1">
              <Trophy className="w-3 h-3 text-amber-700" />
              <span>Official Cohort Rankings</span>
            </span>
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-blue-50 text-[#0A66C2] border border-blue-200 flex items-center gap-1">
              <ShieldCheck className="w-3 h-3 text-[#0A66C2]" />
              <span>Admin Verified</span>
            </span>
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200 flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping" />
              <span>Live Updates</span>
            </span>
          </div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 flex items-center gap-2">
            <span>Domain Performance & Leaderboard</span>
          </h1>
          <p className="text-xs text-slate-600 mt-1 max-w-2xl">
            Real enrolled students cohort rankings evaluated and verified by VirIntern admin mentors across milestone code quality, deliverables, and architecture.
          </p>
        </div>

        {/* Domain Track Selector */}
        <div className="shrink-0 flex items-center gap-2">
          <label className="text-xs font-bold text-slate-700 hidden sm:inline">Track:</label>
          <div className="relative">
            <select
              value={selectedDomainId}
              onChange={(e) => setSelectedDomainId(e.target.value)}
              className="appearance-none bg-slate-50 border border-slate-300 rounded-xl pl-3.5 pr-8 py-2.5 text-xs font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#0A66C2] shadow-2xs cursor-pointer"
            >
              {domains.map((dom) => (
                <option key={dom.id} value={dom.id}>
                  {dom.name}
                </option>
              ))}
            </select>
            <ChevronDown className="w-4 h-4 text-slate-500 absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          </div>
        </div>
      </div>

      {/* Domain Quick Metric Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider">Active Interns</span>
            <div className="w-7 h-7 rounded-lg bg-blue-50 text-[#0A66C2] flex items-center justify-center">
              <Layers className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-black text-slate-900">{leaderboard.length}</p>
          <p className="text-[10px] text-slate-500 mt-0.5 truncate">{selectedDomain?.name}</p>
        </div>

        <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider">Top Domain Score</span>
            <div className="w-7 h-7 rounded-lg bg-amber-50 text-amber-700 flex items-center justify-center">
              <Trophy className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-black text-amber-900">{topScore} <span className="text-xs font-semibold text-slate-500">pts</span></p>
          <p className="text-[10px] text-amber-700 mt-0.5 font-semibold">Highest Verified Score</p>
        </div>

        <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider">Track Average</span>
            <div className="w-7 h-7 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-black text-emerald-900">{domainAverageScore}%</p>
          <p className="text-[10px] text-emerald-700 mt-0.5 font-semibold">Across all milestone tasks</p>
        </div>

        <div className="p-4 bg-gradient-to-br from-[#0A66C2] to-indigo-700 text-white rounded-2xl shadow-xs">
          <div className="flex items-center justify-between text-blue-100 mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider">Your Standing</span>
            <div className="w-7 h-7 rounded-lg bg-white/15 text-white flex items-center justify-center">
              <Star className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-black">{currentUserEntry ? `#${currentUserEntry.rank}` : '--'}</p>
          <p className="text-[10px] text-blue-100 mt-0.5">
            {currentUserEntry ? `${currentUserEntry.totalScore} pts • ${currentUserEntry.levelBadge}` : 'Submit tasks to rank'}
          </p>
        </div>
      </div>

      {/* Current User Standing Highlight Banner */}
      {currentUserEntry && (
        <div className="p-4 sm:p-5 bg-gradient-to-r from-blue-50 via-indigo-50/50 to-white rounded-2xl border border-[#0A66C2]/30 shadow-2xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-[#0A66C2] text-white flex items-center justify-center shrink-0 shadow-xs font-black text-lg">
              #{currentUserEntry.rank}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-black text-slate-900">{currentUserEntry.userName}</span>
                <span className="px-2 py-0.5 bg-[#0A66C2] text-white font-extrabold text-[9px] rounded-md tracking-wider uppercase">
                  YOU
                </span>
                <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 font-bold text-[10px] rounded-full">
                  {currentUserEntry.levelBadge}
                </span>
              </div>
              <p className="text-xs text-slate-600 mt-0.5">
                Total Score: <strong className="text-slate-900">{currentUserEntry.totalScore} pts</strong> • 
                Completed: <strong className="text-slate-900">{currentUserEntry.completedTasksCount} of 5 Milestones</strong> • 
                Average Score: <strong className="text-[#0A66C2]">{currentUserEntry.averageScore}%</strong>
              </p>
            </div>
          </div>
          <div className="text-right">
            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">Target Next Rank</span>
            <span className="text-xs font-bold text-[#0A66C2]">
              {currentUserEntry.rank === 1
                ? '🏆 You are holding the #1 position!'
                : `Submit next task to climb to #${currentUserEntry.rank - 1}`}
            </span>
          </div>
        </div>
      )}

      {/* Top 3 Podium Cards */}
      {top3.length >= 3 && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
          {/* 2nd Place */}
          <div className="order-2 md:order-1 bg-white rounded-2xl border border-slate-200 p-5 shadow-2xs text-center flex flex-col justify-between relative overflow-hidden">
            <div className="absolute top-0 inset-x-0 h-1.5 bg-slate-300" />
            <div className="space-y-3">
              <div className="w-14 h-14 rounded-full bg-slate-100 text-slate-700 flex items-center justify-center mx-auto border-2 border-slate-300 shadow-2xs relative">
                <Medal className="w-7 h-7 text-slate-500" />
                <span className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-slate-600 text-white text-[10px] font-black flex items-center justify-center">
                  2
                </span>
              </div>
              <div>
                <h4 className="text-sm font-bold text-slate-900">{top3[1]?.userName}</h4>
                <p className="text-[11px] text-slate-500 font-semibold">{top3[1]?.levelBadge}</p>
              </div>
              <div className="p-3 bg-slate-50 rounded-xl space-y-1 text-xs">
                <div className="flex justify-between text-slate-600">
                  <span>Total Score:</span>
                  <span className="font-extrabold text-slate-900">{top3[1]?.totalScore} pts</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Avg Quality:</span>
                  <span className="font-bold text-[#0A66C2]">{top3[1]?.averageScore}%</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Milestones:</span>
                  <span className="font-bold text-emerald-700">{top3[1]?.completedTasksCount} / 5</span>
                </div>
              </div>
            </div>
            <div className="mt-3 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
              Runner Up • 2nd Place
            </div>
          </div>

          {/* 1st Place - Champion */}
          <div className="order-1 md:order-2 bg-gradient-to-b from-amber-50/80 via-white to-amber-50/40 rounded-2xl border-2 border-amber-300 p-6 shadow-md text-center flex flex-col justify-between relative overflow-hidden md:-translate-y-2">
            <div className="absolute top-0 inset-x-0 h-2 bg-gradient-to-r from-amber-400 via-amber-500 to-amber-400" />
            <div className="space-y-3">
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-amber-400 to-amber-600 text-white flex items-center justify-center mx-auto shadow-md relative">
                <Trophy className="w-8 h-8 text-white" />
                <span className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-amber-700 text-white text-xs font-black flex items-center justify-center border-2 border-white">
                  1
                </span>
              </div>
              <div>
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-amber-200/90 text-amber-900 inline-block mb-1">
                  Domain Champion
                </span>
                <h3 className="text-base font-black text-slate-900">{top3[0]?.userName}</h3>
                <p className="text-xs text-amber-800 font-bold">{top3[0]?.levelBadge}</p>
              </div>
              <div className="p-3 bg-amber-100/60 rounded-xl space-y-1.5 text-xs border border-amber-200">
                <div className="flex justify-between text-amber-900">
                  <span className="font-semibold">Total Points:</span>
                  <span className="font-black text-slate-900 text-sm">{top3[0]?.totalScore} pts</span>
                </div>
                <div className="flex justify-between text-amber-900">
                  <span className="font-semibold">Mentor Review Avg:</span>
                  <span className="font-black text-[#0A66C2]">{top3[0]?.averageScore}%</span>
                </div>
                <div className="flex justify-between text-amber-900">
                  <span className="font-semibold">All Milestones:</span>
                  <span className="font-black text-emerald-800">{top3[0]?.completedTasksCount} of 5 Done</span>
                </div>
              </div>
            </div>
            <div className="mt-3 text-[11px] font-black text-amber-800 flex items-center justify-center gap-1">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Highest Milestone Score: {top3[0]?.bestTaskScore}%</span>
            </div>
          </div>

          {/* 3rd Place */}
          <div className="order-3 bg-white rounded-2xl border border-slate-200 p-5 shadow-2xs text-center flex flex-col justify-between relative overflow-hidden">
            <div className="absolute top-0 inset-x-0 h-1.5 bg-amber-600/50" />
            <div className="space-y-3">
              <div className="w-14 h-14 rounded-full bg-amber-50 text-amber-800 flex items-center justify-center mx-auto border-2 border-amber-600/40 shadow-2xs relative">
                <Medal className="w-7 h-7 text-amber-700" />
                <span className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-amber-800 text-white text-[10px] font-black flex items-center justify-center">
                  3
                </span>
              </div>
              <div>
                <h4 className="text-sm font-bold text-slate-900">{top3[2]?.userName}</h4>
                <p className="text-[11px] text-slate-500 font-semibold">{top3[2]?.levelBadge}</p>
              </div>
              <div className="p-3 bg-slate-50 rounded-xl space-y-1 text-xs">
                <div className="flex justify-between text-slate-600">
                  <span>Total Score:</span>
                  <span className="font-extrabold text-slate-900">{top3[2]?.totalScore} pts</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Avg Quality:</span>
                  <span className="font-bold text-[#0A66C2]">{top3[2]?.averageScore}%</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Milestones:</span>
                  <span className="font-bold text-emerald-700">{top3[2]?.completedTasksCount} / 5</span>
                </div>
              </div>
            </div>
            <div className="mt-3 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
              Podium • 3rd Place
            </div>
          </div>
        </div>
      )}

      {/* Main Leaderboard Table Section */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        {/* Controls bar */}
        <div className="p-4 sm:p-5 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <h3 className="text-sm sm:text-base font-extrabold text-slate-900 flex items-center gap-2">
              <Trophy className="w-4 h-4 text-[#0A66C2]" />
              <span>Full Cohort Rankings ({selectedDomain?.name})</span>
            </h3>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search intern name..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-8 pr-3 py-1.5 text-xs border border-slate-200 rounded-xl focus:outline-none focus:border-[#0A66C2] text-slate-800 w-44"
              />
            </div>
            <div className="flex items-center p-0.5 bg-slate-100 rounded-xl text-xs">
              <button
                type="button"
                onClick={() => setFilterTier('all')}
                className={`px-2.5 py-1 rounded-lg font-bold transition-all ${filterTier === 'all' ? 'bg-white shadow-2xs text-[#0A66C2]' : 'text-slate-600'}`}
              >
                All
              </button>
              <button
                type="button"
                onClick={() => setFilterTier('top3')}
                className={`px-2.5 py-1 rounded-lg font-bold transition-all ${filterTier === 'top3' ? 'bg-white shadow-2xs text-[#0A66C2]' : 'text-slate-600'}`}
              >
                Top 3
              </button>
              <button
                type="button"
                onClick={() => setFilterTier('completed')}
                className={`px-2.5 py-1 rounded-lg font-bold transition-all ${filterTier === 'completed' ? 'bg-white shadow-2xs text-[#0A66C2]' : 'text-slate-600'}`}
              >
                Finished (5/5)
              </button>
            </div>
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-[11px] font-extrabold uppercase text-slate-500 tracking-wider">
                <th className="py-3 px-4 text-center w-16">Rank</th>
                <th className="py-3 px-4">Intern</th>
                <th className="py-3 px-4 text-center">Milestones</th>
                <th className="py-3 px-4 text-center">Review Avg</th>
                <th className="py-3 px-4 text-center">Best Score</th>
                <th className="py-3 px-4 text-center">Total Points</th>
                <th className="py-3 px-4 text-right">Badge Tier</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-xs">
              {filteredEntries.map((entry, idx) => {
                const isUser = entry.isCurrentUser || entry.userId === user?.uid;
                return (
                  <tr
                    key={`${entry.userId || 'user'}-${entry.rank || idx}-${idx}`}
                    className={`transition-colors ${
                      isUser
                        ? 'bg-blue-50/80 font-semibold ring-1 ring-[#0A66C2]/30'
                        : 'hover:bg-slate-50'
                    }`}
                  >
                    {/* Rank */}
                    <td className="py-3.5 px-4 text-center">
                      {entry.rank === 1 ? (
                        <span className="inline-flex w-7 h-7 rounded-full bg-amber-100 text-amber-900 font-black items-center justify-center border border-amber-300 shadow-2xs">
                          🥇
                        </span>
                      ) : entry.rank === 2 ? (
                        <span className="inline-flex w-7 h-7 rounded-full bg-slate-100 text-slate-800 font-black items-center justify-center border border-slate-300 shadow-2xs">
                          🥈
                        </span>
                      ) : entry.rank === 3 ? (
                        <span className="inline-flex w-7 h-7 rounded-full bg-amber-50 text-amber-900 font-black items-center justify-center border border-amber-600/30 shadow-2xs">
                          🥉
                        </span>
                      ) : (
                        <span className="font-bold text-slate-500">#{entry.rank}</span>
                      )}
                    </td>

                    {/* Intern */}
                    <td className="py-3.5 px-4">
                      <div className="flex items-center gap-2.5">
                        <div className="w-8 h-8 rounded-full bg-slate-200 text-slate-700 flex items-center justify-center font-bold text-xs shrink-0 overflow-hidden border border-slate-200">
                          {entry.userPhoto ? (
                            <img src={entry.userPhoto} alt={entry.userName} className="w-full h-full object-cover" />
                          ) : (
                            <span>{entry.userName.slice(0, 1)}</span>
                          )}
                        </div>
                        <div>
                          <div className="flex items-center gap-1.5">
                            <span className="font-bold text-slate-900">{entry.userName}</span>
                            {isUser && (
                              <span className="px-1.5 py-0.2 bg-[#0A66C2] text-white text-[9px] font-black rounded tracking-wider">
                                YOU
                              </span>
                            )}
                          </div>
                          <span className="text-[10px] text-slate-400 block">{entry.statusText}</span>
                        </div>
                      </div>
                    </td>

                    {/* Milestones */}
                    <td className="py-3.5 px-4 text-center">
                      <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold ${
                        entry.completedTasksCount === 5
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-slate-100 text-slate-700'
                      }`}>
                        {entry.completedTasksCount === 5 && <CheckCircle2 className="w-3 h-3 text-emerald-700" />}
                        <span>{entry.completedTasksCount} / 5</span>
                      </span>
                    </td>

                    {/* Mentor Review Avg */}
                    <td className="py-3.5 px-4 text-center font-bold">
                      <span className={entry.averageScore >= 90 ? 'text-[#057642]' : entry.averageScore >= 80 ? 'text-[#0A66C2]' : 'text-slate-700'}>
                        {entry.averageScore > 0 ? `${entry.averageScore}%` : '--'}
                      </span>
                    </td>

                    {/* Best Score */}
                    <td className="py-3.5 px-4 text-center">
                      <span className="px-2 py-0.5 bg-blue-50 text-[#0A66C2] rounded-md font-bold text-[11px] border border-blue-200 inline-flex items-center gap-1">
                        <Sparkles className="w-2.5 h-2.5 text-[#0A66C2]" />
                        <span>{entry.bestTaskScore > 0 ? `${entry.bestTaskScore}%` : '--'}</span>
                      </span>
                    </td>

                    {/* Total Points */}
                    <td className="py-3.5 px-4 text-center">
                      <span className="font-black text-slate-900 text-sm">
                        {entry.totalScore}
                      </span>
                      <span className="text-[10px] text-slate-400 block">pts</span>
                    </td>

                    {/* Badge Tier */}
                    <td className="py-3.5 px-4 text-right">
                      <span className="px-2.5 py-1 bg-slate-100 text-slate-800 rounded-lg text-[10px] font-bold border border-slate-200 inline-block">
                        {entry.levelBadge}
                      </span>
                    </td>
                  </tr>
                );
              })}

              {filteredEntries.length === 0 && (
                <tr key="empty-filter-row">
                  <td colSpan={7} className="py-8 text-center text-slate-500">
                    No interns found matching your filter criteria.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Official Mentor Rubric Explanation Card */}
      <div className="p-5 bg-gradient-to-r from-blue-50/70 via-indigo-50/60 to-purple-50/50 rounded-2xl border border-blue-200/80 shadow-2xs space-y-3">
        <div className="flex items-center gap-2 text-[#0A66C2] font-black text-sm">
          <Sparkles className="w-4 h-4" />
          <span>How Your Task Submissions Are Evaluated & Scored</span>
        </div>
        <p className="text-xs text-slate-700 leading-relaxed">
          Every task deliverable (GitHub repo, live deployment, architecture documentation, implementation notes) is thoroughly examined and evaluated by our senior technical mentors through four objective engineering pillars:
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 pt-1">
          <div className="p-3 bg-white/80 rounded-xl border border-blue-100">
            <span className="text-[10px] font-extrabold uppercase text-[#0A66C2] tracking-wider block">Pillar 1 (25 pts)</span>
            <p className="text-xs font-bold text-slate-900 mt-0.5">Code Architecture</p>
            <p className="text-[11px] text-slate-500 mt-1">Modular folder structure, clean interfaces, maintainability, and design patterns.</p>
          </div>
          <div className="p-3 bg-white/80 rounded-xl border border-blue-100">
            <span className="text-[10px] font-extrabold uppercase text-[#0A66C2] tracking-wider block">Pillar 2 (25 pts)</span>
            <p className="text-xs font-bold text-slate-900 mt-0.5">Deliverable Completeness</p>
            <p className="text-[11px] text-slate-500 mt-1">Alignment against weekly task milestones, user journeys, and edge case coverage.</p>
          </div>
          <div className="p-3 bg-white/80 rounded-xl border border-blue-100">
            <span className="text-[10px] font-extrabold uppercase text-[#0A66C2] tracking-wider block">Pillar 3 (25 pts)</span>
            <p className="text-xs font-bold text-slate-900 mt-0.5">Practical Implementation</p>
            <p className="text-[11px] text-slate-500 mt-1">Functionality, error handling, performance optimization, and live demo reliability.</p>
          </div>
          <div className="p-3 bg-white/80 rounded-xl border border-blue-100">
            <span className="text-[10px] font-extrabold uppercase text-[#0A66C2] tracking-wider block">Pillar 4 (25 pts)</span>
            <p className="text-xs font-bold text-slate-900 mt-0.5">Documentation & Readiness</p>
            <p className="text-[11px] text-slate-500 mt-1">Clear README setup guide, technical decisions, and professional presentation.</p>
          </div>
        </div>
      </div>
    </div>
  );
};
