import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { ReferralRecord } from '../types';
import { dataService } from '../services/dataService';
import {
  Users,
  Copy,
  Check,
  Share2,
  DollarSign,
  TrendingUp,
  ShieldAlert,
  Sparkles,
  ArrowRight
} from 'lucide-react';

export const ReferralDashboard: React.FC = () => {
  const { user } = useAuth();
  const [referrals, setReferrals] = useState<ReferralRecord[]>([]);
  const [copied, setCopied] = useState(false);
  const [payoutRequested, setPayoutRequested] = useState(false);

  useEffect(() => {
    if (user) {
      dataService.getReferrals(user.uid).then(setReferrals);
    }
  }, [user]);

  if (!user) return null;

  const referralCode = user.referralCode || 'VIRINTERN';
  const referralLink = `${window.location.origin}?ref=${referralCode}`;

  const copyLink = () => {
    navigator.clipboard.writeText(referralLink);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Metrics calculation
  const totalReferrals = referrals.length;
  const successfulReferrals = referrals.filter(r => r.status === 'purchased').length;
  const totalEarnings = Number(
    referrals
      .filter(r => r.status === 'purchased')
      .reduce((sum, r) => sum + (r.rewardAmount || 9.90), 0)
      .toFixed(2)
  );
  const paidEarnings = Number(
    referrals
      .filter(r => r.status === 'purchased' && r.rewardPaid)
      .reduce((sum, r) => sum + (r.rewardAmount || 9.90), 0)
      .toFixed(2)
  );
  const pendingEarnings = Number((totalEarnings - paidEarnings).toFixed(2));

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      {/* Header Banner */}
      <div className="bg-[#0A66C2] rounded-2xl p-8 sm:p-10 text-white shadow-md relative overflow-hidden">
        <div className="max-w-2xl space-y-3">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/15 text-white text-xs font-semibold">
            <Sparkles className="w-3.5 h-3.5" />
            <span>VirIntern Ambassador Program</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-white">
            Refer Friends & Earn 10%
          </h1>
          <p className="text-xs sm:text-sm font-medium text-blue-100 leading-relaxed">
            Invite classmates and fellow developers to join VirIntern. When they upgrade to their official completion package, you receive a 10% direct reward (₹9.90 per student)!
          </p>
        </div>
      </div>

      {/* Referral Link & Code Box (PRD Section 26) */}
      <div className="bg-white p-6 rounded-xl border border-[#E0DFDC] shadow-xs space-y-4">
        <h2 className="text-sm font-bold uppercase tracking-wider text-[#191919]">
          Your Personal Referral Code & Link
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center">
          <div className="md:col-span-4 p-3 bg-[#F4F2EE] border border-[#E0DFDC] rounded-xl">
            <span className="text-[10px] text-[#666666] uppercase font-semibold">Referral Code</span>
            <p className="text-lg font-mono font-extrabold text-[#0A66C2] tracking-wider">
              {referralCode}
            </p>
          </div>

          <div className="md:col-span-8 flex flex-col sm:flex-row gap-2">
            <input
              type="text"
              readOnly
              value={referralLink}
              className="flex-1 px-4 py-2.5 bg-[#F4F2EE] border border-[#E0DFDC] rounded-xl text-xs font-mono text-[#191919] outline-none"
            />
            <button
              onClick={copyLink}
              className="px-5 py-2.5 bg-[#0A66C2] hover:bg-[#004182] text-white font-semibold text-xs rounded-full shadow-xs transition-colors flex items-center justify-center gap-1.5 shrink-0"
            >
              {copied ? <Check className="w-4 h-4 text-emerald-300" /> : <Copy className="w-4 h-4" />}
              <span>{copied ? 'Link Copied!' : 'Copy Link'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* 26. Referral Dashboard Metrics */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        <div className="bg-white p-5 rounded-xl border border-[#E0DFDC] shadow-xs text-center">
          <p className="text-[11px] uppercase tracking-wider text-[#666666] font-semibold">Total Referrals</p>
          <p className="text-2xl font-bold text-[#191919] mt-1">{totalReferrals}</p>
        </div>

        <div className="bg-white p-5 rounded-xl border border-[#E0DFDC] shadow-xs text-center">
          <p className="text-[11px] uppercase tracking-wider text-[#666666] font-semibold">Successful</p>
          <p className="text-2xl font-bold text-[#057642] mt-1">{successfulReferrals}</p>
        </div>

        <div className="bg-white p-5 rounded-xl border border-[#E0DFDC] shadow-xs text-center">
          <p className="text-[11px] uppercase tracking-wider text-[#666666] font-semibold">Total Earnings</p>
          <p className="text-2xl font-bold text-[#0A66C2] mt-1">₹{totalEarnings}</p>
        </div>

        <div className="bg-white p-5 rounded-xl border border-[#E0DFDC] shadow-xs text-center">
          <p className="text-[11px] uppercase tracking-wider text-[#666666] font-semibold">Pending</p>
          <p className="text-2xl font-bold text-[#915907] mt-1">₹{pendingEarnings}</p>
        </div>

        <div className="bg-white p-5 rounded-xl border border-[#E0DFDC] shadow-xs text-center col-span-2 md:col-span-1">
          <p className="text-[11px] uppercase tracking-wider text-[#666666] font-semibold">Paid Out</p>
          <p className="text-2xl font-bold text-[#666666] mt-1">₹{paidEarnings}</p>
        </div>
      </div>

      {/* Fraud Prevention & Rules (PRD Section 25) */}
      <div className="bg-[#F4F2EE] p-4 rounded-xl border border-[#E0DFDC] flex items-start gap-3 text-xs text-[#666666]">
        <ShieldAlert className="w-5 h-5 text-[#915907] shrink-0 mt-0.5" />
        <div>
          <span className="font-bold text-[#191919]">Fraud Prevention Policies Active:</span> Self-referrals, duplicate accounts, and repeat rewards on the same user purchase are strictly prevented by the database rules.
        </div>
      </div>

      {/* Referrals List Table */}
      <div className="bg-white rounded-xl border border-[#E0DFDC] overflow-hidden shadow-xs">
        <div className="p-4 bg-[#F4F2EE] border-b border-[#E0DFDC] flex items-center justify-between">
          <h3 className="text-xs font-bold uppercase tracking-wider text-[#191919]">
            Referred Students History
          </h3>
          <button
            onClick={() => setPayoutRequested(true)}
            disabled={pendingEarnings <= 0}
            className={`px-4 py-1.5 rounded-full text-xs font-semibold transition-colors ${
              pendingEarnings > 0
                ? 'bg-[#057642] hover:bg-[#046237] text-white shadow-xs'
                : 'bg-[#E0DFDC] text-[#666666] cursor-not-allowed'
            }`}
          >
            {payoutRequested ? '✓ Payout Requested' : `Request Payout (₹${pendingEarnings})`}
          </button>
        </div>

        <div className="divide-y divide-slate-100">
          {referrals.length === 0 ? (
            <div className="p-8 text-center text-xs text-slate-400">
              No students have registered using your code yet. Share your link with classmates!
            </div>
          ) : (
            referrals.map((ref) => (
              <div key={ref.id} className="p-4 flex items-center justify-between text-xs">
                <div>
                  <p className="font-bold text-slate-900">{ref.referredName}</p>
                  <p className="text-slate-400 text-[11px]">{ref.referredEmail}</p>
                </div>
                <div className="text-right">
                  <span
                    className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      ref.status === 'purchased'
                        ? 'bg-emerald-100 text-emerald-800'
                        : 'bg-slate-100 text-slate-600'
                    }`}
                  >
                    {ref.status === 'purchased' ? `Earned ₹${ref.rewardAmount || 9.90}` : 'Signed Up'}
                  </span>
                  <p className="text-[10px] text-slate-400 mt-1">
                    {new Date(ref.createdAt).toLocaleDateString()}
                  </p>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
