import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import {
  Award,
  Bell,
  CheckCircle,
  ChevronDown,
  GraduationCap,
  LayoutDashboard,
  LogOut,
  Mail,
  Menu,
  Shield,
  User,
  Users,
  X,
  FileText,
  HelpCircle,
  ExternalLink,
  BookOpen,
  Lock,
  Crown,
  Trophy,
  TrendingUp,
  Sparkles,
  Building2,
  Briefcase
} from 'lucide-react';

interface NavbarProps {
  currentView: string;
  setCurrentView: (view: string) => void;
  openAuthModal: (mode: 'login' | 'signup', portal?: 'student' | 'company') => void;
  openEmailSimulator: () => void;
  onOpenLegal?: (tab: 'privacy' | 'disclaimer' | 'terms' | 'refund') => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentView,
  setCurrentView,
  openAuthModal,
  openEmailSimulator,
  onOpenLegal
}) => {
  const { user, activeInternship, unreadCount, notifications, markNotificationsRead, logout } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [notifDropdownOpen, setNotifDropdownOpen] = useState(false);
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);
  const notifRef = React.useRef<HTMLDivElement>(null);

  const resolvedDisplayName = (user?.name && user.name.trim().toLowerCase() !== 'intern' && user.name.trim().toLowerCase() !== 'student')
    ? user.name
    : (typeof window !== 'undefined'
        ? (localStorage.getItem(`virintern_user_name_${(user?.email || '').toLowerCase()}`) ||
           (user?.uid ? localStorage.getItem(`virintern_user_name_${user.uid}`) : null) ||
           localStorage.getItem('virintern_last_signup_name') ||
           user?.name)
        : user?.name) || (user?.email ? user.email.split('@')[0] : 'Student');

  // Close notifications on click outside
  useEffect(() => {
    const handleOutsideClick = (e: MouseEvent) => {
      if (notifRef.current && !notifRef.current.contains(e.target as Node)) {
        setNotifDropdownOpen(false);
      }
    };
    if (notifDropdownOpen) {
      document.addEventListener('mousedown', handleOutsideClick);
    }
    return () => document.removeEventListener('mousedown', handleOutsideClick);
  }, [notifDropdownOpen]);

  const handleNotifClick = () => {
    setNotifDropdownOpen(prev => !prev);
  };

  return (
    <header className="sticky top-0 z-40 bg-white border-b border-[#E0DFDC] shadow-2xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Brand Logo */}
          <div
            onClick={() => setCurrentView('landing')}
            className="flex items-center gap-2.5 cursor-pointer group"
          >
            <div className="w-9 h-9 rounded-md bg-[#0A66C2] flex items-center justify-center text-white shadow-xs group-hover:bg-[#004182] transition-colors font-black text-sm">
              VI
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold text-lg tracking-tight text-[#191919] group-hover:text-[#0A66C2] transition-colors">
                  VirIntern
                </span>
                <span className="text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded bg-[#EBF4FD] text-[#0A66C2] border border-[#0A66C2]/30">
                  Virtual
                </span>
              </div>
              <p className="text-[11px] text-[#666666] font-medium hidden sm:block">
                Skill & Project Internships
              </p>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-1">
            <button
              onClick={() => setCurrentView('landing')}
              className={`px-3 py-2 text-sm font-semibold transition-colors ${
                currentView === 'landing' ? 'text-[#0A66C2] border-b-2 border-[#0A66C2]' : 'text-[#666666] hover:text-[#191919] hover:bg-[#F3F2F0] rounded-md'
              }`}
            >
              Home
            </button>
            {(!user || user.role === 'student') && (
              <button
                onClick={() => setCurrentView('domains')}
                className={`px-3 py-2 text-sm font-semibold transition-colors ${
                  currentView === 'domains' ? 'text-[#0A66C2] border-b-2 border-[#0A66C2]' : 'text-[#666666] hover:text-[#191919] hover:bg-[#F3F2F0] rounded-md'
                }`}
              >
                Domains
              </button>
            )}

            {/* Student-Only Navigation */}
            {user && user.role === 'student' && (
              <>
                <button
                  onClick={() => setCurrentView('dashboard')}
                  className={`px-3 py-2 text-sm font-semibold flex items-center gap-1.5 transition-colors ${
                    currentView === 'dashboard' ? 'text-[#0A66C2] border-b-2 border-[#0A66C2]' : 'text-[#666666] hover:text-[#191919] hover:bg-[#F3F2F0] rounded-md'
                  }`}
                >
                  <LayoutDashboard className="w-4 h-4 text-[#0A66C2]" />
                  Dashboard
                  {activeInternship && (
                    <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-[#E8F5E9] text-[#057642] font-bold">
                      {activeInternship.progress}%
                    </span>
                  )}
                </button>

                <button
                  onClick={() => setCurrentView('performance')}
                  className={`px-3 py-2 text-sm font-semibold flex items-center gap-1.5 transition-colors ${
                    currentView === 'performance' ? 'text-[#0A66C2] border-b-2 border-[#0A66C2]' : 'text-[#666666] hover:text-[#191919] hover:bg-[#F3F2F0] rounded-md'
                  }`}
                >
                  <TrendingUp className="w-4 h-4 text-[#0A66C2]" />
                  Performance
                </button>

                <button
                  onClick={() => setCurrentView('leaderboard')}
                  className={`px-3 py-2 text-sm font-semibold flex items-center gap-1.5 transition-colors ${
                    currentView === 'leaderboard' ? 'text-[#0A66C2] border-b-2 border-[#0A66C2]' : 'text-[#666666] hover:text-[#191919] hover:bg-[#F3F2F0] rounded-md'
                  }`}
                >
                  <Trophy className="w-4 h-4 text-amber-500" />
                  Leaderboard
                </button>

                <button
                  onClick={() => setCurrentView('premium')}
                  className={`px-3 py-2 text-sm font-semibold flex items-center gap-1.5 transition-colors ${
                    currentView === 'premium' ? 'text-[#0A66C2] border-b-2 border-[#0A66C2]' : 'text-[#666666] hover:text-[#191919] hover:bg-[#F3F2F0] rounded-md'
                  }`}
                >
                  <Crown className="w-4 h-4 text-amber-500" />
                  <span>Premium</span>
                  {user && !user.hasPaidPackage && (
                    <span className="text-[10px] bg-amber-100 text-amber-800 font-bold px-1.5 py-0.2 rounded-full flex items-center gap-0.5 border border-amber-200">
                      <Lock className="w-2.5 h-2.5 text-amber-700" />
                      <span>Lock</span>
                    </span>
                  )}
                  {user && user.hasPaidPackage && (
                    <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-1.5 py-0.2 rounded-full border border-emerald-200">
                      Active
                    </span>
                  )}
                </button>

                <button
                  onClick={() => setCurrentView('referrals')}
                  className={`px-3 py-2 text-sm font-semibold flex items-center gap-1.5 transition-colors ${
                    currentView === 'referrals' ? 'text-[#0A66C2] border-b-2 border-[#0A66C2]' : 'text-[#666666] hover:text-[#191919] hover:bg-[#F3F2F0] rounded-md'
                  }`}
                >
                  <Users className="w-4 h-4 text-[#B26A00]" />
                  Refer & Earn
                  <span className="text-[10px] bg-[#FFF3E0] text-[#B26A00] font-bold px-1 rounded">10%</span>
                </button>
              </>
            )}

            {/* Company / Recruiter Navigation */}
            {user && user.role === 'company' && (
              <>
                <button
                  onClick={() => setCurrentView('company')}
                  className={`px-3.5 py-2 text-sm font-bold rounded-lg flex items-center gap-1.5 transition-colors ${
                    currentView === 'company' ? 'bg-[#0A66C2] text-white shadow-xs' : 'text-[#0A66C2] bg-[#EBF4FD] hover:bg-[#D9EAF9]'
                  }`}
                >
                  <Building2 className="w-4 h-4" />
                  <span>Talent Discovery Portal</span>
                </button>
              </>
            )}

            {/* Admin-Only Navigation */}
            {user?.role === 'admin' && (
              <>
                <button
                  onClick={() => setCurrentView('admin')}
                  className={`px-3.5 py-2 text-sm font-bold rounded-lg flex items-center gap-1.5 transition-colors ${
                    currentView === 'admin' ? 'bg-[#0A66C2] text-white shadow-xs' : 'text-[#0A66C2] bg-[#EBF4FD] hover:bg-[#D9EAF9]'
                  }`}
                >
                  <Shield className="w-4 h-4" />
                  <span>Admin Control Portal</span>
                  <span className="w-2 h-2 rounded-full bg-[#057642] animate-pulse ml-0.5" title="Real-time connected"></span>
                </button>

                <button
                  onClick={() => setCurrentView('leaderboard')}
                  className={`px-3 py-2 text-sm font-semibold flex items-center gap-1.5 transition-colors ${
                    currentView === 'leaderboard' ? 'text-[#0A66C2] border-b-2 border-[#0A66C2]' : 'text-[#666666] hover:text-[#191919] hover:bg-[#F3F2F0] rounded-md'
                  }`}
                >
                  <Trophy className="w-4 h-4 text-amber-500" />
                  <span>Student Leaderboard</span>
                </button>
              </>
            )}

            {/* Public Leaderboard for visitors */}
            {!user && (
              <button
                onClick={() => setCurrentView('leaderboard')}
                className={`px-3 py-2 text-sm font-semibold flex items-center gap-1.5 transition-colors ${
                  currentView === 'leaderboard' ? 'text-[#0A66C2] border-b-2 border-[#0A66C2]' : 'text-[#666666] hover:text-[#191919] hover:bg-[#F3F2F0] rounded-md'
                }`}
              >
                <Trophy className="w-4 h-4 text-amber-500" />
                <span>Leaderboard</span>
              </button>
            )}

            <button
              onClick={() => setCurrentView('verify_cert')}
              className={`px-3 py-2 text-sm font-semibold flex items-center gap-1.5 transition-colors ${
                currentView === 'verify_cert' ? 'text-[#0A66C2] border-b-2 border-[#0A66C2]' : 'text-[#666666] hover:text-[#191919] hover:bg-[#F3F2F0] rounded-md'
              }`}
            >
              <Award className="w-4 h-4 text-[#0A66C2]" />
              Verify Certificate
            </button>
          </nav>

          {/* Right Header Controls */}
          <div className="flex items-center gap-2.5">
            {/* Email Center Button (visible only in admin mode) */}
            {user?.role === 'admin' && (
              <button
                onClick={openEmailSimulator}
                title="System Email Logs & Dispatches"
                className="p-2 text-[#666666] hover:text-[#0A66C2] hover:bg-[#F3F2F0] rounded-lg transition-colors relative"
              >
                <Mail className="w-5 h-5" />
              </button>
            )}

            {/* In-App Notifications */}
            {user && (
              <div className="relative" ref={notifRef}>
                <button
                  onClick={handleNotifClick}
                  className="p-2 text-[#666666] hover:text-[#0A66C2] hover:bg-[#F3F2F0] rounded-lg transition-colors relative cursor-pointer"
                  title="Notifications"
                >
                  <Bell className="w-5 h-5" />
                  {unreadCount > 0 && (
                    <span className="absolute top-1.5 right-1.5 w-4 h-4 bg-[#CC1016] text-white text-[10px] font-bold rounded-full flex items-center justify-center animate-pulse">
                      {unreadCount}
                    </span>
                  )}
                </button>

                {/* Notifications Dropdown */}
                {notifDropdownOpen && (
                  <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-white rounded-xl shadow-xl border border-[#E0DFDC] overflow-hidden z-50 animate-in fade-in zoom-in-95 duration-150">
                    <div className="p-3 bg-[#F4F2EE] border-b border-[#E0DFDC] flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold uppercase tracking-wider text-[#191919]">Notifications</span>
                        {unreadCount > 0 ? (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-[#CC1016] text-white">
                            {unreadCount} new
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-slate-200 text-slate-700">
                            {Math.max(notifications.length, 1)} total
                          </span>
                        )}
                      </div>
                      {unreadCount > 0 && (
                        <button
                          onClick={() => markNotificationsRead()}
                          className="text-xs text-[#0A66C2] hover:text-[#004182] hover:underline font-semibold cursor-pointer"
                        >
                          Mark all read
                        </button>
                      )}
                    </div>
                    <div className="max-h-80 overflow-y-auto divide-y divide-[#E0DFDC]/60">
                      {(notifications.length > 0 ? notifications : [
                        {
                          id: `welcome_${user.uid}`,
                          userId: user.uid,
                          title: 'Welcome to VirIntern! 🎉',
                          message: 'Your virtual internship portal is active. Review your pre-attached offer letter, check your assigned domain milestones, and submit Task 1.',
                          type: 'internship_started' as const,
                          isRead: false,
                          createdAt: user.createdAt || new Date().toISOString()
                        }
                      ]).map((n) => (
                        <div
                          key={n.id}
                          className={`p-3.5 hover:bg-[#F4F2EE] transition-colors ${!n.isRead ? 'bg-[#EBF4FD]/80 border-l-4 border-l-[#0A66C2]' : 'bg-white'}`}
                        >
                          <div className="flex items-start justify-between gap-2">
                            <p className={`text-xs ${!n.isRead ? 'font-bold text-[#0A66C2]' : 'font-semibold text-[#191919]'}`}>
                              {n.title}
                            </p>
                            {!n.isRead && (
                              <span className="w-2 h-2 rounded-full bg-[#0A66C2] shrink-0 mt-1" title="Unread"></span>
                            )}
                          </div>
                          <p className="text-xs text-[#666666] mt-1 leading-relaxed">{n.message}</p>
                          <p className="text-[10px] text-[#8C8C8C] mt-1.5 font-medium">
                            {new Date(n.createdAt).toLocaleDateString([], { month: 'short', day: 'numeric' })}{' '}
                            • {new Date(n.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Auth Buttons or Profile Menu */}
            {!user ? (
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => openAuthModal('login', 'company')}
                  className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-slate-700 hover:text-[#0A66C2] hover:bg-[#F3F2F0] rounded-full border border-slate-300 transition-colors cursor-pointer"
                  title="Employer & Corporate Talent Discovery"
                >
                  <Building2 className="w-3.5 h-3.5 text-[#0A66C2]" />
                  <span>Hire Talent</span>
                </button>
                <button
                  type="button"
                  onClick={() => openAuthModal('login', 'student')}
                  className="px-4 py-1.5 text-sm font-semibold text-[#0A66C2] hover:bg-[#EBF4FD] rounded-full border border-[#0A66C2] transition-colors cursor-pointer"
                >
                  Sign In
                </button>
                <button
                  type="button"
                  onClick={() => openAuthModal('signup', 'student')}
                  className="px-4 py-1.5 text-sm font-semibold text-white bg-[#0A66C2] hover:bg-[#004182] rounded-full shadow-xs transition-colors cursor-pointer"
                >
                  Join now
                </button>
              </div>
            ) : (
              <div className="relative">
                <button
                  onClick={() => setUserDropdownOpen(!userDropdownOpen)}
                  className="flex items-center gap-2 p-1.5 rounded-lg hover:bg-[#F3F2F0] transition-colors"
                >
                  {user.photoURL ? (
                    <img
                      src={user.photoURL}
                      alt={user.name}
                      className="w-8 h-8 rounded-full border border-[#E0DFDC] object-cover"
                    />
                  ) : (
                    <div className="w-8 h-8 rounded-full bg-[#E0DFDC] text-[#666666] flex items-center justify-center font-bold text-xs border border-[#CED0D4]">
                      {user.role === 'company' ? (
                        <Building2 className="w-4 h-4 text-[#0A66C2]" />
                      ) : user.role === 'admin' ? (
                        <Shield className="w-4 h-4 text-[#0A66C2]" />
                      ) : (
                        <User className="w-4 h-4 text-[#666666]" />
                      )}
                    </div>
                  )}
                  <div className="hidden sm:block text-left">
                    <p className="text-xs font-bold text-[#191919] leading-none truncate max-w-[120px]">
                      {resolvedDisplayName}
                    </p>
                    <span className={`text-[10px] font-semibold uppercase tracking-wider ${
                      user.role === 'admin' ? 'text-[#0A66C2]' : user.role === 'company' ? 'text-indigo-600' : 'text-[#057642]'
                    }`}>
                      {user.role === 'company' ? 'Company Partner' : user.role === 'admin' ? 'Admin' : 'Role: Intern'}
                    </span>
                  </div>
                  <ChevronDown className="w-3.5 h-3.5 text-[#666666]" />
                </button>

                {userDropdownOpen && (
                  <div className="absolute right-0 mt-2 w-56 bg-white rounded-xl shadow-xl border border-[#E0DFDC] py-1.5 z-50">
                    <div className="px-4 py-2 border-b border-[#E0DFDC]">
                      <p className="text-xs font-bold text-[#191919]">
                        {resolvedDisplayName}
                      </p>
                      <p className="text-[11px] text-[#666666] truncate">{user.email}</p>
                      <span className="inline-block mt-1 text-[10px] uppercase font-bold px-1.5 py-0.2 rounded bg-slate-100 text-slate-700">
                        {user.role === 'company' ? 'Recruiter Account' : user.role === 'admin' ? 'Admin Portal' : 'Intern Workspace'}
                      </span>
                    </div>

                    {/* Student Menu */}
                    {user.role === 'student' && (
                      <>
                        <button
                          onClick={() => {
                            setCurrentView('dashboard');
                            setUserDropdownOpen(false);
                          }}
                          className="w-full text-left px-4 py-2 text-xs text-[#191919] hover:bg-[#F4F2EE] flex items-center gap-2"
                        >
                          <LayoutDashboard className="w-4 h-4 text-[#0A66C2]" />
                          My Internship Dashboard
                        </button>

                        <button
                          onClick={() => {
                            setCurrentView('performance');
                            setUserDropdownOpen(false);
                          }}
                          className="w-full text-left px-4 py-2 text-xs text-[#191919] hover:bg-[#F4F2EE] flex items-center gap-2"
                        >
                          <TrendingUp className="w-4 h-4 text-[#0A66C2]" />
                          My Performance & Badges
                        </button>

                        <button
                          onClick={() => {
                            setCurrentView('premium');
                            setUserDropdownOpen(false);
                          }}
                          className="w-full text-left px-4 py-2 text-xs text-[#191919] hover:bg-[#F4F2EE] flex items-center justify-between"
                        >
                          <div className="flex items-center gap-2">
                            <Crown className="w-4 h-4 text-amber-500" />
                            <span>Premium Section</span>
                          </div>
                          {!user.hasPaidPackage && (
                            <Lock className="w-3 h-3 text-amber-600" />
                          )}
                        </button>

                        <button
                          onClick={() => {
                            setCurrentView('referrals');
                            setUserDropdownOpen(false);
                          }}
                          className="w-full text-left px-4 py-2 text-xs text-[#191919] hover:bg-[#F4F2EE] flex items-center gap-2"
                        >
                          <Users className="w-4 h-4 text-[#915907]" />
                          Referral Rewards (Code: {user.referralCode})
                        </button>
                      </>
                    )}

                    {/* Company Menu */}
                    {user.role === 'company' && (
                      <>
                        <button
                          onClick={() => {
                            setCurrentView('company');
                            setUserDropdownOpen(false);
                          }}
                          className="w-full text-left px-4 py-2 text-xs text-[#0A66C2] bg-[#EBF4FD] hover:bg-[#D9EAF9] flex items-center gap-2 font-bold"
                        >
                          <Building2 className="w-4 h-4 text-[#0A66C2]" />
                          Talent Discovery Portal
                        </button>
                      </>
                    )}

                    {/* Admin Menu */}
                    {user.role === 'admin' && (
                      <>
                        <button
                          onClick={() => {
                            setCurrentView('admin');
                            setUserDropdownOpen(false);
                          }}
                          className="w-full text-left px-4 py-2 text-xs text-[#0A66C2] bg-[#EBF4FD] hover:bg-[#D9EAF9] flex items-center gap-2 font-bold"
                        >
                          <Shield className="w-4 h-4 text-[#0A66C2]" />
                          Admin Control Portal
                        </button>

                        <button
                          onClick={() => {
                            setCurrentView('leaderboard');
                            setUserDropdownOpen(false);
                          }}
                          className="w-full text-left px-4 py-2 text-xs text-[#191919] hover:bg-[#F4F2EE] flex items-center gap-2"
                        >
                          <Trophy className="w-4 h-4 text-amber-500" />
                          Student Leaderboard
                        </button>
                      </>
                    )}

                    <div className="border-t border-[#E0DFDC] mt-1 pt-1">
                      <button
                        onClick={() => {
                          setUserDropdownOpen(false);
                          if (onOpenLegal) onOpenLegal('privacy');
                        }}
                        className="w-full text-left px-4 py-2 text-xs text-slate-700 hover:bg-[#F4F2EE] flex items-center gap-2"
                      >
                        <FileText className="w-4 h-4 text-[#0A66C2]" />
                        Privacy Policy & Disclaimer
                      </button>

                      <button
                        onClick={() => {
                          logout();
                          setUserDropdownOpen(false);
                          setCurrentView('landing');
                        }}
                        className="w-full text-left px-4 py-2 text-xs text-[#CC1016] hover:bg-[#FCE8E6] flex items-center gap-2 font-medium"
                      >
                        <LogOut className="w-4 h-4 text-[#CC1016]" />
                        Sign Out
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Mobile menu button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 text-[#666666] hover:text-[#191919] rounded-lg hover:bg-[#F3F2F0]"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-[#E0DFDC] bg-white px-4 py-3 space-y-2">
          <button
            onClick={() => { setCurrentView('landing'); setMobileMenuOpen(false); }}
            className="w-full text-left px-3 py-2 text-sm font-medium text-[#191919] rounded-lg hover:bg-[#F4F2EE]"
          >
            Home
          </button>
          {(!user || user.role === 'student') && (
            <button
              onClick={() => { setCurrentView('domains'); setMobileMenuOpen(false); }}
              className="w-full text-left px-3 py-2 text-sm font-medium text-[#191919] rounded-lg hover:bg-[#F4F2EE]"
            >
              Explore Domains
            </button>
          )}

          {/* Student Mobile Navigation */}
          {user && user.role === 'student' && (
            <>
              <button
                onClick={() => { setCurrentView('dashboard'); setMobileMenuOpen(false); }}
                className="w-full text-left px-3 py-2 text-sm font-medium text-[#191919] rounded-lg hover:bg-[#F4F2EE] flex items-center justify-between"
              >
                <span>Dashboard</span>
                {activeInternship && <span className="text-xs bg-[#E8F5E9] text-[#057642] font-bold px-2 py-0.5 rounded">{activeInternship.progress}%</span>}
              </button>
              <button
                onClick={() => { setCurrentView('performance'); setMobileMenuOpen(false); }}
                className="w-full text-left px-3 py-2 text-sm font-medium text-[#191919] rounded-lg hover:bg-[#F4F2EE] flex items-center justify-between"
              >
                <div className="flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-[#0A66C2]" />
                  <span>My Performance</span>
                </div>
                <span className="text-[10px] bg-blue-100 text-[#0A66C2] font-bold px-1.5 py-0.5 rounded-full border border-blue-200">
                  Analytics
                </span>
              </button>
              <button
                onClick={() => { setCurrentView('leaderboard'); setMobileMenuOpen(false); }}
                className="w-full text-left px-3 py-2 text-sm font-medium text-[#191919] rounded-lg hover:bg-[#F4F2EE] flex items-center justify-between"
              >
                <div className="flex items-center gap-2">
                  <Trophy className="w-4 h-4 text-amber-500" />
                  <span>Cohort Leaderboard</span>
                </div>
                <span className="text-[10px] bg-amber-100 text-amber-800 font-bold px-1.5 py-0.5 rounded-full border border-amber-200">
                  Rankings
                </span>
              </button>
              <button
                onClick={() => { setCurrentView('premium'); setMobileMenuOpen(false); }}
                className="w-full text-left px-3 py-2 text-sm font-medium text-[#191919] rounded-lg hover:bg-[#F4F2EE] flex items-center justify-between"
              >
                <div className="flex items-center gap-2">
                  <Crown className="w-4 h-4 text-amber-500" />
                  <span>Premium Section</span>
                </div>
                {!user.hasPaidPackage ? (
                  <span className="text-[10px] bg-amber-100 text-amber-800 font-bold px-1.5 py-0.2 rounded-full flex items-center gap-0.5 border border-amber-200">
                    <Lock className="w-2.5 h-2.5 text-amber-700" />
                    <span>Locked</span>
                  </span>
                ) : (
                  <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-1.5 py-0.2 rounded-full border border-emerald-200">
                    Active
                  </span>
                )}
              </button>
              <button
                onClick={() => { setCurrentView('referrals'); setMobileMenuOpen(false); }}
                className="w-full text-left px-3 py-2 text-sm font-medium text-[#191919] rounded-lg hover:bg-[#F4F2EE]"
              >
                Refer & Earn (10%)
              </button>
            </>
          )}

          {/* Company Mobile Navigation */}
          {user && user.role === 'company' && (
            <button
              onClick={() => { setCurrentView('company'); setMobileMenuOpen(false); }}
              className="w-full text-left px-3 py-2 text-sm font-bold text-[#0A66C2] bg-[#EBF4FD] rounded-lg flex items-center gap-2"
            >
              <Building2 className="w-4 h-4 text-[#0A66C2]" />
              <span>Talent Discovery Portal</span>
            </button>
          )}

          {/* Admin Mobile Navigation */}
          {user?.role === 'admin' && (
            <>
              <button
                onClick={() => { setCurrentView('admin'); setMobileMenuOpen(false); }}
                className="w-full text-left px-3 py-2 text-sm font-bold text-[#0A66C2] bg-[#EBF4FD] rounded-lg flex items-center gap-2"
              >
                <Shield className="w-4 h-4 text-[#0A66C2]" />
                <span>Admin Control Portal</span>
              </button>
              <button
                onClick={() => { setCurrentView('leaderboard'); setMobileMenuOpen(false); }}
                className="w-full text-left px-3 py-2 text-sm font-medium text-[#191919] rounded-lg hover:bg-[#F4F2EE] flex items-center gap-2"
              >
                <Trophy className="w-4 h-4 text-amber-500" />
                <span>Student Leaderboard</span>
              </button>
            </>
          )}

          {/* Visitor Employer Option */}
          {!user && (
            <button
              onClick={() => { openAuthModal('login', 'company'); setMobileMenuOpen(false); }}
              className="w-full text-left px-3 py-2 text-sm font-bold text-[#0A66C2] bg-blue-50 rounded-lg flex items-center gap-2"
            >
              <Building2 className="w-4 h-4 text-[#0A66C2]" />
              <span>For Employers / Hire Talent</span>
            </button>
          )}

          <button
            onClick={() => { setCurrentView('verify_cert'); setMobileMenuOpen(false); }}
            className="w-full text-left px-3 py-2 text-sm font-medium text-[#191919] rounded-lg hover:bg-[#F4F2EE] flex items-center gap-2"
          >
            <Award className="w-4 h-4 text-[#0A66C2]" />
            <span>Verify Certificate</span>
          </button>

          <button
            onClick={() => {
              setMobileMenuOpen(false);
              if (onOpenLegal) onOpenLegal('privacy');
            }}
            className="w-full text-left px-3 py-2 text-sm font-medium text-slate-700 rounded-lg hover:bg-[#F4F2EE] flex items-center gap-2"
          >
            <FileText className="w-4 h-4 text-[#0A66C2]" />
            <span>Privacy Policy & Disclaimer</span>
          </button>
        </div>
      )}
    </header>
  );
};
