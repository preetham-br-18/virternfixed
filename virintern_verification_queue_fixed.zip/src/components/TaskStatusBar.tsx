import React from 'react';
import { TaskSubmission } from '../types';
import {
  Clock,
  CheckCircle2,
  Lock,
  ArrowRight,
  Shield,
  Award,
  ExternalLink,
  Sliders,
  FileCheck,
  Youtube,
  Globe,
  Sparkles,
  AlertCircle
} from 'lucide-react';

interface TaskStatusBarProps {
  taskNumber: number;
  totalTasks?: number;
  currentSubmission?: TaskSubmission;
  isUnderReview: boolean;
  isApproved: boolean;
  isUnlocked: boolean;
  onProceedToNextTask?: () => void;
  onViewPreviousTask?: () => void;
  onViewCertificate?: () => void;
}

export const TaskStatusBar: React.FC<TaskStatusBarProps> = ({
  taskNumber,
  totalTasks = 5,
  currentSubmission,
  isUnderReview,
  isApproved,
  isUnlocked,
  onProceedToNextTask,
  onViewPreviousTask,
  onViewCertificate
}) => {
  const nextTaskNum = taskNumber < totalTasks ? taskNumber + 1 : totalTasks;
  const rubricScore = currentSubmission?.rubricScore;
  const isLastTask = taskNumber === totalTasks;

  // 1. STATE: APPROVED BY ADMIN
  if (isApproved && currentSubmission) {
    return (
      <div className="w-full bg-gradient-to-r from-[#E8F5E9] via-emerald-50 to-[#F1F8F3] rounded-2xl border-2 border-emerald-400 p-4 sm:p-6 shadow-sm space-y-4 animate-fadeIn transition-all">
        {/* Top Header Row */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-emerald-200">
          <div className="flex flex-wrap items-center gap-2.5">
            <span className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-emerald-100 text-[#057642] font-black text-xs sm:text-sm border border-emerald-300 shadow-2xs tracking-wide">
              <CheckCircle2 className="w-4 h-4 text-[#057642]" />
              <span>STATUS BAR: APPROVED ✓</span>
            </span>
            <span className="text-xs font-bold text-slate-700">
              Task {taskNumber} of {totalTasks} Verified & Scored
            </span>
          </div>

          <div className="flex items-center gap-2">
            <span className="px-3.5 py-1.5 rounded-full bg-[#0A66C2] text-white font-extrabold text-xs shadow-xs flex items-center gap-1.5">
              <Award className="w-3.5 h-3.5 text-amber-300" />
              <span>Official Marks: {rubricScore ?? 90} / 100</span>
            </span>
            {currentSubmission.reviewedAt && (
              <span className="text-[11px] text-slate-500 font-medium hidden md:inline-block">
                {new Date(currentSubmission.reviewedAt).toLocaleDateString()}
              </span>
            )}
          </div>
        </div>

        {/* 4-Stage Visual Progress Pipeline (Responsive: Grid on Mobile, Connected pipeline on Laptop) */}
        <div className="bg-white/80 rounded-xl p-3 sm:p-4 border border-emerald-200/90 shadow-2xs">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs">
            {/* Step 1 */}
            <div className="flex items-center gap-2 p-2 bg-emerald-50/70 rounded-lg border border-emerald-200">
              <div className="w-6 h-6 rounded-full bg-emerald-600 text-white flex items-center justify-center text-[10px] font-bold shrink-0">
                ✓
              </div>
              <div className="truncate">
                <span className="font-bold text-emerald-950 block text-[11px] truncate">1. Work Submitted</span>
                <span className="text-[10px] text-emerald-700 block truncate">Deliverables Uploaded</span>
              </div>
            </div>

            {/* Step 2 */}
            <div className="flex items-center gap-2 p-2 bg-emerald-50/70 rounded-lg border border-emerald-200">
              <div className="w-6 h-6 rounded-full bg-emerald-600 text-white flex items-center justify-center text-[10px] font-bold shrink-0">
                ✓
              </div>
              <div className="truncate">
                <span className="font-bold text-emerald-950 block text-[11px] truncate">2. Admin Verified</span>
                <span className="text-[10px] text-emerald-700 block truncate">
                  {currentSubmission.reviewedBy ? `By ${currentSubmission.reviewedBy}` : 'Manual Inspection Done'}
                </span>
              </div>
            </div>

            {/* Step 3 */}
            <div className="flex items-center gap-2 p-2 bg-emerald-50/70 rounded-lg border border-emerald-200">
              <div className="w-6 h-6 rounded-full bg-emerald-600 text-white flex items-center justify-center text-[10px] font-bold shrink-0">
                ✓
              </div>
              <div className="truncate">
                <span className="font-bold text-emerald-950 block text-[11px] truncate">3. Marks Assigned</span>
                <span className="text-[10px] text-emerald-800 font-extrabold block truncate">
                  Score: {rubricScore ?? 90} / 100
                </span>
              </div>
            </div>

            {/* Step 4 */}
            <div className="flex items-center gap-2 p-2 bg-blue-50/90 rounded-lg border border-blue-200">
              <div className="w-6 h-6 rounded-full bg-[#0A66C2] text-white flex items-center justify-center text-[10px] font-bold shrink-0">
                {isLastTask ? '🎓' : '→'}
              </div>
              <div className="truncate">
                <span className="font-bold text-[#0A66C2] block text-[11px] truncate">
                  {isLastTask ? '4. Final Certificate' : `4. Task ${nextTaskNum} Unlocked`}
                </span>
                <span className="text-[10px] text-blue-700 font-semibold block truncate">
                  {isLastTask ? 'Graduation Cleared' : 'Accessible Now'}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Admin Feedback Box */}
        {currentSubmission.adminFeedback && (
          <div className="p-3 sm:p-3.5 bg-white/95 rounded-xl border border-emerald-200 text-xs text-slate-800 flex items-start gap-2.5 shadow-2xs">
            <Sparkles className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            <div>
              <span className="font-bold text-emerald-950 block text-[11px]">Administrator Mentor Feedback:</span>
              <p className="italic text-slate-700 mt-0.5 leading-relaxed">"{currentSubmission.adminFeedback}"</p>
            </div>
          </div>
        )}

        {/* Action Button Row */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
          <p className="text-xs text-emerald-900 font-semibold flex items-center gap-1.5">
            <span>✓ Milestone requirements met. You can proceed with full access.</span>
          </p>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            {!isLastTask && onProceedToNextTask && (
              <button
                type="button"
                onClick={onProceedToNextTask}
                className="w-full sm:w-auto px-5 py-2.5 bg-[#0A66C2] hover:bg-[#004182] text-white font-extrabold text-xs rounded-xl shadow-xs transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-95"
              >
                <span>Proceed to Task {nextTaskNum} Workspace</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            )}

            {isLastTask && onViewCertificate && (
              <button
                type="button"
                onClick={onViewCertificate}
                className="w-full sm:w-auto px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-xl shadow-xs transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-95"
              >
                <span>View Official Certificate & Graduation 🎓</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </div>
    );
  }

  // 2. STATE: REVIEW PENDING (Submitted, Kept under review until admin verifies and assigns marks)
  if (isUnderReview || (currentSubmission && currentSubmission.status !== 'approved')) {
    return (
      <div className="w-full bg-gradient-to-r from-[#FFF8E7] via-amber-50 to-[#FFFBF0] rounded-2xl border-2 border-amber-300 sm:border-amber-400 p-4 sm:p-6 shadow-sm space-y-4 animate-fadeIn transition-all">
        {/* Top Header Row */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-amber-200">
          <div className="flex flex-wrap items-center gap-2.5">
            <span className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-amber-200 text-amber-950 font-black text-xs sm:text-sm border border-amber-300 shadow-2xs tracking-wide">
              <Clock className="w-4 h-4 text-amber-700 animate-pulse" />
              <span>STATUS BAR: REVIEW PENDING ⏳</span>
            </span>
            <span className="text-xs font-bold text-amber-950">
              Task {taskNumber} of {totalTasks} Under Admin Review
            </span>
          </div>

          <div className="flex items-center gap-2">
            <span className="px-3 py-1 rounded-full bg-amber-100 text-amber-900 border border-amber-300 text-[11px] font-bold">
              Pending Manual Admin Marks
            </span>
            {currentSubmission?.submittedAt && (
              <span className="text-[11px] text-slate-500 font-medium hidden md:inline-block">
                Submitted {new Date(currentSubmission.submittedAt).toLocaleDateString()}
              </span>
            )}
          </div>
        </div>

        {/* 4-Stage Visual Progress Pipeline */}
        <div className="bg-white/90 rounded-xl p-3 sm:p-4 border border-amber-200 shadow-2xs">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs">
            {/* Step 1: Done */}
            <div className="flex items-center gap-2 p-2 bg-emerald-50/80 rounded-lg border border-emerald-200">
              <div className="w-6 h-6 rounded-full bg-emerald-600 text-white flex items-center justify-center text-[10px] font-bold shrink-0">
                ✓
              </div>
              <div className="truncate">
                <span className="font-bold text-emerald-950 block text-[11px] truncate">1. Work Submitted</span>
                <span className="text-[10px] text-emerald-700 block truncate">Deliverables Attached</span>
              </div>
            </div>

            {/* Step 2: In Review (Active Pulsing) */}
            <div className="flex items-center gap-2 p-2 bg-amber-100/90 rounded-lg border-2 border-amber-400 shadow-2xs">
              <div className="w-6 h-6 rounded-full bg-amber-600 text-white flex items-center justify-center text-[10px] font-black shrink-0 animate-pulse">
                ⏳
              </div>
              <div className="truncate">
                <span className="font-black text-amber-950 block text-[11px] truncate">2. Review Pending</span>
                <span className="text-[10px] text-amber-800 font-bold block truncate">Under Admin Review</span>
              </div>
            </div>

            {/* Step 3: Marks (Awaiting) */}
            <div className="flex items-center gap-2 p-2 bg-slate-50 rounded-lg border border-slate-200 opacity-90">
              <div className="w-6 h-6 rounded-full bg-slate-300 text-slate-700 flex items-center justify-center text-[10px] font-bold shrink-0">
                <Lock className="w-3 h-3 text-slate-600" />
              </div>
              <div className="truncate">
                <span className="font-bold text-slate-700 block text-[11px] truncate">3. Marks Assignment</span>
                <span className="text-[10px] text-slate-500 block truncate">Awaiting Admin Score</span>
              </div>
            </div>

            {/* Step 4: Next Task (Locked) */}
            <div className="flex items-center gap-2 p-2 bg-slate-50 rounded-lg border border-slate-200 opacity-80">
              <div className="w-6 h-6 rounded-full bg-slate-300 text-slate-700 flex items-center justify-center text-[10px] font-bold shrink-0">
                <Lock className="w-3 h-3 text-slate-600" />
              </div>
              <div className="truncate">
                <span className="font-bold text-slate-700 block text-[11px] truncate">
                  4. Task {nextTaskNum} Access
                </span>
                <span className="text-[10px] text-amber-800 font-semibold block truncate">
                  Locked Until Approved
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Core Explanatory Banner (User Requirement) */}
        <div className="p-3.5 sm:p-4 bg-amber-100/80 rounded-xl border border-amber-300 text-xs text-amber-950 space-y-1.5">
          <div className="flex items-center gap-2 font-black text-amber-950 text-xs sm:text-sm">
            <Shield className="w-4 h-4 text-amber-700 shrink-0" />
            <span>Strict Quality & Review Policy</span>
          </div>
          <p className="text-xs text-amber-950 leading-relaxed font-medium">
            The tasks which is submitted should be kept under review untill unless it is verified by admin and marks is assigned it should not show the next task. Admin should verify manually and then the user can access next task.
          </p>
          <p className="text-[11px] text-amber-900 font-bold pt-1 border-t border-amber-200">
            🔒 Task {nextTaskNum} will remain hidden and locked until an administrator opens the Admin Portal, verifies your deliverables, and assigns your passing score.
          </p>
        </div>

        {/* Deliverables Summary Pills */}
        {currentSubmission && (
          <div className="p-3 bg-white/90 rounded-xl border border-amber-200 text-xs space-y-2">
            <span className="text-[10px] font-extrabold uppercase tracking-wider text-slate-500 block">
              Deliverables Kept Under Review:
            </span>
            <div className="flex flex-wrap gap-2 text-[11px]">
              {taskNumber === 1 ? (
                <>
                  <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-emerald-50 text-emerald-800 border border-emerald-200 rounded-lg font-medium">
                    <FileCheck className="w-3 h-3 text-emerald-600" />
                    <span>Offer Letter Attached</span>
                  </span>
                  <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-red-50 text-red-800 border border-red-200 rounded-lg font-medium">
                    <Youtube className="w-3 h-3 text-red-600" />
                    <span>YouTube Handle: {currentSubmission.youtubeProofText || '@submitted'}</span>
                  </span>
                  <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-red-50 text-red-800 border border-red-200 rounded-lg font-medium">
                    <Youtube className="w-3 h-3 text-red-600" />
                    <span>Screenshot Attached for Verification</span>
                  </span>
                  <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-blue-50 text-[#0A66C2] border border-blue-200 rounded-lg font-medium">
                    <Globe className="w-3 h-3 text-[#0A66C2]" />
                    <span>LinkedIn Announcement Linked</span>
                  </span>
                </>
              ) : (
                <>
                  {currentSubmission.repositoryURL && (
                    <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-blue-50 text-[#0A66C2] border border-blue-200 rounded-lg font-medium">
                      <span>Repo: {currentSubmission.repositoryURL}</span>
                    </span>
                  )}
                  {currentSubmission.demoURL && (
                    <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-purple-50 text-purple-800 border border-purple-200 rounded-lg font-medium">
                      <span>Demo: {currentSubmission.demoURL}</span>
                    </span>
                  )}
                  {currentSubmission.notes && (
                    <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-slate-50 text-slate-700 border border-slate-200 rounded-lg font-medium">
                      <span>Technical Notes Included</span>
                    </span>
                  )}
                </>
              )}
            </div>
          </div>
        )}

        {/* Review Status Footer Notice */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
          <div className="flex items-center gap-1.5 text-xs text-amber-900 font-medium">
            <Clock className="w-3.5 h-3.5 text-amber-700 animate-pulse shrink-0" />
            <span>Submission queued for evaluation. Once verified by the mentor in the Admin Portal, your marks and next task will unlock automatically.</span>
          </div>

          <span className="text-[11px] font-bold text-amber-900 bg-amber-200/90 px-3 py-1 rounded-full border border-amber-300">
            Awaiting Admin Grading
          </span>
        </div>
      </div>
    );
  }

  // 3. STATE: READY FOR SUBMISSION (Not submitted yet)
  return (
    <div className="w-full bg-gradient-to-r from-[#F4F8FD] via-white to-[#F0F6FD] rounded-2xl border border-[#CEDFEB] p-4 sm:p-5 shadow-2xs space-y-3 animate-fadeIn transition-all">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-2.5">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#EBF4FD] text-[#0A66C2] font-black text-xs border border-[#0A66C2]/30 shadow-2xs">
            <span>STATUS BAR: READY FOR SUBMISSION 📝</span>
          </span>
          <span className="text-xs font-bold text-slate-800">
            Task {taskNumber} of {totalTasks} Active
          </span>
        </div>

        <span className="text-[11px] text-[#666666] font-medium">
          Sequential Gating Active
        </span>
      </div>

      <p className="text-xs text-slate-600 leading-relaxed">
        Complete and submit your required deliverables below. After submission, the status bar will change to <strong>"Review Pending"</strong> and will remain under review until verified by admin with marks assigned.
      </p>

      {/* 4-Step Track Preview */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2 pt-1 text-[11px] text-slate-500 font-medium">
        <div className="p-2 bg-white rounded-lg border border-blue-200 text-[#0A66C2] font-bold">
          1. Submit Work (In Progress)
        </div>
        <div className="p-2 bg-slate-50 rounded-lg border border-slate-200">
          2. Review Pending (Next)
        </div>
        <div className="p-2 bg-slate-50 rounded-lg border border-slate-200">
          3. Marks Assigned
        </div>
        <div className="p-2 bg-slate-50 rounded-lg border border-slate-200">
          4. Unlock Next Task
        </div>
      </div>
    </div>
  );
};
